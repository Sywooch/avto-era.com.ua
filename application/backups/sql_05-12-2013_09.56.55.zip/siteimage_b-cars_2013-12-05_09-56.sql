#
# TABLE STRUCTURE FOR: answer_notifications
#

DROP TABLE IF EXISTS answer_notifications;

CREATE TABLE `answer_notifications` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `locale` varchar(5) CHARACTER SET utf8 NOT NULL,
  `name` varchar(25) CHARACTER SET utf8 NOT NULL,
  `message` text CHARACTER SET utf8 NOT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB AUTO_INCREMENT=7 DEFAULT CHARSET=latin1;

INSERT INTO answer_notifications (`id`, `locale`, `name`, `message`) VALUES (1, 'ua', 'incoming', '<h1>Дякуємо</h1>\n<div>В короткий час наші менеджери звяжуться з Вами</div>\n<div id=\"dc_vk_code\" style=\"display: none;\">&nbsp;</div>');
INSERT INTO answer_notifications (`id`, `locale`, `name`, `message`) VALUES (2, 'ua', 'callback', '<h1>Дякуємо</h1>\n<div>В короткий час наші менеджери звяжуться з Вами</div>\n<div id=\"dc_vk_code\" style=\"display: none;\">&nbsp;</div>');
INSERT INTO answer_notifications (`id`, `locale`, `name`, `message`) VALUES (3, 'ua', 'order', '<h1>Дякуємо</h1>\n<div>В короткий час наші менеджери звяжуться з Вами</div>\n<div id=\"dc_vk_code\" style=\"display: none;\">&nbsp;</div>');
INSERT INTO answer_notifications (`id`, `locale`, `name`, `message`) VALUES (4, 'ru', 'incoming', '<h1>Спасибо</h1>\r\n<div>В ближайшее время наши менеджеры свяжутся с Вами</div>');
INSERT INTO answer_notifications (`id`, `locale`, `name`, `message`) VALUES (5, 'ru', 'callback', '<h1>Спасибо</h1>\r\n<div>В ближайшее время наши менеджеры свяжутся с Вами</div>');
INSERT INTO answer_notifications (`id`, `locale`, `name`, `message`) VALUES (6, 'ru', 'order', '<h1>Спасибо</h1>\r\n<div>В ближайшее время наши менеджеры свяжутся с Вами</div>');


#
# TABLE STRUCTURE FOR: category
#

DROP TABLE IF EXISTS category;

CREATE TABLE `category` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `parent_id` int(11) NOT NULL DEFAULT '0',
  `position` mediumint(5) NOT NULL DEFAULT '0',
  `name` varchar(160) NOT NULL,
  `title` varchar(250) DEFAULT NULL,
  `short_desc` text NOT NULL,
  `url` varchar(300) NOT NULL,
  `image` varchar(250) DEFAULT NULL,
  `keywords` text,
  `description` text,
  `fetch_pages` text NOT NULL,
  `main_tpl` varchar(50) NOT NULL,
  `tpl` varchar(50) DEFAULT NULL,
  `page_tpl` varchar(50) DEFAULT NULL,
  `per_page` smallint(5) NOT NULL,
  `order_by` varchar(25) NOT NULL,
  `sort_order` varchar(25) NOT NULL,
  `comments_default` tinyint(1) NOT NULL DEFAULT '0',
  `field_group` int(11) NOT NULL,
  `category_field_group` int(11) NOT NULL,
  `settings` varchar(10000) DEFAULT NULL,
  PRIMARY KEY (`id`),
  KEY `name` (`name`),
  KEY `url` (`url`)
) ENGINE=MyISAM AUTO_INCREMENT=72 DEFAULT CHARSET=utf8;

INSERT INTO category (`id`, `parent_id`, `position`, `name`, `title`, `short_desc`, `url`, `image`, `keywords`, `description`, `fetch_pages`, `main_tpl`, `tpl`, `page_tpl`, `per_page`, `order_by`, `sort_order`, `comments_default`, `field_group`, `category_field_group`, `settings`) VALUES (69, 0, 1, 'Новости', '', '', 'novosti', '', '', '', 'a:2:{i:0;s:2:\"69\";i:1;s:2:\"71\";}', '', '', '', 15, 'publish_date', 'desc', 0, 13, 13, 'a:2:{s:26:\"category_apply_for_subcats\";b:0;s:17:\"apply_for_subcats\";b:0;}');
INSERT INTO category (`id`, `parent_id`, `position`, `name`, `title`, `short_desc`, `url`, `image`, `keywords`, `description`, `fetch_pages`, `main_tpl`, `tpl`, `page_tpl`, `per_page`, `order_by`, `sort_order`, `comments_default`, `field_group`, `category_field_group`, `settings`) VALUES (71, 69, 3, 'Архив', '', '', 'arhiv', '', '', '', 'b:0;', '', '', '', 15, 'publish_date', 'desc', 0, -1, -1, 'a:2:{s:26:\"category_apply_for_subcats\";b:0;s:17:\"apply_for_subcats\";b:0;}');


#
# TABLE STRUCTURE FOR: category_translate
#

DROP TABLE IF EXISTS category_translate;

CREATE TABLE `category_translate` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `alias` int(11) NOT NULL,
  `name` varchar(160) NOT NULL,
  `title` varchar(250) DEFAULT NULL,
  `short_desc` text,
  `image` varchar(250) DEFAULT NULL,
  `keywords` text,
  `description` text,
  `lang` int(11) NOT NULL,
  PRIMARY KEY (`id`),
  KEY `name` (`name`,`lang`)
) ENGINE=MyISAM AUTO_INCREMENT=9 DEFAULT CHARSET=utf8;

#
# TABLE STRUCTURE FOR: comments
#

DROP TABLE IF EXISTS comments;

CREATE TABLE `comments` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `module` varchar(25) NOT NULL DEFAULT 'core',
  `user_id` int(11) NOT NULL,
  `user_name` varchar(50) NOT NULL,
  `user_mail` varchar(50) NOT NULL,
  `user_site` varchar(250) NOT NULL,
  `item_id` bigint(11) NOT NULL,
  `text` text,
  `date` int(11) NOT NULL,
  `status` smallint(1) NOT NULL,
  `agent` varchar(250) NOT NULL,
  `user_ip` varchar(64) NOT NULL,
  `rate` int(11) NOT NULL,
  `text_plus` varchar(500) DEFAULT NULL,
  `text_minus` varchar(500) DEFAULT NULL,
  `like` int(11) NOT NULL,
  `disslike` int(11) NOT NULL,
  `parent` int(11) DEFAULT NULL,
  PRIMARY KEY (`id`),
  KEY `module` (`module`),
  KEY `item_id` (`item_id`),
  KEY `date` (`date`)
) ENGINE=MyISAM AUTO_INCREMENT=96 DEFAULT CHARSET=utf8;

INSERT INTO comments (`id`, `module`, `user_id`, `user_name`, `user_mail`, `user_site`, `item_id`, `text`, `date`, `status`, `agent`, `user_ip`, `rate`, `text_plus`, `text_minus`, `like`, `disslike`, `parent`) VALUES (92, 'shop', 48, 'admin', 'ad@min.com', '', 189, 'LAN ReadyЖК ТВ: технология Motionflow 100Hz, эко-функции, экран с Edge LED, диагональ 117 см / 46, Full HD 1080, Wirel', 1385627522, 0, 'Mozilla/5.0 (Windows NT 6.1; WOW64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/31.0.1650.57 Safari/537.36', '127.0.0.1', 4, '', '', 1, 0, 0);
INSERT INTO comments (`id`, `module`, `user_id`, `user_name`, `user_mail`, `user_site`, `item_id`, `text`, `date`, `status`, `agent`, `user_ip`, `rate`, `text_plus`, `text_minus`, `like`, `disslike`, `parent`) VALUES (93, 'shop', 48, 'admin', 'ad@min.com', '', 189, 'LAN ReadyЖК ТВ: технология Motionflow 100Hz, эко-функции, экран с Edge LED, диагональ 117 см / 46, Full HD 1080, WirelLAN ReadyЖК ТВ: технология Motionflow 100Hz, эко-функции, экран с Edge LED, диагональ 117 см / 46, Full HD 1080, Wirel', 1385627547, 0, 'Mozilla/5.0 (Windows NT 6.1; WOW64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/31.0.1650.57 Safari/537.36', '127.0.0.1', 0, '', '', 0, 0, 92);
INSERT INTO comments (`id`, `module`, `user_id`, `user_name`, `user_mail`, `user_site`, `item_id`, `text`, `date`, `status`, `agent`, `user_ip`, `rate`, `text_plus`, `text_minus`, `like`, `disslike`, `parent`) VALUES (94, 'shop', 48, 'admin', 'ad@min.com', '', 189, 'LAN ReadyЖК ТВ: технология Motionflow 100Hz, эко-функции, экран с Edge LED, диагональ 117 см / 46, Full HD 1080, Wirel', 1385627554, 0, 'Mozilla/5.0 (Windows NT 6.1; WOW64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/31.0.1650.57 Safari/537.36', '127.0.0.1', 0, '', '', 0, 0, 92);


#
# TABLE STRUCTURE FOR: components
#

DROP TABLE IF EXISTS components;

CREATE TABLE `components` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `name` varchar(50) NOT NULL,
  `identif` varchar(25) NOT NULL,
  `enabled` int(1) NOT NULL,
  `autoload` int(1) NOT NULL,
  `in_menu` int(1) NOT NULL DEFAULT '0',
  `settings` text,
  `position` int(11) DEFAULT NULL,
  PRIMARY KEY (`id`),
  KEY `name` (`name`),
  KEY `identif` (`identif`),
  KEY `enabled` (`enabled`),
  KEY `autoload` (`autoload`)
) ENGINE=MyISAM AUTO_INCREMENT=346 DEFAULT CHARSET=utf8;

INSERT INTO components (`id`, `name`, `identif`, `enabled`, `autoload`, `in_menu`, `settings`, `position`) VALUES (1, 'user_manager', 'user_manager', 0, 0, 0, NULL, 11);
INSERT INTO components (`id`, `name`, `identif`, `enabled`, `autoload`, `in_menu`, `settings`, `position`) VALUES (2, 'auth', 'auth', 1, 0, 0, NULL, 20);
INSERT INTO components (`id`, `name`, `identif`, `enabled`, `autoload`, `in_menu`, `settings`, `position`) VALUES (4, 'comments', 'comments', 1, 1, 0, NULL, 9);
INSERT INTO components (`id`, `name`, `identif`, `enabled`, `autoload`, `in_menu`, `settings`, `position`) VALUES (7, 'navigation', 'navigation', 0, 0, 0, NULL, 21);
INSERT INTO components (`id`, `name`, `identif`, `enabled`, `autoload`, `in_menu`, `settings`, `position`) VALUES (30, 'tags', 'tags', 1, 1, 0, NULL, 22);
INSERT INTO components (`id`, `name`, `identif`, `enabled`, `autoload`, `in_menu`, `settings`, `position`) VALUES (92, 'gallery', 'gallery', 1, 0, 0, 'a:26:{s:13:\"max_file_size\";s:1:\"5\";s:9:\"max_width\";s:1:\"0\";s:10:\"max_height\";s:1:\"0\";s:7:\"quality\";s:2:\"95\";s:14:\"maintain_ratio\";b:1;s:19:\"maintain_ratio_prev\";b:1;s:19:\"maintain_ratio_icon\";b:1;s:4:\"crop\";b:0;s:9:\"crop_prev\";b:0;s:9:\"crop_icon\";b:0;s:14:\"prev_img_width\";s:3:\"500\";s:15:\"prev_img_height\";s:3:\"500\";s:11:\"thumb_width\";s:3:\"100\";s:12:\"thumb_height\";s:3:\"100\";s:14:\"watermark_text\";s:0:\"\";s:16:\"wm_vrt_alignment\";s:6:\"bottom\";s:16:\"wm_hor_alignment\";s:4:\"left\";s:19:\"watermark_font_size\";s:2:\"14\";s:15:\"watermark_color\";s:6:\"ffffff\";s:17:\"watermark_padding\";s:2:\"-5\";s:19:\"watermark_font_path\";s:20:\"./system/fonts/1.ttf\";s:15:\"watermark_image\";s:0:\"\";s:23:\"watermark_image_opacity\";s:2:\"50\";s:14:\"watermark_type\";s:4:\"text\";s:8:\"order_by\";s:4:\"date\";s:10:\"sort_order\";s:4:\"desc\";}', 10);
INSERT INTO components (`id`, `name`, `identif`, `enabled`, `autoload`, `in_menu`, `settings`, `position`) VALUES (55, 'rss', 'rss', 1, 0, 0, 'a:5:{s:5:\"title\";s:9:\"Image CMS\";s:11:\"description\";s:35:\"Тестируем модуль RSS\";s:10:\"categories\";a:1:{i:0;s:1:\"3\";}s:9:\"cache_ttl\";i:60;s:11:\"pages_count\";i:10;}', 14);
INSERT INTO components (`id`, `name`, `identif`, `enabled`, `autoload`, `in_menu`, `settings`, `position`) VALUES (60, 'menu', 'menu', 0, 1, 1, NULL, 3);
INSERT INTO components (`id`, `name`, `identif`, `enabled`, `autoload`, `in_menu`, `settings`, `position`) VALUES (58, 'sitemap', 'sitemap', 1, 1, 0, 'a:8:{s:18:\"main_page_priority\";b:0;s:13:\"cats_priority\";b:0;s:14:\"pages_priority\";b:0;s:20:\"main_page_changefreq\";b:0;s:21:\"categories_changefreq\";b:0;s:16:\"pages_changefreq\";b:0;s:7:\"sendXML\";N;s:8:\"lastSend\";i:1386001594;}', 15);
INSERT INTO components (`id`, `name`, `identif`, `enabled`, `autoload`, `in_menu`, `settings`, `position`) VALUES (80, 'search', 'search', 1, 0, 0, NULL, 24);
INSERT INTO components (`id`, `name`, `identif`, `enabled`, `autoload`, `in_menu`, `settings`, `position`) VALUES (84, 'feedback', 'feedback', 1, 0, 0, 'a:2:{s:5:\"email\";s:19:\"admin@localhost.loc\";s:15:\"message_max_len\";i:550;}', 12);
INSERT INTO components (`id`, `name`, `identif`, `enabled`, `autoload`, `in_menu`, `settings`, `position`) VALUES (117, 'template_editor', 'template_editor', 0, 0, 0, NULL, 16);
INSERT INTO components (`id`, `name`, `identif`, `enabled`, `autoload`, `in_menu`, `settings`, `position`) VALUES (86, 'group_mailer', 'group_mailer', 0, 0, 0, NULL, 13);
INSERT INTO components (`id`, `name`, `identif`, `enabled`, `autoload`, `in_menu`, `settings`, `position`) VALUES (95, 'filter', 'filter', 1, 0, 0, NULL, 25);
INSERT INTO components (`id`, `name`, `identif`, `enabled`, `autoload`, `in_menu`, `settings`, `position`) VALUES (96, 'cfcm', 'cfcm', 0, 0, 0, NULL, 17);
INSERT INTO components (`id`, `name`, `identif`, `enabled`, `autoload`, `in_menu`, `settings`, `position`) VALUES (121, 'shop', 'shop', 1, 0, 0, NULL, 17);
INSERT INTO components (`id`, `name`, `identif`, `enabled`, `autoload`, `in_menu`, `settings`, `position`) VALUES (137, 'mailer', 'mailer', 1, 0, 1, NULL, 2);
INSERT INTO components (`id`, `name`, `identif`, `enabled`, `autoload`, `in_menu`, `settings`, `position`) VALUES (345, 'shop_news', 'shop_news', 1, 1, 0, NULL, NULL);
INSERT INTO components (`id`, `name`, `identif`, `enabled`, `autoload`, `in_menu`, `settings`, `position`) VALUES (153, 'share', 'share', 1, 0, 0, 'a:8:{s:5:\"vkcom\";s:1:\"1\";s:8:\"facebook\";s:1:\"1\";s:7:\"twitter\";s:1:\"1\";s:2:\"gg\";s:1:\"1\";s:4:\"type\";s:4:\"none\";s:13:\"facebook_like\";s:1:\"1\";s:7:\"vk_like\";s:1:\"1\";s:8:\"vk_apiid\";s:5:\"ghfgh\";}', 8);
INSERT INTO components (`id`, `name`, `identif`, `enabled`, `autoload`, `in_menu`, `settings`, `position`) VALUES (177, 'banners', 'banners', 1, 0, 1, 'a:1:{s:8:\"show_tpl\";i:1;}', 1);
INSERT INTO components (`id`, `name`, `identif`, `enabled`, `autoload`, `in_menu`, `settings`, `position`) VALUES (205, 'mod_discount', 'mod_discount', 1, 1, 1, NULL, 0);
INSERT INTO components (`id`, `name`, `identif`, `enabled`, `autoload`, `in_menu`, `settings`, `position`) VALUES (253, 'smart_filter', 'smart_filter', 1, 1, 0, NULL, 23);
INSERT INTO components (`id`, `name`, `identif`, `enabled`, `autoload`, `in_menu`, `settings`, `position`) VALUES (185, 'exchange', 'exchange', 1, 0, 1, 'a:13:{s:3:\"zip\";s:2:\"no\";s:8:\"filesize\";s:7:\"2048000\";s:7:\"validIP\";s:9:\"127.0.0.1\";s:5:\"login\";s:10:\"ad@min.com\";s:8:\"password\";s:5:\"admin\";s:11:\"usepassword\";s:2:\"on\";s:12:\"userstatuses\";N;s:10:\"autoresize\";N;s:5:\"debug\";N;s:5:\"email\";s:0:\"\";s:5:\"brand\";s:0:\"\";s:18:\"userstatuses_after\";s:1:\"1\";s:6:\"backup\";s:1:\"1\";}', 5);
INSERT INTO components (`id`, `name`, `identif`, `enabled`, `autoload`, `in_menu`, `settings`, `position`) VALUES (344, 'wishlist', 'wishlist', 1, 1, 1, 'a:10:{s:11:\"maxUserName\";s:3:\"256\";s:11:\"maxListName\";s:3:\"254\";s:13:\"maxListsCount\";s:2:\"10\";s:13:\"maxItemsCount\";s:3:\"100\";s:16:\"maxCommentLenght\";s:3:\"500\";s:13:\"maxDescLenght\";s:4:\"1000\";s:15:\"maxWLDescLenght\";s:4:\"1000\";s:13:\"maxImageWidth\";s:3:\"150\";s:14:\"maxImageHeight\";s:3:\"150\";s:12:\"maxImageSize\";s:7:\"2000000\";}\" }', 2);
INSERT INTO components (`id`, `name`, `identif`, `enabled`, `autoload`, `in_menu`, `settings`, `position`) VALUES (188, 'cmsemail', 'cmsemail', 1, 0, 1, 'a:8:{s:4:\"from\";s:21:\"beautiful-cars.com.ua\";s:10:\"from_email\";s:30:\"noreplay@beautiful-cars.com.ua\";s:11:\"admin_email\";s:26:\"info@beautiful-cars.com.ua\";s:5:\"theme\";s:63:\"интернет магазин АВТОШИНЫ-beautiful cars\";s:6:\"wraper\";s:0:\"\";s:8:\"mailpath\";s:0:\"\";s:8:\"protocol\";s:4:\"SMTP\";s:4:\"port\";s:0:\"\";}', 7);
INSERT INTO components (`id`, `name`, `identif`, `enabled`, `autoload`, `in_menu`, `settings`, `position`) VALUES (216, 'new_level', 'new_level', 1, 1, 1, 'a:3:{s:15:\"propertiesTypes\";a:3:{i:0;s:6:\"scroll\";i:1;s:4:\"full\";i:2;s:8:\"dropDown\";}s:7:\"columns\";a:4:{i:0;s:1:\"1\";i:1;s:1:\"2\";i:2;s:1:\"3\";i:3;s:1:\"4\";}s:5:\"thema\";s:18:\"css/color_scheme_1\";}', 4);
INSERT INTO components (`id`, `name`, `identif`, `enabled`, `autoload`, `in_menu`, `settings`, `position`) VALUES (261, 'trash', 'trash', 0, 1, 0, NULL, 7);
INSERT INTO components (`id`, `name`, `identif`, `enabled`, `autoload`, `in_menu`, `settings`, `position`) VALUES (204, 'mobile', 'mobile', 1, 1, 1, NULL, 6);
INSERT INTO components (`id`, `name`, `identif`, `enabled`, `autoload`, `in_menu`, `settings`, `position`) VALUES (264, 'language_switch', 'language_switch', 0, 0, 0, NULL, 19);
INSERT INTO components (`id`, `name`, `identif`, `enabled`, `autoload`, `in_menu`, `settings`, `position`) VALUES (265, 'star_rating', 'star_rating', 1, 0, 0, NULL, 26);
INSERT INTO components (`id`, `name`, `identif`, `enabled`, `autoload`, `in_menu`, `settings`, `position`) VALUES (266, 'imagebox', 'imagebox', 0, 1, 0, NULL, 27);


#
# TABLE STRUCTURE FOR: content
#

DROP TABLE IF EXISTS content;

CREATE TABLE `content` (
  `id` bigint(11) NOT NULL AUTO_INCREMENT,
  `title` varchar(500) NOT NULL,
  `meta_title` varchar(300) DEFAULT NULL,
  `url` varchar(500) NOT NULL,
  `cat_url` varchar(260) DEFAULT NULL,
  `keywords` text,
  `description` text,
  `prev_text` text,
  `full_text` longtext NOT NULL,
  `category` int(11) NOT NULL,
  `full_tpl` varchar(50) DEFAULT NULL,
  `main_tpl` varchar(50) NOT NULL,
  `position` smallint(5) NOT NULL,
  `comments_status` smallint(1) NOT NULL,
  `comments_count` int(9) DEFAULT '0',
  `post_status` varchar(15) NOT NULL,
  `author` varchar(50) NOT NULL,
  `publish_date` int(11) NOT NULL,
  `created` int(11) NOT NULL,
  `updated` int(11) NOT NULL,
  `showed` int(11) NOT NULL,
  `lang` int(11) NOT NULL DEFAULT '0',
  `lang_alias` int(11) NOT NULL DEFAULT '0',
  PRIMARY KEY (`id`),
  KEY `url` (`url`(333)),
  KEY `lang` (`lang`),
  KEY `post_status` (`post_status`(4)),
  KEY `cat_url` (`cat_url`),
  KEY `publish_date` (`publish_date`),
  KEY `category` (`category`),
  KEY `created` (`created`),
  KEY `updated` (`updated`)
) ENGINE=MyISAM AUTO_INCREMENT=98 DEFAULT CHARSET=utf8;

INSERT INTO content (`id`, `title`, `meta_title`, `url`, `cat_url`, `keywords`, `description`, `prev_text`, `full_text`, `category`, `full_tpl`, `main_tpl`, `position`, `comments_status`, `comments_count`, `post_status`, `author`, `publish_date`, `created`, `updated`, `showed`, `lang`, `lang_alias`) VALUES (64, 'О компании', '', 'o-kompanii', '', 'магазине', 'О магазине', '<h1>Интернет-магазин автошин &laquo;Beautiful cars&raquo;</h1>\n<h2>Что предлагает наш магазин и почему выгодно купить шины именно здесь?</h2>\n<p>Купить шины в Украине, а особенно в Киеве, не составляет большой проблемы. Множество магазинов предлагают купить резину на авто от уже зарекомендовавших себя и менее известных производителей. Цены, как и уровень качества продукции, разные. Сейчас &laquo;обуть&raquo; своего железного коня можно за любые деньги. Что же покупают чаще? Анализ продаж за несколько последних лет свидетельствует о том, что большинство водителей, которые ездят на новых автомобилях, предпочитают купить шины по более высокой цене. Много автомобилистов в Украине покупают автошины по одному принципу: мы не такие богатые, чтобы покупать дешевые вещи.</p>\n<p>Во-первых, покупка фирменных шин &mdash; это не затраты, а разумные вложения, которые со временем обязательно окупятся. Качественные автошины обеспечивают лучшее сцепление с дорогой и сокращают тормозной путь. Выигранных несколько сантиметров на трассе значат очень много, и речь идет не только о стоимости поврежденного бампера дорогого автомобиля, но и о бесценной человеческой жизни.</p>\n<h2>Заголовок второго уровня</h2>\n<div class=\"title_ul\">Основные способы оплаты покупок в интернет-магазине:</div>\n<ul>\n<li>Наличный расчет &mdash; товар оплачивается курьеру наличными деньгами при получении покупателем товара;</li>\n<li>Электронные деньги &mdash; безналичный вид расчёта;</li>\n<li>Терминалы моментальной оплаты &mdash; оплата производится в уличных платёжных терминалах.</li>\n</ul>\n<h3>Заголовок третьего уровня</h3>\n<p>Электронные кассы &mdash; вид расчета, объединяющий практически все перечисленные выше способы оплаты.</p>\n<table>\n<thead>\n<tr><th>Название</th><th>Размер</th><th>Цена</th><th>Цена</th><th>Цена</th></tr>\n</thead>\n<tbody>\n<tr>\n<td>Ширина</td>\n<td>10.5 м</td>\n<td>100 грн</td>\n<td>100 грн</td>\n<td>100 грн</td>\n</tr>\n<tr>\n<td>Длина рулона</td>\n<td>2 м</td>\n<td>250 грн</td>\n<td>250 грн</td>\n<td>250 грн</td>\n</tr>\n<tr>\n<td>Отрез</td>\n<td>8 м. п.</td>\n<td>300 грн</td>\n<td>300 грн</td>\n<td>300 грн</td>\n</tr>\n<tr>\n<td>Длина рулона</td>\n<td>2 м</td>\n<td>250 грн</td>\n<td>250 грн</td>\n<td>250 грн</td>\n</tr>\n<tr>\n<td>Отрез</td>\n<td>8 м. п.</td>\n<td>300 грн</td>\n<td>300 грн</td>\n<td>300 грн</td>\n</tr>\n</tbody>\n</table>\n<p>При выборе такого способа оплаты пользователю предлагается на выбор наиболее удобный способ перевода денег от пластиковой карточки до терминала и мобильного телефона.</p>\n<div class=\"title_ul\">Основные способы оплаты покупок в интернет-магазине:</div>\n<ol>\n<li>Наличный расчет &mdash; товар оплачивается курьеру наличными деньгами при получении покупателем</li>\n<li>Электронные деньги &mdash; безналичный вид расчёта;</li>\n<li>Терминалы моментальной оплаты &mdash; оплата производится в уличных платёжных терминалах.</li>\n</ol>', '', 0, '', '', 0, 1, 0, 'publish', 'admin', 1291295776, 0, 1386001593, 406, 3, 0);
INSERT INTO content (`id`, `title`, `meta_title`, `url`, `cat_url`, `keywords`, `description`, `prev_text`, `full_text`, `category`, `full_tpl`, `main_tpl`, `position`, `comments_status`, `comments_count`, `post_status`, `author`, `publish_date`, `created`, `updated`, `showed`, `lang`, `lang_alias`) VALUES (66, 'Доставка и оплата', '', 'dostavka', '', 'доставка', 'Доставка', '<p>Страница на стадии разработки</p>', '', 0, '', '', 0, 1, 0, 'publish', 'admin', 1291295844, 1291295851, 1385979170, 177, 3, 0);
INSERT INTO content (`id`, `title`, `meta_title`, `url`, `cat_url`, `keywords`, `description`, `prev_text`, `full_text`, `category`, `full_tpl`, `main_tpl`, `position`, `comments_status`, `comments_count`, `post_status`, `author`, `publish_date`, `created`, `updated`, `showed`, `lang`, `lang_alias`) VALUES (67, 'Система скидок', '', 'sistema-skidok', '', 'помощь', 'Помощь', '<p>Страница на стадии разработки</p>', '', 0, '', '', 0, 1, 0, 'publish', 'admin', 1291295855, 1291295867, 1384940038, 92, 3, 0);
INSERT INTO content (`id`, `title`, `meta_title`, `url`, `cat_url`, `keywords`, `description`, `prev_text`, `full_text`, `category`, `full_tpl`, `main_tpl`, `position`, `comments_status`, `comments_count`, `post_status`, `author`, `publish_date`, `created`, `updated`, `showed`, `lang`, `lang_alias`) VALUES (68, 'Контакты', '', 'contact_us', '', 'контакты', 'Контакты', '<p>Страница на стадии разработки</p>', '', 0, '', '', 0, 1, 0, 'publish', 'admin', 1291295870, 1291295888, 1385979223, 97, 3, 0);
INSERT INTO content (`id`, `title`, `meta_title`, `url`, `cat_url`, `keywords`, `description`, `prev_text`, `full_text`, `category`, `full_tpl`, `main_tpl`, `position`, `comments_status`, `comments_count`, `post_status`, `author`, `publish_date`, `created`, `updated`, `showed`, `lang`, `lang_alias`) VALUES (75, 'Contact', '', 'contact_us', '', 'ssss', 'ssss', '<p><span id=\"result_box\" lang=\"en\"><span>Hot Phone</span><span>:</span> <span>0800</span> <span>80</span> <span>80 800</span><br /><br /> <span>Head office in</span> <span>Moscow</span><br /><br /> <span>street</span><span>.</span> <span>Gagarin</span> <span>half</span><br /><br /> <span>tel.</span> <span>095</span> <span>095</span> <span>00</span> <span>00</span><br /><br /> <span>The main office</span> <span>in Kiev</span><br /><br /> <span>street</span><span>.</span> <span>Gagarin</span> <span>half</span><br /><br /> <span>tel.</span> <span>098</span> <span>098</span> <span>00</span> <span>00</span></span></p>', '', 0, '', '', 0, 1, 4, 'publish', 'admin', 1291295870, 1291295888, 1343664873, 35, 30, 68);
INSERT INTO content (`id`, `title`, `meta_title`, `url`, `cat_url`, `keywords`, `description`, `prev_text`, `full_text`, `category`, `full_tpl`, `main_tpl`, `position`, `comments_status`, `comments_count`, `post_status`, `author`, `publish_date`, `created`, `updated`, `showed`, `lang`, `lang_alias`) VALUES (76, 'Delivery', '', 'dostavka', '', 'support, the, delivery, service, autoworld, around, world, also, possible, all, major, cities, ukraine, and, russia, possibility, courier, your, area, please, call, desired, you, can, pick, purchased, goods, themselves, our, offices', 'We support the delivery of service Autoworld around the world. It is also possible delivery to all major cities of Ukraine and Russia (the possibility of delivery by courier in your area please call 0800820 22 22.) If desired, you can pick up the purchase', '<p><span id=\"result_box\" lang=\"en\"><span>We support the</span> <span>delivery of</span> <span>service</span> <span>Autoworld</span> <span>around the world.</span><br /><br /> <span>It is also possible</span> <span>delivery</span> <span>to all</span> <span>major cities</span> <span>of Ukraine and Russia</span> <span>(the possibility of</span> <span>delivery</span> <span>by courier</span> <span>in your area</span> <span>please call</span> <span>0800820</span> <span>22 22</span><span>.)</span><br /><br /> <span>If desired,</span> <span>you can</span> <span>pick up the</span> <span>purchased goods</span> <span>themselves</span> <span>in our offices.</span></span></p>', '', 0, '', '', 0, 1, 4, 'publish', 'admin', 1291295844, 1291295851, 1343664842, 8, 30, 66);
INSERT INTO content (`id`, `title`, `meta_title`, `url`, `cat_url`, `keywords`, `description`, `prev_text`, `full_text`, `category`, `full_tpl`, `main_tpl`, `position`, `comments_status`, `comments_count`, `post_status`, `author`, `publish_date`, `created`, `updated`, `showed`, `lang`, `lang_alias`) VALUES (77, 'Help', '', 'sistema-skidok', '', 'order, purchase, goods, our, store, you, must, follow, few, simple, steps, choose, the, right, product, vospolzovavshit, navigation, left, search, add, products, cart, shopping, select, shipping, method, and, provide, your, contact', 'In order to purchase goods in our store, you must follow a few simple steps: Choose the right product, vospolzovavshit navigation on the left, or search. Add products to cart. Go to the shopping cart, select shipping method and provide your contact inform', '<p><span id=\"result_box\" lang=\"en\"><span>In order to</span> <span>purchase goods</span> <span>in our store,</span> <span>you must follow</span> <span>a few simple steps</span><span>:</span><br /><br />&nbsp;&nbsp;&nbsp;&nbsp; <span>Choose</span> <span>the right product,</span> <span>vospolzovavshit</span> <span>navigation</span> <span>on the left</span><span>, or</span> <span>search.</span><br />&nbsp;&nbsp;&nbsp;&nbsp; <span>Add products</span> <span>to cart</span><span>.</span><br />&nbsp;&nbsp;&nbsp;&nbsp; <span>Go to the</span> <span>shopping cart,</span> <span>select</span> <span>shipping method</span> <span>and provide</span> <span>your contact information.</span><br />&nbsp;&nbsp;&nbsp;&nbsp; <span>Proceed to checkout</span> <span>and select the</span> <span>payment method.</span><br /><br /> <span>After that,</span> <span>our managers</span> <span>will contact</span> <span>you and</span> <span>help you</span> <span>with payment</span> <span>and delivery</span> <span>of the goods</span><span>, as well</span> <span>as give advice on</span> <span>any subject.</span></span></p>', '', 0, '', '', 0, 1, 0, 'publish', 'admin', 1291295855, 1291295867, 1343664897, 11, 30, 67);
INSERT INTO content (`id`, `title`, `meta_title`, `url`, `cat_url`, `keywords`, `description`, `prev_text`, `full_text`, `category`, `full_tpl`, `main_tpl`, `position`, `comments_status`, `comments_count`, `post_status`, `author`, `publish_date`, `created`, `updated`, `showed`, `lang`, `lang_alias`) VALUES (79, 'About us', '', 'o-kompanii', '', 'shop, imagecms, offers, huge, selection, vehicles, suit, every, taste, the, best, prices, our, store, has, more, than, years, and, during, that, time, was, not, single, return, goods, serve, hundreds, customers', 'Shop ImageCMS Shop offers a huge selection of vehicles to suit every taste at the best prices. Our store has more than 5 years and during that time was not a single return of the goods. We serve hundreds of customers every day and do it with joy. Buy equi', '<p><span id=\"result_box\" lang=\"en\"><span>Shop</span> <span>ImageCMS Shop</span> <span>offers</span> <span>a huge selection</span> <span>of vehicles</span> <span>to suit every taste</span> <span>at the best prices</span><span>.</span><br /><br /> <span>Our store</span> <span>has more than</span> <span>5 years</span> <span>and during that time</span> <span>was not a single</span> <span>return of the goods</span><span>.</span><br /><br /> <span>We serve</span> <span>hundreds of</span> <span>customers</span> <span>every day</span> <span>and do</span> <span>it with joy.</span><br /><br /> <span>Buy</span> <span>equipment from</span> <span>us and</span> <span>become the owner of</span> <span>the world\'s best</span> <span>technology</span><span>!</span></span></p>', '', 0, '', '', 0, 1, 1, 'publish', 'admin', 1291295776, 1291295792, 1343745649, 5, 30, 64);
INSERT INTO content (`id`, `title`, `meta_title`, `url`, `cat_url`, `keywords`, `description`, `prev_text`, `full_text`, `category`, `full_tpl`, `main_tpl`, `position`, `comments_status`, `comments_count`, `post_status`, `author`, `publish_date`, `created`, `updated`, `showed`, `lang`, `lang_alias`) VALUES (97, 'Гарантия и возврат', '', 'garantiia-i-vozvrat', '', 'страница, стадии, разработки', 'Страница на стадии разработки', '<p>Страница на стадии разработки</p>', '', 0, '', '', 0, 1, 0, 'publish', 'admin', 1384940160, 1384940160, 1384940190, 15, 3, 0);
INSERT INTO content (`id`, `title`, `meta_title`, `url`, `cat_url`, `keywords`, `description`, `prev_text`, `full_text`, `category`, `full_tpl`, `main_tpl`, `position`, `comments_status`, `comments_count`, `post_status`, `author`, `publish_date`, `created`, `updated`, `showed`, `lang`, `lang_alias`) VALUES (91, 'Подбор автошин самостоятельно, автоматический сервис', '', 'kak-raskrutit-sait-metody-poiskovogo-prodvizheniia', 'novosti/', 'наличие, корпоративного, сайта, стало, стандартом, факто, знаком, хорошего, тона, любой, компании, только, известных, игроков, рынка, независимо, области, вашей, деятельности, собственный, ресурс, любом, случае, принесет, пользу, особенно, знаете, раскрутить, сайт, самостоятельно', 'Наличие корпоративного сайта уже стало стандартом де-факто и знаком   хорошего тона любой компании, а не только известных игроков рынка.   Независимо от области вашей деятельности, собственный ресурс в любом   случае принесет вам пользу, особенно если вы', '<p>Наши специалисты помогут вам подобрать шины для вашего любимого автомобиля любой марки, а также производства.</p>', '<p>Наличие корпоративного сайта уже стало стандартом де-факто и знаком хорошего тона любой компании, а не только известных игроков рынка. Независимо от области вашей деятельности, собственный ресурс в любом случае принесет вам пользу, особенно если вы знаете как раскрутить сайт самостоятельно. Его можно использовать не только для повышения узнаваемости бренда, но и в качестве эффективного инструмента продаж.</p>\n<p>После разработки и создания, каждый владелец Интернет-ресурса непременно задумается как раскрутить сайт, ведь это - очень важный момент. И тогда стоит разобраться в актуальных методах продвижения с целью выбора оптимального.</p>\n<p>Все методы можно разделить на две основные группы: белые и черные (или спамные) - не важно, интересует ли вас как раскрутить сайт бесплатно или же с помощью студии. Если применение &laquo;белых&raquo; методов не влечет за собой возможные санкции со стороны поисковых систем, то применение запрещенных &laquo;черных&raquo; методов хотя и обещает быстрый результат и высокую эффективность в краткосрочном периоде, в долгосрочном периоде может обернутся жесткими санкциями со стороны поисковых систем.</p>\n<p>Но, скорее всего, большинство интересуется именно вопросом как раскрутить сайт бесплатно или с минимальными финансовыми вложениями. А значит, стоит обратить внимание на такие методы бесплатного продвижения как добавление в специализированные каталоги, рассылку пресс-релизов, e-mail маркетинг, обмен ссылками с другими сайтами схожей тематики. В таком случае вопрос сколько стоит раскрутить сайт отпадает, так как все делается своими силами. Но прежде нужно хорошо подумать, не лучше ли обратиться к профессионалам своего дела? Ведь <a href=\"http://www.imagecms.net/blog/obzory/biznes-v-internete-kak-perspektivnyi-trend\" target=\"_blank\">бизнес в Интернете</a> требует затрат времени и они могут оказаться колоссальными, и в случае с профессиональными подрядчиками по крайней мере можно быть уверенным в результате.</p>\n<p>Кроме того, стоит обратить внимание на специализированные движки для сайтов, которые &ldquo;с коробки&rdquo; обладают хорошими возможностями в плане SEO-оптимизации. Одной из таких систем является <a href=\"http://www.imagecms.net/download\">ImageCMS</a> - благодаря тому, что движок изначально является SEO-friendly, не нужно устанавливать дополнительные модули и компоненты, а значит можно сэкономить массу времени и нервов.</p>\n<p><a href=\"http://www.imagecms.net/download\"><img src=\"http://www.imagecms.net/uploads/images/blog/2.png\" alt=\"Система для создания интернет-магазинов - ImageCMS\" width=\"705\" height=\"183\" /></a></p>\n<p>Если анализировать сколько стоит раскрутить сайт, то стоит отталкиваться от того факта, что это - комплексный процесс, и предусматривает он работу сразу в нескольких направлениях, а значит лучше, если работу будут вести несколько человек. Поэтому самостоятельно справиться будет нелегко.</p>\n<p>Если вы задумались как раскрутить сайт бесплатно в сжатые сроки, то лучше сразу отбросьте эту идею и обратите внимание на платные методы - с их помощью можно сделать это гораздо быстрее, да и эффективность в этом случае на порядок выше. Здесь важен вопрос сколько стоит раскрутить сайт и вопрос больше по бюджету. Продвижение в таком случае ведется с использованием покупных ссылок на тематических сайтах, специализированных бирж, заказа текстов у копирайтеров, организации кампаний в сетях контекстной рекламы, а также использования потенциала социальных медиа. Кроме того, <a href=\"http://www.imagecms.net/blog/obzory/osnovy-iuzabiliti-saita\" target=\"_blank\">юзабилити сайта</a> также играет важную роль.</p>\n<p>Выбирать между возможностью раскрутить сайт самостоятельно и заказать продвижение у специализированного агентства &ndash; нелегко. Во многом из-за необходимости хорошо проанализировать, что для вас важнее &ndash; экономия средств или экономия времени. Да порой, если задумываешься как раскрутить сайт самостоятельно, стоит обратить внимание в сторону услуг подрядчиков, ведь с помощью профессионалов гораздо лучше сделать все быстро и сэкономленный временной ресурс направить на получение прибыли в области, в которой вы действительно хорошо разбираетесь.</p>', 69, '', '', 0, 1, 0, 'publish', 'admin', 1362225580, 1362225580, 1385042067, 2, 3, 0);
INSERT INTO content (`id`, `title`, `meta_title`, `url`, `cat_url`, `keywords`, `description`, `prev_text`, `full_text`, `category`, `full_tpl`, `main_tpl`, `position`, `comments_status`, `comments_count`, `post_status`, `author`, `publish_date`, `created`, `updated`, `showed`, `lang`, `lang_alias`) VALUES (92, 'Минимальные цены, оперативная бесплатная доставка по Украине', '', 'kak-dobavit-sait-v-iandeks-i-gugl-sovety-nachinaiushchim-vebmasteram', 'novosti/', 'создание, сайта, само, себе, является, нелегким, довольно, продолжительным, процессом, позади, неприятно, обнаружить, ваш, красивый, наполненный, полезными, материалами, сайт, никто, кроме, самих, заходит, пожалуй, владельцы, сайтов, которые, запустили, свой, первый, проект', 'Создание сайта само по себе является нелегким и довольно продолжительным   процессом, и когда все уже позади, довольно неприятно обнаружить, что   на ваш красивый и наполненный полезными материалами сайт никто кроме  вас  самих не заходит. Пожалуй, владел', '<p>Качественный сервис, гарантия возврата, широкий ассортимент на любой бюджет - это только часть наших преимуществ.</p>', '<p>Создание сайта само по себе является нелегким и довольно продолжительным процессом, и когда все уже позади, довольно неприятно обнаружить, что на ваш красивый и наполненный полезными материалами сайт никто кроме вас самих не заходит. Пожалуй, владельцы сайтов, которые запустили свой первый проект, чаще всего испытывают неприятное удивление в связи с этим фактом. А на самом деле все просто &ndash; прежде всего, нужно знать как добавить сайт в поисковики.</p>\n<p>Посетители переходят на сайты из результатов поиска, выдаваемых им Google при вводе определенного запроса. Но, чтобы появится в выдаче по этому запросу, нужно сначала, чтобы поисковый робот проиндексировал ваш сайт, то есть, внес его в свою поисковую базу. Поэтому, если вы имеете понятие про <a href=\"http://www.imagecms.net/blog/obzory/biznes-v-internete-kak-perspektivnyi-trend\" target=\"_blank\">бизнес в Интернете</a>, и уже запустили собственный ресурс, вопрос как добавить сайт в поисковики будет актуальным для каждого вебмастера.</p>\n<p><a href=\"http://www.imagecms.net/download\"><img src=\"http://www.imagecms.net/uploads/images/blog/2.png\" alt=\"Мощная система для создания сайтов любых типов\" width=\"705\" height=\"183\" /></a></p>\n<p>Часто бывает, что ресурс может проиндексироваться сразу же после регистрации доменного имени, но лучше всего самостоятельно добавить сайт в поисковые системы. Тем более, учитывая тот факт, что это займет совсем немного времени.</p>\n<p>&nbsp;</p>\n<h3>Добавить сайт в Яндекс</h3>\n<p>&nbsp;</p>\n<p>Для того, чтобы сообщить этому поисковику о новом сайте, нужно перейти на страницу со специальной формой, которая находится по следующему адресу: <a href=\"http://webmaster.yandex.ua/addurl.xml\" target=\"_blank\">http://webmaster.yandex.ua/addurl.xml</a></p>\n<p>С помощью панельки можно просто и быстро добавить сайт в Яндекс с минимальными затратами времени и сил. Перейдя по ссылке, вы увидите следующую форму: <br /><img src=\"http://www.imagecms.net/uploads/images/blog/add_yandex.jpg\" alt=\"Форма добавления сайта в индекс ПС Яндекс\" width=\"695\" height=\"266\" /> <br />В поле URL ведите адрес сайта, ниже введите цифры с картинки каптчи (защита от спама), после чего нажмите кнопку &laquo;Добавить&raquo;. Поздравляем! Только что вы смогли добавить сайт в Яндекс и уже в ближайшее время на него заглянет поисковый паук, чтобы внести в свою базу. После этого он появится в результатах поиска, и вы получите первых посетителей.</p>\n<p>&nbsp;</p>\n<h3>Добавить сайт в Гугл</h3>\n<p>&nbsp;</p>\n<p>Эта поисковая система является мировым лидером в области web-поиска, и сообщить ей о своем сайте нужно обязательно. Добавить сайт в Гугл еще проще, чем в предыдущем случае, ведь не нужно даже вводить каптчу. Перейдите <a href=\"https://www.google.com/webmasters/tools/submit-url?hl=ru\" target=\"_blank\">по этой ссылке</a> и перед вами откроется окно, с помощью которого можно добавить сайт в Google: <br /><img src=\"http://www.imagecms.net/uploads/images/blog/add_google.jpg\" alt=\"Добавление url в индекс ПС Google\" width=\"695\" height=\"311\" /><br /> Введите адрес и по желанию можно добавить примечание. Хотя вряд ли в этом есть смысл, так как это ни на что не влияет. Кстати, не нужно вводить никаких отдельных страниц, чтобы добавить сайт в Гугл достаточно вставить в поле формы URL главной страницы.</p>\n<p>Как видите, добавить сайт в поисковые системы совсем не сложно. Тем более, если учитывать, что хорошая индексация ведет к росту посещаемости, а значит и повышает <a href=\"http://www.imagecms.net/blog/obzory/otsenka-stoimosti-saita-i-faktory-kotorye-vliiaiut-na-tsenu\" target=\"_blank\">стоимость сайта</a> в целом. Это займет у вас минимум времени, но благодаря проделанным операциям вы сможете быть уверены в том, что поисковые системы узнают о сайте и добавят его в базу, а значит, на сайт начнут заходить посетители. Теперь вы знаете как добавить сайт в Google и можете без проблем сделать это самостоятельно.</p>', 69, '', '', 0, 1, 0, 'publish', 'admin', 1362225699, 1362225699, 1385042102, 2, 3, 0);
INSERT INTO content (`id`, `title`, `meta_title`, `url`, `cat_url`, `keywords`, `description`, `prev_text`, `full_text`, `category`, `full_tpl`, `main_tpl`, `position`, `comments_status`, `comments_count`, `post_status`, `author`, `publish_date`, `created`, `updated`, `showed`, `lang`, `lang_alias`) VALUES (93, 'Срок эксплуатации дорогих шин намного больше, чем дешевых', '', '8r-biznes-v-seti', 'novosti/', 'редкий, предприниматель, наше, время, задается, вопросом, «как, помощью, интернета, увеличить, продажи, подробный, обстоятельный, ответ, каждый, сможет, получить, традиционной, ежегодной, конференции, бизнес, сети, которая, третий, состоится, одессе, ожидается, около, участников, этом', 'Редкий предприниматель в наше время не задается вопросом: «Как с помощью  интернета увеличить продажи?» Подробный и обстоятельный ответ каждый  сможет получить на традиционной ежегодной конференции “8Р: Бизнес в  сети”, которая в третий раз состоится в Од', '<p>Если водитель рассчитывает на то, что резина прослужит ему сезона три, то он старается купить именно шины у нас.</p>', '<p>&nbsp;</p>\n<p><img src=\"http://www.imagecms.net/uploads/images/8p_logo.jpg\" alt=\"\" width=\"300\" height=\"70\" />Редкий предприниматель в наше время не задается вопросом: &laquo;Как с помощью интернета увеличить продажи?&raquo; Подробный и обстоятельный ответ каждый сможет получить на традиционной ежегодной конференции &ldquo;8Р: Бизнес в сети&rdquo;, которая в третий раз состоится &nbsp;в Одессе 13.07.2013г. Ожидается около 700 участников.</p>\n<p dir=\"ltr\">В этом году оргкомитет выбрал наиболее актуальные темы, пригласил более 40 докладчиков и решил немного отойти от теоретики, сделав упор на примеры из практики. Большое количество кейсов &ndash; отличительная черта &ldquo;8P&rdquo; 2013.</p>\n<p dir=\"ltr\">В программе конференции предусмотрены 4 потока:</p>\n<p>&nbsp;</p>\n<ul>\n<li dir=\"ltr\">Интернет-маркетинг &nbsp;&ndash; инструменты онлайн продвижения бизнеса</li>\n<li dir=\"ltr\">E-commerce &ndash; привлечение новых клиентов, увеличение конверсии, формирование лояльности</li>\n<li dir=\"ltr\">Кейсы &ndash; примеры успешного продвижения в сети</li>\n<li dir=\"ltr\">Мастер-классы &ndash; полтора часа непрерывного общения&nbsp;</li>\n</ul>\n<p>&nbsp;</p>\n<p>Оформить регистрацию на конференцию &ldquo;8Р: Бизнес в сети&rdquo; 2013 можно <a href=\"http://8p.ua/?utm_source=p20954&amp;utm_medium=press_release&amp;utm_campaign=8p\">здесь</a>.</p>\n<p dir=\"ltr\">Там же вы можете посмотреть фото и видео с прошлогодней конференции, прочитать отзывы участников.</p>\n<p dir=\"ltr\">Стартовая цена билета &ndash; 950 грн. Внимание: с каждым проданным билетом она возрастает на 1 грн.<br />Адрес конференции: г.Одесса, банкетный дом Ренессанс. От железнодорожного вокзала будет курсировать комфортабельный автобус. Добираться можно и на своем автомобиле - бесплатная парковка к вашим услугам.</p>\n<p>В программе также кофе-брейки, обед, афтер-пати.<br />Испытание на стойкость - афтер-афтер-пати.<br /> <br />Организатор конференции: <a href=\"http://netpeak.ua\">Netpeak</a> - агентство интернет-маркетинга</p>', 69, '', '', 0, 1, 0, 'publish', 'admin', 1362225792, 1362225792, 1385042134, 5, 3, 0);
INSERT INTO content (`id`, `title`, `meta_title`, `url`, `cat_url`, `keywords`, `description`, `prev_text`, `full_text`, `category`, `full_tpl`, `main_tpl`, `position`, `comments_status`, `comments_count`, `post_status`, `author`, `publish_date`, `created`, `updated`, `showed`, `lang`, `lang_alias`) VALUES (94, 'Lviv Social Media Camp 2013', '', 'lviv-social-media-camp-2013', 'novosti/arhiv/', 'lviv, social, media, camp, третья, ежегодная, конференция, вопросам, продвижения, малого, бизнеса, социальных, сетях, состоится, февраля, успешные, форумы, года, собравшие, почти, участников, доказали, покорения, изменчивого, мира, медиа, необходимы, незаурядные, знания, опыт', 'Lviv Social Media Camp 2013 - третья ежегодная конференция по вопросам  продвижения малого бизнеса в социальных сетях - состоится 23 февраля.  Успешные форумы 2011 и 2012 года, собравшие почти 700 участников,  доказали - для покорения изменчивого мира соц', '<p>Lviv Social Media Camp 2013 - третья ежегодная конференция по вопросам \nпродвижения малого бизнеса в социальных сетях - состоится 23 февраля. \nУспешные форумы 2011 и 2012 года, собравшие почти 700 участников, \nдоказали - для покорения &nbsp;изменчивого мира социальных медиа необходимы \nнезаурядные знания и опыт, которыми могут поделиться только настоящие \nпрофессионалы. Как следствие - десятки новых ярких звезд, вспыхнувших в \nукраинском бизнес-пространстве. Такие результаты не могли не вдохновить \nорганизаторов на продолжение работы в этом перспективном направлении.</p>', '<p><img src=\"http://www.imagecms.net/uploads/images/smcamp2013.png\" height=\"237\" width=\"850\"><br><a href=\"http://smcamp.com.ua\">Lviv Social Media Camp 2013</a>\n - третья ежегодная конференция по вопросам продвижения малого бизнеса в\n социальных сетях - состоится 23 февраля. Успешные форумы 2011 и 2012 \nгода, собравшие почти 700 участников, доказали - для покорения \n&nbsp;изменчивого мира социальных медиа необходимы незаурядные знания и опыт,\n которыми могут поделиться только настоящие профессионалы. Как следствие\n - десятки новых ярких звезд, вспыхнувших в украинском \nбизнес-пространстве. Такие результаты не могли не вдохновить \nорганизаторов на продолжение работы в этом перспективном направлении.<br> <br>Красноречивые факты:</p><br><ul><li dir=\"ltr\">22 млн. гривен - общий объем видеорекламы в Уанете.</li><li dir=\"ltr\">680 млн. гривен - объем украинского рынка интернет-рекламы</li><li dir=\"ltr\">180 млн. гривен - объем прошлогоднего рынка Digital-услуг</li><li dir=\"ltr\">Около 20% - &nbsp;прогнозируемый рост Digital на 2013 год</li></ul><br><p><br>Нынешняя программа конференции разработана специально для \nпредпринимателей и представителей малого бизнеса, которым интересны \n&nbsp;новые возможности для продвижения своего продукта. К тому же, \nконференция станет точкой сбора для украинских профессионалов SMM.<br> <br>По традиции, в программе конференции будет три потока:<br> <br>Social Media Marketing:</p><br><ul><li dir=\"ltr\">Украинский SMM в 2013 году - успехи и провалы</li><li dir=\"ltr\">Нужен ли SMM украинскому бизнесу?</li><li dir=\"ltr\">Методы манипулирования выдачей Facebook</li><li dir=\"ltr\">Как продвигать \"звезд\" в YouTube</li><li dir=\"ltr\">Вирусные промокампании</li><li dir=\"ltr\">Использование возможностей Pinterest и Instagram</li><li dir=\"ltr\">Social Media Optimization: о секретных алгоритмах Facebook</li><li dir=\"ltr\">Опыт работы лучших украинских Digital-агентств</li></ul><br><p><br>Social Media и бизнес:</p><br><ul><li dir=\"ltr\">Нуждается ли мой бизнес в использовании &nbsp;соц. сетей - как узнать?</li><li dir=\"ltr\">Успешные локальные маркетинговые кампании - рассмотрим примеры</li><li dir=\"ltr\">Facebook в Украине, Киеве, во Львове - определяем пользу</li><li dir=\"ltr\">Facebook-страница - как правильно оформить?</li><li dir=\"ltr\">Максимум результата за минимум времени - как добиться?</li><li dir=\"ltr\">Агентства – стоит ли доверяться?</li></ul><br><p><br>Новые медиа, разработка, стартапы:</p><br><ul><li dir=\"ltr\">Собственные сервисы и social media - вопросы интеграции</li><li dir=\"ltr\">Mixed media</li><li dir=\"ltr\">Twitter, Facebook, Foursquare API</li><li dir=\"ltr\">BlogCamp</li><li dir=\"ltr\">SmartTV</li><li dir=\"ltr\">Линчи social media стартапов </li></ul><br><p><br>Стоимость билета:<br>200 грн. - Первые 50 билетов для ранних пташек<br>300 грн. - Следующие 200 билетов<br>500 грн. - Предпоследние 50 билетов<br>800 грн. - Кто поздно приходит, тому последние 20 билетов<br> <br>Встречаемся&nbsp;23 февраля в конференц-зале УКУ (ул.. Хуторовка, 35а).</p>', 71, '', '', 0, 1, 0, 'publish', 'admin', 1362225886, 1362225886, 0, 1, 3, 0);
INSERT INTO content (`id`, `title`, `meta_title`, `url`, `cat_url`, `keywords`, `description`, `prev_text`, `full_text`, `category`, `full_tpl`, `main_tpl`, `position`, `comments_status`, `comments_count`, `post_status`, `author`, `publish_date`, `created`, `updated`, `showed`, `lang`, `lang_alias`) VALUES (95, 'Оценка стоимости сайта и факторы, которые влияют на цену', '', 'otsenka-stoimosti-saita-i-faktory-kotorye-vliiaiut-na-tsenu', 'novosti/arhiv/', 'как, время, разработки, продажи, интернет, ресурса, учитывается, достаточно, много, факторов, влияющих, цену, поэтому, нужно, уметь, оценить, стоимость, сайта, своими, силами, важно, планируете, создание, коммерческого, собираетесь, запустить, личный, блог, знать, финансовые', 'Как во время разработки, так и во время продажи Интернет-ресурса   учитывается достаточно много факторов, влияющих на его цену. Поэтому   нужно уметь оценить стоимость сайта своими силами. Не важно, планируете   ли вы создание коммерческого сайта или соби', '<p>Как во время разработки, так и во время продажи Интернет-ресурса  \nучитывается достаточно много факторов, влияющих на его цену. Поэтому  \nнужно уметь оценить стоимость сайта своими силами. Не важно, планируете \n ли вы создание коммерческого сайта или собираетесь запустить личный  \nблог, знать финансовые стороны вопроса никогда не будет лишним.</p>', '<br><p><img src=\"http://www.imagecms.net/uploads/images/blog/site-price.jpg\" alt=\"Быстрая оценка любого сайта\" height=\"172\" width=\"250\">Как\n во время разработки, так и во время продажи Интернет-ресурса \nучитывается достаточно много факторов, влияющих на его цену. Поэтому \nнужно уметь оценить стоимость сайта своими силами. Не важно, планируете \nли вы создание коммерческого сайта или собираетесь запустить личный \nблог, знать финансовые стороны вопроса никогда не будет лишним. <a title=\"стоимость создания сайта\" href=\"http://www.imagecms.net/blog/obzory/skolko-stoit-sait-postroit\" target=\"_blank\">Стоимость создания сайта</a>\n для многих является ключевым фактором, влияющим на принятие решения о \nразработка. Многое зависит от необходимых вам возможностей, ведь для \nпростого блога вполне хватит бесплатной версии ImageCMS, а вот уже для \nторговой площадки понадобится коммерческий модуль Интернет-магазина.</p>\n<p>Оценка стоимости сайта при его разработке зависит от нескольких факторов. Пройдемся по пунктам:</p><br><ul><li>Дизайн. Если он уникальный – стоимость будет выше, но в этом случае \nучитываются все ваши пожелания и специфика вашего бизнеса. \nИндивидуальный подход позволяет сделать внешний вид сайта именно таким, \nкаким вы бы хотели его видеть, и поднять <a title=\"юзабилити сайт\" href=\"http://www.imagecms.net/blog/obzory/osnovy-iuzabiliti-saita\" target=\"_blank\">юзабилити сайта</a>\n на действительно высокий уровень. Шаблонный сайт обойдется дешевле, что\n позволит оценить стоимость сайта ниже, но и качество не будет на \nвысоком уровне. Кроме того, такой же шаблон может использоваться и на \nдесятках других сайтов.</li><li>Функциональность. Думаю, не нужно быть профессионалом в \nweb-разработке, чтобы понять, что различие в цене разработки \nсайта-визитки для местного фотографа и туристического портала, будет \nсущественным. Оценка стоимости сайта в таком случае определяется \nсложностью добавляемых модулей.</li><li>Контент. Пожалуй, о важности качественного контента на данный момент\n можно и не напоминать, это аксиома известная всем, как заказчикам,  так\n и исполнителям. Конечно, качественный копирайтинг не может стоить \nдешево, и чем больше таких страниц нужно создать, тем дороже это \nобойдется. Точные знания относительно необходимого количества контента, \nпозволяет узнать стоимость сайта более подробно. Но стоит помнить, что \nвложения в качество обязательно окупятся в долгосрочной перспективе.</li><li>Оптимизация под поисковые системы (SEO). Если вам не нужны \nпосетители, а сайт сделан просто для галочки и надписи на визитке – \nможете смело пропускать этот пункт. Вот только зачем тогда его вообще \nсоздавать? Оптимизация сайта является важным пунктом договора, который \nзаранее оговаривается при разработке. Чтобы узнать стоимость сайта, \nнеобязательно сразу же просчитывать этот пункт, это скорее затраты \nбудущего периода. Особенно хорошо нужно проработать такой момент как <a title=\"подбор ключевых слов для сайта\" href=\"http://www.imagecms.net/blog/obzory/podbor-kliuchevyh-slov-kak-sdelat-vse-pravilno\" target=\"_blank\">подбор ключевых слов</a> для сайта, то есть, составление семантического ядра.</li><li>Тематика сайта. Коммерческая ниша в любом случае будет цениться гораздо выше, чем развлекательная.</li><li>Количество страниц в индексе. Чем их больше, тем выше можно \nвыставить цену при продаже. Хороший багаж в плане контента будет полезен\n для любого проекта, как залог лояльности со стороны поисковых систем. \nГлавное – чтобы все материалы сайта были уникальными, а не обычным \nкопипастом.</li><li>Показатели тИЦ и PR. Пожалуй, оценить стоимость сайта на основе \nэтого показателя проще всего. Тут действует простое правило – чем \nбольше, тем лучше.</li><li>Посещаемость сайта. Оценка стоимости сайта с высокой посещаемостью \nвсегда была высокой. В последнее время, в связи с ужесточением поисковых\n алгоритмов и увеличением конкуренции, сайты с более-менее пристойным \nколичеством посетителей стали цениться еще выше.</li><li>Присутствие в каталогах DMOZ, Mail.ru и Яндекс.Каталог. Хотя данный \nфактор уже не имеет такого веса как во времена расцвета ссылочных бирж, \nно он все еще играет весомую роль, если вас интересует оценка стоимости \nсайта, так как является своеобразным знаком качества от поисковиков.</li></ul><br><p><a href=\"http://www.imagecms.net/download\"><img src=\"http://www.imagecms.net/uploads/images/blog/2.png\" alt=\"Загрузить ImageCMS Corporate бесплатно\" height=\"183\" width=\"705\"></a></p>\n<p>Перечисленные выше факторы позволяют точно оценить стоимость сайта \nеще на этапе проектирования, и в случае надобности – внести необходимые \nкорректировки. В случае, если ресурс принадлежит вам лично, а не \nкомпании, узнать стоимость сайта также очень важно, ведь он является \nвыгодным активом, который можно в любой момент продать. Это может быть \nкак блог, так и узкотематический проект, который хорошо закрепился в \nсвоей нише и представляет ценность для пользователей.</p>\n<p>В таком случае узнать стоимость сайта можно с помощью оценки немного \nдругих показателей, чем в первом случае. При продаже на стоимость \nповлияют такие показатели:</p>\n<p>В этой статье мы перечислили все основные факторы, с учетом которых \nможно оценить стоимость сайта и применить данные методики по отношению \nкак корпоративному, так и личному проекту.</p>', 71, '', '', 0, 1, 0, 'publish', 'admin', 1362225958, 1362225958, 0, 1, 3, 0);
INSERT INTO content (`id`, `title`, `meta_title`, `url`, `cat_url`, `keywords`, `description`, `prev_text`, `full_text`, `category`, `full_tpl`, `main_tpl`, `position`, `comments_status`, `comments_count`, `post_status`, `author`, `publish_date`, `created`, `updated`, `showed`, `lang`, `lang_alias`) VALUES (96, 'Зачем вашему оффлайн-бизнесу нужен Интернет-магазин?', '', 'zachem-vashemu-offlain-biznesu-nuzhen-internet-magazin', 'novosti/arhiv/', 'несмотря, бурный, рост, интернет, коммерции, далеко, предприниматели, понимают, преимущества, магазина, особенно, оффлайная, торговая, точка, именно, таком, случае, проявляются, лучше, всего, ведь, получаете, только, отличный, источник, дополнительного, дохода, возможность, сравнения, эффективности', 'Несмотря на бурный рост Интернет-коммерции, далеко не все  предприниматели понимают, в чем преимущества Интернет-магазина, особенно  если уже есть оффлайная торговая точка. Но именно в таком случае  преимущества Интернет-магазина проявляются лучше всего,', '<p>Несмотря на бурный рост Интернет-коммерции, далеко не все \nпредприниматели понимают, в чем преимущества Интернет-магазина, особенно\n если уже есть оффлайная торговая точка. Но именно в таком случае \nпреимущества Интернет-магазина проявляются лучше всего, ведь вы \nполучаете не только отличный источник дополнительного дохода, но и \nвозможность сравнения эффективности вложения средств.</p>', '<br><p><img src=\"http://www.imagecms.net/uploads/images/blog/inet-magaz.jpg\" alt=\"Интернет как перспективная бизнес-среда\" height=\"200\" width=\"213\">Несмотря\n на бурный рост Интернет-коммерции, далеко не все предприниматели \nпонимают, в чем преимущества Интернет-магазина, особенно если уже есть \nоффлайная торговая точка. Но именно в таком случае преимущества \nИнтернет-магазина проявляются лучше всего, ведь вы получаете не только \nотличный источник дополнительного дохода, но и возможность сравнения \nэффективности вложения средств.</p>\n<p>Так зачем нужен Интернет-магазин современному предпринимателю? В \nзависимости от того, есть ли у вас уже действующий оффлайн-бизнес, он \nможет быть как дополнением к нему, или же основным источником дохода. \nУже отталкиваясь от этого, нужно планировать бюджет создания магазина и \nего развития. Над онлайновой торговой площадкой нужно вести постоянную \nработу, подробно проработать <a href=\"http://www.imagecms.net/blog/obzory/biznes-plan-internet-magazina-na-chto-obratit-vnimanie\" target=\"_blank\">бизнес-план Интернет-магазина</a>\n - это не просто визитка, созданная «для галочки»... это полноценный и \nочень эффективный инструмент продаж. Плюсов у онлайн-бизнеса, по \nсравнению с оффлайном, довольно много.</p>\n<p><a href=\"http://www.imagecms.net/download\"><img src=\"http://www.imagecms.net/uploads/images/blog/2.png\" alt=\"Система для создания интернет-магазинов - ImageCMS\" height=\"183\" width=\"705\"></a></p>\n<p>Перечислим основные преимущества Интернет-магазина:</p><br><ul><li>можно обойтись без аренды производственных площадей и складов -  достаточно небольшого офиса для обслуживания;</li><li>может быть как основным источником прибыли, так и дополнительным по \nотношению к основному бизнесу - это важное обоснование при вопросе зачем\n нужен Интернет-магазин;</li><li>гораздо меньший порог вхождения, хотя конкуренция в разных тематиках отличается;</li><li>нет региональных ограничений: можно находить клиентов как в своем городе или области, так и по всей стране;</li><li>доступность в режиме 24/7: круглосуточно и семь дней в неделю;</li><li>такие преимущества Интернет-магазина как экономия времени и свобода выбора, играют важную роль и для покупателей;</li><li><a title=\"бизнес в Интернете\" href=\"http://www.imagecms.net/blog/obzory/biznes-v-internete-kak-perspektivnyi-trend\" target=\"_blank\">бизнес в Интернете</a>\n не требует большого количества обслуживающего персонала: можно обойтись\n одним консультантом там, где обычные торговые точки обслуживают \nпятерых;</li><li>нет ограничений по количеству представленных на виртуальной витрине товаров;</li><li>в случае с раскруткой и продвижением можно сфокусироваться только на\n потенциально заинтересованных в ваших товарах или услугах \nпользователях.</li></ul><br><p>Можно привести несколько примеров развертывания Интернет-магазинов на платформе <a href=\"http://www.imagecms.net/products/imagecms-shop-professional\">ImageCMS Shop Professional</a>:\n boutique-ekaterinasmolina.ru, euro-technika.com.ua и др. Как видно из \nпримеров, можно торговать в онлайне как с небольшим ассортиментом, так и\n предлагая тысячи наименований товаров. Учитывая вышеперечисленное, \nкаждый владелец бизнеса может понять, зачем нужен Интернет-магазин и \nкакие выгоды от его разработки можно получить (независимо от того, \nработаете ли вы с розничной торговлей или в области B2B).</p>', 71, '', '', 0, 1, 0, 'publish', 'admin', 1362226037, 1362226037, 0, 6, 3, 0);


#
# TABLE STRUCTURE FOR: content_field_groups
#

DROP TABLE IF EXISTS content_field_groups;

CREATE TABLE `content_field_groups` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `name` varchar(255) NOT NULL,
  `description` text,
  PRIMARY KEY (`id`),
  KEY `name` (`name`)
) ENGINE=MyISAM AUTO_INCREMENT=14 DEFAULT CHARSET=utf8;

INSERT INTO content_field_groups (`id`, `name`, `description`) VALUES (13, 'images', '');


#
# TABLE STRUCTURE FOR: content_fields
#

DROP TABLE IF EXISTS content_fields;

CREATE TABLE `content_fields` (
  `field_name` varchar(255) NOT NULL,
  `type` varchar(255) NOT NULL,
  `label` varchar(255) NOT NULL,
  `data` text NOT NULL,
  `weight` int(11) NOT NULL,
  `in_search` tinyint(1) DEFAULT '0',
  PRIMARY KEY (`field_name`),
  UNIQUE KEY `field_name` (`field_name`),
  KEY `type` (`type`),
  KEY `in_search` (`in_search`)
) ENGINE=MyISAM DEFAULT CHARSET=utf8;

INSERT INTO content_fields (`field_name`, `type`, `label`, `data`, `weight`, `in_search`) VALUES ('field_image', 'text', 'image', 'a:7:{s:5:\"label\";s:5:\"image\";s:7:\"initial\";s:0:\"\";s:9:\"help_text\";s:0:\"\";s:4:\"type\";s:4:\"text\";s:20:\"enable_image_browser\";s:1:\"1\";s:10:\"validation\";s:0:\"\";s:6:\"groups\";a:1:{i:0;s:2:\"13\";}}', 1, 0);


#
# TABLE STRUCTURE FOR: content_fields_data
#

DROP TABLE IF EXISTS content_fields_data;

CREATE TABLE `content_fields_data` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `item_id` int(11) NOT NULL,
  `item_type` varchar(15) NOT NULL,
  `field_name` varchar(255) NOT NULL,
  `data` text NOT NULL,
  PRIMARY KEY (`id`),
  KEY `item_id` (`item_id`),
  KEY `item_type` (`item_type`),
  KEY `field_name` (`field_name`)
) ENGINE=MyISAM AUTO_INCREMENT=27 DEFAULT CHARSET=utf8;

INSERT INTO content_fields_data (`id`, `item_id`, `item_type`, `field_name`, `data`) VALUES (24, 91, 'page', 'field_image', '/uploads/shop/news/bus_img1.jpg');
INSERT INTO content_fields_data (`id`, `item_id`, `item_type`, `field_name`, `data`) VALUES (25, 92, 'page', 'field_image', '/uploads/shop/news/bus_img2.jpg');
INSERT INTO content_fields_data (`id`, `item_id`, `item_type`, `field_name`, `data`) VALUES (26, 93, 'page', 'field_image', '/uploads/shop/news/bus_img3.jpg');


#
# TABLE STRUCTURE FOR: content_fields_groups_relations
#

DROP TABLE IF EXISTS content_fields_groups_relations;

CREATE TABLE `content_fields_groups_relations` (
  `field_name` varchar(64) NOT NULL,
  `group_id` int(3) NOT NULL
) ENGINE=MyISAM DEFAULT CHARSET=latin1;

INSERT INTO content_fields_groups_relations (`field_name`, `group_id`) VALUES ('field_sfsdfsdf', 0);
INSERT INTO content_fields_groups_relations (`field_name`, `group_id`) VALUES ('field_sfsdfsdf', 0);
INSERT INTO content_fields_groups_relations (`field_name`, `group_id`) VALUES ('field_fyjtyutyu', 0);
INSERT INTO content_fields_groups_relations (`field_name`, `group_id`) VALUES ('field_fg12', 0);
INSERT INTO content_fields_groups_relations (`field_name`, `group_id`) VALUES ('field_fg12', 0);
INSERT INTO content_fields_groups_relations (`field_name`, `group_id`) VALUES ('field_image', 13);


#
# TABLE STRUCTURE FOR: content_permissions
#

DROP TABLE IF EXISTS content_permissions;

CREATE TABLE `content_permissions` (
  `id` bigint(11) NOT NULL AUTO_INCREMENT,
  `page_id` bigint(11) NOT NULL,
  `data` text NOT NULL,
  PRIMARY KEY (`id`),
  KEY `page_id` (`page_id`)
) ENGINE=MyISAM AUTO_INCREMENT=24 DEFAULT CHARSET=utf8;

INSERT INTO content_permissions (`id`, `page_id`, `data`) VALUES (23, 80, 'a:3:{i:0;a:1:{s:7:\"role_id\";s:1:\"0\";}i:1;a:1:{s:7:\"role_id\";s:1:\"1\";}i:2;a:1:{s:7:\"role_id\";s:1:\"2\";}}');


#
# TABLE STRUCTURE FOR: content_tags
#

DROP TABLE IF EXISTS content_tags;

CREATE TABLE `content_tags` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `page_id` int(11) NOT NULL,
  `tag_id` int(11) NOT NULL,
  PRIMARY KEY (`id`),
  KEY `page_id` (`page_id`),
  KEY `tag_id` (`tag_id`)
) ENGINE=MyISAM DEFAULT CHARSET=utf8;

#
# TABLE STRUCTURE FOR: custom_fields
#

DROP TABLE IF EXISTS custom_fields;

CREATE TABLE `custom_fields` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `field_type_id` int(11) NOT NULL,
  `field_name` varchar(64) NOT NULL,
  `is_required` tinyint(1) NOT NULL DEFAULT '1',
  `is_active` tinyint(1) NOT NULL DEFAULT '1',
  `is_private` tinyint(1) NOT NULL DEFAULT '0',
  `validators` varchar(255) DEFAULT NULL,
  `entity` varchar(32) DEFAULT NULL,
  `options` varchar(65) DEFAULT NULL,
  `classes` text,
  `position` tinyint(4) DEFAULT NULL,
  PRIMARY KEY (`id`)
) ENGINE=MyISAM AUTO_INCREMENT=96 DEFAULT CHARSET=utf8;

#
# TABLE STRUCTURE FOR: custom_fields_data
#

DROP TABLE IF EXISTS custom_fields_data;

CREATE TABLE `custom_fields_data` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `field_id` int(11) NOT NULL,
  `entity_id` int(11) NOT NULL,
  `field_data` text,
  `locale` varchar(4) NOT NULL,
  PRIMARY KEY (`id`)
) ENGINE=MyISAM AUTO_INCREMENT=514 DEFAULT CHARSET=utf8;

#
# TABLE STRUCTURE FOR: custom_fields_i18n
#

DROP TABLE IF EXISTS custom_fields_i18n;

CREATE TABLE `custom_fields_i18n` (
  `id` int(11) NOT NULL,
  `locale` varchar(4) NOT NULL,
  `field_label` varchar(255) DEFAULT NULL,
  `field_description` text,
  `possible_values` text,
  PRIMARY KEY (`id`,`locale`)
) ENGINE=MyISAM DEFAULT CHARSET=utf8;

#
# TABLE STRUCTURE FOR: emails
#

DROP TABLE IF EXISTS emails;

CREATE TABLE `emails` (
  `name` varchar(50) CHARACTER SET utf8 NOT NULL,
  `template` text CHARACTER SET utf8 NOT NULL,
  `settings` text CHARACTER SET utf8 NOT NULL,
  `locale` varchar(5) CHARACTER SET utf8 NOT NULL,
  `description` text CHARACTER SET utf8 NOT NULL
) ENGINE=MyISAM DEFAULT CHARSET=latin1;

INSERT INTO emails (`name`, `template`, `settings`, `locale`, `description`) VALUES ('wishListMail', 'Шановний %userName%. Ви створили наступний список побажань %wishKey%<br>Створений: %wishDateCreated%  ', 'a:4:{s:5:\"theme\";s:29:\"Список побажань\";s:4:\"from\";s:43:\"Адміністрація магазину\";s:9:\"from_mail\";s:19:\"admin@localhost.loc\";s:9:\"variables\";a:3:{i:0;s:10:\"%userName%\";i:1;s:9:\"%wishKey%\";i:2;s:17:\"%wishDateCreated%\";}}', 'ua', 'Лист про створений список побажань  ');
INSERT INTO emails (`name`, `template`, `settings`, `locale`, `description`) VALUES ('wishListMail', '<h2> Уважаемый %userName%.</h2> Вы создали следующий список желаний %wishKey%<div>Ссылка на просмотр списка желаний -&nbsp;&nbsp; %wishLink% <br>Создан %wishDateCreated%   %orderId% </div>  ', 'a:5:{s:5:\"theme\";s:14:\"Вишлист\";s:4:\"from\";s:43:\"Администрация магазина\";s:9:\"from_mail\";s:19:\"admin@localhost.loc\";s:9:\"variables\";b:0;s:9:\"mail_type\";s:4:\"html\";}', 'ru', 'Письмо о создании списка желаний.  ');
INSERT INTO emails (`name`, `template`, `settings`, `locale`, `description`) VALUES ('noticeOfAppearance', 'Шаблон письма  ', 'a:5:{s:5:\"theme\";s:46:\"Уведомлениен о появлении\";s:4:\"from\";s:37:\"Администрация сайта\";s:9:\"from_mail\";s:0:\"\";s:9:\"variables\";b:0;s:9:\"mail_type\";s:4:\"html\";}', 'ru', 'Шаблон письма об уведомлении о появлении  ');
INSERT INTO emails (`name`, `template`, `settings`, `locale`, `description`) VALUES ('callBackNotification', 'Callback notification  ', 'a:5:{s:5:\"theme\";s:8:\"Callback\";s:4:\"from\";s:24:\"Пользователь\";s:10:\"from_email\";s:0:\"\";s:9:\"variables\";b:0;s:9:\"mail_type\";s:4:\"html\";}', 'ru', 'Шаблон письма для callback  ');
INSERT INTO emails (`name`, `template`, `settings`, `locale`, `description`) VALUES ('toAdminOrderNotification', 'Шаблон письма для администратора о совершении заказа  ', 'a:5:{s:5:\"theme\";s:59:\"Уведомление о совершении заказа\";s:4:\"from\";s:34:\"Админ панель сайта\";s:10:\"from_email\";s:0:\"\";s:9:\"variables\";b:0;s:9:\"mail_type\";s:4:\"html\";}', 'ru', 'Шаблон письма для администратора о совершении заказа    ');
INSERT INTO emails (`name`, `template`, `settings`, `locale`, `description`) VALUES ('toUserOrderNotification', 'Здравствуйте, %userName%.<br><br>Мы благодарны Вам за то, что совершили заказ в нашем магазине \"ImageCMS Shop\"<br><br>Вы указали следующие контактные данные:<br><br>Email адрес: %userEmail%<br><br>Номер телефона: %userPhone%<br><br>Адрес доставки: %userDeliver%<br><br>Менеджеры нашего магазина вскоре свяжутся с Вами и помогут с оформлением и оплатой товара.<br><br>Также, Вы можете всегда посмотреть за статусом Вашего заказа, перейдя по ссылке:&nbsp; %orderLink%.<br><br>Спасибо за ваш заказ, искренне Ваши, сотрудники ImageCMS Shop.<br><br>При возникновении любых вопросов, обращайтесь за телефонами:<br><br>+7 (095) 222-33-22 +38 (098) 222-33-22  ', 'a:5:{s:5:\"theme\";s:80:\"Уведомление покупателя о совершении заказа\";s:4:\"from\";b:0;s:9:\"from_mail\";s:21:\"noreply@localhost.loc\";s:9:\"variables\";b:0;s:9:\"mail_type\";s:4:\"html\";}', 'ru', 'Уведомление покупателя о совершении заказа  ');
INSERT INTO emails (`name`, `template`, `settings`, `locale`, `description`) VALUES ('toUserChangeOrderStatusNotification', 'Уведомление пользователя о смене статуса заказа    ', 'a:5:{s:5:\"theme\";s:89:\"Уведомление пользователя о смене статуса заказа\";s:4:\"from\";s:37:\"Администрация сайта\";s:10:\"from_email\";s:19:\"admin@localhost.loc\";s:9:\"variables\";b:0;s:9:\"mail_type\";s:4:\"html\";}', 'ru', 'Уведомление пользователя о смене статуса заказа    ');
INSERT INTO emails (`name`, `template`, `settings`, `locale`, `description`) VALUES ('afterOrderUserRegistration', 'Письмо о регистрации на сатйе после совершения заказа  ', 'a:5:{s:5:\"theme\";s:38:\"Регистрация на сайте\";s:4:\"from\";s:43:\"Администрация магазина\";s:10:\"from_email\";s:19:\"admin@localhost.loc\";s:9:\"variables\";b:0;s:9:\"mail_type\";s:4:\"html\";}', 'ru', 'Письмо о регистрации на сатйе после совершения заказа    ');
INSERT INTO emails (`name`, `template`, `settings`, `locale`, `description`) VALUES ('forgotPassword', 'Здравствуйте!<br><br>На сайте %webSiteName% создан запрос на восстановление пароля для Вашего аккаунта.<br><br>Для завершения процедуры восстановления пароля перейдите по ссылке %resetPasswordUri%<br><br>Ваш новый пароль для входа: %password%<br><br>Если это письмо попало к Вам по ошибке просто проигнорируйте его.<br><br>При возникновении любых вопросов, обращайтесь по телефонам:<br><br>(012)&nbsp; 345-67-89 , (012)&nbsp; 345-67-89<br><br>---<br><br>С уважением,<br><br>сотрудники службы продаж %webSiteName%  ', 'a:5:{s:5:\"theme\";s:41:\"Восстановление пароля\";s:4:\"from\";s:37:\"Администрация сайта\";s:9:\"from_mail\";s:0:\"\";s:9:\"variables\";b:0;s:9:\"mail_type\";s:4:\"html\";}', 'ru', 'Шаблон письма о восстановлении пароля  ');
INSERT INTO emails (`name`, `template`, `settings`, `locale`, `description`) VALUES ('wishListMail', 'Шановний %userName%. Ви створили наступний список побажань %wishKey%<br>Створений: %wishDateCreated%  ', 'a:4:{s:5:\"theme\";s:29:\"Список побажань\";s:4:\"from\";s:43:\"Адміністрація магазину\";s:9:\"from_mail\";s:19:\"admin@localhost.loc\";s:9:\"variables\";a:3:{i:0;s:10:\"%userName%\";i:1;s:9:\"%wishKey%\";i:2;s:17:\"%wishDateCreated%\";}}', 'ua', 'Лист про створений список побажань  ');
INSERT INTO emails (`name`, `template`, `settings`, `locale`, `description`) VALUES ('wishListMail', '<h2> Уважаемый %userName%.</h2> Вы создали следующий список желаний %wishKey%<div>Ссылка на просмотр списка желаний -&nbsp;&nbsp; %wishLink% <br>Создан %wishDateCreated%   %orderId% </div>  ', 'a:5:{s:5:\"theme\";s:14:\"Вишлист\";s:4:\"from\";s:43:\"Администрация магазина\";s:9:\"from_mail\";s:19:\"admin@localhost.loc\";s:9:\"variables\";b:0;s:9:\"mail_type\";s:4:\"html\";}', 'ru', 'Письмо о создании списка желаний.  ');
INSERT INTO emails (`name`, `template`, `settings`, `locale`, `description`) VALUES ('noticeOfAppearance', 'Шаблон письма  ', 'a:5:{s:5:\"theme\";s:46:\"Уведомлениен о появлении\";s:4:\"from\";s:37:\"Администрация сайта\";s:9:\"from_mail\";s:0:\"\";s:9:\"variables\";b:0;s:9:\"mail_type\";s:4:\"html\";}', 'ru', 'Шаблон письма об уведомлении о появлении  ');
INSERT INTO emails (`name`, `template`, `settings`, `locale`, `description`) VALUES ('callBackNotification', 'Callback notification  ', 'a:5:{s:5:\"theme\";s:8:\"Callback\";s:4:\"from\";s:24:\"Пользователь\";s:10:\"from_email\";s:0:\"\";s:9:\"variables\";b:0;s:9:\"mail_type\";s:4:\"html\";}', 'ru', 'Шаблон письма для callback  ');
INSERT INTO emails (`name`, `template`, `settings`, `locale`, `description`) VALUES ('toAdminOrderNotification', 'Шаблон письма для администратора о совершении заказа  ', 'a:5:{s:5:\"theme\";s:59:\"Уведомление о совершении заказа\";s:4:\"from\";s:34:\"Админ панель сайта\";s:10:\"from_email\";s:0:\"\";s:9:\"variables\";b:0;s:9:\"mail_type\";s:4:\"html\";}', 'ru', 'Шаблон письма для администратора о совершении заказа    ');
INSERT INTO emails (`name`, `template`, `settings`, `locale`, `description`) VALUES ('toUserOrderNotification', 'Здравствуйте, %userName%.<br><br>Мы благодарны Вам за то, что совершили заказ в нашем магазине \"ImageCMS Shop\"<br><br>Вы указали следующие контактные данные:<br><br>Email адрес: %userEmail%<br><br>Номер телефона: %userPhone%<br><br>Адрес доставки: %userDeliver%<br><br>Менеджеры нашего магазина вскоре свяжутся с Вами и помогут с оформлением и оплатой товара.<br><br>Также, Вы можете всегда посмотреть за статусом Вашего заказа, перейдя по ссылке:&nbsp; %orderLink%.<br><br>Спасибо за ваш заказ, искренне Ваши, сотрудники ImageCMS Shop.<br><br>При возникновении любых вопросов, обращайтесь за телефонами:<br><br>+7 (095) 222-33-22 +38 (098) 222-33-22  ', 'a:5:{s:5:\"theme\";s:80:\"Уведомление покупателя о совершении заказа\";s:4:\"from\";b:0;s:9:\"from_mail\";s:21:\"noreply@localhost.loc\";s:9:\"variables\";b:0;s:9:\"mail_type\";s:4:\"html\";}', 'ru', 'Уведомление покупателя о совершении заказа  ');
INSERT INTO emails (`name`, `template`, `settings`, `locale`, `description`) VALUES ('toUserChangeOrderStatusNotification', 'Уведомление пользователя о смене статуса заказа    ', 'a:5:{s:5:\"theme\";s:89:\"Уведомление пользователя о смене статуса заказа\";s:4:\"from\";s:37:\"Администрация сайта\";s:10:\"from_email\";s:19:\"admin@localhost.loc\";s:9:\"variables\";b:0;s:9:\"mail_type\";s:4:\"html\";}', 'ru', 'Уведомление пользователя о смене статуса заказа    ');
INSERT INTO emails (`name`, `template`, `settings`, `locale`, `description`) VALUES ('afterOrderUserRegistration', 'Письмо о регистрации на сатйе после совершения заказа  ', 'a:5:{s:5:\"theme\";s:38:\"Регистрация на сайте\";s:4:\"from\";s:43:\"Администрация магазина\";s:10:\"from_email\";s:19:\"admin@localhost.loc\";s:9:\"variables\";b:0;s:9:\"mail_type\";s:4:\"html\";}', 'ru', 'Письмо о регистрации на сатйе после совершения заказа    ');
INSERT INTO emails (`name`, `template`, `settings`, `locale`, `description`) VALUES ('forgotPassword', 'Здравствуйте!<br><br>На сайте %webSiteName% создан запрос на восстановление пароля для Вашего аккаунта.<br><br>Для завершения процедуры восстановления пароля перейдите по ссылке %resetPasswordUri%<br><br>Ваш новый пароль для входа: %password%<br><br>Если это письмо попало к Вам по ошибке просто проигнорируйте его.<br><br>При возникновении любых вопросов, обращайтесь по телефонам:<br><br>(012)&nbsp; 345-67-89 , (012)&nbsp; 345-67-89<br><br>---<br><br>С уважением,<br><br>сотрудники службы продаж %webSiteName%  ', 'a:5:{s:5:\"theme\";s:41:\"Восстановление пароля\";s:4:\"from\";s:37:\"Администрация сайта\";s:9:\"from_mail\";s:0:\"\";s:9:\"variables\";b:0;s:9:\"mail_type\";s:4:\"html\";}', 'ru', 'Шаблон письма о восстановлении пароля  ');


#
# TABLE STRUCTURE FOR: gallery_albums
#

DROP TABLE IF EXISTS gallery_albums;

CREATE TABLE `gallery_albums` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `category_id` int(11) NOT NULL,
  `cover_id` int(11) NOT NULL DEFAULT '0',
  `position` int(9) NOT NULL DEFAULT '0',
  `created` int(11) NOT NULL,
  `updated` int(11) NOT NULL,
  `tpl_file` varchar(50) NOT NULL DEFAULT '',
  PRIMARY KEY (`id`),
  KEY `category_id` (`category_id`),
  KEY `created` (`created`)
) ENGINE=MyISAM AUTO_INCREMENT=4 DEFAULT CHARSET=utf8;

#
# TABLE STRUCTURE FOR: gallery_albums_i18n
#

DROP TABLE IF EXISTS gallery_albums_i18n;

CREATE TABLE `gallery_albums_i18n` (
  `id` int(11) NOT NULL,
  `locale` varchar(5) NOT NULL,
  `description` text NOT NULL,
  `name` varchar(255) NOT NULL,
  PRIMARY KEY (`id`,`locale`)
) ENGINE=MyISAM DEFAULT CHARSET=utf8;

#
# TABLE STRUCTURE FOR: gallery_category
#

DROP TABLE IF EXISTS gallery_category;

CREATE TABLE `gallery_category` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `cover_id` int(11) NOT NULL DEFAULT '0',
  `position` int(9) NOT NULL DEFAULT '0',
  `created` int(11) NOT NULL,
  PRIMARY KEY (`id`)
) ENGINE=MyISAM AUTO_INCREMENT=7 DEFAULT CHARSET=utf8;

#
# TABLE STRUCTURE FOR: gallery_category_i18n
#

DROP TABLE IF EXISTS gallery_category_i18n;

CREATE TABLE `gallery_category_i18n` (
  `id` int(11) NOT NULL,
  `locale` varchar(5) NOT NULL,
  `description` text,
  `name` varchar(255) DEFAULT NULL,
  PRIMARY KEY (`id`,`locale`)
) ENGINE=MyISAM DEFAULT CHARSET=utf8;

#
# TABLE STRUCTURE FOR: gallery_images
#

DROP TABLE IF EXISTS gallery_images;

CREATE TABLE `gallery_images` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `album_id` int(11) NOT NULL,
  `file_name` varchar(150) NOT NULL,
  `file_ext` varchar(8) NOT NULL,
  `file_size` varchar(20) NOT NULL,
  `position` int(9) NOT NULL,
  `width` int(6) NOT NULL,
  `height` int(6) NOT NULL,
  `uploaded` int(11) NOT NULL,
  `views` int(11) NOT NULL,
  PRIMARY KEY (`id`)
) ENGINE=MyISAM AUTO_INCREMENT=2 DEFAULT CHARSET=utf8;

#
# TABLE STRUCTURE FOR: gallery_images_i18n
#

DROP TABLE IF EXISTS gallery_images_i18n;

CREATE TABLE `gallery_images_i18n` (
  `id` int(11) NOT NULL,
  `locale` varchar(5) NOT NULL,
  `description` text,
  PRIMARY KEY (`id`,`locale`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8;

#
# TABLE STRUCTURE FOR: languages
#

DROP TABLE IF EXISTS languages;

CREATE TABLE `languages` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `lang_name` varchar(100) NOT NULL,
  `identif` varchar(10) NOT NULL,
  `image` text NOT NULL,
  `folder` varchar(100) NOT NULL,
  `template` varchar(100) NOT NULL,
  `default` int(1) NOT NULL,
  `locale` varchar(100) NOT NULL,
  PRIMARY KEY (`id`),
  KEY `identif` (`identif`),
  KEY `default` (`default`)
) ENGINE=MyISAM AUTO_INCREMENT=31 DEFAULT CHARSET=utf8;

INSERT INTO languages (`id`, `lang_name`, `identif`, `image`, `folder`, `template`, `default`, `locale`) VALUES (3, 'Русский', 'ru', '', 'russian', 'commerce', 1, 'ru_RU');


#
# TABLE STRUCTURE FOR: login_attempts
#

DROP TABLE IF EXISTS login_attempts;

CREATE TABLE `login_attempts` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `ip_address` varchar(40) NOT NULL,
  `time` timestamp NOT NULL DEFAULT CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP,
  PRIMARY KEY (`id`),
  KEY `ip_address` (`ip_address`),
  KEY `time` (`time`)
) ENGINE=MyISAM AUTO_INCREMENT=107 DEFAULT CHARSET=utf8;

#
# TABLE STRUCTURE FOR: logs
#

DROP TABLE IF EXISTS logs;

CREATE TABLE `logs` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `user_id` int(11) NOT NULL,
  `username` varchar(250) NOT NULL,
  `message` text NOT NULL,
  `date` int(11) NOT NULL,
  PRIMARY KEY (`id`),
  KEY `date` (`date`)
) ENGINE=MyISAM AUTO_INCREMENT=956 DEFAULT CHARSET=utf8;

INSERT INTO logs (`id`, `user_id`, `username`, `message`, `date`) VALUES (741, 1, 'admin', 'Вышел из панели управления', 1363601996);
INSERT INTO logs (`id`, `user_id`, `username`, `message`, `date`) VALUES (742, 1, 'admin', 'Вошел в панель управления IP 127.0.0.1', 1363602140);
INSERT INTO logs (`id`, `user_id`, `username`, `message`, `date`) VALUES (743, 1, 'admin', 'Изменил настройки сайта', 1363605006);
INSERT INTO logs (`id`, `user_id`, `username`, `message`, `date`) VALUES (744, 1, 'admin', 'Создал виджет popular_products', 1363606273);
INSERT INTO logs (`id`, `user_id`, `username`, `message`, `date`) VALUES (745, 1, 'admin', 'Создал виджет new_products', 1363606324);
INSERT INTO logs (`id`, `user_id`, `username`, `message`, `date`) VALUES (746, 1, 'admin', 'Создал виджет action_products', 1363606361);
INSERT INTO logs (`id`, `user_id`, `username`, `message`, `date`) VALUES (747, 1, 'admin', 'Создал виджет brands', 1363606422);
INSERT INTO logs (`id`, `user_id`, `username`, `message`, `date`) VALUES (748, 1, 'admin', 'Создал виджет view_product', 1363606497);
INSERT INTO logs (`id`, `user_id`, `username`, `message`, `date`) VALUES (749, 1, 'admin', 'Создал виджет similar', 1363606582);
INSERT INTO logs (`id`, `user_id`, `username`, `message`, `date`) VALUES (750, 1, 'admin', 'Создал категорию        <a href=\"/admin/categories/edit/69\"> Новости</a>', 1363608590);
INSERT INTO logs (`id`, `user_id`, `username`, `message`, `date`) VALUES (751, 1, 'admin', 'Создал категорию        <a href=\"/admin/categories/edit/70\"> Последние новости</a>', 1363608751);
INSERT INTO logs (`id`, `user_id`, `username`, `message`, `date`) VALUES (752, 1, 'admin', 'Изменил категорию   <a href=\"/admin/categories/edit/70\"> Последние новости</a>', 1363608759);
INSERT INTO logs (`id`, `user_id`, `username`, `message`, `date`) VALUES (753, 1, 'admin', 'Создал категорию        <a href=\"/admin/categories/edit/71\"> Архив</a>', 1363608777);
INSERT INTO logs (`id`, `user_id`, `username`, `message`, `date`) VALUES (754, 1, 'admin', 'Изменил категорию   <a href=\"/admin/categories/edit/69\"> Новости</a>', 1363610618);
INSERT INTO logs (`id`, `user_id`, `username`, `message`, `date`) VALUES (755, 1, 'admin', 'Вышел из панели управления', 1363617075);
INSERT INTO logs (`id`, `user_id`, `username`, `message`, `date`) VALUES (756, 47, 'admin', 'Вышел из панели управления', 1368174639);
INSERT INTO logs (`id`, `user_id`, `username`, `message`, `date`) VALUES (757, 47, 'admin', 'Вошел в панель управления IP 127.0.0.1', 1368174783);
INSERT INTO logs (`id`, `user_id`, `username`, `message`, `date`) VALUES (758, 47, 'admin', 'Очистил кеш', 1368174887);
INSERT INTO logs (`id`, `user_id`, `username`, `message`, `date`) VALUES (759, 48, 'admin', 'Cleared the cache', 1384939535);
INSERT INTO logs (`id`, `user_id`, `username`, `message`, `date`) VALUES (760, 48, 'admin', 'Cleared the cache', 1384939536);
INSERT INTO logs (`id`, `user_id`, `username`, `message`, `date`) VALUES (761, 48, 'admin', 'Changed the page <a href=\"http://beautiful_cars.loc/admin/pages/edit/64\">О компании</a>', 1384939676);
INSERT INTO logs (`id`, `user_id`, `username`, `message`, `date`) VALUES (762, 48, 'admin', 'Deleted ID page 35', 1384939685);
INSERT INTO logs (`id`, `user_id`, `username`, `message`, `date`) VALUES (763, 48, 'admin', 'Deleted ID page 65', 1384939828);
INSERT INTO logs (`id`, `user_id`, `username`, `message`, `date`) VALUES (764, 48, 'admin', 'Changed the page <a href=\"http://beautiful_cars.loc/admin/pages/edit/66\">Доставка и оплата</a>', 1384939837);
INSERT INTO logs (`id`, `user_id`, `username`, `message`, `date`) VALUES (765, 48, 'admin', 'Changed the page <a href=\"http://beautiful_cars.loc/admin/pages/edit/67\">Система скидок</a>', 1384939922);
INSERT INTO logs (`id`, `user_id`, `username`, `message`, `date`) VALUES (766, 48, 'admin', 'Changed the page <a href=\"http://beautiful_cars.loc/admin/pages/edit/67\">Система скидок</a>', 1384940022);
INSERT INTO logs (`id`, `user_id`, `username`, `message`, `date`) VALUES (767, 48, 'admin', 'Changed the page <a href=\"http://beautiful_cars.loc/admin/pages/edit/64\">О компании</a>', 1384940031);
INSERT INTO logs (`id`, `user_id`, `username`, `message`, `date`) VALUES (768, 48, 'admin', 'Changed the page <a href=\"http://beautiful_cars.loc/admin/pages/edit/67\">Система скидок</a>', 1384940038);
INSERT INTO logs (`id`, `user_id`, `username`, `message`, `date`) VALUES (769, 48, 'admin', 'Created a page <a href=\"http://beautiful_cars.loc/admin/pages/edit/97\">Гарантия и возврат</a>', 1384940188);
INSERT INTO logs (`id`, `user_id`, `username`, `message`, `date`) VALUES (770, 48, 'admin', 'Changed the page <a href=\"http://beautiful_cars.loc/admin/pages/edit/97\">Гарантия и возврат</a>', 1384940190);
INSERT INTO logs (`id`, `user_id`, `username`, `message`, `date`) VALUES (771, 48, 'admin', 'Entered the IP control panel 127.0.0.1', 1384942177);
INSERT INTO logs (`id`, `user_id`, `username`, `message`, `date`) VALUES (772, 48, 'admin', 'Cleared the cache', 1384942182);
INSERT INTO logs (`id`, `user_id`, `username`, `message`, `date`) VALUES (773, 48, 'admin', 'Cleared the cache', 1384945248);
INSERT INTO logs (`id`, `user_id`, `username`, `message`, `date`) VALUES (774, 48, 'admin', 'Cleared the cache', 1384945249);
INSERT INTO logs (`id`, `user_id`, `username`, `message`, `date`) VALUES (775, 48, 'admin', 'Cleared the cache', 1384945853);
INSERT INTO logs (`id`, `user_id`, `username`, `message`, `date`) VALUES (776, 48, 'admin', 'Changed wesite settings', 1384948210);
INSERT INTO logs (`id`, `user_id`, `username`, `message`, `date`) VALUES (777, 48, 'admin', 'Cleared the cache', 1384952687);
INSERT INTO logs (`id`, `user_id`, `username`, `message`, `date`) VALUES (778, 48, 'admin', 'Cleared the cache', 1384952688);
INSERT INTO logs (`id`, `user_id`, `username`, `message`, `date`) VALUES (779, 48, 'admin', 'Cleared the cache', 1384952868);
INSERT INTO logs (`id`, `user_id`, `username`, `message`, `date`) VALUES (780, 48, 'admin', 'Cleared the cache', 1384952868);
INSERT INTO logs (`id`, `user_id`, `username`, `message`, `date`) VALUES (781, 48, 'admin', 'Cleared the cache', 1384954593);
INSERT INTO logs (`id`, `user_id`, `username`, `message`, `date`) VALUES (782, 48, 'admin', 'Cleared the cache', 1384954593);
INSERT INTO logs (`id`, `user_id`, `username`, `message`, `date`) VALUES (783, 48, 'admin', 'Cleared the cache', 1384958853);
INSERT INTO logs (`id`, `user_id`, `username`, `message`, `date`) VALUES (784, 48, 'admin', 'Cleared the cache', 1384958983);
INSERT INTO logs (`id`, `user_id`, `username`, `message`, `date`) VALUES (785, 48, 'admin', 'Cleared the cache', 1384962130);
INSERT INTO logs (`id`, `user_id`, `username`, `message`, `date`) VALUES (786, 48, 'admin', 'Cleared the cache', 1384962590);
INSERT INTO logs (`id`, `user_id`, `username`, `message`, `date`) VALUES (787, 48, 'admin', 'Cleared the cache', 1384962590);
INSERT INTO logs (`id`, `user_id`, `username`, `message`, `date`) VALUES (788, 48, 'admin', 'Cleared the cache', 1384962654);
INSERT INTO logs (`id`, `user_id`, `username`, `message`, `date`) VALUES (789, 48, 'admin', 'Cleared the cache', 1384962654);
INSERT INTO logs (`id`, `user_id`, `username`, `message`, `date`) VALUES (790, 48, 'admin', 'Cleared the cache', 1384962701);
INSERT INTO logs (`id`, `user_id`, `username`, `message`, `date`) VALUES (791, 48, 'admin', 'Cleared the cache', 1384962701);
INSERT INTO logs (`id`, `user_id`, `username`, `message`, `date`) VALUES (792, 48, 'admin', 'Cleared the cache', 1384962749);
INSERT INTO logs (`id`, `user_id`, `username`, `message`, `date`) VALUES (793, 48, 'admin', 'Cleared the cache', 1384962749);
INSERT INTO logs (`id`, `user_id`, `username`, `message`, `date`) VALUES (794, 48, 'admin', 'Cleared the cache', 1384962749);
INSERT INTO logs (`id`, `user_id`, `username`, `message`, `date`) VALUES (795, 48, 'admin', 'Cleared the cache', 1384962957);
INSERT INTO logs (`id`, `user_id`, `username`, `message`, `date`) VALUES (796, 48, 'admin', 'Cleared the cache', 1384962957);
INSERT INTO logs (`id`, `user_id`, `username`, `message`, `date`) VALUES (797, 48, 'admin', 'Cleared the cache', 1384963078);
INSERT INTO logs (`id`, `user_id`, `username`, `message`, `date`) VALUES (798, 48, 'admin', 'Cleared the cache', 1384963078);
INSERT INTO logs (`id`, `user_id`, `username`, `message`, `date`) VALUES (799, 48, 'admin', 'Cleared the cache', 1384964994);
INSERT INTO logs (`id`, `user_id`, `username`, `message`, `date`) VALUES (800, 48, 'admin', 'Cleared the cache', 1384964994);
INSERT INTO logs (`id`, `user_id`, `username`, `message`, `date`) VALUES (801, 48, 'admin', 'Entered the IP control panel 127.0.0.1', 1384965138);
INSERT INTO logs (`id`, `user_id`, `username`, `message`, `date`) VALUES (802, 48, 'admin', 'Cleared the cache', 1384965143);
INSERT INTO logs (`id`, `user_id`, `username`, `message`, `date`) VALUES (803, 48, 'admin', 'Cleared the cache', 1384965143);
INSERT INTO logs (`id`, `user_id`, `username`, `message`, `date`) VALUES (804, 48, 'admin', 'Cleared the cache', 1384966677);
INSERT INTO logs (`id`, `user_id`, `username`, `message`, `date`) VALUES (805, 48, 'admin', 'Cleared the cache', 1384966677);
INSERT INTO logs (`id`, `user_id`, `username`, `message`, `date`) VALUES (806, 48, 'admin', 'Entered the IP control panel 127.0.0.1', 1385021916);
INSERT INTO logs (`id`, `user_id`, `username`, `message`, `date`) VALUES (807, 48, 'admin', 'Cleared the cache', 1385021921);
INSERT INTO logs (`id`, `user_id`, `username`, `message`, `date`) VALUES (808, 48, 'admin', 'Cleared the cache', 1385021921);
INSERT INTO logs (`id`, `user_id`, `username`, `message`, `date`) VALUES (809, 48, 'admin', 'Cleared the cache', 1385028968);
INSERT INTO logs (`id`, `user_id`, `username`, `message`, `date`) VALUES (810, 48, 'admin', 'Cleared the cache', 1385028968);
INSERT INTO logs (`id`, `user_id`, `username`, `message`, `date`) VALUES (811, 48, 'admin', 'Cleared the cache', 1385029355);
INSERT INTO logs (`id`, `user_id`, `username`, `message`, `date`) VALUES (812, 48, 'admin', 'Cleared the cache', 1385029355);
INSERT INTO logs (`id`, `user_id`, `username`, `message`, `date`) VALUES (813, 48, 'admin', 'Cleared the cache', 1385030499);
INSERT INTO logs (`id`, `user_id`, `username`, `message`, `date`) VALUES (814, 48, 'admin', 'Cleared the cache', 1385035834);
INSERT INTO logs (`id`, `user_id`, `username`, `message`, `date`) VALUES (815, 48, 'admin', 'Cleared the cache', 1385035835);
INSERT INTO logs (`id`, `user_id`, `username`, `message`, `date`) VALUES (816, 48, 'admin', 'Cleared the cache', 1385035922);
INSERT INTO logs (`id`, `user_id`, `username`, `message`, `date`) VALUES (817, 48, 'admin', 'Cleared the cache', 1385036686);
INSERT INTO logs (`id`, `user_id`, `username`, `message`, `date`) VALUES (818, 48, 'admin', 'Cleared the cache', 1385036686);
INSERT INTO logs (`id`, `user_id`, `username`, `message`, `date`) VALUES (819, 48, 'admin', 'Cleared the cache', 1385036744);
INSERT INTO logs (`id`, `user_id`, `username`, `message`, `date`) VALUES (820, 48, 'admin', 'Cleared the cache', 1385036744);
INSERT INTO logs (`id`, `user_id`, `username`, `message`, `date`) VALUES (821, 48, 'admin', 'Cleared the cache', 1385036830);
INSERT INTO logs (`id`, `user_id`, `username`, `message`, `date`) VALUES (822, 48, 'admin', 'Cleared the cache', 1385036831);
INSERT INTO logs (`id`, `user_id`, `username`, `message`, `date`) VALUES (823, 48, 'admin', 'Cleared the cache', 1385037237);
INSERT INTO logs (`id`, `user_id`, `username`, `message`, `date`) VALUES (824, 48, 'admin', 'Cleared the cache', 1385037237);
INSERT INTO logs (`id`, `user_id`, `username`, `message`, `date`) VALUES (825, 48, 'admin', 'Cleared the cache', 1385037892);
INSERT INTO logs (`id`, `user_id`, `username`, `message`, `date`) VALUES (826, 48, 'admin', 'Cleared the cache', 1385037903);
INSERT INTO logs (`id`, `user_id`, `username`, `message`, `date`) VALUES (827, 48, 'admin', 'Cleared the cache', 1385037904);
INSERT INTO logs (`id`, `user_id`, `username`, `message`, `date`) VALUES (828, 48, 'admin', 'Cleared the cache', 1385038181);
INSERT INTO logs (`id`, `user_id`, `username`, `message`, `date`) VALUES (829, 48, 'admin', 'Cleared the cache', 1385038250);
INSERT INTO logs (`id`, `user_id`, `username`, `message`, `date`) VALUES (830, 48, 'admin', 'Cleared the cache', 1385038387);
INSERT INTO logs (`id`, `user_id`, `username`, `message`, `date`) VALUES (831, 48, 'admin', 'Cleared the cache', 1385038564);
INSERT INTO logs (`id`, `user_id`, `username`, `message`, `date`) VALUES (832, 48, 'admin', 'Cleared the cache', 1385038622);
INSERT INTO logs (`id`, `user_id`, `username`, `message`, `date`) VALUES (833, 48, 'admin', 'Cleared the cache', 1385038657);
INSERT INTO logs (`id`, `user_id`, `username`, `message`, `date`) VALUES (834, 48, 'admin', 'Cleared the cache', 1385038779);
INSERT INTO logs (`id`, `user_id`, `username`, `message`, `date`) VALUES (835, 48, 'admin', 'Cleared the cache', 1385038780);
INSERT INTO logs (`id`, `user_id`, `username`, `message`, `date`) VALUES (836, 48, 'admin', 'Cleared the cache', 1385038975);
INSERT INTO logs (`id`, `user_id`, `username`, `message`, `date`) VALUES (837, 48, 'admin', 'Cleared the cache', 1385039032);
INSERT INTO logs (`id`, `user_id`, `username`, `message`, `date`) VALUES (838, 48, 'admin', 'Cleared the cache', 1385039033);
INSERT INTO logs (`id`, `user_id`, `username`, `message`, `date`) VALUES (839, 48, 'admin', 'Cleared the cache', 1385039096);
INSERT INTO logs (`id`, `user_id`, `username`, `message`, `date`) VALUES (840, 48, 'admin', 'Cleared the cache', 1385039263);
INSERT INTO logs (`id`, `user_id`, `username`, `message`, `date`) VALUES (841, 48, 'admin', 'Changed a widget ', 1385040924);
INSERT INTO logs (`id`, `user_id`, `username`, `message`, `date`) VALUES (842, 48, 'admin', 'Cleared the cache', 1385040931);
INSERT INTO logs (`id`, `user_id`, `username`, `message`, `date`) VALUES (843, 48, 'admin', 'Changed the page <a href=\"http://beautiful_cars.loc/admin/pages/edit/91\">Как раскрутить сайт? Методы поискового продвижения</a>', 1385041871);
INSERT INTO logs (`id`, `user_id`, `username`, `message`, `date`) VALUES (844, 48, 'admin', 'Changed the page <a href=\"http://beautiful_cars.loc/admin/pages/edit/92\">Как добавить сайт в Яндекс и Гугл. Советы начинающим вебмастерам</a>', 1385041877);
INSERT INTO logs (`id`, `user_id`, `username`, `message`, `date`) VALUES (845, 48, 'admin', 'Changed the page <a href=\"http://beautiful_cars.loc/admin/pages/edit/93\">8Р: Бизнес в сети</a>', 1385041886);
INSERT INTO logs (`id`, `user_id`, `username`, `message`, `date`) VALUES (846, 48, 'admin', 'Deleted ID category or ID category has been deleted 70', 1385041921);
INSERT INTO logs (`id`, `user_id`, `username`, `message`, `date`) VALUES (847, 48, 'admin', 'Changed the category <a href=\"/admin/categories/edit/69\"> Новости</a>', 1385041981);
INSERT INTO logs (`id`, `user_id`, `username`, `message`, `date`) VALUES (848, 48, 'admin', 'Changed the page <a href=\"http://beautiful_cars.loc/admin/pages/edit/91\">Подбор автошин самостоятельно, автоматический сервис</a>', 1385042067);
INSERT INTO logs (`id`, `user_id`, `username`, `message`, `date`) VALUES (849, 48, 'admin', 'Changed the page <a href=\"http://beautiful_cars.loc/admin/pages/edit/92\">Минимальные цены, оперативная бесплатная доставка по Украине</a>', 1385042102);
INSERT INTO logs (`id`, `user_id`, `username`, `message`, `date`) VALUES (850, 48, 'admin', 'Changed the page <a href=\"http://beautiful_cars.loc/admin/pages/edit/93\">Срок эксплуатации дорогих шин намного больше, чем дешевых</a>', 1385042134);
INSERT INTO logs (`id`, `user_id`, `username`, `message`, `date`) VALUES (851, 48, 'admin', 'Cleared the cache', 1385042247);
INSERT INTO logs (`id`, `user_id`, `username`, `message`, `date`) VALUES (852, 48, 'admin', 'Deleted a module shop_news', 1385042342);
INSERT INTO logs (`id`, `user_id`, `username`, `message`, `date`) VALUES (853, 48, 'admin', 'Installed a module shop_news', 1385042364);
INSERT INTO logs (`id`, `user_id`, `username`, `message`, `date`) VALUES (854, 48, 'admin', 'Cleared the cache', 1385042457);
INSERT INTO logs (`id`, `user_id`, `username`, `message`, `date`) VALUES (855, 48, 'admin', 'Entered the IP control panel 127.0.0.1', 1385046117);
INSERT INTO logs (`id`, `user_id`, `username`, `message`, `date`) VALUES (856, 48, 'admin', 'Cleared the cache', 1385046596);
INSERT INTO logs (`id`, `user_id`, `username`, `message`, `date`) VALUES (857, 48, 'admin', 'Cleared the cache', 1385046596);
INSERT INTO logs (`id`, `user_id`, `username`, `message`, `date`) VALUES (858, 48, 'admin', 'Changed wesite settings', 1385050297);
INSERT INTO logs (`id`, `user_id`, `username`, `message`, `date`) VALUES (859, 48, 'admin', 'Changed wesite settings', 1385050605);
INSERT INTO logs (`id`, `user_id`, `username`, `message`, `date`) VALUES (860, 48, 'admin', 'Cleared the cache', 1385052842);
INSERT INTO logs (`id`, `user_id`, `username`, `message`, `date`) VALUES (861, 48, 'admin', 'Cleared the cache', 1385053434);
INSERT INTO logs (`id`, `user_id`, `username`, `message`, `date`) VALUES (862, 48, 'admin', 'Cleared the cache', 1385053434);
INSERT INTO logs (`id`, `user_id`, `username`, `message`, `date`) VALUES (863, 48, 'admin', 'Entered the IP control panel 127.0.0.1', 1385110294);
INSERT INTO logs (`id`, `user_id`, `username`, `message`, `date`) VALUES (864, 48, 'admin', 'Cleared the cache', 1385117356);
INSERT INTO logs (`id`, `user_id`, `username`, `message`, `date`) VALUES (865, 48, 'admin', 'Cleared the cache', 1385117357);
INSERT INTO logs (`id`, `user_id`, `username`, `message`, `date`) VALUES (866, 48, 'admin', 'Cleared the cache', 1385126261);
INSERT INTO logs (`id`, `user_id`, `username`, `message`, `date`) VALUES (867, 48, 'admin', 'Cleared the cache', 1385126261);
INSERT INTO logs (`id`, `user_id`, `username`, `message`, `date`) VALUES (868, 48, 'admin', 'Cleared the cache', 1385133925);
INSERT INTO logs (`id`, `user_id`, `username`, `message`, `date`) VALUES (869, 48, 'admin', 'Cleared the cache', 1385134752);
INSERT INTO logs (`id`, `user_id`, `username`, `message`, `date`) VALUES (870, 48, 'admin', 'Cleared the cache', 1385134752);
INSERT INTO logs (`id`, `user_id`, `username`, `message`, `date`) VALUES (871, 48, 'admin', 'Entered the IP control panel 127.0.0.1', 1385382379);
INSERT INTO logs (`id`, `user_id`, `username`, `message`, `date`) VALUES (872, 48, 'admin', 'Cleared the cache', 1385390395);
INSERT INTO logs (`id`, `user_id`, `username`, `message`, `date`) VALUES (873, 48, 'admin', 'Cleared the cache', 1385390396);
INSERT INTO logs (`id`, `user_id`, `username`, `message`, `date`) VALUES (874, 48, 'admin', 'Cleared the cache', 1385392334);
INSERT INTO logs (`id`, `user_id`, `username`, `message`, `date`) VALUES (875, 48, 'admin', 'Cleared the cache', 1385392334);
INSERT INTO logs (`id`, `user_id`, `username`, `message`, `date`) VALUES (876, 48, 'admin', 'Cleared the cache', 1385394301);
INSERT INTO logs (`id`, `user_id`, `username`, `message`, `date`) VALUES (877, 48, 'admin', 'Changed a widget ', 1385472671);
INSERT INTO logs (`id`, `user_id`, `username`, `message`, `date`) VALUES (878, 48, 'admin', 'Changed a widget ', 1385473540);
INSERT INTO logs (`id`, `user_id`, `username`, `message`, `date`) VALUES (879, 48, 'admin', 'Cleared the cache', 1385483613);
INSERT INTO logs (`id`, `user_id`, `username`, `message`, `date`) VALUES (880, 48, 'admin', 'Cleared the cache', 1385483614);
INSERT INTO logs (`id`, `user_id`, `username`, `message`, `date`) VALUES (881, 48, 'admin', 'Cleared the cache', 1385484961);
INSERT INTO logs (`id`, `user_id`, `username`, `message`, `date`) VALUES (882, 48, 'admin', 'Cleared the cache', 1385484962);
INSERT INTO logs (`id`, `user_id`, `username`, `message`, `date`) VALUES (883, 48, 'admin', 'Cleared the cache', 1385485023);
INSERT INTO logs (`id`, `user_id`, `username`, `message`, `date`) VALUES (884, 48, 'admin', 'Cleared the cache', 1385485024);
INSERT INTO logs (`id`, `user_id`, `username`, `message`, `date`) VALUES (885, 48, 'admin', 'Cleared the cache', 1385638907);
INSERT INTO logs (`id`, `user_id`, `username`, `message`, `date`) VALUES (886, 48, 'admin', 'Cleared the cache', 1385638908);
INSERT INTO logs (`id`, `user_id`, `username`, `message`, `date`) VALUES (887, 48, 'admin', 'Cleared the cache', 1385639338);
INSERT INTO logs (`id`, `user_id`, `username`, `message`, `date`) VALUES (888, 48, 'admin', 'Cleared the cache', 1385639339);
INSERT INTO logs (`id`, `user_id`, `username`, `message`, `date`) VALUES (889, 48, 'admin', 'Cleared the cache', 1385640460);
INSERT INTO logs (`id`, `user_id`, `username`, `message`, `date`) VALUES (890, 48, 'admin', 'Cleared the cache', 1385640460);
INSERT INTO logs (`id`, `user_id`, `username`, `message`, `date`) VALUES (891, 48, 'admin', 'Cleared the cache', 1385644782);
INSERT INTO logs (`id`, `user_id`, `username`, `message`, `date`) VALUES (892, 48, 'admin', 'Cleared the cache', 1385644782);
INSERT INTO logs (`id`, `user_id`, `username`, `message`, `date`) VALUES (893, 48, 'admin', 'Cleared the cache', 1385652196);
INSERT INTO logs (`id`, `user_id`, `username`, `message`, `date`) VALUES (894, 48, 'admin', 'Cleared the cache', 1385652196);
INSERT INTO logs (`id`, `user_id`, `username`, `message`, `date`) VALUES (895, 48, 'admin', 'Cleared the cache', 1385716279);
INSERT INTO logs (`id`, `user_id`, `username`, `message`, `date`) VALUES (896, 48, 'admin', 'Cleared the cache', 1385716279);
INSERT INTO logs (`id`, `user_id`, `username`, `message`, `date`) VALUES (897, 48, 'admin', 'Cleared the cache', 1385725116);
INSERT INTO logs (`id`, `user_id`, `username`, `message`, `date`) VALUES (898, 48, 'admin', 'Cleared the cache', 1385725117);
INSERT INTO logs (`id`, `user_id`, `username`, `message`, `date`) VALUES (899, 48, 'admin', 'Cleared the cache', 1385728026);
INSERT INTO logs (`id`, `user_id`, `username`, `message`, `date`) VALUES (900, 48, 'admin', 'Cleared the cache', 1385728026);
INSERT INTO logs (`id`, `user_id`, `username`, `message`, `date`) VALUES (901, 48, 'admin', 'Cleared the cache', 1385728059);
INSERT INTO logs (`id`, `user_id`, `username`, `message`, `date`) VALUES (902, 48, 'admin', 'Cleared the cache', 1385728688);
INSERT INTO logs (`id`, `user_id`, `username`, `message`, `date`) VALUES (903, 48, 'admin', 'Cleared the cache', 1385728689);
INSERT INTO logs (`id`, `user_id`, `username`, `message`, `date`) VALUES (904, 48, 'admin', 'Cleared the cache', 1385728754);
INSERT INTO logs (`id`, `user_id`, `username`, `message`, `date`) VALUES (905, 48, 'admin', 'Cleared the cache', 1385728756);
INSERT INTO logs (`id`, `user_id`, `username`, `message`, `date`) VALUES (906, 48, 'admin', 'Cleared the cache', 1385729075);
INSERT INTO logs (`id`, `user_id`, `username`, `message`, `date`) VALUES (907, 48, 'admin', 'Cleared the cache', 1385729076);
INSERT INTO logs (`id`, `user_id`, `username`, `message`, `date`) VALUES (908, 48, 'admin', 'Cleared the cache', 1385729104);
INSERT INTO logs (`id`, `user_id`, `username`, `message`, `date`) VALUES (909, 48, 'admin', 'Cleared the cache', 1385729105);
INSERT INTO logs (`id`, `user_id`, `username`, `message`, `date`) VALUES (910, 48, 'admin', 'Cleared the cache', 1385729447);
INSERT INTO logs (`id`, `user_id`, `username`, `message`, `date`) VALUES (911, 48, 'admin', 'Cleared the cache', 1385729447);
INSERT INTO logs (`id`, `user_id`, `username`, `message`, `date`) VALUES (912, 48, 'admin', 'Cleared the cache', 1385729883);
INSERT INTO logs (`id`, `user_id`, `username`, `message`, `date`) VALUES (913, 48, 'admin', 'Entered the IP control panel 127.0.0.1', 1385737903);
INSERT INTO logs (`id`, `user_id`, `username`, `message`, `date`) VALUES (914, 48, 'admin', 'Cleared the cache', 1385737910);
INSERT INTO logs (`id`, `user_id`, `username`, `message`, `date`) VALUES (915, 48, 'admin', 'Cleared the cache', 1385737910);
INSERT INTO logs (`id`, `user_id`, `username`, `message`, `date`) VALUES (916, 48, 'admin', 'Entered the IP control panel 127.0.0.1', 1385740227);
INSERT INTO logs (`id`, `user_id`, `username`, `message`, `date`) VALUES (917, 48, 'admin', 'Cleared the cache', 1385740234);
INSERT INTO logs (`id`, `user_id`, `username`, `message`, `date`) VALUES (918, 48, 'admin', 'Cleared the cache', 1385740378);
INSERT INTO logs (`id`, `user_id`, `username`, `message`, `date`) VALUES (919, 48, 'admin', 'Entered the IP control panel 127.0.0.1', 1385742171);
INSERT INTO logs (`id`, `user_id`, `username`, `message`, `date`) VALUES (920, 48, 'admin', 'Entered the IP control panel 127.0.0.1', 1385974794);
INSERT INTO logs (`id`, `user_id`, `username`, `message`, `date`) VALUES (921, 48, 'admin', 'Changed the page <a href=\"http://beautiful_cars.loc/admin/pages/edit/64\">О компании</a>', 1385979135);
INSERT INTO logs (`id`, `user_id`, `username`, `message`, `date`) VALUES (922, 48, 'admin', 'Changed the page <a href=\"http://beautiful_cars.loc/admin/pages/edit/66\">Доставка и оплата</a>', 1385979170);
INSERT INTO logs (`id`, `user_id`, `username`, `message`, `date`) VALUES (923, 48, 'admin', 'Changed the page <a href=\"http://beautiful_cars.loc/admin/pages/edit/68\">Контакты</a>', 1385979223);
INSERT INTO logs (`id`, `user_id`, `username`, `message`, `date`) VALUES (924, 48, 'admin', 'Cleared the cache', 1385982640);
INSERT INTO logs (`id`, `user_id`, `username`, `message`, `date`) VALUES (925, 48, 'admin', 'Cleared the cache', 1385982641);
INSERT INTO logs (`id`, `user_id`, `username`, `message`, `date`) VALUES (926, 48, 'admin', 'Changed wesite settings', 1385984495);
INSERT INTO logs (`id`, `user_id`, `username`, `message`, `date`) VALUES (927, 48, 'admin', 'Cleared the cache', 1385986306);
INSERT INTO logs (`id`, `user_id`, `username`, `message`, `date`) VALUES (928, 48, 'admin', 'Cleared the cache', 1385986306);
INSERT INTO logs (`id`, `user_id`, `username`, `message`, `date`) VALUES (929, 48, 'admin', 'Cleared the cache', 1385986361);
INSERT INTO logs (`id`, `user_id`, `username`, `message`, `date`) VALUES (930, 48, 'admin', 'Cleared the cache', 1385986677);
INSERT INTO logs (`id`, `user_id`, `username`, `message`, `date`) VALUES (931, 48, 'admin', 'Cleared the cache', 1385987849);
INSERT INTO logs (`id`, `user_id`, `username`, `message`, `date`) VALUES (932, 48, 'admin', 'Cleared the cache', 1385988372);
INSERT INTO logs (`id`, `user_id`, `username`, `message`, `date`) VALUES (933, 48, 'admin', 'Cleared the cache', 1385988614);
INSERT INTO logs (`id`, `user_id`, `username`, `message`, `date`) VALUES (934, 48, 'admin', 'Cleared the cache', 1385988679);
INSERT INTO logs (`id`, `user_id`, `username`, `message`, `date`) VALUES (935, 48, 'admin', 'Cleared the cache', 1385988818);
INSERT INTO logs (`id`, `user_id`, `username`, `message`, `date`) VALUES (936, 48, 'admin', 'Cleared the cache', 1385988904);
INSERT INTO logs (`id`, `user_id`, `username`, `message`, `date`) VALUES (937, 48, 'admin', 'Cleared the cache', 1385988952);
INSERT INTO logs (`id`, `user_id`, `username`, `message`, `date`) VALUES (938, 48, 'admin', 'Cleared the cache', 1385989825);
INSERT INTO logs (`id`, `user_id`, `username`, `message`, `date`) VALUES (939, 48, 'admin', 'Cleared the cache', 1385989948);
INSERT INTO logs (`id`, `user_id`, `username`, `message`, `date`) VALUES (940, 48, 'admin', 'Cleared the cache', 1385990878);
INSERT INTO logs (`id`, `user_id`, `username`, `message`, `date`) VALUES (941, 48, 'admin', 'Cleared the cache', 1385991066);
INSERT INTO logs (`id`, `user_id`, `username`, `message`, `date`) VALUES (942, 48, 'admin', 'Cleared the cache', 1385991125);
INSERT INTO logs (`id`, `user_id`, `username`, `message`, `date`) VALUES (943, 48, 'admin', 'Cleared the cache', 1385991174);
INSERT INTO logs (`id`, `user_id`, `username`, `message`, `date`) VALUES (944, 48, 'admin', 'Cleared the cache', 1385991316);
INSERT INTO logs (`id`, `user_id`, `username`, `message`, `date`) VALUES (945, 48, 'admin', 'Cleared the cache', 1385991366);
INSERT INTO logs (`id`, `user_id`, `username`, `message`, `date`) VALUES (946, 48, 'admin', 'Cleared the cache', 1385991414);
INSERT INTO logs (`id`, `user_id`, `username`, `message`, `date`) VALUES (947, 48, 'admin', 'Changed the page <a href=\"http://beautiful_cars.loc/admin/pages/edit/64\">О компании</a>', 1385991825);
INSERT INTO logs (`id`, `user_id`, `username`, `message`, `date`) VALUES (948, 48, 'admin', 'Cleared the cache', 1385992004);
INSERT INTO logs (`id`, `user_id`, `username`, `message`, `date`) VALUES (949, 48, 'admin', 'Cleared the cache', 1385992423);
INSERT INTO logs (`id`, `user_id`, `username`, `message`, `date`) VALUES (950, 48, 'admin', 'Cleared the cache', 1385992931);
INSERT INTO logs (`id`, `user_id`, `username`, `message`, `date`) VALUES (951, 48, 'admin', 'Cleared the cache', 1385998280);
INSERT INTO logs (`id`, `user_id`, `username`, `message`, `date`) VALUES (952, 48, 'admin', 'Кэш очищен', 1385998620);
INSERT INTO logs (`id`, `user_id`, `username`, `message`, `date`) VALUES (953, 48, 'admin', 'Кэш очищен', 1385999603);
INSERT INTO logs (`id`, `user_id`, `username`, `message`, `date`) VALUES (954, 48, 'admin', 'Страница изменена <a href=\"http://beautiful-cars.siteimage.com.ua/admin/pages/edit/64\">О компании</a>', 1386001593);
INSERT INTO logs (`id`, `user_id`, `username`, `message`, `date`) VALUES (955, 48, 'admin', 'Введен IP панели управления 194.44.251.143', 1386230158);


#
# TABLE STRUCTURE FOR: mail
#

DROP TABLE IF EXISTS mail;

CREATE TABLE `mail` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `email` varchar(255) DEFAULT NULL,
  `date` int(15) DEFAULT NULL,
  PRIMARY KEY (`id`)
) ENGINE=MyISAM DEFAULT CHARSET=utf8;

#
# TABLE STRUCTURE FOR: menu_translate
#

DROP TABLE IF EXISTS menu_translate;

CREATE TABLE `menu_translate` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `item_id` int(11) NOT NULL,
  `lang_id` int(11) NOT NULL,
  `title` varchar(250) NOT NULL,
  PRIMARY KEY (`id`),
  KEY `item_id` (`item_id`),
  KEY `lang_id` (`lang_id`)
) ENGINE=MyISAM AUTO_INCREMENT=52 DEFAULT CHARSET=utf8;

INSERT INTO menu_translate (`id`, `item_id`, `lang_id`, `title`) VALUES (32, 8, 30, 'Home');
INSERT INTO menu_translate (`id`, `item_id`, `lang_id`, `title`) VALUES (31, 8, 3, 'Главная');
INSERT INTO menu_translate (`id`, `item_id`, `lang_id`, `title`) VALUES (6, 9, 30, 'About');
INSERT INTO menu_translate (`id`, `item_id`, `lang_id`, `title`) VALUES (5, 9, 3, 'О Магазине');
INSERT INTO menu_translate (`id`, `item_id`, `lang_id`, `title`) VALUES (7, 13, 3, 'Контакты');
INSERT INTO menu_translate (`id`, `item_id`, `lang_id`, `title`) VALUES (8, 13, 30, 'Contacts');
INSERT INTO menu_translate (`id`, `item_id`, `lang_id`, `title`) VALUES (11, 10, 3, 'Оплата');
INSERT INTO menu_translate (`id`, `item_id`, `lang_id`, `title`) VALUES (12, 10, 30, 'Delivery');
INSERT INTO menu_translate (`id`, `item_id`, `lang_id`, `title`) VALUES (15, 12, 3, 'Помощь');
INSERT INTO menu_translate (`id`, `item_id`, `lang_id`, `title`) VALUES (16, 12, 30, 'Help');
INSERT INTO menu_translate (`id`, `item_id`, `lang_id`, `title`) VALUES (17, 14, 3, 'Главная');
INSERT INTO menu_translate (`id`, `item_id`, `lang_id`, `title`) VALUES (18, 14, 30, 'Home');
INSERT INTO menu_translate (`id`, `item_id`, `lang_id`, `title`) VALUES (25, 18, 3, 'Контакты');
INSERT INTO menu_translate (`id`, `item_id`, `lang_id`, `title`) VALUES (26, 18, 30, 'Contacts');
INSERT INTO menu_translate (`id`, `item_id`, `lang_id`, `title`) VALUES (29, 19, 3, 'Главная');
INSERT INTO menu_translate (`id`, `item_id`, `lang_id`, `title`) VALUES (30, 19, 30, 'Home');
INSERT INTO menu_translate (`id`, `item_id`, `lang_id`, `title`) VALUES (33, 20, 3, 'Видео');
INSERT INTO menu_translate (`id`, `item_id`, `lang_id`, `title`) VALUES (34, 20, 30, 'Video');
INSERT INTO menu_translate (`id`, `item_id`, `lang_id`, `title`) VALUES (36, 21, 3, 'О магазине');
INSERT INTO menu_translate (`id`, `item_id`, `lang_id`, `title`) VALUES (37, 21, 30, 'About');
INSERT INTO menu_translate (`id`, `item_id`, `lang_id`, `title`) VALUES (38, 22, 3, 'Домашнее аудио');
INSERT INTO menu_translate (`id`, `item_id`, `lang_id`, `title`) VALUES (39, 22, 30, 'Home music');
INSERT INTO menu_translate (`id`, `item_id`, `lang_id`, `title`) VALUES (40, 23, 3, 'Доставка и оплата');
INSERT INTO menu_translate (`id`, `item_id`, `lang_id`, `title`) VALUES (41, 23, 30, 'Delivery');
INSERT INTO menu_translate (`id`, `item_id`, `lang_id`, `title`) VALUES (42, 24, 3, 'Фото и камеры');
INSERT INTO menu_translate (`id`, `item_id`, `lang_id`, `title`) VALUES (43, 24, 30, 'Photo and Camera');
INSERT INTO menu_translate (`id`, `item_id`, `lang_id`, `title`) VALUES (44, 25, 3, 'Помощь');
INSERT INTO menu_translate (`id`, `item_id`, `lang_id`, `title`) VALUES (45, 25, 30, 'Help');
INSERT INTO menu_translate (`id`, `item_id`, `lang_id`, `title`) VALUES (46, 26, 3, 'Домашняя электроника');
INSERT INTO menu_translate (`id`, `item_id`, `lang_id`, `title`) VALUES (47, 26, 30, 'Home Electronics');
INSERT INTO menu_translate (`id`, `item_id`, `lang_id`, `title`) VALUES (48, 27, 3, 'Контакты');
INSERT INTO menu_translate (`id`, `item_id`, `lang_id`, `title`) VALUES (49, 27, 30, 'Contacts');
INSERT INTO menu_translate (`id`, `item_id`, `lang_id`, `title`) VALUES (50, 28, 3, 'Авто музыка и видео');
INSERT INTO menu_translate (`id`, `item_id`, `lang_id`, `title`) VALUES (51, 28, 30, 'Auto Tabs');


#
# TABLE STRUCTURE FOR: menus
#

DROP TABLE IF EXISTS menus;

CREATE TABLE `menus` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `name` varchar(250) NOT NULL,
  `main_title` varchar(300) NOT NULL,
  `tpl` varchar(255) DEFAULT NULL,
  `expand_level` int(255) DEFAULT NULL,
  `description` text,
  `created` varchar(50) NOT NULL,
  PRIMARY KEY (`id`),
  KEY `name` (`name`)
) ENGINE=MyISAM AUTO_INCREMENT=13 DEFAULT CHARSET=utf8;

INSERT INTO menus (`id`, `name`, `main_title`, `tpl`, `expand_level`, `description`, `created`) VALUES (4, 'top_menu', 'Top menu', 'top_menu', 0, 'Меню в верхней части шаблона', '2012-05-11 14:53:24');
INSERT INTO menus (`id`, `name`, `main_title`, `tpl`, `expand_level`, `description`, `created`) VALUES (5, 'footer_menu', 'Footer menu', 'footer_menu', 0, 'Нижнее меню шаблона', '2012-05-25 11:43:06');
INSERT INTO menus (`id`, `name`, `main_title`, `tpl`, `expand_level`, `description`, `created`) VALUES (11, 'left_menu', 'left_menu', 'left_menu', 1, 'Меню в левой части шаблона', '2013-03-18 16:13:38');
INSERT INTO menus (`id`, `name`, `main_title`, `tpl`, `expand_level`, `description`, `created`) VALUES (12, 'footer_menu_mobile', 'footer_menu_mobile', '', 0, 'Меню нижней части мобильной версии', '2013-09-19 17:42:17');


#
# TABLE STRUCTURE FOR: menus_data
#

DROP TABLE IF EXISTS menus_data;

CREATE TABLE `menus_data` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `menu_id` int(9) NOT NULL,
  `item_id` int(9) NOT NULL,
  `item_type` varchar(15) NOT NULL,
  `item_image` varchar(255) DEFAULT NULL,
  `roles` text,
  `hidden` smallint(1) NOT NULL DEFAULT '0',
  `title` varchar(300) NOT NULL,
  `parent_id` int(9) NOT NULL,
  `position` smallint(5) DEFAULT NULL,
  `description` text,
  `add_data` text,
  PRIMARY KEY (`id`),
  KEY `menu_id` (`menu_id`),
  KEY `position` (`position`)
) ENGINE=MyISAM AUTO_INCREMENT=49 DEFAULT CHARSET=utf8;

INSERT INTO menus_data (`id`, `menu_id`, `item_id`, `item_type`, `item_image`, `roles`, `hidden`, `title`, `parent_id`, `position`, `description`, `add_data`) VALUES (48, 4, 97, 'page', '', '', 0, 'Гарантия и возврат', 0, 3, NULL, 'a:1:{s:7:\"newpage\";i:0;}');
INSERT INTO menus_data (`id`, `menu_id`, `item_id`, `item_type`, `item_image`, `roles`, `hidden`, `title`, `parent_id`, `position`, `description`, `add_data`) VALUES (15, 4, 64, 'page', NULL, '', 0, 'О компании', 0, 1, NULL, 'a:2:{s:4:\"page\";N;s:7:\"newpage\";i:0;}');
INSERT INTO menus_data (`id`, `menu_id`, `item_id`, `item_type`, `item_image`, `roles`, `hidden`, `title`, `parent_id`, `position`, `description`, `add_data`) VALUES (16, 4, 66, 'page', NULL, '', 0, 'Доставка и оплата', 0, 2, NULL, 'a:2:{s:4:\"page\";N;s:7:\"newpage\";i:0;}');
INSERT INTO menus_data (`id`, `menu_id`, `item_id`, `item_type`, `item_image`, `roles`, `hidden`, `title`, `parent_id`, `position`, `description`, `add_data`) VALUES (17, 4, 67, 'page', NULL, '', 0, 'Система скидок', 0, 4, NULL, 'a:2:{s:4:\"page\";N;s:7:\"newpage\";i:0;}');
INSERT INTO menus_data (`id`, `menu_id`, `item_id`, `item_type`, `item_image`, `roles`, `hidden`, `title`, `parent_id`, `position`, `description`, `add_data`) VALUES (18, 4, 68, 'page', '', '', 0, 'Контакты', 0, 6, NULL, 'a:1:{s:7:\"newpage\";s:1:\"0\";}');
INSERT INTO menus_data (`id`, `menu_id`, `item_id`, `item_type`, `item_image`, `roles`, `hidden`, `title`, `parent_id`, `position`, `description`, `add_data`) VALUES (19, 5, 0, 'url', '', '', 0, 'Главная', 0, 1, NULL, 'a:2:{s:3:\"url\";s:1:\"/\";s:7:\"newpage\";s:1:\"0\";}');
INSERT INTO menus_data (`id`, `menu_id`, `item_id`, `item_type`, `item_image`, `roles`, `hidden`, `title`, `parent_id`, `position`, `description`, `add_data`) VALUES (20, 5, 0, 'url', '', '', 0, 'Видео', 0, 2, NULL, 'a:2:{s:3:\"url\";s:20:\"/shop/category/video\";s:7:\"newpage\";s:1:\"0\";}');
INSERT INTO menus_data (`id`, `menu_id`, `item_id`, `item_type`, `item_image`, `roles`, `hidden`, `title`, `parent_id`, `position`, `description`, `add_data`) VALUES (21, 5, 64, 'page', '', '', 0, 'О магазине', 0, 3, NULL, 'a:1:{s:7:\"newpage\";s:1:\"0\";}');
INSERT INTO menus_data (`id`, `menu_id`, `item_id`, `item_type`, `item_image`, `roles`, `hidden`, `title`, `parent_id`, `position`, `description`, `add_data`) VALUES (22, 5, 0, 'url', '', '', 0, 'Домашнее  аудио', 0, 4, NULL, 'a:2:{s:3:\"url\";s:30:\"/shop/category/domashnee_audio\";s:7:\"newpage\";s:1:\"0\";}');
INSERT INTO menus_data (`id`, `menu_id`, `item_id`, `item_type`, `item_image`, `roles`, `hidden`, `title`, `parent_id`, `position`, `description`, `add_data`) VALUES (23, 5, 66, 'page', '', '', 0, 'Доставка и оплата', 0, 5, NULL, 'a:1:{s:7:\"newpage\";s:1:\"0\";}');
INSERT INTO menus_data (`id`, `menu_id`, `item_id`, `item_type`, `item_image`, `roles`, `hidden`, `title`, `parent_id`, `position`, `description`, `add_data`) VALUES (24, 5, 0, 'url', '', '', 0, 'Фото и камеры', 0, 6, NULL, 'a:2:{s:3:\"url\";s:28:\"/shop/category/foto_i_kamery\";s:7:\"newpage\";s:1:\"0\";}');
INSERT INTO menus_data (`id`, `menu_id`, `item_id`, `item_type`, `item_image`, `roles`, `hidden`, `title`, `parent_id`, `position`, `description`, `add_data`) VALUES (25, 5, 67, 'page', '', '', 0, 'Помощь', 0, 7, NULL, 'a:1:{s:7:\"newpage\";s:1:\"0\";}');
INSERT INTO menus_data (`id`, `menu_id`, `item_id`, `item_type`, `item_image`, `roles`, `hidden`, `title`, `parent_id`, `position`, `description`, `add_data`) VALUES (26, 5, 0, 'url', '', '', 0, 'Домашняя электроника', 0, 8, NULL, 'a:2:{s:3:\"url\";s:38:\"/shop/category/domashniaia_elektronika\";s:7:\"newpage\";s:1:\"0\";}');
INSERT INTO menus_data (`id`, `menu_id`, `item_id`, `item_type`, `item_image`, `roles`, `hidden`, `title`, `parent_id`, `position`, `description`, `add_data`) VALUES (27, 5, 68, 'page', '', '', 0, 'Контакты', 0, 9, NULL, 'a:1:{s:7:\"newpage\";s:1:\"0\";}');
INSERT INTO menus_data (`id`, `menu_id`, `item_id`, `item_type`, `item_image`, `roles`, `hidden`, `title`, `parent_id`, `position`, `description`, `add_data`) VALUES (28, 5, 0, 'url', '', '', 0, 'Авто музыка и видео', 0, 10, NULL, 'a:2:{s:3:\"url\";s:34:\"/shop/category/avto_muzyka_i_video\";s:7:\"newpage\";s:1:\"0\";}');
INSERT INTO menus_data (`id`, `menu_id`, `item_id`, `item_type`, `item_image`, `roles`, `hidden`, `title`, `parent_id`, `position`, `description`, `add_data`) VALUES (37, 11, 69, 'category', NULL, '', 0, 'Новости', 0, 2, NULL, 'N;');
INSERT INTO menus_data (`id`, `menu_id`, `item_id`, `item_type`, `item_image`, `roles`, `hidden`, `title`, `parent_id`, `position`, `description`, `add_data`) VALUES (39, 11, 71, 'category', NULL, '', 0, 'Архив', 37, 2, NULL, 'a:1:{s:7:\"newpage\";i:0;}');
INSERT INTO menus_data (`id`, `menu_id`, `item_id`, `item_type`, `item_image`, `roles`, `hidden`, `title`, `parent_id`, `position`, `description`, `add_data`) VALUES (40, 4, 69, 'category', NULL, '', 0, 'Новости', 0, 5, NULL, 'a:1:{s:7:\"newpage\";i:0;}');
INSERT INTO menus_data (`id`, `menu_id`, `item_id`, `item_type`, `item_image`, `roles`, `hidden`, `title`, `parent_id`, `position`, `description`, `add_data`) VALUES (41, 11, 64, 'page', NULL, 'a:1:{i:0;s:1:\"0\";}', 0, 'О магазине', 0, 6, NULL, 'a:2:{s:4:\"page\";N;s:7:\"newpage\";i:0;}');
INSERT INTO menus_data (`id`, `menu_id`, `item_id`, `item_type`, `item_image`, `roles`, `hidden`, `title`, `parent_id`, `position`, `description`, `add_data`) VALUES (42, 11, 66, 'page', NULL, '', 0, 'Доставка', 0, 3, NULL, 'a:1:{s:7:\"newpage\";i:0;}');
INSERT INTO menus_data (`id`, `menu_id`, `item_id`, `item_type`, `item_image`, `roles`, `hidden`, `title`, `parent_id`, `position`, `description`, `add_data`) VALUES (43, 11, 67, 'page', NULL, '', 0, 'Помощь', 0, 4, NULL, 'a:1:{s:7:\"newpage\";i:0;}');
INSERT INTO menus_data (`id`, `menu_id`, `item_id`, `item_type`, `item_image`, `roles`, `hidden`, `title`, `parent_id`, `position`, `description`, `add_data`) VALUES (44, 12, 67, 'page', '', '', 0, 'Помощь', 0, 2, NULL, 'a:1:{s:7:\"newpage\";i:0;}');
INSERT INTO menus_data (`id`, `menu_id`, `item_id`, `item_type`, `item_image`, `roles`, `hidden`, `title`, `parent_id`, `position`, `description`, `add_data`) VALUES (45, 12, 65, 'page', '', '', 0, 'Оплата', 0, 3, NULL, 'a:1:{s:7:\"newpage\";i:0;}');
INSERT INTO menus_data (`id`, `menu_id`, `item_id`, `item_type`, `item_image`, `roles`, `hidden`, `title`, `parent_id`, `position`, `description`, `add_data`) VALUES (46, 12, 35, 'page', '', '', 0, 'О сайте', 0, 4, NULL, 'a:1:{s:7:\"newpage\";i:0;}');
INSERT INTO menus_data (`id`, `menu_id`, `item_id`, `item_type`, `item_image`, `roles`, `hidden`, `title`, `parent_id`, `position`, `description`, `add_data`) VALUES (47, 12, 66, 'page', '', '', 0, 'Доставка', 0, 5, NULL, 'a:1:{s:7:\"newpage\";i:0;}');


#
# TABLE STRUCTURE FOR: mod_banner
#

DROP TABLE IF EXISTS mod_banner;

CREATE TABLE `mod_banner` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `active` tinyint(4) NOT NULL,
  `active_to` int(11) DEFAULT NULL,
  `where_show` text,
  `position` int(11) NOT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB AUTO_INCREMENT=6 DEFAULT CHARSET=utf8;

INSERT INTO mod_banner (`id`, `active`, `active_to`, `where_show`, `position`) VALUES (4, 1, 1409950800, 'a:1:{i:0;s:6:\"main_0\";}', 0);
INSERT INTO mod_banner (`id`, `active`, `active_to`, `where_show`, `position`) VALUES (5, 1, 1410555600, 'a:1:{i:0;s:6:\"main_0\";}', 0);


#
# TABLE STRUCTURE FOR: mod_banner_i18n
#

DROP TABLE IF EXISTS mod_banner_i18n;

CREATE TABLE `mod_banner_i18n` (
  `id` int(11) NOT NULL,
  `url` text,
  `locale` varchar(5) NOT NULL,
  `name` varchar(25) DEFAULT NULL,
  `description` text,
  `photo` varchar(255) DEFAULT NULL,
  KEY `id` (`id`,`locale`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8;

INSERT INTO mod_banner_i18n (`id`, `url`, `locale`, `name`, `description`, `photo`) VALUES (4, '', 'ru', 'shuny_cumfo', '', '/uploads/shop/banners/shuny_kunfo.jpg');
INSERT INTO mod_banner_i18n (`id`, `url`, `locale`, `name`, `description`, `photo`) VALUES (5, '', 'ru', 'shuny_cumfo_copy', '', '/uploads/shop/banners/shuny_kunfo.jpg');


#
# TABLE STRUCTURE FOR: mod_discount_all_order
#

DROP TABLE IF EXISTS mod_discount_all_order;

CREATE TABLE `mod_discount_all_order` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `for_autorized` tinyint(4) DEFAULT NULL,
  `discount_id` int(11) DEFAULT NULL,
  `is_gift` tinyint(4) DEFAULT NULL,
  `begin_value` float DEFAULT NULL,
  PRIMARY KEY (`id`),
  KEY `discount_id` (`discount_id`)
) ENGINE=MyISAM DEFAULT CHARSET=utf8;

#
# TABLE STRUCTURE FOR: mod_discount_brand
#

DROP TABLE IF EXISTS mod_discount_brand;

CREATE TABLE `mod_discount_brand` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `brand_id` int(11) DEFAULT NULL,
  `discount_id` int(11) DEFAULT NULL,
  PRIMARY KEY (`id`),
  KEY `discount_id` (`discount_id`),
  KEY `brand_id` (`brand_id`)
) ENGINE=MyISAM DEFAULT CHARSET=utf8;

#
# TABLE STRUCTURE FOR: mod_discount_category
#

DROP TABLE IF EXISTS mod_discount_category;

CREATE TABLE `mod_discount_category` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `category_id` int(11) DEFAULT NULL,
  `discount_id` int(11) DEFAULT NULL,
  PRIMARY KEY (`id`),
  KEY `discount_id` (`discount_id`),
  KEY `category_id` (`category_id`)
) ENGINE=MyISAM AUTO_INCREMENT=2 DEFAULT CHARSET=utf8;

INSERT INTO mod_discount_category (`id`, `category_id`, `discount_id`) VALUES (1, 40, 1);


#
# TABLE STRUCTURE FOR: mod_discount_comulativ
#

DROP TABLE IF EXISTS mod_discount_comulativ;

CREATE TABLE `mod_discount_comulativ` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `discount_id` int(11) DEFAULT NULL,
  `begin_value` int(11) DEFAULT NULL,
  `end_value` int(11) DEFAULT NULL,
  PRIMARY KEY (`id`),
  KEY `discount_id` (`discount_id`)
) ENGINE=MyISAM DEFAULT CHARSET=utf8;

#
# TABLE STRUCTURE FOR: mod_discount_group_user
#

DROP TABLE IF EXISTS mod_discount_group_user;

CREATE TABLE `mod_discount_group_user` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `group_id` int(11) DEFAULT NULL,
  `discount_id` int(11) DEFAULT NULL,
  PRIMARY KEY (`id`),
  KEY `discount_id` (`discount_id`),
  KEY `group_id` (`group_id`)
) ENGINE=MyISAM DEFAULT CHARSET=utf8;

#
# TABLE STRUCTURE FOR: mod_discount_product
#

DROP TABLE IF EXISTS mod_discount_product;

CREATE TABLE `mod_discount_product` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `product_id` int(11) DEFAULT NULL,
  `discount_id` int(11) DEFAULT NULL,
  PRIMARY KEY (`id`),
  KEY `discount_id` (`discount_id`),
  KEY `product_id` (`product_id`)
) ENGINE=MyISAM DEFAULT CHARSET=utf8;

#
# TABLE STRUCTURE FOR: mod_discount_user
#

DROP TABLE IF EXISTS mod_discount_user;

CREATE TABLE `mod_discount_user` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `user_id` int(11) DEFAULT NULL,
  `discount_id` int(11) DEFAULT NULL,
  PRIMARY KEY (`id`),
  KEY `discount_id` (`discount_id`),
  KEY `user_id` (`user_id`)
) ENGINE=MyISAM DEFAULT CHARSET=utf8;

#
# TABLE STRUCTURE FOR: mod_email_paterns
#

DROP TABLE IF EXISTS mod_email_paterns;

CREATE TABLE `mod_email_paterns` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `name` varchar(256) NOT NULL,
  `patern` text,
  `from` varchar(256) NOT NULL,
  `from_email` varchar(256) NOT NULL,
  `admin_email` varchar(256) NOT NULL,
  `type` enum('HTML','Text') NOT NULL DEFAULT 'HTML',
  `user_message_active` tinyint(1) NOT NULL,
  `admin_message_active` tinyint(1) NOT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB AUTO_INCREMENT=9 DEFAULT CHARSET=utf8;

INSERT INTO mod_email_paterns (`id`, `name`, `patern`, `from`, `from_email`, `admin_email`, `type`, `user_message_active`, `admin_message_active`) VALUES (1, 'make_order', '', 'Администрация сайта', 'no-replay@beautiful-cars.com.ua', '', 'HTML', 1, 1);
INSERT INTO mod_email_paterns (`id`, `name`, `patern`, `from`, `from_email`, `admin_email`, `type`, `user_message_active`, `admin_message_active`) VALUES (2, 'change_order_status', '', 'Администрация сайта', 'no-replay@beautiful-cars.com.ua', '', 'HTML', 1, 0);
INSERT INTO mod_email_paterns (`id`, `name`, `patern`, `from`, `from_email`, `admin_email`, `type`, `user_message_active`, `admin_message_active`) VALUES (3, 'notification_email', '', 'Администрация сайта', 'no-replay@beautiful-cars.com.ua', '', 'HTML', 1, 0);
INSERT INTO mod_email_paterns (`id`, `name`, `patern`, `from`, `from_email`, `admin_email`, `type`, `user_message_active`, `admin_message_active`) VALUES (4, 'create_user', '', 'Администрация сайта', 'no-replay@beautiful-cars.com.ua', '', 'HTML', 1, 1);
INSERT INTO mod_email_paterns (`id`, `name`, `patern`, `from`, `from_email`, `admin_email`, `type`, `user_message_active`, `admin_message_active`) VALUES (5, 'forgot_password', '', 'Администрация сайта', 'no-replay@shop.com', '', 'HTML', 1, 0);
INSERT INTO mod_email_paterns (`id`, `name`, `patern`, `from`, `from_email`, `admin_email`, `type`, `user_message_active`, `admin_message_active`) VALUES (6, 'change_password', '', 'Администрация сайта', 'no-replay@beautiful-cars.com.ua', '', 'HTML', 1, 0);
INSERT INTO mod_email_paterns (`id`, `name`, `patern`, `from`, `from_email`, `admin_email`, `type`, `user_message_active`, `admin_message_active`) VALUES (7, 'price_change', '', 'Администрация сайта', 'admin@beautiful-cars.com.ua', 'admin@local.loc', 'HTML', 1, 0);
INSERT INTO mod_email_paterns (`id`, `name`, `patern`, `from`, `from_email`, `admin_email`, `type`, `user_message_active`, `admin_message_active`) VALUES (8, 'wish_list', '', 'Администрация сайта', 'no-replay@beautiful-cars.com.ua', '', 'HTML', 1, 1);


#
# TABLE STRUCTURE FOR: mod_email_paterns_i18n
#

DROP TABLE IF EXISTS mod_email_paterns_i18n;

CREATE TABLE `mod_email_paterns_i18n` (
  `id` int(11) NOT NULL,
  `locale` varchar(5) NOT NULL,
  `theme` varchar(256) NOT NULL,
  `user_message` text NOT NULL,
  `admin_message` text NOT NULL,
  `description` text NOT NULL,
  `variables` text NOT NULL,
  PRIMARY KEY (`id`,`locale`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8;

INSERT INTO mod_email_paterns_i18n (`id`, `locale`, `theme`, `user_message`, `admin_message`, `description`, `variables`) VALUES (1, 'ru', 'Заказ товара', '<p>adsdasdasdasdasd</p>', '<p>Пользователь&nbsp;<span>$userName$ совершил заказ товара&nbsp;</span></p>\n<p><span><span>Email адрес: $userEmail$</span><br /><br /><span>Номер телефона: $userPhone$</span><br /><br /><span>Адрес доставки: $userDeliver$</span></span></p>', '<p><span>Уведомление покупателя о совершении заказа</span></p>', 'a:5:{s:10:\"$userName$\";s:31:\"Имя пользователя\";s:11:\"$userEmail$\";s:30:\"Email Пользователя\";s:11:\"$userPhone$\";s:39:\"Телефон Пользователя\";s:13:\"$userDeliver$\";s:27:\"Адрес доставки\";s:11:\"$orderLink$\";s:28:\"Ссылка на заказ\";}');
INSERT INTO mod_email_paterns_i18n (`id`, `locale`, `theme`, `user_message`, `admin_message`, `description`, `variables`) VALUES (2, 'ru', 'Смена статуса заказа', '<p><span>Здравствуйте, $userName$.</span><br /><br /><span>Статус вашего заказа изменен на&nbsp;<span>$status$</span></span><br /><br /><span>Вы указали следующие контактные данные:</span><br /><br /><span>Email адрес: $userEmail$</span><br /><br /><span>Номер телефона: $userPhone$</span><br /><br /><span>Адрес доставки: $userDeliver$</span><br /><br /><span>Менеджеры нашего магазина вскоре свяжутся с Вами и помогут с оформлением и оплатой товара.</span><br /><br /><span>Также, Вы можете всегда посмотреть за статусом Вашего заказа, перейдя по ссылке:&nbsp; $orderLink$.</span><br /><br /><span>Спасибо за ваш заказ, искренне Ваши, сотрудники ImageCMS Shop.</span><br /><br /><span>При возникновении любых вопросов, обращайтесь за телефонами:</span><br /><br /><span id=\"docs-internal-guid-2f7a5076-b326-40be-797c-5006dc01d975\"><span>80676520009</span></span>&nbsp;</p>', '', '<p>Смена статуса заказа</p>', 'a:4:{s:10:\"$userName$\";s:31:\"Имя пользователя\";s:11:\"$userEmail$\";s:30:\"Email Пользователя\";s:11:\"$orderLink$\";s:28:\"Ссылка на заказ\";s:8:\"$status$\";s:25:\"статус заказа\";}');
INSERT INTO mod_email_paterns_i18n (`id`, `locale`, `theme`, `user_message`, `admin_message`, `description`, `variables`) VALUES (3, 'ru', 'Уведомление', '<p><span>Здравствуйте, $userName$.</span><br /><br /><span>Статус товара $productName$&nbsp;за которым вы следите изменен на <span>$status$</span></span><br /><br /><span>Спасибо за ваш заказ, искренне Ваши, сотрудники ImageCMS Shop.</span><br /><br /><span>При возникновении любых вопросов, обращайтесь за телефонами:</span><br /><br /><span id=\"docs-internal-guid-2f7a5076-b326-40be-797c-5006dc01d975\"><span>80676520009</span></span></p>', '', '<p>Уведомление о появлении</p>', 'a:5:{s:10:\"$userName$\";s:31:\"Имя пользователя\";s:11:\"$userEmail$\";s:30:\"Email Пользователя\";s:13:\"$productName$\";s:33:\"Название продукта\";s:8:\"$status$\";s:12:\"Статус\";s:13:\"$productLink$\";s:32:\"Ссылка на продукт\";}');
INSERT INTO mod_email_paterns_i18n (`id`, `locale`, `theme`, `user_message`, `admin_message`, `description`, `variables`) VALUES (4, 'ru', 'Создание пользователя', '<p><span>Успешно пройдена реєстрация $user_name$&nbsp;</span></p>\n<p>Ваши данние:<br /><span>Пароль: $user_password$</span><br /><span>Адрес: &nbsp;$user_address$</span><br /><span>Email: $user_email$</span><br /><span>Телефон: $user_phone$</span></p>', '<p><span>Создан пользователь $user_name$:</span><br /><span>С паролем: $user_password$</span><br /><span>Адресом: &nbsp;$<span>user_</span>address$</span><br /><span>Email пользователя: $user_email$</span><br /><span>Телефон пользователя: $user_phone$</span></p>', '<p>Шаблон письма на создание пользователя</p>', 'a:6:{s:11:\"$user_name$\";s:31:\"Имя пользователя\";s:14:\"$user_address$\";s:35:\"Адрес пользователя\";s:15:\"$user_password$\";s:37:\"Пароль пользователя\";s:12:\"$user_phone$\";s:39:\"Телефон пользователя\";s:12:\"$user_email$\";s:30:\"Email пользователя\";}');
INSERT INTO mod_email_paterns_i18n (`id`, `locale`, `theme`, `user_message`, `admin_message`, `description`, `variables`) VALUES (5, 'ru', 'Восстановление пароля', '<p><span>Здравствуйте!</span><br /><br /><span>На сайте $webSiteName$ создан запрос на восстановление пароля для Вашего аккаунта.</span><br /><br /><span>Для завершения процедуры восстановления пароля перейдите по ссылке $resetPasswordUri$</span><br /><br /><span>Ваш новый пароль для входа: $password$</span><br /><br /><span>Если это письмо попало к Вам по ошибке просто проигнорируйте его.</span><br /><br /><span>При возникновении любых вопросов, обращайтесь по телефонам:</span><br /><br /><span id=\"docs-internal-guid-2f7a5076-b329-01d9-108f-a8511ac24f76\"><span>80676520009</span></span><br /><br /><span>---</span><br /><br /><span>С уважением,</span><br /><br /><span>сотрудники службы продаж $webSiteName$</span></p>', '', '<p>Шаблон письма на восстановление пароля</p>', 'a:5:{s:13:\"$webSiteName$\";s:17:\"Имя сайта\";s:18:\"$resetPasswordUri$\";s:57:\"Ссилка на восстановления пароля\";s:10:\"$password$\";s:12:\"Пароль\";s:5:\"$key$\";s:8:\"Ключ\";s:16:\"$webMasterEmail$\";s:52:\"Email сотрудникjd службы продаж\";}');
INSERT INTO mod_email_paterns_i18n (`id`, `locale`, `theme`, `user_message`, `admin_message`, `description`, `variables`) VALUES (6, 'ru', 'Смена пароля', '<p><span>Здравствуйте $user_name$!</span><br /><br /><span>Ваш новый пароль для входа: $password$</span><br /><br /><span>Если это письмо попало к Вам по ошибке просто проигнорируйте его.</span><br /><br /><span><br /></span></p>', '', '<p>Шаблон письма изменения пароля</p>', 'a:2:{s:11:\"$user_name$\";s:31:\"Имя пользователя\";s:10:\"$password$\";s:23:\"Новий пароль\";}');
INSERT INTO mod_email_paterns_i18n (`id`, `locale`, `theme`, `user_message`, `admin_message`, `description`, `variables`) VALUES (7, 'ru', 'Изменение цены', '<p>Цена на $name$ за которым вы следите на сайте $server$ изменилась.<br /> <a title=\"Посмотреть список слежения\" href=\"$list_url_look$\">Посмотреть список слежения</a><br /> <a title=\"Отписатся от слежения\" href=\"$delete_list_url_look$\">Отписатся от слежения</a></p>\n<div id=\"dc_vk_code\">&nbsp;</div>', '<p>&nbsp;</p>\n<div id=\"dc_vk_code\">&nbsp;</div>', '<p>Изменение цены</p>\n<div id=\"dc_vk_code\" style=\"display: none;\">&nbsp;</div>', '');
INSERT INTO mod_email_paterns_i18n (`id`, `locale`, `theme`, `user_message`, `admin_message`, `description`, `variables`) VALUES (7, 'ua', 'Ціна змінилася', '<p>Ціна на $name$ за яким Ви слідкуєте на сайті $server$ змінилася.<br /> <a title=\"Переглянути список слідкувань\" href=\"$list_url_look$\">Переглянути список слідкувань</a><br /> <a title=\"Відписатися від слідкування\" href=\"$delete_list_url_look$\">Відписатися від слідкування</a></p>\n<div id=\"dc_vk_code\"  none;\">&nbsp;</div>', '<p>&nbsp;</p>\n<div id=\"dc_vk_code\">&nbsp;</div>', '<p>Слідкування за ціною</p>\n<div id=\"dc_vk_code\" style=\"display: none;\">&nbsp;</div>', '');
INSERT INTO mod_email_paterns_i18n (`id`, `locale`, `theme`, `user_message`, `admin_message`, `description`, `variables`) VALUES (8, 'ru', 'Список Желаний', '<h2>Уважаемый $userName$.</h2>\n<p>Вы создали следующий список желаний $wishName$ null</p>\n<div>Ссылка на просмотр списка желаний -&nbsp;&nbsp; $wishLink$ <br /> Количество просмотров списка - $wishListViews$</div>', '<p>Пользователь&nbsp;<span>$userName$ совершил заказ товара&nbsp;</span></p>\n<p><span><span>Email адрес: $userEmail$</span><br /><br /><span>Номер телефона: $userPhone$</span><br /><br /><span>Адрес доставки: $userDeliver$</span></span></p>', '<p><span>Уведомление покупателя о совершении заказа</span></p>', 'a:4:{s:10:\"$userName$\";s:31:\"Имя пользователя\";s:10:\"$wishName$\";s:29:\"Название списка\";s:10:\"$wishLink$\";s:30:\"Ссилка на список\";s:15:\"$wishListViews$\";s:54:\"Количество просмотров списка\";}');


#
# TABLE STRUCTURE FOR: mod_new_level_columns
#

DROP TABLE IF EXISTS mod_new_level_columns;

CREATE TABLE `mod_new_level_columns` (
  `category_id` varchar(500) NOT NULL,
  `column` varchar(256) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8;

#
# TABLE STRUCTURE FOR: mod_new_level_product_properties_types
#

DROP TABLE IF EXISTS mod_new_level_product_properties_types;

CREATE TABLE `mod_new_level_product_properties_types` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `property_id` int(11) NOT NULL,
  `name` int(11) NOT NULL,
  `type` varchar(500) NOT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB AUTO_INCREMENT=12 DEFAULT CHARSET=utf8;

INSERT INTO mod_new_level_product_properties_types (`id`, `property_id`, `name`, `type`) VALUES (1, 29, 0, 'a:2:{i:0;s:6:\"scroll\";i:1;s:8:\"dropDown\";}');
INSERT INTO mod_new_level_product_properties_types (`id`, `property_id`, `name`, `type`) VALUES (4, 28, 0, 'a:2:{i:0;s:6:\"scroll\";i:1;s:8:\"dropDown\";}');
INSERT INTO mod_new_level_product_properties_types (`id`, `property_id`, `name`, `type`) VALUES (5, 45, 0, 'a:2:{i:0;s:6:\"scroll\";i:1;s:8:\"dropDown\";}');
INSERT INTO mod_new_level_product_properties_types (`id`, `property_id`, `name`, `type`) VALUES (6, 43, 0, 'a:2:{i:0;s:6:\"scroll\";i:1;s:8:\"dropDown\";}');
INSERT INTO mod_new_level_product_properties_types (`id`, `property_id`, `name`, `type`) VALUES (7, 46, 0, 'a:2:{i:0;s:6:\"scroll\";i:1;s:8:\"dropDown\";}');
INSERT INTO mod_new_level_product_properties_types (`id`, `property_id`, `name`, `type`) VALUES (8, 44, 0, 'a:2:{i:0;s:6:\"scroll\";i:1;s:8:\"dropDown\";}');
INSERT INTO mod_new_level_product_properties_types (`id`, `property_id`, `name`, `type`) VALUES (9, 47, 0, 'a:2:{i:0;s:6:\"scroll\";i:1;s:8:\"dropDown\";}');
INSERT INTO mod_new_level_product_properties_types (`id`, `property_id`, `name`, `type`) VALUES (10, 48, 0, 'a:2:{i:0;s:6:\"scroll\";i:1;s:8:\"dropDown\";}');
INSERT INTO mod_new_level_product_properties_types (`id`, `property_id`, `name`, `type`) VALUES (11, 42, 0, 'a:2:{i:0;s:6:\"scroll\";i:1;s:8:\"dropDown\";}');


#
# TABLE STRUCTURE FOR: mod_shop_discounts
#

DROP TABLE IF EXISTS mod_shop_discounts;

CREATE TABLE `mod_shop_discounts` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `key` varchar(25) DEFAULT NULL,
  `name` varchar(150) DEFAULT NULL,
  `active` tinyint(4) DEFAULT NULL,
  `max_apply` int(11) DEFAULT NULL,
  `count_apply` int(11) DEFAULT NULL,
  `date_begin` int(11) DEFAULT NULL,
  `date_end` int(11) DEFAULT NULL,
  `type_value` tinyint(4) DEFAULT NULL,
  `value` int(11) DEFAULT NULL,
  `type_discount` varchar(15) DEFAULT NULL,
  PRIMARY KEY (`id`),
  UNIQUE KEY `key_UNIQUE` (`key`)
) ENGINE=MyISAM AUTO_INCREMENT=2 DEFAULT CHARSET=utf8;

INSERT INTO mod_shop_discounts (`id`, `key`, `name`, `active`, `max_apply`, `count_apply`, `date_begin`, `date_end`, `type_value`, `value`, `type_discount`) VALUES (1, 'a63nx37d7srt7l10', NULL, 1, NULL, NULL, 1385071200, 0, 1, 2, 'category');


#
# TABLE STRUCTURE FOR: mod_shop_discounts_i18n
#

DROP TABLE IF EXISTS mod_shop_discounts_i18n;

CREATE TABLE `mod_shop_discounts_i18n` (
  `id` int(11) NOT NULL,
  `locale` varchar(5) NOT NULL,
  `name` varchar(150) DEFAULT NULL,
  PRIMARY KEY (`id`,`locale`)
) ENGINE=MyISAM DEFAULT CHARSET=utf8;

INSERT INTO mod_shop_discounts_i18n (`id`, `locale`, `name`) VALUES (1, 'ru', 'category');


#
# TABLE STRUCTURE FOR: mod_shop_news
#

DROP TABLE IF EXISTS mod_shop_news;

CREATE TABLE `mod_shop_news` (
  `content_id` int(11) NOT NULL,
  `shop_categories_ids` varchar(1000) NOT NULL
) ENGINE=MyISAM DEFAULT CHARSET=utf8;

#
# TABLE STRUCTURE FOR: mod_wish_list
#

DROP TABLE IF EXISTS mod_wish_list;

CREATE TABLE `mod_wish_list` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `title` varchar(254) NOT NULL,
  `description` text,
  `access` enum('public','private','shared') NOT NULL DEFAULT 'shared',
  `user_id` int(11) NOT NULL,
  `review_count` int(11) NOT NULL DEFAULT '0',
  `hash` varchar(16) NOT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB AUTO_INCREMENT=4 DEFAULT CHARSET=utf8;

INSERT INTO mod_wish_list (`id`, `title`, `description`, `access`, `user_id`, `review_count`, `hash`) VALUES (2, 'test', NULL, 'shared', 48, 0, '93b2d7350dac4194');
INSERT INTO mod_wish_list (`id`, `title`, `description`, `access`, `user_id`, `review_count`, `hash`) VALUES (3, 'test2', NULL, 'shared', 48, 0, '6dfb667783284422');


#
# TABLE STRUCTURE FOR: mod_wish_list_products
#

DROP TABLE IF EXISTS mod_wish_list_products;

CREATE TABLE `mod_wish_list_products` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `wish_list_id` int(11) NOT NULL,
  `variant_id` int(11) NOT NULL,
  `comment` text,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB AUTO_INCREMENT=19 DEFAULT CHARSET=utf8;

INSERT INTO mod_wish_list_products (`id`, `wish_list_id`, `variant_id`, `comment`) VALUES (10, 2, 217, NULL);
INSERT INTO mod_wish_list_products (`id`, `wish_list_id`, `variant_id`, `comment`) VALUES (11, 2, 219, NULL);
INSERT INTO mod_wish_list_products (`id`, `wish_list_id`, `variant_id`, `comment`) VALUES (12, 2, 94, NULL);
INSERT INTO mod_wish_list_products (`id`, `wish_list_id`, `variant_id`, `comment`) VALUES (13, 2, 113, NULL);
INSERT INTO mod_wish_list_products (`id`, `wish_list_id`, `variant_id`, `comment`) VALUES (14, 2, 92, NULL);
INSERT INTO mod_wish_list_products (`id`, `wish_list_id`, `variant_id`, `comment`) VALUES (15, 2, 105, NULL);
INSERT INTO mod_wish_list_products (`id`, `wish_list_id`, `variant_id`, `comment`) VALUES (16, 3, 114, NULL);
INSERT INTO mod_wish_list_products (`id`, `wish_list_id`, `variant_id`, `comment`) VALUES (17, 3, 98, NULL);
INSERT INTO mod_wish_list_products (`id`, `wish_list_id`, `variant_id`, `comment`) VALUES (18, 3, 82, NULL);


#
# TABLE STRUCTURE FOR: mod_wish_list_users
#

DROP TABLE IF EXISTS mod_wish_list_users;

CREATE TABLE `mod_wish_list_users` (
  `id` int(11) NOT NULL,
  `user_name` varchar(254) DEFAULT NULL,
  `user_image` text,
  `user_birthday` int(11) DEFAULT NULL,
  `description` text,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8;

INSERT INTO mod_wish_list_users (`id`, `user_name`, `user_image`, `user_birthday`, `description`) VALUES (48, 'admin', NULL, NULL, NULL);


#
# TABLE STRUCTURE FOR: propel_migration
#

DROP TABLE IF EXISTS propel_migration;

CREATE TABLE `propel_migration` (
  `version` int(11) DEFAULT '0'
) ENGINE=MyISAM DEFAULT CHARSET=utf8;

INSERT INTO propel_migration (`version`) VALUES (1363604832);


#
# TABLE STRUCTURE FOR: rating
#

DROP TABLE IF EXISTS rating;

CREATE TABLE `rating` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `id_type` varchar(25) DEFAULT NULL,
  `type` varchar(25) DEFAULT NULL,
  `votes` int(11) NOT NULL,
  `rating` int(11) NOT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8;

#
# TABLE STRUCTURE FOR: search
#

DROP TABLE IF EXISTS search;

CREATE TABLE `search` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `hash` varchar(264) NOT NULL,
  `datetime` int(11) NOT NULL,
  `where_array` text NOT NULL,
  `select_array` text NOT NULL,
  `table_name` varchar(100) NOT NULL,
  `order_by` text NOT NULL,
  `row_count` int(11) NOT NULL,
  `total_rows` int(11) NOT NULL,
  `ids` text NOT NULL,
  `search_title` varchar(250) NOT NULL,
  PRIMARY KEY (`id`),
  KEY `hash` (`hash`),
  KEY `datetime` (`datetime`)
) ENGINE=MyISAM AUTO_INCREMENT=11 DEFAULT CHARSET=utf8;

#
# TABLE STRUCTURE FOR: settings
#

DROP TABLE IF EXISTS settings;

CREATE TABLE `settings` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `s_name` varchar(50) NOT NULL,
  `create_keywords` varchar(25) NOT NULL,
  `create_description` varchar(25) NOT NULL,
  `create_cat_keywords` varchar(25) NOT NULL,
  `create_cat_description` varchar(25) NOT NULL,
  `add_site_name` int(1) NOT NULL,
  `add_site_name_to_cat` int(1) NOT NULL,
  `delimiter` varchar(5) NOT NULL,
  `editor_theme` varchar(10) NOT NULL,
  `site_template` varchar(50) NOT NULL,
  `site_offline` varchar(5) NOT NULL,
  `google_analytics_id` varchar(40) DEFAULT NULL,
  `main_type` varchar(50) NOT NULL,
  `main_page_id` int(11) NOT NULL,
  `main_page_cat` text NOT NULL,
  `main_page_module` varchar(50) NOT NULL,
  `sidepanel` varchar(5) NOT NULL,
  `lk` varchar(250) DEFAULT NULL,
  `lang_sel` varchar(15) NOT NULL DEFAULT 'russian_lang',
  `google_webmaster` varchar(200) DEFAULT NULL,
  `yandex_webmaster` varchar(200) DEFAULT NULL,
  `yandex_metric` varchar(11) NOT NULL,
  `ss` varchar(255) NOT NULL,
  `cat_list` varchar(10) NOT NULL,
  `text_editor` varchar(30) NOT NULL,
  `siteinfo` text NOT NULL,
  `update` text,
  `backup` text,
  PRIMARY KEY (`id`),
  KEY `s_name` (`s_name`)
) ENGINE=MyISAM AUTO_INCREMENT=5 DEFAULT CHARSET=utf8;

INSERT INTO settings (`id`, `s_name`, `create_keywords`, `create_description`, `create_cat_keywords`, `create_cat_description`, `add_site_name`, `add_site_name_to_cat`, `delimiter`, `editor_theme`, `site_template`, `site_offline`, `google_analytics_id`, `main_type`, `main_page_id`, `main_page_cat`, `main_page_module`, `sidepanel`, `lk`, `lang_sel`, `google_webmaster`, `yandex_webmaster`, `yandex_metric`, `ss`, `cat_list`, `text_editor`, `siteinfo`, `update`, `backup`) VALUES (2, 'main', 'auto', 'auto', '0', '0', 1, 1, '/', '0', 'newLevel', 'no', '', 'module', 69, '63', 'shop', '', '', 'russian_lang', '', '', '', '', 'yes', 'tinymce', 'a:7:{s:20:\"siteinfo_companytype\";s:68:\"© Интернет магазин автошин «Beautiful Cars»\";s:16:\"siteinfo_address\";s:0:\"\";s:18:\"siteinfo_mainphone\";s:46:\"+38 (067) <span class=\"f-w_b\">652 00 09</span>\";s:19:\"siteinfo_adminemail\";s:26:\"info@beautiful-cars.com.ua\";s:13:\"siteinfo_logo\";a:3:{s:8:\"newLevel\";a:2:{s:3:\"url\";s:63:\"http://image.loc/templates/newLevel/css/color_scheme_1/logo.png\";s:4:\"path\";s:46:\"templates/newLevel/css/color_scheme_1/logo.png\";}s:9:\"corporate\";a:2:{s:3:\"url\";s:52:\"http://image.loc/templates/corporate/images/logo.png\";s:4:\"path\";s:35:\"templates/corporate/images/logo.png\";}s:10:\"commerce4x\";a:2:{s:3:\"url\";s:53:\"http://image.loc/templates/commerce4x/images/logo.png\";s:4:\"path\";s:36:\"templates/commerce4x/images/logo.png\";}}s:16:\"siteinfo_favicon\";a:3:{s:8:\"newLevel\";a:2:{s:3:\"url\";s:66:\"http://image.loc/templates/newLevel/css/color_scheme_1/favicon.ico\";s:4:\"path\";s:49:\"templates/newLevel/css/color_scheme_1/favicon.ico\";}s:9:\"corporate\";a:2:{s:3:\"url\";s:55:\"http://image.loc/templates/corporate/images/favicon.png\";s:4:\"path\";s:38:\"templates/corporate/images/favicon.png\";}s:10:\"commerce4x\";a:2:{s:3:\"url\";s:56:\"http://image.loc/templates/commerce4x/images/favicon.png\";s:4:\"path\";s:39:\"templates/commerce4x/images/favicon.png\";}}s:8:\"contacts\";a:1:{s:5:\"Email\";s:26:\"info@beautiful-cars.com.ua\";}}', NULL, NULL);


#
# TABLE STRUCTURE FOR: settings_i18n
#

DROP TABLE IF EXISTS settings_i18n;

CREATE TABLE `settings_i18n` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `lang_ident` int(11) NOT NULL,
  `name` varchar(255) CHARACTER SET utf8 DEFAULT NULL,
  `short_name` varchar(255) CHARACTER SET utf8 DEFAULT NULL,
  `description` varchar(255) CHARACTER SET utf8 DEFAULT NULL,
  `keywords` varchar(255) CHARACTER SET utf8 DEFAULT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB AUTO_INCREMENT=2 DEFAULT CHARSET=latin1;

INSERT INTO settings_i18n (`id`, `lang_ident`, `name`, `short_name`, `description`, `keywords`) VALUES (1, 3, 'интернет магазин АВТОШИНЫ-beautiful cars', 'АВТОШИНЫ-beautiful cars', '', '');


#
# TABLE STRUCTURE FOR: shop_banners
#

DROP TABLE IF EXISTS shop_banners;

CREATE TABLE `shop_banners` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `position` smallint(6) DEFAULT NULL,
  `active` tinyint(1) DEFAULT NULL,
  `categories` text,
  `on_main` tinyint(1) DEFAULT NULL,
  `espdate` int(11) DEFAULT NULL,
  PRIMARY KEY (`id`),
  KEY `shop_banners_I_1` (`position`)
) ENGINE=MyISAM AUTO_INCREMENT=13 DEFAULT CHARSET=utf8;

INSERT INTO shop_banners (`id`, `position`, `active`, `categories`, `on_main`, `espdate`) VALUES (7, 23, 1, 'false', 1, 2147483647);
INSERT INTO shop_banners (`id`, `position`, `active`, `categories`, `on_main`, `espdate`) VALUES (11, 24, 1, 'false', 1, 2147457600);
INSERT INTO shop_banners (`id`, `position`, `active`, `categories`, `on_main`, `espdate`) VALUES (12, 25, 1, 'false', 1, 2147457600);


#
# TABLE STRUCTURE FOR: shop_banners_i18n
#

DROP TABLE IF EXISTS shop_banners_i18n;

CREATE TABLE `shop_banners_i18n` (
  `id` int(11) NOT NULL,
  `locale` varchar(5) NOT NULL,
  `name` varchar(255) DEFAULT NULL,
  `text` varchar(255) DEFAULT NULL,
  `url` varchar(255) NOT NULL,
  `image` varchar(255) DEFAULT NULL,
  PRIMARY KEY (`id`,`locale`)
) ENGINE=MyISAM DEFAULT CHARSET=utf8;

INSERT INTO shop_banners_i18n (`id`, `locale`, `name`, `text`, `url`, `image`) VALUES (12, 'ru', 'Samsung', ' ', '/shop/brand/samsung', 'template-imageshop-banner-3.jpg');
INSERT INTO shop_banners_i18n (`id`, `locale`, `name`, `text`, `url`, `image`) VALUES (7, 'ru', 'Epson', ' ', '/shop/brand/epson', 'template-imageshop-banner-1.jpg');
INSERT INTO shop_banners_i18n (`id`, `locale`, `name`, `text`, `url`, `image`) VALUES (11, 'ru', 'Sony', ' ', '/shop/brand/sony', 'template-imageshop-banner-2.jpg');


#
# TABLE STRUCTURE FOR: shop_brands
#

DROP TABLE IF EXISTS shop_brands;

CREATE TABLE `shop_brands` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `url` varchar(255) NOT NULL,
  `image` varchar(255) DEFAULT NULL,
  `position` smallint(6) NOT NULL,
  PRIMARY KEY (`id`),
  KEY `shop_brands_I_2` (`url`),
  KEY `shop_brands_I_1` (`url`)
) ENGINE=MyISAM AUTO_INCREMENT=51 DEFAULT CHARSET=utf8;

INSERT INTO shop_brands (`id`, `url`, `image`, `position`) VALUES (45, 'nokian-tyres', 'nokian-tyres.jpg', 0);
INSERT INTO shop_brands (`id`, `url`, `image`, `position`) VALUES (44, 'toyotires', 'toyotires.jpg', 0);
INSERT INTO shop_brands (`id`, `url`, `image`, `position`) VALUES (43, 'bridgestone', 'bridgestone.jpg', 0);
INSERT INTO shop_brands (`id`, `url`, `image`, `position`) VALUES (42, 'continental', 'continental.jpg', 0);
INSERT INTO shop_brands (`id`, `url`, `image`, `position`) VALUES (41, 'mishelin', 'mishelin.jpg', 0);
INSERT INTO shop_brands (`id`, `url`, `image`, `position`) VALUES (46, 'dunlop', 'dunlop.jpg', 0);
INSERT INTO shop_brands (`id`, `url`, `image`, `position`) VALUES (47, 'fulda', 'fulda.jpg', 0);
INSERT INTO shop_brands (`id`, `url`, `image`, `position`) VALUES (48, 'goodyear', 'goodyear.jpg', 0);
INSERT INTO shop_brands (`id`, `url`, `image`, `position`) VALUES (49, 'komhotyres', 'komhotyres.jpg', 0);
INSERT INTO shop_brands (`id`, `url`, `image`, `position`) VALUES (50, 'lassa', 'lassa.jpg', 0);


#
# TABLE STRUCTURE FOR: shop_brands_i18n
#

DROP TABLE IF EXISTS shop_brands_i18n;

CREATE TABLE `shop_brands_i18n` (
  `id` int(11) NOT NULL,
  `locale` varchar(5) NOT NULL,
  `name` varchar(500) NOT NULL,
  `description` text,
  `meta_title` varchar(255) DEFAULT NULL,
  `meta_description` varchar(255) DEFAULT NULL,
  `meta_keywords` varchar(255) DEFAULT NULL,
  PRIMARY KEY (`id`,`locale`),
  KEY `shop_brands_i18n_I_1` (`name`(333))
) ENGINE=MyISAM DEFAULT CHARSET=utf8;

INSERT INTO shop_brands_i18n (`id`, `locale`, `name`, `description`, `meta_title`, `meta_description`, `meta_keywords`) VALUES (43, 'ru', 'bridgestone', '', '', '', '');
INSERT INTO shop_brands_i18n (`id`, `locale`, `name`, `description`, `meta_title`, `meta_description`, `meta_keywords`) VALUES (44, 'ru', 'toyotires', '', '', '', '');
INSERT INTO shop_brands_i18n (`id`, `locale`, `name`, `description`, `meta_title`, `meta_description`, `meta_keywords`) VALUES (45, 'ru', 'nokian-tyres', '', '', '', '');
INSERT INTO shop_brands_i18n (`id`, `locale`, `name`, `description`, `meta_title`, `meta_description`, `meta_keywords`) VALUES (46, 'ru', 'dunlop', '', '', '', '');
INSERT INTO shop_brands_i18n (`id`, `locale`, `name`, `description`, `meta_title`, `meta_description`, `meta_keywords`) VALUES (47, 'ru', 'fulda', '', '', '', '');
INSERT INTO shop_brands_i18n (`id`, `locale`, `name`, `description`, `meta_title`, `meta_description`, `meta_keywords`) VALUES (48, 'ru', 'goodyear', '', '', '', '');
INSERT INTO shop_brands_i18n (`id`, `locale`, `name`, `description`, `meta_title`, `meta_description`, `meta_keywords`) VALUES (49, 'ru', 'komhotyres', '', '', '', '');
INSERT INTO shop_brands_i18n (`id`, `locale`, `name`, `description`, `meta_title`, `meta_description`, `meta_keywords`) VALUES (50, 'ru', 'lassa', '', '', '', '');
INSERT INTO shop_brands_i18n (`id`, `locale`, `name`, `description`, `meta_title`, `meta_description`, `meta_keywords`) VALUES (42, 'ru', 'continental', '', '', '', '');
INSERT INTO shop_brands_i18n (`id`, `locale`, `name`, `description`, `meta_title`, `meta_description`, `meta_keywords`) VALUES (41, 'ru', 'mishelin', '', '', '', '');


#
# TABLE STRUCTURE FOR: shop_callbacks
#

DROP TABLE IF EXISTS shop_callbacks;

CREATE TABLE `shop_callbacks` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `user_id` int(11) DEFAULT NULL,
  `status_id` int(11) DEFAULT NULL,
  `theme_id` varchar(255) DEFAULT NULL,
  `phone` varchar(255) DEFAULT NULL,
  `name` varchar(255) DEFAULT NULL,
  `comment` text,
  `date` int(11) DEFAULT NULL,
  PRIMARY KEY (`id`),
  KEY `shop_callbacks_I_1` (`user_id`),
  KEY `shop_callbacks_I_2` (`status_id`),
  KEY `shop_callbacks_I_3` (`theme_id`),
  KEY `shop_callbacks_I_4` (`date`)
) ENGINE=MyISAM AUTO_INCREMENT=4 DEFAULT CHARSET=utf8;

#
# TABLE STRUCTURE FOR: shop_callbacks_statuses
#

DROP TABLE IF EXISTS shop_callbacks_statuses;

CREATE TABLE `shop_callbacks_statuses` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `is_default` tinyint(1) DEFAULT NULL,
  PRIMARY KEY (`id`)
) ENGINE=MyISAM AUTO_INCREMENT=8 DEFAULT CHARSET=utf8;

INSERT INTO shop_callbacks_statuses (`id`, `is_default`) VALUES (1, 1);
INSERT INTO shop_callbacks_statuses (`id`, `is_default`) VALUES (3, 0);


#
# TABLE STRUCTURE FOR: shop_callbacks_statuses_i18n
#

DROP TABLE IF EXISTS shop_callbacks_statuses_i18n;

CREATE TABLE `shop_callbacks_statuses_i18n` (
  `id` int(11) NOT NULL,
  `locale` varchar(5) NOT NULL,
  `text` varchar(255) DEFAULT NULL,
  PRIMARY KEY (`id`,`locale`),
  KEY `shop_callbacks_statuses_i18n_I_1` (`text`)
) ENGINE=MyISAM DEFAULT CHARSET=utf8;

INSERT INTO shop_callbacks_statuses_i18n (`id`, `locale`, `text`) VALUES (1, 'ru', 'Новый');
INSERT INTO shop_callbacks_statuses_i18n (`id`, `locale`, `text`) VALUES (3, 'ru', 'Обработан');


#
# TABLE STRUCTURE FOR: shop_callbacks_themes
#

DROP TABLE IF EXISTS shop_callbacks_themes;

CREATE TABLE `shop_callbacks_themes` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `position` int(11) DEFAULT NULL,
  PRIMARY KEY (`id`)
) ENGINE=MyISAM AUTO_INCREMENT=9 DEFAULT CHARSET=utf8;

INSERT INTO shop_callbacks_themes (`id`, `position`) VALUES (1, 0);


#
# TABLE STRUCTURE FOR: shop_callbacks_themes_i18n
#

DROP TABLE IF EXISTS shop_callbacks_themes_i18n;

CREATE TABLE `shop_callbacks_themes_i18n` (
  `id` int(11) NOT NULL,
  `locale` varchar(5) NOT NULL,
  `text` varchar(255) DEFAULT NULL,
  PRIMARY KEY (`id`,`locale`),
  KEY `shop_callbacks_themes_i18n_I_1` (`text`)
) ENGINE=MyISAM DEFAULT CHARSET=utf8;

INSERT INTO shop_callbacks_themes_i18n (`id`, `locale`, `text`) VALUES (1, 'ru', 'Первая тема');
INSERT INTO shop_callbacks_themes_i18n (`id`, `locale`, `text`) VALUES (1, 'ua', 'Перша тема');


#
# TABLE STRUCTURE FOR: shop_category
#

DROP TABLE IF EXISTS shop_category;

CREATE TABLE `shop_category` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `url` varchar(255) NOT NULL,
  `parent_id` int(11) DEFAULT NULL,
  `position` int(11) DEFAULT NULL,
  `full_path` varchar(1000) DEFAULT NULL,
  `full_path_ids` varchar(250) DEFAULT NULL,
  `active` tinyint(1) DEFAULT NULL,
  `external_id` varchar(255) DEFAULT NULL,
  `image` varchar(255) DEFAULT NULL,
  `tpl` varchar(250) DEFAULT NULL,
  `order_method` int(11) DEFAULT NULL,
  `showsitetitle` int(11) DEFAULT NULL,
  PRIMARY KEY (`id`),
  KEY `shop_category_I_2` (`url`),
  KEY `shop_category_I_3` (`active`),
  KEY `shop_category_I_4` (`parent_id`),
  KEY `shop_category_I_5` (`position`),
  KEY `shop_category_I_1` (`url`),
  KEY `external_id` (`external_id`)
) ENGINE=MyISAM AUTO_INCREMENT=84 DEFAULT CHARSET=utf8;

INSERT INTO shop_category (`id`, `url`, `parent_id`, `position`, `full_path`, `full_path_ids`, `active`, `external_id`, `image`, `tpl`, `order_method`, `showsitetitle`) VALUES (46, 'zimnie', 44, 3, 'gruzovye-shiny/zimnie', 'a:1:{i:0;i:44;}', 1, NULL, 'zimn', '', 1, NULL);
INSERT INTO shop_category (`id`, `url`, `parent_id`, `position`, `full_path`, `full_path_ids`, `active`, `external_id`, `image`, `tpl`, `order_method`, `showsitetitle`) VALUES (45, 'vsesezonnye', 44, 2, 'gruzovye-shiny/vsesezonnye', 'a:1:{i:0;i:44;}', 1, NULL, 'vsesez', '', 1, NULL);
INSERT INTO shop_category (`id`, `url`, `parent_id`, `position`, `full_path`, `full_path_ids`, `active`, `external_id`, `image`, `tpl`, `order_method`, `showsitetitle`) VALUES (44, 'gruzovye-shiny', 0, 1, 'gruzovye-shiny', 'a:0:{}', 1, NULL, 'gryzov', '', 1, NULL);
INSERT INTO shop_category (`id`, `url`, `parent_id`, `position`, `full_path`, `full_path_ids`, `active`, `external_id`, `image`, `tpl`, `order_method`, `showsitetitle`) VALUES (43, 'zimnie', 40, 6, 'legkovye-shiny/zimnie', 'a:1:{i:0;i:40;}', 1, NULL, 'zimn', '', 1, NULL);
INSERT INTO shop_category (`id`, `url`, `parent_id`, `position`, `full_path`, `full_path_ids`, `active`, `external_id`, `image`, `tpl`, `order_method`, `showsitetitle`) VALUES (41, 'vsesezonnye', 40, 5, 'legkovye-shiny/vsesezonnye', 'a:1:{i:0;i:40;}', 1, NULL, 'vsesez', '', 1, NULL);
INSERT INTO shop_category (`id`, `url`, `parent_id`, `position`, `full_path`, `full_path_ids`, `active`, `external_id`, `image`, `tpl`, `order_method`, `showsitetitle`) VALUES (81, 'zimnie-pod-ship', 44, 4, 'gruzovye-shiny/zimnie-pod-ship', 'a:1:{i:0;i:44;}', 1, NULL, 'zimn-shup', '', 0, NULL);
INSERT INTO shop_category (`id`, `url`, `parent_id`, `position`, `full_path`, `full_path_ids`, `active`, `external_id`, `image`, `tpl`, `order_method`, `showsitetitle`) VALUES (40, 'legkovye-shiny', 0, 0, 'legkovye-shiny', 'a:0:{}', 1, NULL, 'lehkovue', '', 0, NULL);
INSERT INTO shop_category (`id`, `url`, `parent_id`, `position`, `full_path`, `full_path_ids`, `active`, `external_id`, `image`, `tpl`, `order_method`, `showsitetitle`) VALUES (78, 'zimnie-pod-ship', 40, 17, 'legkovye-shiny/zimnie-pod-ship', 'a:1:{i:0;i:40;}', 1, NULL, 'zimn-shup', '', 0, NULL);
INSERT INTO shop_category (`id`, `url`, `parent_id`, `position`, `full_path`, `full_path_ids`, `active`, `external_id`, `image`, `tpl`, `order_method`, `showsitetitle`) VALUES (79, 'zimnie-shipovinnye', 40, 18, 'legkovye-shiny/zimnie-shipovinnye', 'a:1:{i:0;i:40;}', 1, NULL, 'zimn-shupov', '', 0, NULL);
INSERT INTO shop_category (`id`, `url`, `parent_id`, `position`, `full_path`, `full_path_ids`, `active`, `external_id`, `image`, `tpl`, `order_method`, `showsitetitle`) VALUES (80, 'letnie', 40, 19, 'legkovye-shiny/letnie', 'a:1:{i:0;i:40;}', 1, NULL, 'letnie', '', 0, NULL);
INSERT INTO shop_category (`id`, `url`, `parent_id`, `position`, `full_path`, `full_path_ids`, `active`, `external_id`, `image`, `tpl`, `order_method`, `showsitetitle`) VALUES (82, 'zimnie-shipovinnye', 44, 5, 'gruzovye-shiny/zimnie-shipovinnye', 'a:1:{i:0;i:44;}', 1, NULL, 'zimn-shupov', '', 0, NULL);
INSERT INTO shop_category (`id`, `url`, `parent_id`, `position`, `full_path`, `full_path_ids`, `active`, `external_id`, `image`, `tpl`, `order_method`, `showsitetitle`) VALUES (83, 'letnie', 44, 6, 'gruzovye-shiny/letnie', 'a:1:{i:0;i:44;}', 1, NULL, 'letnie', '', 0, NULL);


#
# TABLE STRUCTURE FOR: shop_category_i18n
#

DROP TABLE IF EXISTS shop_category_i18n;

CREATE TABLE `shop_category_i18n` (
  `id` int(11) NOT NULL,
  `locale` varchar(5) NOT NULL,
  `name` varchar(255) NOT NULL,
  `h1` varchar(255) NOT NULL,
  `description` text,
  `meta_desc` varchar(255) NOT NULL,
  `meta_title` varchar(255) NOT NULL,
  `meta_keywords` varchar(255) NOT NULL,
  PRIMARY KEY (`id`,`locale`),
  KEY `shop_category_i18n_I_1` (`name`)
) ENGINE=MyISAM DEFAULT CHARSET=utf8;

INSERT INTO shop_category_i18n (`id`, `locale`, `name`, `h1`, `description`, `meta_desc`, `meta_title`, `meta_keywords`) VALUES (46, 'ru', 'Зимние', '', '', '', '', '');
INSERT INTO shop_category_i18n (`id`, `locale`, `name`, `h1`, `description`, `meta_desc`, `meta_title`, `meta_keywords`) VALUES (45, 'ru', 'Всесезонные', '', '', '', '', '');
INSERT INTO shop_category_i18n (`id`, `locale`, `name`, `h1`, `description`, `meta_desc`, `meta_title`, `meta_keywords`) VALUES (44, 'ru', 'Грузовые шины', '', '', '', '', '');
INSERT INTO shop_category_i18n (`id`, `locale`, `name`, `h1`, `description`, `meta_desc`, `meta_title`, `meta_keywords`) VALUES (43, 'ru', 'Зимние', '', '', '', '', '');
INSERT INTO shop_category_i18n (`id`, `locale`, `name`, `h1`, `description`, `meta_desc`, `meta_title`, `meta_keywords`) VALUES (41, 'ru', 'Всесезонные', '', '', '', '', '');
INSERT INTO shop_category_i18n (`id`, `locale`, `name`, `h1`, `description`, `meta_desc`, `meta_title`, `meta_keywords`) VALUES (40, 'ru', 'Легковые шины', '', '<div class=\"title-h1\">Интернет-магазин автошин &laquo;Beautiful cars&raquo;</div>\r\n<div class=\"title-h2\">Что предлагает наш магазин и почему выгодно купить шины именно здесь?</div>\r\n<p>Купить шины в Украине, а особенно в Киеве, не составляет большой проблемы. Множество магазинов предлагают купить резину на авто от уже зарекомендовавших себя и менее известных производителей. Цены, как и уровень качества продукции, разные. Сейчас &laquo;обуть&raquo; своего железного коня можно за любые деньги. Что же покупают чаще? Анализ продаж за несколько последних лет свидетельствует о том, что большинство водителей, которые ездят на новых автомобилях, предпочитают купить шины по более высокой цене. Много автомобилистов в Украине покупают автошины по одному принципу: мы не такие богатые, чтобы покупать дешевые вещи.</p>\r\n<p>Во-первых, покупка фирменных шин &mdash; это не затраты, а разумные вложения, которые со временем обязательно окупятся. Качественные автошины обеспечивают лучшее сцепление с дорогой и сокращают тормозной путь. Выигранных несколько сантиметров на трассе значат очень много, и речь идет не только о стоимости поврежденного бампера дорогого автомобиля, но и о бесценной человеческой жизни.</p>', '', '', '');
INSERT INTO shop_category_i18n (`id`, `locale`, `name`, `h1`, `description`, `meta_desc`, `meta_title`, `meta_keywords`) VALUES (78, 'ru', 'Зимние под шип', '', '', '', '', '');
INSERT INTO shop_category_i18n (`id`, `locale`, `name`, `h1`, `description`, `meta_desc`, `meta_title`, `meta_keywords`) VALUES (79, 'ru', 'Зимние шиповинные', '', '', '', '', '');
INSERT INTO shop_category_i18n (`id`, `locale`, `name`, `h1`, `description`, `meta_desc`, `meta_title`, `meta_keywords`) VALUES (40, 'en', 'Home audio', '', '', '', '', '');
INSERT INTO shop_category_i18n (`id`, `locale`, `name`, `h1`, `description`, `meta_desc`, `meta_title`, `meta_keywords`) VALUES (41, 'en', 'Home Theater', '', '', '', '', '');
INSERT INTO shop_category_i18n (`id`, `locale`, `name`, `h1`, `description`, `meta_desc`, `meta_title`, `meta_keywords`) VALUES (43, 'en', 'Speakers', '', '', '', '', '');
INSERT INTO shop_category_i18n (`id`, `locale`, `name`, `h1`, `description`, `meta_desc`, `meta_title`, `meta_keywords`) VALUES (44, 'en', 'Photo & Camera', '', '', '', '', '');
INSERT INTO shop_category_i18n (`id`, `locale`, `name`, `h1`, `description`, `meta_desc`, `meta_title`, `meta_keywords`) VALUES (45, 'en', 'Digital cameras', '', '', '', '', '');
INSERT INTO shop_category_i18n (`id`, `locale`, `name`, `h1`, `description`, `meta_desc`, `meta_title`, `meta_keywords`) VALUES (46, 'en', 'Photo Printers', '', '', '', '', '');
INSERT INTO shop_category_i18n (`id`, `locale`, `name`, `h1`, `description`, `meta_desc`, `meta_title`, `meta_keywords`) VALUES (80, 'ru', 'Летние', '', '', '', '', '');
INSERT INTO shop_category_i18n (`id`, `locale`, `name`, `h1`, `description`, `meta_desc`, `meta_title`, `meta_keywords`) VALUES (81, 'ru', 'Зимние под шип', '', '', '', '', '');
INSERT INTO shop_category_i18n (`id`, `locale`, `name`, `h1`, `description`, `meta_desc`, `meta_title`, `meta_keywords`) VALUES (82, 'ru', 'Зимние шиповинные', '', '', '', '', '');
INSERT INTO shop_category_i18n (`id`, `locale`, `name`, `h1`, `description`, `meta_desc`, `meta_title`, `meta_keywords`) VALUES (83, 'ru', 'Летние', '', '', '', '', '');


#
# TABLE STRUCTURE FOR: shop_comulativ_discount
#

DROP TABLE IF EXISTS shop_comulativ_discount;

CREATE TABLE `shop_comulativ_discount` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `description` varchar(255) DEFAULT NULL,
  `discount` int(3) DEFAULT NULL,
  `active` int(1) DEFAULT NULL,
  `date` int(15) DEFAULT NULL,
  `total` int(255) DEFAULT NULL,
  `total_a` int(255) DEFAULT NULL,
  PRIMARY KEY (`id`)
) ENGINE=MyISAM AUTO_INCREMENT=12 DEFAULT CHARSET=utf8;

#
# TABLE STRUCTURE FOR: shop_currencies
#

DROP TABLE IF EXISTS shop_currencies;

CREATE TABLE `shop_currencies` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `name` varchar(255) DEFAULT NULL,
  `main` tinyint(1) DEFAULT NULL,
  `is_default` tinyint(1) DEFAULT NULL,
  `code` varchar(5) DEFAULT NULL,
  `symbol` varchar(5) DEFAULT NULL,
  `rate` float(6,3) DEFAULT '1.000',
  `showOnSite` int(1) DEFAULT '0',
  PRIMARY KEY (`id`),
  KEY `shop_currencies_I_1` (`name`),
  KEY `shop_currencies_I_2` (`main`),
  KEY `shop_currencies_I_3` (`is_default`)
) ENGINE=MyISAM AUTO_INCREMENT=5 DEFAULT CHARSET=utf8;

INSERT INTO shop_currencies (`id`, `name`, `main`, `is_default`, `code`, `symbol`, `rate`, `showOnSite`) VALUES (4, 'Гривні', 1, 1, 'UAH', 'грн', '1.000', 0);


#
# TABLE STRUCTURE FOR: shop_delivery_methods
#

DROP TABLE IF EXISTS shop_delivery_methods;

CREATE TABLE `shop_delivery_methods` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `price` float(10,2) NOT NULL,
  `free_from` float(10,2) NOT NULL,
  `enabled` tinyint(1) DEFAULT NULL,
  `is_price_in_percent` tinyint(1) NOT NULL,
  `position` int(11) DEFAULT NULL,
  PRIMARY KEY (`id`),
  KEY `shop_delivery_methods_I_2` (`enabled`),
  KEY `shop_delivery_methods_I_1` (`enabled`)
) ENGINE=MyISAM AUTO_INCREMENT=53 DEFAULT CHARSET=utf8;

INSERT INTO shop_delivery_methods (`id`, `price`, `free_from`, `enabled`, `is_price_in_percent`, `position`) VALUES (7, '0.00', '0.00', 1, 0, 0);
INSERT INTO shop_delivery_methods (`id`, `price`, `free_from`, `enabled`, `is_price_in_percent`, `position`) VALUES (6, '10.00', '0.00', 1, 0, 2);


#
# TABLE STRUCTURE FOR: shop_delivery_methods_i18n
#

DROP TABLE IF EXISTS shop_delivery_methods_i18n;

CREATE TABLE `shop_delivery_methods_i18n` (
  `id` int(11) NOT NULL,
  `locale` varchar(5) NOT NULL,
  `name` varchar(500) NOT NULL,
  `description` text,
  `pricedescription` text,
  PRIMARY KEY (`id`,`locale`),
  KEY `shop_delivery_methods_i18n_I_1` (`name`(333))
) ENGINE=MyISAM DEFAULT CHARSET=utf8;

INSERT INTO shop_delivery_methods_i18n (`id`, `locale`, `name`, `description`, `pricedescription`) VALUES (7, 'ru', 'Новая Почта:', '<p>доставка бесплатно</p>', '');
INSERT INTO shop_delivery_methods_i18n (`id`, `locale`, `name`, `description`, `pricedescription`) VALUES (6, 'ru', 'Ин-Тайм:', '<p>стоимость по тарифам перевозчика</p>', '');
INSERT INTO shop_delivery_methods_i18n (`id`, `locale`, `name`, `description`, `pricedescription`) VALUES (7, 'ua', 'Самовивезення', '', NULL);


#
# TABLE STRUCTURE FOR: shop_delivery_methods_systems
#

DROP TABLE IF EXISTS shop_delivery_methods_systems;

CREATE TABLE `shop_delivery_methods_systems` (
  `delivery_method_id` int(11) NOT NULL,
  `payment_method_id` int(11) NOT NULL,
  PRIMARY KEY (`delivery_method_id`,`payment_method_id`),
  KEY `shop_delivery_methods_systems_FI_2` (`payment_method_id`)
) ENGINE=MyISAM DEFAULT CHARSET=utf8;

INSERT INTO shop_delivery_methods_systems (`delivery_method_id`, `payment_method_id`) VALUES (6, 1);
INSERT INTO shop_delivery_methods_systems (`delivery_method_id`, `payment_method_id`) VALUES (6, 4);
INSERT INTO shop_delivery_methods_systems (`delivery_method_id`, `payment_method_id`) VALUES (7, 1);
INSERT INTO shop_delivery_methods_systems (`delivery_method_id`, `payment_method_id`) VALUES (7, 4);
INSERT INTO shop_delivery_methods_systems (`delivery_method_id`, `payment_method_id`) VALUES (15, 1);
INSERT INTO shop_delivery_methods_systems (`delivery_method_id`, `payment_method_id`) VALUES (16, 1);
INSERT INTO shop_delivery_methods_systems (`delivery_method_id`, `payment_method_id`) VALUES (16, 2);
INSERT INTO shop_delivery_methods_systems (`delivery_method_id`, `payment_method_id`) VALUES (16, 3);
INSERT INTO shop_delivery_methods_systems (`delivery_method_id`, `payment_method_id`) VALUES (20, 1);
INSERT INTO shop_delivery_methods_systems (`delivery_method_id`, `payment_method_id`) VALUES (20, 3);
INSERT INTO shop_delivery_methods_systems (`delivery_method_id`, `payment_method_id`) VALUES (21, 2);
INSERT INTO shop_delivery_methods_systems (`delivery_method_id`, `payment_method_id`) VALUES (23, 3);
INSERT INTO shop_delivery_methods_systems (`delivery_method_id`, `payment_method_id`) VALUES (24, 3);
INSERT INTO shop_delivery_methods_systems (`delivery_method_id`, `payment_method_id`) VALUES (25, 1);
INSERT INTO shop_delivery_methods_systems (`delivery_method_id`, `payment_method_id`) VALUES (25, 2);
INSERT INTO shop_delivery_methods_systems (`delivery_method_id`, `payment_method_id`) VALUES (25, 3);
INSERT INTO shop_delivery_methods_systems (`delivery_method_id`, `payment_method_id`) VALUES (25, 4);


#
# TABLE STRUCTURE FOR: shop_discounts
#

DROP TABLE IF EXISTS shop_discounts;

CREATE TABLE `shop_discounts` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `name` varchar(255) NOT NULL,
  `active` tinyint(1) NOT NULL,
  `date_start` int(11) DEFAULT NULL,
  `date_stop` int(11) DEFAULT NULL,
  `discount` varchar(11) DEFAULT NULL,
  `min_price` float(10,2) DEFAULT NULL,
  `max_price` float(10,2) DEFAULT NULL,
  `categories` text,
  `products` text,
  `description` text,
  `user_group` varchar(255) DEFAULT NULL,
  PRIMARY KEY (`id`)
) ENGINE=MyISAM AUTO_INCREMENT=10 DEFAULT CHARSET=utf8;

#
# TABLE STRUCTURE FOR: shop_gifts
#

DROP TABLE IF EXISTS shop_gifts;

CREATE TABLE `shop_gifts` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `key` varchar(255) DEFAULT NULL,
  `active` int(11) DEFAULT NULL,
  `price` int(11) DEFAULT NULL,
  `created` int(11) DEFAULT NULL,
  `espdate` int(11) DEFAULT NULL,
  PRIMARY KEY (`id`)
) ENGINE=MyISAM AUTO_INCREMENT=4 DEFAULT CHARSET=utf8;

INSERT INTO shop_gifts (`id`, `key`, `active`, `price`, `created`, `espdate`) VALUES (1, 'WTWWwPHJ4Al91jnZ', NULL, 100, 1354039607, 1354219200);
INSERT INTO shop_gifts (`id`, `key`, `active`, `price`, `created`, `espdate`) VALUES (2, '7WMAohSSCA3OViRL', NULL, 4, 1354039810, 1353700800);
INSERT INTO shop_gifts (`id`, `key`, `active`, `price`, `created`, `espdate`) VALUES (3, 'psnqw6IFxamCOCVmsd', NULL, 35, 1354039839, 1352404800);


#
# TABLE STRUCTURE FOR: shop_kit
#

DROP TABLE IF EXISTS shop_kit;

CREATE TABLE `shop_kit` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `product_id` int(11) DEFAULT NULL,
  `active` tinyint(1) NOT NULL DEFAULT '1',
  `position` smallint(6) NOT NULL,
  PRIMARY KEY (`id`),
  KEY `shop_kit_FI_1` (`product_id`)
) ENGINE=MyISAM AUTO_INCREMENT=11 DEFAULT CHARSET=utf8;

#
# TABLE STRUCTURE FOR: shop_kit_product
#

DROP TABLE IF EXISTS shop_kit_product;

CREATE TABLE `shop_kit_product` (
  `product_id` int(11) NOT NULL,
  `kit_id` int(11) NOT NULL,
  `discount` varchar(11) DEFAULT '0',
  PRIMARY KEY (`product_id`,`kit_id`),
  KEY `shop_kit_product_FI_2` (`kit_id`)
) ENGINE=MyISAM DEFAULT CHARSET=utf8;

#
# TABLE STRUCTURE FOR: shop_notification_statuses
#

DROP TABLE IF EXISTS shop_notification_statuses;

CREATE TABLE `shop_notification_statuses` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `position` smallint(6) DEFAULT NULL,
  PRIMARY KEY (`id`),
  KEY `shop_notification_statuses_I_2` (`position`),
  KEY `shop_notification_statuses_I_1` (`position`)
) ENGINE=MyISAM AUTO_INCREMENT=6 DEFAULT CHARSET=utf8;

INSERT INTO shop_notification_statuses (`id`, `position`) VALUES (1, 1);
INSERT INTO shop_notification_statuses (`id`, `position`) VALUES (2, 0);


#
# TABLE STRUCTURE FOR: shop_notification_statuses_i18n
#

DROP TABLE IF EXISTS shop_notification_statuses_i18n;

CREATE TABLE `shop_notification_statuses_i18n` (
  `id` int(11) NOT NULL,
  `locale` varchar(5) NOT NULL,
  `name` varchar(500) NOT NULL,
  PRIMARY KEY (`id`,`locale`),
  KEY `shop_notification_statuses_i18n_I_1` (`name`(333))
) ENGINE=MyISAM DEFAULT CHARSET=utf8;

INSERT INTO shop_notification_statuses_i18n (`id`, `locale`, `name`) VALUES (1, 'ru', 'Новый');
INSERT INTO shop_notification_statuses_i18n (`id`, `locale`, `name`) VALUES (2, 'ru', 'Выполнен');


#
# TABLE STRUCTURE FOR: shop_notifications
#

DROP TABLE IF EXISTS shop_notifications;

CREATE TABLE `shop_notifications` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `product_id` int(11) NOT NULL,
  `variant_id` int(11) NOT NULL,
  `user_name` varchar(100) DEFAULT NULL,
  `user_email` varchar(100) DEFAULT NULL,
  `user_phone` varchar(100) DEFAULT NULL,
  `user_comment` varchar(500) DEFAULT NULL,
  `status` int(11) NOT NULL,
  `date_created` int(11) NOT NULL,
  `active_to` int(11) NOT NULL,
  `manager_id` int(11) DEFAULT NULL,
  `notified_by_email` tinyint(1) DEFAULT NULL,
  PRIMARY KEY (`id`),
  KEY `shop_notifications_I_1` (`user_email`),
  KEY `shop_notifications_I_2` (`user_phone`),
  KEY `shop_notifications_I_3` (`status`),
  KEY `shop_notifications_I_4` (`date_created`),
  KEY `shop_notifications_I_5` (`active_to`),
  KEY `shop_notifications_FI_1` (`product_id`),
  KEY `shop_notifications_FI_2` (`variant_id`)
) ENGINE=MyISAM AUTO_INCREMENT=6 DEFAULT CHARSET=utf8;

INSERT INTO shop_notifications (`id`, `product_id`, `variant_id`, `user_name`, `user_email`, `user_phone`, `user_comment`, `status`, `date_created`, `active_to`, `manager_id`, `notified_by_email`) VALUES (5, 187, 0, 'admin', 'ad@min.com', '', '', 1, 1385979271, 1385979271, NULL, 0);


#
# TABLE STRUCTURE FOR: shop_order_statuses
#

DROP TABLE IF EXISTS shop_order_statuses;

CREATE TABLE `shop_order_statuses` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `position` smallint(6) DEFAULT NULL,
  PRIMARY KEY (`id`),
  KEY `shop_order_statuses_I_2` (`position`),
  KEY `shop_order_statuses_I_1` (`position`)
) ENGINE=MyISAM AUTO_INCREMENT=10 DEFAULT CHARSET=utf8;

INSERT INTO shop_order_statuses (`id`, `position`) VALUES (1, 1);
INSERT INTO shop_order_statuses (`id`, `position`) VALUES (2, 99);


#
# TABLE STRUCTURE FOR: shop_order_statuses_i18n
#

DROP TABLE IF EXISTS shop_order_statuses_i18n;

CREATE TABLE `shop_order_statuses_i18n` (
  `id` int(11) NOT NULL,
  `locale` varchar(5) NOT NULL,
  `name` varchar(500) NOT NULL,
  PRIMARY KEY (`id`,`locale`),
  KEY `shop_order_statuses_i18n_I_1` (`name`(333))
) ENGINE=MyISAM DEFAULT CHARSET=utf8;

INSERT INTO shop_order_statuses_i18n (`id`, `locale`, `name`) VALUES (1, 'ru', 'Новый');
INSERT INTO shop_order_statuses_i18n (`id`, `locale`, `name`) VALUES (2, 'ru', 'Доставлен');


#
# TABLE STRUCTURE FOR: shop_orders
#

DROP TABLE IF EXISTS shop_orders;

CREATE TABLE `shop_orders` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `key` varchar(255) NOT NULL,
  `delivery_method` int(11) DEFAULT NULL,
  `delivery_price` float(10,2) DEFAULT NULL,
  `status` int(11) DEFAULT NULL,
  `paid` tinyint(1) DEFAULT NULL,
  `user_full_name` varchar(255) DEFAULT NULL,
  `user_email` varchar(255) DEFAULT NULL,
  `user_phone` varchar(255) DEFAULT NULL,
  `user_deliver_to` varchar(500) DEFAULT NULL,
  `user_comment` varchar(1000) DEFAULT NULL,
  `date_created` int(11) DEFAULT NULL,
  `date_updated` int(11) DEFAULT NULL,
  `user_ip` varchar(255) DEFAULT NULL,
  `user_id` int(11) DEFAULT NULL,
  `payment_method` int(11) DEFAULT NULL,
  `total_price` float(10,2) DEFAULT NULL,
  `external_id` varchar(255) DEFAULT NULL,
  `gift_cert_key` varchar(25) DEFAULT NULL,
  `gift_cert_price` int(11) DEFAULT NULL,
  `comulativ` int(3) DEFAULT NULL,
  `discount` float(10,2) DEFAULT NULL,
  `discount_info` text,
  `origin_price` float(10,2) DEFAULT NULL,
  PRIMARY KEY (`id`),
  KEY `shop_orders_I_1` (`key`),
  KEY `shop_orders_I_2` (`status`),
  KEY `shop_orders_I_3` (`date_created`),
  KEY `shop_orders_FI_1` (`delivery_method`),
  KEY `shop_orders_FI_2` (`payment_method`)
) ENGINE=MyISAM AUTO_INCREMENT=53 DEFAULT CHARSET=utf8;

INSERT INTO shop_orders (`id`, `key`, `delivery_method`, `delivery_price`, `status`, `paid`, `user_full_name`, `user_email`, `user_phone`, `user_deliver_to`, `user_comment`, `date_created`, `date_updated`, `user_ip`, `user_id`, `payment_method`, `total_price`, `external_id`, `gift_cert_key`, `gift_cert_price`, `comulativ`, `discount`, `discount_info`, `origin_price`) VALUES (51, 'k190mn0512', 6, '0.00', 1, NULL, 'admin', 'ad@min.com', '', '', '', 1385650537, 1385650537, '127.0.0.1', 48, 1, '809.00', NULL, NULL, NULL, NULL, '16.00', NULL, '825.00');
INSERT INTO shop_orders (`id`, `key`, `delivery_method`, `delivery_price`, `status`, `paid`, `user_full_name`, `user_email`, `user_phone`, `user_deliver_to`, `user_comment`, `date_created`, `date_updated`, `user_ip`, `user_id`, `payment_method`, `total_price`, `external_id`, `gift_cert_key`, `gift_cert_price`, `comulativ`, `discount`, `discount_info`, `origin_price`) VALUES (52, '6gr28075w9', 6, '0.00', 1, NULL, 'admin', 'ad@min.com', '', '', '', 1385650973, 1385650973, '127.0.0.1', 48, 4, '216.00', NULL, NULL, NULL, NULL, '4.00', NULL, '220.00');


#
# TABLE STRUCTURE FOR: shop_orders_products
#

DROP TABLE IF EXISTS shop_orders_products;

CREATE TABLE `shop_orders_products` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `order_id` int(11) NOT NULL,
  `product_id` int(11) NOT NULL,
  `variant_id` int(11) NOT NULL,
  `product_name` varchar(255) DEFAULT NULL,
  `variant_name` varchar(255) DEFAULT NULL,
  `price` float(10,2) DEFAULT NULL,
  `quantity` int(11) DEFAULT NULL,
  `kit_id` int(11) DEFAULT NULL,
  `is_main` tinyint(1) DEFAULT NULL,
  PRIMARY KEY (`id`),
  KEY `shop_orders_products_I_1` (`order_id`),
  KEY `shop_orders_products_FI_1` (`product_id`)
) ENGINE=MyISAM AUTO_INCREMENT=83 DEFAULT CHARSET=utf8;

INSERT INTO shop_orders_products (`id`, `order_id`, `product_id`, `variant_id`, `product_name`, `variant_name`, `price`, `quantity`, `kit_id`, `is_main`) VALUES (81, 51, 191, 219, 'Sony KDL-22EX553', '', '809.00', 1, NULL, NULL);
INSERT INTO shop_orders_products (`id`, `order_id`, `product_id`, `variant_id`, `product_name`, `variant_name`, `price`, `quantity`, `kit_id`, `is_main`) VALUES (82, 52, 102, 113, 'Epson Stylus R1900 Photo Printer', '', '216.00', 1, NULL, NULL);


#
# TABLE STRUCTURE FOR: shop_orders_status_history
#

DROP TABLE IF EXISTS shop_orders_status_history;

CREATE TABLE `shop_orders_status_history` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `order_id` int(11) NOT NULL,
  `status_id` int(11) NOT NULL,
  `user_id` int(11) NOT NULL,
  `date_created` int(11) DEFAULT NULL,
  `comment` varchar(1000) DEFAULT NULL,
  PRIMARY KEY (`id`),
  KEY `shop_orders_status_history_I_1` (`order_id`),
  KEY `shop_orders_status_history_FI_2` (`status_id`)
) ENGINE=MyISAM AUTO_INCREMENT=25 DEFAULT CHARSET=utf8;

INSERT INTO shop_orders_status_history (`id`, `order_id`, `status_id`, `user_id`, `date_created`, `comment`) VALUES (23, 51, 1, 48, 1385650538, '');
INSERT INTO shop_orders_status_history (`id`, `order_id`, `status_id`, `user_id`, `date_created`, `comment`) VALUES (24, 52, 1, 48, 1385650974, '');


#
# TABLE STRUCTURE FOR: shop_payment_methods
#

DROP TABLE IF EXISTS shop_payment_methods;

CREATE TABLE `shop_payment_methods` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `active` tinyint(1) DEFAULT NULL,
  `currency_id` int(11) DEFAULT NULL,
  `position` int(11) DEFAULT NULL,
  `payment_system_name` varchar(255) DEFAULT NULL,
  PRIMARY KEY (`id`),
  KEY `shop_payment_methods_I_2` (`position`),
  KEY `shop_payment_methods_FI_1` (`currency_id`),
  KEY `shop_payment_methods_I_1` (`position`)
) ENGINE=MyISAM AUTO_INCREMENT=9 DEFAULT CHARSET=utf8;

INSERT INTO shop_payment_methods (`id`, `active`, `currency_id`, `position`, `payment_system_name`) VALUES (1, 1, 4, 0, '0');
INSERT INTO shop_payment_methods (`id`, `active`, `currency_id`, `position`, `payment_system_name`) VALUES (4, 1, 4, 3, '0');


#
# TABLE STRUCTURE FOR: shop_payment_methods_i18n
#

DROP TABLE IF EXISTS shop_payment_methods_i18n;

CREATE TABLE `shop_payment_methods_i18n` (
  `id` int(11) NOT NULL,
  `locale` varchar(5) NOT NULL,
  `name` varchar(255) DEFAULT NULL,
  `description` text,
  PRIMARY KEY (`id`,`locale`),
  KEY `shop_payment_methods_i18n_I_1` (`name`)
) ENGINE=MyISAM DEFAULT CHARSET=utf8;

INSERT INTO shop_payment_methods_i18n (`id`, `locale`, `name`, `description`) VALUES (1, 'ru', 'Наличными:', '<p>оплата при получении товара</p>');
INSERT INTO shop_payment_methods_i18n (`id`, `locale`, `name`, `description`) VALUES (4, 'ru', 'На карточку:', '<p>№885018658945</p>');
INSERT INTO shop_payment_methods_i18n (`id`, `locale`, `name`, `description`) VALUES (1, 'en', 'Payment for the courier', '');
INSERT INTO shop_payment_methods_i18n (`id`, `locale`, `name`, `description`) VALUES (4, 'en', 'Robokassa', '');


#
# TABLE STRUCTURE FOR: shop_product_categories
#

DROP TABLE IF EXISTS shop_product_categories;

CREATE TABLE `shop_product_categories` (
  `product_id` int(11) NOT NULL,
  `category_id` int(11) NOT NULL,
  PRIMARY KEY (`product_id`,`category_id`),
  KEY `shop_product_categories_FI_2` (`category_id`)
) ENGINE=MyISAM DEFAULT CHARSET=utf8;

INSERT INTO shop_product_categories (`product_id`, `category_id`) VALUES (71, 40);
INSERT INTO shop_product_categories (`product_id`, `category_id`) VALUES (78, 40);
INSERT INTO shop_product_categories (`product_id`, `category_id`) VALUES (79, 40);
INSERT INTO shop_product_categories (`product_id`, `category_id`) VALUES (81, 40);
INSERT INTO shop_product_categories (`product_id`, `category_id`) VALUES (82, 40);
INSERT INTO shop_product_categories (`product_id`, `category_id`) VALUES (83, 40);
INSERT INTO shop_product_categories (`product_id`, `category_id`) VALUES (84, 40);
INSERT INTO shop_product_categories (`product_id`, `category_id`) VALUES (85, 40);
INSERT INTO shop_product_categories (`product_id`, `category_id`) VALUES (86, 40);
INSERT INTO shop_product_categories (`product_id`, `category_id`) VALUES (87, 40);
INSERT INTO shop_product_categories (`product_id`, `category_id`) VALUES (88, 40);
INSERT INTO shop_product_categories (`product_id`, `category_id`) VALUES (89, 40);
INSERT INTO shop_product_categories (`product_id`, `category_id`) VALUES (90, 40);
INSERT INTO shop_product_categories (`product_id`, `category_id`) VALUES (90, 41);
INSERT INTO shop_product_categories (`product_id`, `category_id`) VALUES (91, 40);
INSERT INTO shop_product_categories (`product_id`, `category_id`) VALUES (91, 41);
INSERT INTO shop_product_categories (`product_id`, `category_id`) VALUES (92, 40);
INSERT INTO shop_product_categories (`product_id`, `category_id`) VALUES (93, 40);
INSERT INTO shop_product_categories (`product_id`, `category_id`) VALUES (94, 40);
INSERT INTO shop_product_categories (`product_id`, `category_id`) VALUES (94, 43);
INSERT INTO shop_product_categories (`product_id`, `category_id`) VALUES (95, 40);
INSERT INTO shop_product_categories (`product_id`, `category_id`) VALUES (95, 44);
INSERT INTO shop_product_categories (`product_id`, `category_id`) VALUES (96, 40);
INSERT INTO shop_product_categories (`product_id`, `category_id`) VALUES (96, 44);
INSERT INTO shop_product_categories (`product_id`, `category_id`) VALUES (97, 44);
INSERT INTO shop_product_categories (`product_id`, `category_id`) VALUES (97, 45);
INSERT INTO shop_product_categories (`product_id`, `category_id`) VALUES (98, 44);
INSERT INTO shop_product_categories (`product_id`, `category_id`) VALUES (98, 45);
INSERT INTO shop_product_categories (`product_id`, `category_id`) VALUES (99, 44);
INSERT INTO shop_product_categories (`product_id`, `category_id`) VALUES (99, 45);
INSERT INTO shop_product_categories (`product_id`, `category_id`) VALUES (100, 44);
INSERT INTO shop_product_categories (`product_id`, `category_id`) VALUES (100, 46);
INSERT INTO shop_product_categories (`product_id`, `category_id`) VALUES (101, 44);
INSERT INTO shop_product_categories (`product_id`, `category_id`) VALUES (101, 46);
INSERT INTO shop_product_categories (`product_id`, `category_id`) VALUES (102, 40);
INSERT INTO shop_product_categories (`product_id`, `category_id`) VALUES (102, 44);
INSERT INTO shop_product_categories (`product_id`, `category_id`) VALUES (103, 40);
INSERT INTO shop_product_categories (`product_id`, `category_id`) VALUES (103, 44);
INSERT INTO shop_product_categories (`product_id`, `category_id`) VALUES (104, 40);
INSERT INTO shop_product_categories (`product_id`, `category_id`) VALUES (104, 44);
INSERT INTO shop_product_categories (`product_id`, `category_id`) VALUES (105, 40);
INSERT INTO shop_product_categories (`product_id`, `category_id`) VALUES (106, 40);
INSERT INTO shop_product_categories (`product_id`, `category_id`) VALUES (107, 40);
INSERT INTO shop_product_categories (`product_id`, `category_id`) VALUES (108, 40);
INSERT INTO shop_product_categories (`product_id`, `category_id`) VALUES (109, 40);
INSERT INTO shop_product_categories (`product_id`, `category_id`) VALUES (110, 40);
INSERT INTO shop_product_categories (`product_id`, `category_id`) VALUES (111, 40);
INSERT INTO shop_product_categories (`product_id`, `category_id`) VALUES (112, 40);
INSERT INTO shop_product_categories (`product_id`, `category_id`) VALUES (113, 40);
INSERT INTO shop_product_categories (`product_id`, `category_id`) VALUES (114, 40);
INSERT INTO shop_product_categories (`product_id`, `category_id`) VALUES (115, 40);
INSERT INTO shop_product_categories (`product_id`, `category_id`) VALUES (116, 40);
INSERT INTO shop_product_categories (`product_id`, `category_id`) VALUES (117, 40);
INSERT INTO shop_product_categories (`product_id`, `category_id`) VALUES (118, 40);
INSERT INTO shop_product_categories (`product_id`, `category_id`) VALUES (119, 40);
INSERT INTO shop_product_categories (`product_id`, `category_id`) VALUES (120, 40);
INSERT INTO shop_product_categories (`product_id`, `category_id`) VALUES (121, 40);
INSERT INTO shop_product_categories (`product_id`, `category_id`) VALUES (122, 40);
INSERT INTO shop_product_categories (`product_id`, `category_id`) VALUES (123, 40);
INSERT INTO shop_product_categories (`product_id`, `category_id`) VALUES (124, 40);
INSERT INTO shop_product_categories (`product_id`, `category_id`) VALUES (185, 40);
INSERT INTO shop_product_categories (`product_id`, `category_id`) VALUES (186, 40);
INSERT INTO shop_product_categories (`product_id`, `category_id`) VALUES (187, 40);
INSERT INTO shop_product_categories (`product_id`, `category_id`) VALUES (188, 40);
INSERT INTO shop_product_categories (`product_id`, `category_id`) VALUES (189, 40);
INSERT INTO shop_product_categories (`product_id`, `category_id`) VALUES (190, 40);
INSERT INTO shop_product_categories (`product_id`, `category_id`) VALUES (191, 40);


#
# TABLE STRUCTURE FOR: shop_product_images
#

DROP TABLE IF EXISTS shop_product_images;

CREATE TABLE `shop_product_images` (
  `product_id` int(11) NOT NULL,
  `image_name` varchar(255) NOT NULL,
  `position` smallint(6) DEFAULT NULL,
  PRIMARY KEY (`product_id`,`image_name`),
  KEY `shop_product_images_I_1` (`position`)
) ENGINE=MyISAM DEFAULT CHARSET=utf8;

INSERT INTO shop_product_images (`product_id`, `image_name`, `position`) VALUES (186, '186_2.jpg', 2);
INSERT INTO shop_product_images (`product_id`, `image_name`, `position`) VALUES (186, '186_1.jpg', 1);
INSERT INTO shop_product_images (`product_id`, `image_name`, `position`) VALUES (187, '187_0.jpg', 0);
INSERT INTO shop_product_images (`product_id`, `image_name`, `position`) VALUES (186, '186_3.jpg', 3);
INSERT INTO shop_product_images (`product_id`, `image_name`, `position`) VALUES (186, '186_4.jpg', 4);
INSERT INTO shop_product_images (`product_id`, `image_name`, `position`) VALUES (187, '187_1.jpg', 1);
INSERT INTO shop_product_images (`product_id`, `image_name`, `position`) VALUES (187, '187_2.jpg', 2);
INSERT INTO shop_product_images (`product_id`, `image_name`, `position`) VALUES (187, '187_3.jpg', 3);
INSERT INTO shop_product_images (`product_id`, `image_name`, `position`) VALUES (188, '188_0.jpg', 0);
INSERT INTO shop_product_images (`product_id`, `image_name`, `position`) VALUES (188, '188_1.jpg', 1);
INSERT INTO shop_product_images (`product_id`, `image_name`, `position`) VALUES (188, '188_2.jpg', 2);
INSERT INTO shop_product_images (`product_id`, `image_name`, `position`) VALUES (188, '188_3.jpg', 3);
INSERT INTO shop_product_images (`product_id`, `image_name`, `position`) VALUES (71, '71_0.jpg', 0);
INSERT INTO shop_product_images (`product_id`, `image_name`, `position`) VALUES (71, '71_1.jpg', 1);
INSERT INTO shop_product_images (`product_id`, `image_name`, `position`) VALUES (71, '71_2.jpg', 2);
INSERT INTO shop_product_images (`product_id`, `image_name`, `position`) VALUES (189, '189_0.jpg', 0);
INSERT INTO shop_product_images (`product_id`, `image_name`, `position`) VALUES (189, '189_1.jpg', 1);
INSERT INTO shop_product_images (`product_id`, `image_name`, `position`) VALUES (189, '189_2.jpg', 2);
INSERT INTO shop_product_images (`product_id`, `image_name`, `position`) VALUES (190, '190_0.jpg', 0);
INSERT INTO shop_product_images (`product_id`, `image_name`, `position`) VALUES (190, '190_1.jpg', 1);
INSERT INTO shop_product_images (`product_id`, `image_name`, `position`) VALUES (190, '190_2.jpg', 2);
INSERT INTO shop_product_images (`product_id`, `image_name`, `position`) VALUES (191, '191_0.jpg', 0);
INSERT INTO shop_product_images (`product_id`, `image_name`, `position`) VALUES (191, '191_1.jpg', 1);
INSERT INTO shop_product_images (`product_id`, `image_name`, `position`) VALUES (185, '185_0.jpg', 0);
INSERT INTO shop_product_images (`product_id`, `image_name`, `position`) VALUES (185, '185_1.jpg', 1);
INSERT INTO shop_product_images (`product_id`, `image_name`, `position`) VALUES (185, '185_2.jpg', 2);


#
# TABLE STRUCTURE FOR: shop_product_properties
#

DROP TABLE IF EXISTS shop_product_properties;

CREATE TABLE `shop_product_properties` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `csv_name` varchar(50) NOT NULL,
  `active` tinyint(1) DEFAULT NULL,
  `show_in_compare` tinyint(1) DEFAULT NULL,
  `position` int(11) NOT NULL,
  `show_on_site` tinyint(1) DEFAULT NULL,
  `multiple` tinyint(1) DEFAULT NULL,
  `external_id` varchar(255) DEFAULT NULL,
  `show_in_filter` tinyint(1) DEFAULT NULL,
  `main_property` tinyint(1) DEFAULT NULL,
  `show_faq` tinyint(1) DEFAULT NULL,
  PRIMARY KEY (`id`),
  KEY `shop_product_properties_I_2` (`active`),
  KEY `shop_product_properties_I_3` (`show_on_site`),
  KEY `shop_product_properties_I_4` (`show_in_compare`),
  KEY `shop_product_properties_I_5` (`position`),
  KEY `shop_product_properties_I_1` (`active`),
  KEY `external_id` (`external_id`)
) ENGINE=MyISAM AUTO_INCREMENT=49 DEFAULT CHARSET=utf8;

INSERT INTO shop_product_properties (`id`, `csv_name`, `active`, `show_in_compare`, `position`, `show_on_site`, `multiple`, `external_id`, `show_in_filter`, `main_property`, `show_faq`) VALUES (48, 'sezonnostj', 1, 1, 0, 1, 1, NULL, 1, 0, 0);
INSERT INTO shop_product_properties (`id`, `csv_name`, `active`, `show_in_compare`, `position`, `show_on_site`, `multiple`, `external_id`, `show_in_filter`, `main_property`, `show_faq`) VALUES (47, 'tipavto', 1, 1, 0, 1, 1, NULL, 1, 0, 0);
INSERT INTO shop_product_properties (`id`, `csv_name`, `active`, `show_in_compare`, `position`, `show_on_site`, `multiple`, `external_id`, `show_in_filter`, `main_property`, `show_faq`) VALUES (46, 'indexnagryzki', 1, 1, 0, 1, 1, NULL, 1, 0, 0);
INSERT INTO shop_product_properties (`id`, `csv_name`, `active`, `show_in_compare`, `position`, `show_on_site`, `multiple`, `external_id`, `show_in_filter`, `main_property`, `show_faq`) VALUES (45, 'indexskorosti', 1, 1, 0, 1, 1, NULL, 1, 0, 0);
INSERT INTO shop_product_properties (`id`, `csv_name`, `active`, `show_in_compare`, `position`, `show_on_site`, `multiple`, `external_id`, `show_in_filter`, `main_property`, `show_faq`) VALUES (44, 'diametr', 1, 1, 0, 1, 1, NULL, 1, 0, 0);
INSERT INTO shop_product_properties (`id`, `csv_name`, `active`, `show_in_compare`, `position`, `show_on_site`, `multiple`, `external_id`, `show_in_filter`, `main_property`, `show_faq`) VALUES (42, 'shurinashuny', 1, 1, 0, 1, 1, NULL, 1, 0, 0);
INSERT INTO shop_product_properties (`id`, `csv_name`, `active`, `show_in_compare`, `position`, `show_on_site`, `multiple`, `external_id`, `show_in_filter`, `main_property`, `show_faq`) VALUES (43, 'profil', 1, 1, 0, 1, 1, NULL, 1, 0, 0);


#
# TABLE STRUCTURE FOR: shop_product_properties_categories
#

DROP TABLE IF EXISTS shop_product_properties_categories;

CREATE TABLE `shop_product_properties_categories` (
  `property_id` int(11) NOT NULL,
  `category_id` int(11) NOT NULL,
  PRIMARY KEY (`property_id`,`category_id`),
  KEY `shop_product_properties_categories_FI_2` (`category_id`)
) ENGINE=MyISAM DEFAULT CHARSET=utf8;

INSERT INTO shop_product_properties_categories (`property_id`, `category_id`) VALUES (42, 40);
INSERT INTO shop_product_properties_categories (`property_id`, `category_id`) VALUES (42, 41);
INSERT INTO shop_product_properties_categories (`property_id`, `category_id`) VALUES (42, 43);
INSERT INTO shop_product_properties_categories (`property_id`, `category_id`) VALUES (42, 44);
INSERT INTO shop_product_properties_categories (`property_id`, `category_id`) VALUES (42, 45);
INSERT INTO shop_product_properties_categories (`property_id`, `category_id`) VALUES (42, 46);
INSERT INTO shop_product_properties_categories (`property_id`, `category_id`) VALUES (42, 78);
INSERT INTO shop_product_properties_categories (`property_id`, `category_id`) VALUES (42, 79);
INSERT INTO shop_product_properties_categories (`property_id`, `category_id`) VALUES (42, 80);
INSERT INTO shop_product_properties_categories (`property_id`, `category_id`) VALUES (42, 81);
INSERT INTO shop_product_properties_categories (`property_id`, `category_id`) VALUES (42, 82);
INSERT INTO shop_product_properties_categories (`property_id`, `category_id`) VALUES (42, 83);
INSERT INTO shop_product_properties_categories (`property_id`, `category_id`) VALUES (43, 40);
INSERT INTO shop_product_properties_categories (`property_id`, `category_id`) VALUES (43, 41);
INSERT INTO shop_product_properties_categories (`property_id`, `category_id`) VALUES (43, 43);
INSERT INTO shop_product_properties_categories (`property_id`, `category_id`) VALUES (43, 44);
INSERT INTO shop_product_properties_categories (`property_id`, `category_id`) VALUES (43, 45);
INSERT INTO shop_product_properties_categories (`property_id`, `category_id`) VALUES (43, 46);
INSERT INTO shop_product_properties_categories (`property_id`, `category_id`) VALUES (43, 78);
INSERT INTO shop_product_properties_categories (`property_id`, `category_id`) VALUES (43, 79);
INSERT INTO shop_product_properties_categories (`property_id`, `category_id`) VALUES (43, 80);
INSERT INTO shop_product_properties_categories (`property_id`, `category_id`) VALUES (43, 81);
INSERT INTO shop_product_properties_categories (`property_id`, `category_id`) VALUES (43, 82);
INSERT INTO shop_product_properties_categories (`property_id`, `category_id`) VALUES (43, 83);
INSERT INTO shop_product_properties_categories (`property_id`, `category_id`) VALUES (44, 40);
INSERT INTO shop_product_properties_categories (`property_id`, `category_id`) VALUES (44, 41);
INSERT INTO shop_product_properties_categories (`property_id`, `category_id`) VALUES (44, 43);
INSERT INTO shop_product_properties_categories (`property_id`, `category_id`) VALUES (44, 44);
INSERT INTO shop_product_properties_categories (`property_id`, `category_id`) VALUES (44, 45);
INSERT INTO shop_product_properties_categories (`property_id`, `category_id`) VALUES (44, 46);
INSERT INTO shop_product_properties_categories (`property_id`, `category_id`) VALUES (44, 78);
INSERT INTO shop_product_properties_categories (`property_id`, `category_id`) VALUES (44, 79);
INSERT INTO shop_product_properties_categories (`property_id`, `category_id`) VALUES (44, 80);
INSERT INTO shop_product_properties_categories (`property_id`, `category_id`) VALUES (44, 81);
INSERT INTO shop_product_properties_categories (`property_id`, `category_id`) VALUES (44, 82);
INSERT INTO shop_product_properties_categories (`property_id`, `category_id`) VALUES (44, 83);
INSERT INTO shop_product_properties_categories (`property_id`, `category_id`) VALUES (45, 40);
INSERT INTO shop_product_properties_categories (`property_id`, `category_id`) VALUES (45, 41);
INSERT INTO shop_product_properties_categories (`property_id`, `category_id`) VALUES (45, 43);
INSERT INTO shop_product_properties_categories (`property_id`, `category_id`) VALUES (45, 44);
INSERT INTO shop_product_properties_categories (`property_id`, `category_id`) VALUES (45, 45);
INSERT INTO shop_product_properties_categories (`property_id`, `category_id`) VALUES (45, 46);
INSERT INTO shop_product_properties_categories (`property_id`, `category_id`) VALUES (45, 78);
INSERT INTO shop_product_properties_categories (`property_id`, `category_id`) VALUES (45, 79);
INSERT INTO shop_product_properties_categories (`property_id`, `category_id`) VALUES (45, 80);
INSERT INTO shop_product_properties_categories (`property_id`, `category_id`) VALUES (45, 81);
INSERT INTO shop_product_properties_categories (`property_id`, `category_id`) VALUES (45, 82);
INSERT INTO shop_product_properties_categories (`property_id`, `category_id`) VALUES (45, 83);
INSERT INTO shop_product_properties_categories (`property_id`, `category_id`) VALUES (46, 40);
INSERT INTO shop_product_properties_categories (`property_id`, `category_id`) VALUES (46, 41);
INSERT INTO shop_product_properties_categories (`property_id`, `category_id`) VALUES (46, 43);
INSERT INTO shop_product_properties_categories (`property_id`, `category_id`) VALUES (46, 44);
INSERT INTO shop_product_properties_categories (`property_id`, `category_id`) VALUES (46, 45);
INSERT INTO shop_product_properties_categories (`property_id`, `category_id`) VALUES (46, 46);
INSERT INTO shop_product_properties_categories (`property_id`, `category_id`) VALUES (46, 78);
INSERT INTO shop_product_properties_categories (`property_id`, `category_id`) VALUES (46, 79);
INSERT INTO shop_product_properties_categories (`property_id`, `category_id`) VALUES (46, 80);
INSERT INTO shop_product_properties_categories (`property_id`, `category_id`) VALUES (46, 81);
INSERT INTO shop_product_properties_categories (`property_id`, `category_id`) VALUES (46, 82);
INSERT INTO shop_product_properties_categories (`property_id`, `category_id`) VALUES (46, 83);
INSERT INTO shop_product_properties_categories (`property_id`, `category_id`) VALUES (47, 40);
INSERT INTO shop_product_properties_categories (`property_id`, `category_id`) VALUES (47, 41);
INSERT INTO shop_product_properties_categories (`property_id`, `category_id`) VALUES (47, 43);
INSERT INTO shop_product_properties_categories (`property_id`, `category_id`) VALUES (47, 44);
INSERT INTO shop_product_properties_categories (`property_id`, `category_id`) VALUES (47, 45);
INSERT INTO shop_product_properties_categories (`property_id`, `category_id`) VALUES (47, 46);
INSERT INTO shop_product_properties_categories (`property_id`, `category_id`) VALUES (47, 78);
INSERT INTO shop_product_properties_categories (`property_id`, `category_id`) VALUES (47, 79);
INSERT INTO shop_product_properties_categories (`property_id`, `category_id`) VALUES (47, 80);
INSERT INTO shop_product_properties_categories (`property_id`, `category_id`) VALUES (47, 81);
INSERT INTO shop_product_properties_categories (`property_id`, `category_id`) VALUES (47, 82);
INSERT INTO shop_product_properties_categories (`property_id`, `category_id`) VALUES (47, 83);
INSERT INTO shop_product_properties_categories (`property_id`, `category_id`) VALUES (48, 40);
INSERT INTO shop_product_properties_categories (`property_id`, `category_id`) VALUES (48, 41);
INSERT INTO shop_product_properties_categories (`property_id`, `category_id`) VALUES (48, 43);
INSERT INTO shop_product_properties_categories (`property_id`, `category_id`) VALUES (48, 44);
INSERT INTO shop_product_properties_categories (`property_id`, `category_id`) VALUES (48, 45);
INSERT INTO shop_product_properties_categories (`property_id`, `category_id`) VALUES (48, 46);
INSERT INTO shop_product_properties_categories (`property_id`, `category_id`) VALUES (48, 78);
INSERT INTO shop_product_properties_categories (`property_id`, `category_id`) VALUES (48, 79);
INSERT INTO shop_product_properties_categories (`property_id`, `category_id`) VALUES (48, 80);
INSERT INTO shop_product_properties_categories (`property_id`, `category_id`) VALUES (48, 81);
INSERT INTO shop_product_properties_categories (`property_id`, `category_id`) VALUES (48, 82);
INSERT INTO shop_product_properties_categories (`property_id`, `category_id`) VALUES (48, 83);


#
# TABLE STRUCTURE FOR: shop_product_properties_data
#

DROP TABLE IF EXISTS shop_product_properties_data;

CREATE TABLE `shop_product_properties_data` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `property_id` int(11) DEFAULT NULL,
  `product_id` int(11) DEFAULT NULL,
  `value` varchar(500) NOT NULL,
  `locale` varchar(5) NOT NULL,
  PRIMARY KEY (`id`),
  KEY `shop_product_properties_data_I_1` (`value`(333)),
  KEY `shop_product_properties_data_FI_2` (`product_id`),
  KEY `shop_product_properties_data_FI_1` (`property_id`)
) ENGINE=MyISAM AUTO_INCREMENT=6227 DEFAULT CHARSET=utf8;

INSERT INTO shop_product_properties_data (`id`, `property_id`, `product_id`, `value`, `locale`) VALUES (6124, 43, 85, '64', 'ru');
INSERT INTO shop_product_properties_data (`id`, `property_id`, `product_id`, `value`, `locale`) VALUES (6123, 42, 85, '174', 'ru');
INSERT INTO shop_product_properties_data (`id`, `property_id`, `product_id`, `value`, `locale`) VALUES (6122, 45, 85, 'Q - 164 км/ч', 'ru');
INSERT INTO shop_product_properties_data (`id`, `property_id`, `product_id`, `value`, `locale`) VALUES (6121, 44, 85, 'R13', 'ru');
INSERT INTO shop_product_properties_data (`id`, `property_id`, `product_id`, `value`, `locale`) VALUES (6120, 48, 85, 'зимние', 'ru');
INSERT INTO shop_product_properties_data (`id`, `property_id`, `product_id`, `value`, `locale`) VALUES (6119, 47, 85, 'легковой', 'ru');
INSERT INTO shop_product_properties_data (`id`, `property_id`, `product_id`, `value`, `locale`) VALUES (6118, 46, 85, '75 - до 435 кг', 'ru');
INSERT INTO shop_product_properties_data (`id`, `property_id`, `product_id`, `value`, `locale`) VALUES (6117, 43, 84, '65', 'ru');
INSERT INTO shop_product_properties_data (`id`, `property_id`, `product_id`, `value`, `locale`) VALUES (6116, 42, 84, '175', 'ru');
INSERT INTO shop_product_properties_data (`id`, `property_id`, `product_id`, `value`, `locale`) VALUES (6115, 45, 84, 'Q - 160 км/ч', 'ru');
INSERT INTO shop_product_properties_data (`id`, `property_id`, `product_id`, `value`, `locale`) VALUES (6114, 44, 84, 'R14', 'ru');
INSERT INTO shop_product_properties_data (`id`, `property_id`, `product_id`, `value`, `locale`) VALUES (6113, 48, 84, 'зимние', 'ru');
INSERT INTO shop_product_properties_data (`id`, `property_id`, `product_id`, `value`, `locale`) VALUES (6112, 47, 84, 'легковой', 'ru');
INSERT INTO shop_product_properties_data (`id`, `property_id`, `product_id`, `value`, `locale`) VALUES (6111, 46, 84, '82 - до 475 кг', 'ru');
INSERT INTO shop_product_properties_data (`id`, `property_id`, `product_id`, `value`, `locale`) VALUES (6214, 43, 86, '75', 'ru');
INSERT INTO shop_product_properties_data (`id`, `property_id`, `product_id`, `value`, `locale`) VALUES (6213, 42, 86, '188', 'ru');
INSERT INTO shop_product_properties_data (`id`, `property_id`, `product_id`, `value`, `locale`) VALUES (6212, 45, 86, 'Q - 170 км/ч', 'ru');
INSERT INTO shop_product_properties_data (`id`, `property_id`, `product_id`, `value`, `locale`) VALUES (6211, 44, 86, 'R18', 'ru');
INSERT INTO shop_product_properties_data (`id`, `property_id`, `product_id`, `value`, `locale`) VALUES (6210, 48, 86, 'летние', 'ru');
INSERT INTO shop_product_properties_data (`id`, `property_id`, `product_id`, `value`, `locale`) VALUES (6209, 47, 86, 'легковой', 'ru');
INSERT INTO shop_product_properties_data (`id`, `property_id`, `product_id`, `value`, `locale`) VALUES (6188, 46, 87, '85 - до 480 кг', 'ru');
INSERT INTO shop_product_properties_data (`id`, `property_id`, `product_id`, `value`, `locale`) VALUES (6189, 47, 87, 'легковой', 'ru');
INSERT INTO shop_product_properties_data (`id`, `property_id`, `product_id`, `value`, `locale`) VALUES (6190, 48, 87, 'летние', 'ru');
INSERT INTO shop_product_properties_data (`id`, `property_id`, `product_id`, `value`, `locale`) VALUES (6208, 46, 86, '95 - до 565 кг', 'ru');
INSERT INTO shop_product_properties_data (`id`, `property_id`, `product_id`, `value`, `locale`) VALUES (6180, 43, 83, '65', 'ru');
INSERT INTO shop_product_properties_data (`id`, `property_id`, `product_id`, `value`, `locale`) VALUES (6179, 42, 83, '175', 'ru');
INSERT INTO shop_product_properties_data (`id`, `property_id`, `product_id`, `value`, `locale`) VALUES (6178, 45, 83, 'Q - 160 км/ч', 'ru');
INSERT INTO shop_product_properties_data (`id`, `property_id`, `product_id`, `value`, `locale`) VALUES (6177, 44, 83, 'R14', 'ru');
INSERT INTO shop_product_properties_data (`id`, `property_id`, `product_id`, `value`, `locale`) VALUES (6174, 46, 83, '82 - до 475 кг', 'ru');
INSERT INTO shop_product_properties_data (`id`, `property_id`, `product_id`, `value`, `locale`) VALUES (6175, 47, 83, 'легковой', 'ru');
INSERT INTO shop_product_properties_data (`id`, `property_id`, `product_id`, `value`, `locale`) VALUES (6176, 48, 83, 'зимние', 'ru');
INSERT INTO shop_product_properties_data (`id`, `property_id`, `product_id`, `value`, `locale`) VALUES (6137, 42, 82, '80', 'ru');
INSERT INTO shop_product_properties_data (`id`, `property_id`, `product_id`, `value`, `locale`) VALUES (6138, 43, 82, '69', 'ru');
INSERT INTO shop_product_properties_data (`id`, `property_id`, `product_id`, `value`, `locale`) VALUES (6215, 46, 93, '98 - до 589 кг', 'ru');
INSERT INTO shop_product_properties_data (`id`, `property_id`, `product_id`, `value`, `locale`) VALUES (6216, 47, 93, 'легковой', 'ru');
INSERT INTO shop_product_properties_data (`id`, `property_id`, `product_id`, `value`, `locale`) VALUES (6217, 48, 93, 'зимние', 'ru');
INSERT INTO shop_product_properties_data (`id`, `property_id`, `product_id`, `value`, `locale`) VALUES (6218, 44, 93, 'R16', 'ru');
INSERT INTO shop_product_properties_data (`id`, `property_id`, `product_id`, `value`, `locale`) VALUES (6219, 45, 93, 'Q - 160 км/ч', 'ru');
INSERT INTO shop_product_properties_data (`id`, `property_id`, `product_id`, `value`, `locale`) VALUES (6220, 46, 95, '100 - до 590 кг', 'ru');
INSERT INTO shop_product_properties_data (`id`, `property_id`, `product_id`, `value`, `locale`) VALUES (6221, 47, 95, 'легковой', 'ru');
INSERT INTO shop_product_properties_data (`id`, `property_id`, `product_id`, `value`, `locale`) VALUES (6222, 48, 95, 'летние', 'ru');
INSERT INTO shop_product_properties_data (`id`, `property_id`, `product_id`, `value`, `locale`) VALUES (6223, 44, 95, 'R15', 'ru');
INSERT INTO shop_product_properties_data (`id`, `property_id`, `product_id`, `value`, `locale`) VALUES (6224, 45, 95, 'Q - 165 км/ч', 'ru');
INSERT INTO shop_product_properties_data (`id`, `property_id`, `product_id`, `value`, `locale`) VALUES (6225, 42, 95, '175', 'ru');
INSERT INTO shop_product_properties_data (`id`, `property_id`, `product_id`, `value`, `locale`) VALUES (6226, 43, 95, '75', 'ru');
INSERT INTO shop_product_properties_data (`id`, `property_id`, `product_id`, `value`, `locale`) VALUES (6172, 42, 81, '188', 'ru');
INSERT INTO shop_product_properties_data (`id`, `property_id`, `product_id`, `value`, `locale`) VALUES (6171, 45, 81, 'Q - 180 км/ч', 'ru');
INSERT INTO shop_product_properties_data (`id`, `property_id`, `product_id`, `value`, `locale`) VALUES (6136, 45, 82, 'Q - 120 км/ч', 'ru');
INSERT INTO shop_product_properties_data (`id`, `property_id`, `product_id`, `value`, `locale`) VALUES (6170, 44, 81, 'R15', 'ru');
INSERT INTO shop_product_properties_data (`id`, `property_id`, `product_id`, `value`, `locale`) VALUES (6169, 48, 81, 'зимние', 'ru');
INSERT INTO shop_product_properties_data (`id`, `property_id`, `product_id`, `value`, `locale`) VALUES (6168, 47, 81, 'легковой', 'ru');
INSERT INTO shop_product_properties_data (`id`, `property_id`, `product_id`, `value`, `locale`) VALUES (6167, 46, 81, '82 - до 475 кг', 'ru');
INSERT INTO shop_product_properties_data (`id`, `property_id`, `product_id`, `value`, `locale`) VALUES (6166, 43, 79, '75', 'ru');
INSERT INTO shop_product_properties_data (`id`, `property_id`, `product_id`, `value`, `locale`) VALUES (6173, 43, 81, '80', 'ru');
INSERT INTO shop_product_properties_data (`id`, `property_id`, `product_id`, `value`, `locale`) VALUES (6191, 44, 87, 'R15', 'ru');
INSERT INTO shop_product_properties_data (`id`, `property_id`, `product_id`, `value`, `locale`) VALUES (6192, 45, 87, 'Q - 170 км/ч', 'ru');
INSERT INTO shop_product_properties_data (`id`, `property_id`, `product_id`, `value`, `locale`) VALUES (6193, 42, 87, '185', 'ru');
INSERT INTO shop_product_properties_data (`id`, `property_id`, `product_id`, `value`, `locale`) VALUES (6194, 43, 87, '70', 'ru');
INSERT INTO shop_product_properties_data (`id`, `property_id`, `product_id`, `value`, `locale`) VALUES (6195, 46, 88, '85 - до 480 кг', 'ru');
INSERT INTO shop_product_properties_data (`id`, `property_id`, `product_id`, `value`, `locale`) VALUES (6196, 47, 88, 'легковой', 'ru');
INSERT INTO shop_product_properties_data (`id`, `property_id`, `product_id`, `value`, `locale`) VALUES (6197, 48, 88, 'летние', 'ru');
INSERT INTO shop_product_properties_data (`id`, `property_id`, `product_id`, `value`, `locale`) VALUES (6198, 44, 88, 'R15', 'ru');
INSERT INTO shop_product_properties_data (`id`, `property_id`, `product_id`, `value`, `locale`) VALUES (6199, 45, 88, 'Q - 165 км/ч', 'ru');
INSERT INTO shop_product_properties_data (`id`, `property_id`, `product_id`, `value`, `locale`) VALUES (6200, 42, 88, '188', 'ru');
INSERT INTO shop_product_properties_data (`id`, `property_id`, `product_id`, `value`, `locale`) VALUES (6201, 43, 88, '67', 'ru');
INSERT INTO shop_product_properties_data (`id`, `property_id`, `product_id`, `value`, `locale`) VALUES (6202, 46, 101, '97 - до 585 кг', 'ru');
INSERT INTO shop_product_properties_data (`id`, `property_id`, `product_id`, `value`, `locale`) VALUES (6165, 42, 79, '182', 'ru');
INSERT INTO shop_product_properties_data (`id`, `property_id`, `product_id`, `value`, `locale`) VALUES (6135, 44, 82, 'R19', 'ru');
INSERT INTO shop_product_properties_data (`id`, `property_id`, `product_id`, `value`, `locale`) VALUES (6164, 45, 79, 'Q - 170 км/ч', 'ru');
INSERT INTO shop_product_properties_data (`id`, `property_id`, `product_id`, `value`, `locale`) VALUES (6163, 44, 79, 'R17', 'ru');
INSERT INTO shop_product_properties_data (`id`, `property_id`, `product_id`, `value`, `locale`) VALUES (6162, 48, 79, 'зимние', 'ru');
INSERT INTO shop_product_properties_data (`id`, `property_id`, `product_id`, `value`, `locale`) VALUES (6161, 47, 79, 'легковой', 'ru');
INSERT INTO shop_product_properties_data (`id`, `property_id`, `product_id`, `value`, `locale`) VALUES (6160, 46, 79, '90 - до 555 кг', 'ru');
INSERT INTO shop_product_properties_data (`id`, `property_id`, `product_id`, `value`, `locale`) VALUES (6159, 43, 78, '75', 'ru');
INSERT INTO shop_product_properties_data (`id`, `property_id`, `product_id`, `value`, `locale`) VALUES (6203, 46, 100, '96 - до 570 кг', 'ru');
INSERT INTO shop_product_properties_data (`id`, `property_id`, `product_id`, `value`, `locale`) VALUES (6204, 46, 99, '95 - до 565 кг', 'ru');
INSERT INTO shop_product_properties_data (`id`, `property_id`, `product_id`, `value`, `locale`) VALUES (6158, 42, 78, '188', 'ru');
INSERT INTO shop_product_properties_data (`id`, `property_id`, `product_id`, `value`, `locale`) VALUES (6134, 48, 82, 'летняя', 'ru');
INSERT INTO shop_product_properties_data (`id`, `property_id`, `product_id`, `value`, `locale`) VALUES (6157, 45, 78, 'Q - 170 км/ч', 'ru');
INSERT INTO shop_product_properties_data (`id`, `property_id`, `product_id`, `value`, `locale`) VALUES (6156, 44, 78, 'R17', 'ru');
INSERT INTO shop_product_properties_data (`id`, `property_id`, `product_id`, `value`, `locale`) VALUES (6155, 48, 78, 'зимние', 'ru');
INSERT INTO shop_product_properties_data (`id`, `property_id`, `product_id`, `value`, `locale`) VALUES (6154, 47, 78, 'легковой', 'ru');
INSERT INTO shop_product_properties_data (`id`, `property_id`, `product_id`, `value`, `locale`) VALUES (6153, 46, 78, '85 - до 480 кг', 'ru');
INSERT INTO shop_product_properties_data (`id`, `property_id`, `product_id`, `value`, `locale`) VALUES (6145, 43, 71, '65', 'ru');
INSERT INTO shop_product_properties_data (`id`, `property_id`, `product_id`, `value`, `locale`) VALUES (6144, 42, 71, '175', 'ru');
INSERT INTO shop_product_properties_data (`id`, `property_id`, `product_id`, `value`, `locale`) VALUES (6143, 45, 71, 'Q - 160 км/ч', 'ru');
INSERT INTO shop_product_properties_data (`id`, `property_id`, `product_id`, `value`, `locale`) VALUES (6142, 44, 71, 'R14', 'ru');
INSERT INTO shop_product_properties_data (`id`, `property_id`, `product_id`, `value`, `locale`) VALUES (6141, 48, 71, 'зимние', 'ru');
INSERT INTO shop_product_properties_data (`id`, `property_id`, `product_id`, `value`, `locale`) VALUES (6133, 47, 82, 'легковой', 'ru');
INSERT INTO shop_product_properties_data (`id`, `property_id`, `product_id`, `value`, `locale`) VALUES (6140, 47, 71, 'легковой', 'ru');
INSERT INTO shop_product_properties_data (`id`, `property_id`, `product_id`, `value`, `locale`) VALUES (6139, 46, 71, '82 - до 475 кг', 'ru');
INSERT INTO shop_product_properties_data (`id`, `property_id`, `product_id`, `value`, `locale`) VALUES (6207, 46, 89, '96 - до 570 кг', 'ru');
INSERT INTO shop_product_properties_data (`id`, `property_id`, `product_id`, `value`, `locale`) VALUES (6206, 46, 91, '97 - до 585 кг', 'ru');
INSERT INTO shop_product_properties_data (`id`, `property_id`, `product_id`, `value`, `locale`) VALUES (6205, 46, 98, '92 - до 557 кг', 'ru');
INSERT INTO shop_product_properties_data (`id`, `property_id`, `product_id`, `value`, `locale`) VALUES (6152, 43, 96, '67', 'ru');
INSERT INTO shop_product_properties_data (`id`, `property_id`, `product_id`, `value`, `locale`) VALUES (6151, 42, 96, '182', 'ru');
INSERT INTO shop_product_properties_data (`id`, `property_id`, `product_id`, `value`, `locale`) VALUES (6132, 46, 82, '60- до 175 кг', 'ru');
INSERT INTO shop_product_properties_data (`id`, `property_id`, `product_id`, `value`, `locale`) VALUES (6150, 45, 96, 'Q - 165 км/ч', 'ru');
INSERT INTO shop_product_properties_data (`id`, `property_id`, `product_id`, `value`, `locale`) VALUES (6146, 46, 96, '85 - до 480 кг', 'ru');
INSERT INTO shop_product_properties_data (`id`, `property_id`, `product_id`, `value`, `locale`) VALUES (6147, 47, 96, 'легковой', 'ru');
INSERT INTO shop_product_properties_data (`id`, `property_id`, `product_id`, `value`, `locale`) VALUES (6148, 48, 96, 'летние', 'ru');
INSERT INTO shop_product_properties_data (`id`, `property_id`, `product_id`, `value`, `locale`) VALUES (6149, 44, 96, 'R16', 'ru');


#
# TABLE STRUCTURE FOR: shop_product_properties_data_i18n
#

DROP TABLE IF EXISTS shop_product_properties_data_i18n;

CREATE TABLE `shop_product_properties_data_i18n` (
  `id` int(11) NOT NULL,
  `locale` varchar(5) NOT NULL,
  `value` varchar(500) NOT NULL,
  PRIMARY KEY (`id`),
  KEY `shop_product_properties_data_i18n_I_1` (`value`)
) ENGINE=MyISAM DEFAULT CHARSET=latin1;

#
# TABLE STRUCTURE FOR: shop_product_properties_i18n
#

DROP TABLE IF EXISTS shop_product_properties_i18n;

CREATE TABLE `shop_product_properties_i18n` (
  `id` int(11) NOT NULL,
  `name` varchar(50) NOT NULL,
  `locale` varchar(5) NOT NULL,
  `data` text,
  `description` text,
  PRIMARY KEY (`id`,`locale`),
  KEY `shop_product_properties_i18n_I_2` (`name`),
  KEY `shop_product_properties_i18n_I_1` (`name`)
) ENGINE=MyISAM DEFAULT CHARSET=utf8;

INSERT INTO shop_product_properties_i18n (`id`, `name`, `locale`, `data`, `description`) VALUES (46, 'Индекс нагрузки', 'ru', 'a:10:{i:0;s:18:\"82 - до 475 кг\";i:1;s:18:\"85 - до 480 кг\";i:2;s:18:\"88 - до 545 кг\";i:3;s:18:\"90 - до 555 кг\";i:4;s:18:\"92 - до 557 кг\";i:5;s:18:\"95 - до 565 кг\";i:6;s:18:\"96 - до 570 кг\";i:7;s:18:\"97 - до 585 кг\";i:8;s:18:\"98 - до 589 кг\";i:9;s:19:\"100 - до 590 кг\";}', '');
INSERT INTO shop_product_properties_i18n (`id`, `name`, `locale`, `data`, `description`) VALUES (47, 'Тип авто', 'ru', 'a:2:{i:0;s:16:\"легковой\";i:1;s:16:\"грузовой\";}', '');
INSERT INTO shop_product_properties_i18n (`id`, `name`, `locale`, `data`, `description`) VALUES (48, 'Сезонность', 'ru', 'a:2:{i:0;s:12:\"летние\";i:1;s:12:\"зимние\";}', '');
INSERT INTO shop_product_properties_i18n (`id`, `name`, `locale`, `data`, `description`) VALUES (44, 'Диаметр', 'ru', 'a:5:{i:0;s:3:\"R14\";i:1;s:3:\"R15\";i:2;s:3:\"R16\";i:3;s:3:\"R17\";i:4;s:3:\"R18\";}', '');
INSERT INTO shop_product_properties_i18n (`id`, `name`, `locale`, `data`, `description`) VALUES (45, 'Индекс скорости', 'ru', 'a:4:{i:0;s:15:\"Q - 160 км/ч\";i:1;s:15:\"Q - 165 км/ч\";i:2;s:15:\"Q - 170 км/ч\";i:3;s:15:\"Q - 180 км/ч\";}', '');
INSERT INTO shop_product_properties_i18n (`id`, `name`, `locale`, `data`, `description`) VALUES (42, 'Ширина шины', 'ru', 'a:5:{i:0;s:3:\"175\";i:1;s:3:\"182\";i:2;s:3:\"185\";i:3;s:3:\"188\";i:4;s:3:\"190\";}', '');
INSERT INTO shop_product_properties_i18n (`id`, `name`, `locale`, `data`, `description`) VALUES (43, 'Профиль', 'ru', 'a:5:{i:0;s:2:\"65\";i:1;s:2:\"67\";i:2;s:2:\"70\";i:3;s:2:\"75\";i:4;s:2:\"80\";}', '');


#
# TABLE STRUCTURE FOR: shop_product_variants
#

DROP TABLE IF EXISTS shop_product_variants;

CREATE TABLE `shop_product_variants` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `product_id` int(11) NOT NULL,
  `price` double(20,5) NOT NULL,
  `number` varchar(255) DEFAULT NULL,
  `stock` int(11) DEFAULT NULL,
  `position` int(11) DEFAULT NULL,
  `mainImage` varchar(255) DEFAULT NULL,
  `smallImage` varchar(255) DEFAULT NULL,
  `external_id` varchar(255) DEFAULT NULL,
  `currency` int(11) DEFAULT NULL,
  `price_in_main` double(20,5) NOT NULL,
  PRIMARY KEY (`id`),
  KEY `shop_product_variants_I_1` (`product_id`),
  KEY `shop_product_variants_I_2` (`position`),
  KEY `shop_product_variants_I_3` (`number`),
  KEY `shop_product_variants_I_5` (`price`),
  KEY `shop_product_variants_I_4` (`price`),
  KEY `shop_product_variants_FI_2` (`currency`),
  KEY `external_id` (`external_id`)
) ENGINE=MyISAM AUTO_INCREMENT=224 DEFAULT CHARSET=utf8;

INSERT INTO shop_product_variants (`id`, `product_id`, `price`, `number`, `stock`, `position`, `mainImage`, `smallImage`, `external_id`, `currency`, `price_in_main`) VALUES (82, 71, '2500.00000', ' 034976', 3, 0, '71_vM82.jpg', '71_vS82.jpg', NULL, 4, '2500.00000');
INSERT INTO shop_product_variants (`id`, `product_id`, `price`, `number`, `stock`, `position`, `mainImage`, `smallImage`, `external_id`, `currency`, `price_in_main`) VALUES (89, 78, '51.00000', '', 8, 0, '78_vM89.jpg', NULL, NULL, 4, '51.00000');
INSERT INTO shop_product_variants (`id`, `product_id`, `price`, `number`, `stock`, `position`, `mainImage`, `smallImage`, `external_id`, `currency`, `price_in_main`) VALUES (90, 79, '51.00000', '', 9, 0, '79_vM90.jpg', '79_vS90.jpg', NULL, 4, '51.00000');
INSERT INTO shop_product_variants (`id`, `product_id`, `price`, `number`, `stock`, `position`, `mainImage`, `smallImage`, `external_id`, `currency`, `price_in_main`) VALUES (92, 81, '172.00000', 'AD-78-SA-QW', 7, 0, '81_vM92.jpg', '81_vS92.jpg', NULL, 4, '172.00000');
INSERT INTO shop_product_variants (`id`, `product_id`, `price`, `number`, `stock`, `position`, `mainImage`, `smallImage`, `external_id`, `currency`, `price_in_main`) VALUES (93, 82, '51.60000', '', 5, 0, '82_vM93.jpg', '82_vS93.jpg', NULL, 4, '51.60000');
INSERT INTO shop_product_variants (`id`, `product_id`, `price`, `number`, `stock`, `position`, `mainImage`, `smallImage`, `external_id`, `currency`, `price_in_main`) VALUES (94, 83, '51.60000', '', 6, 0, '83_vM94.jpg', '83_vS94.jpg', NULL, 4, '51.60000');
INSERT INTO shop_product_variants (`id`, `product_id`, `price`, `number`, `stock`, `position`, `mainImage`, `smallImage`, `external_id`, `currency`, `price_in_main`) VALUES (95, 84, '40.20000', '', 8, 0, '84_vM95.jpg', '84_vS95.jpg', NULL, 4, '40.20000');
INSERT INTO shop_product_variants (`id`, `product_id`, `price`, `number`, `stock`, `position`, `mainImage`, `smallImage`, `external_id`, `currency`, `price_in_main`) VALUES (96, 85, '88.00000', 'D01B570', 7, 0, '85_vM96.jpg', '85_vS96.jpg', NULL, 4, '88.00000');
INSERT INTO shop_product_variants (`id`, `product_id`, `price`, `number`, `stock`, `position`, `mainImage`, `smallImage`, `external_id`, `currency`, `price_in_main`) VALUES (97, 86, '61.60000', '', 4, 0, '86_vM97.jpg', '86_vS97.jpg', NULL, 4, '61.60000');
INSERT INTO shop_product_variants (`id`, `product_id`, `price`, `number`, `stock`, `position`, `mainImage`, `smallImage`, `external_id`, `currency`, `price_in_main`) VALUES (98, 87, '872.50000', '', 7, 0, '87_vM98.jpg', '87_vS98.jpg', NULL, 4, '872.50000');
INSERT INTO shop_product_variants (`id`, `product_id`, `price`, `number`, `stock`, `position`, `mainImage`, `smallImage`, `external_id`, `currency`, `price_in_main`) VALUES (99, 88, '220.00000', '', 8, 0, '88_vM99.jpg', '88_vS99.jpg', NULL, 4, '220.00000');
INSERT INTO shop_product_variants (`id`, `product_id`, `price`, `number`, `stock`, `position`, `mainImage`, `smallImage`, `external_id`, `currency`, `price_in_main`) VALUES (100, 89, '148.80000', '', 9, 0, '89_vM100.jpg', '89_vS100.jpg', NULL, 4, '148.80000');
INSERT INTO shop_product_variants (`id`, `product_id`, `price`, `number`, `stock`, `position`, `mainImage`, `smallImage`, `external_id`, `currency`, `price_in_main`) VALUES (101, 90, '399.60001', '', 2, 0, '90_vM101.jpg', '90_vS101.jpg', NULL, 4, '399.60001');
INSERT INTO shop_product_variants (`id`, `product_id`, `price`, `number`, `stock`, `position`, `mainImage`, `smallImage`, `external_id`, `currency`, `price_in_main`) VALUES (102, 91, '219.20000', '', 1, 0, '91_vM102.jpg', '91_vS102.jpg', NULL, 4, '219.20000');
INSERT INTO shop_product_variants (`id`, `product_id`, `price`, `number`, `stock`, `position`, `mainImage`, `smallImage`, `external_id`, `currency`, `price_in_main`) VALUES (103, 92, '118.80000', '', 4, 0, '92_vM103.jpg', '92_vS103.jpg', NULL, 4, '118.80000');
INSERT INTO shop_product_variants (`id`, `product_id`, `price`, `number`, `stock`, `position`, `mainImage`, `smallImage`, `external_id`, `currency`, `price_in_main`) VALUES (104, 93, '140.00000', '', 8, 0, '93_vM104.jpg', '93_vS104.jpg', NULL, 4, '140.00000');
INSERT INTO shop_product_variants (`id`, `product_id`, `price`, `number`, `stock`, `position`, `mainImage`, `smallImage`, `external_id`, `currency`, `price_in_main`) VALUES (105, 94, '39.98000', '', 4, 0, '94_vM105.jpg', '94_vS105.jpg', NULL, 4, '39.98000');
INSERT INTO shop_product_variants (`id`, `product_id`, `price`, `number`, `stock`, `position`, `mainImage`, `smallImage`, `external_id`, `currency`, `price_in_main`) VALUES (106, 95, '319.60001', '', 5, 0, NULL, NULL, NULL, 4, '319.60001');
INSERT INTO shop_product_variants (`id`, `product_id`, `price`, `number`, `stock`, `position`, `mainImage`, `smallImage`, `external_id`, `currency`, `price_in_main`) VALUES (107, 96, '1747.50000', '4383B001', 6, 0, '96_vM107.jpg', '96_vS107.jpg', NULL, 4, '1747.50000');
INSERT INTO shop_product_variants (`id`, `product_id`, `price`, `number`, `stock`, `position`, `mainImage`, `smallImage`, `external_id`, `currency`, `price_in_main`) VALUES (108, 97, '319.60001', '', 1, 0, '97_vM108.jpg', '97_vS108.jpg', NULL, 4, '319.60001');
INSERT INTO shop_product_variants (`id`, `product_id`, `price`, `number`, `stock`, `position`, `mainImage`, `smallImage`, `external_id`, `currency`, `price_in_main`) VALUES (109, 98, '219.60001', '', 4, 0, '98_vM109.jpg', '98_vS109.jpg', NULL, 4, '219.60001');
INSERT INTO shop_product_variants (`id`, `product_id`, `price`, `number`, `stock`, `position`, `mainImage`, `smallImage`, `external_id`, `currency`, `price_in_main`) VALUES (110, 99, '200.00000', '', 8, 0, '99_vM110.jpg', '99_vS110.jpg', NULL, 4, '200.00000');
INSERT INTO shop_product_variants (`id`, `product_id`, `price`, `number`, `stock`, `position`, `mainImage`, `smallImage`, `external_id`, `currency`, `price_in_main`) VALUES (111, 100, '71.95000', '', 2, 0, '100_vM111.jpg', '100_vS111.jpg', NULL, 4, '71.95000');
INSERT INTO shop_product_variants (`id`, `product_id`, `price`, `number`, `stock`, `position`, `mainImage`, `smallImage`, `external_id`, `currency`, `price_in_main`) VALUES (112, 101, '30.00000', '', 9, 0, '101_vM112.jpg', '101_vS112.jpg', NULL, 4, '30.00000');
INSERT INTO shop_product_variants (`id`, `product_id`, `price`, `number`, `stock`, `position`, `mainImage`, `smallImage`, `external_id`, `currency`, `price_in_main`) VALUES (113, 102, '220.00000', '', 2, 0, '102_vM113.jpg', '102_vS113.jpg', NULL, 4, '220.00000');
INSERT INTO shop_product_variants (`id`, `product_id`, `price`, `number`, `stock`, `position`, `mainImage`, `smallImage`, `external_id`, `currency`, `price_in_main`) VALUES (114, 103, '34.76000', '', 8, 0, '103_vM114.jpg', '103_vS114.jpg', NULL, 4, '34.76000');
INSERT INTO shop_product_variants (`id`, `product_id`, `price`, `number`, `stock`, `position`, `mainImage`, `smallImage`, `external_id`, `currency`, `price_in_main`) VALUES (115, 104, '320.00000', '', 0, 0, '104_vM115.jpg', '104_vS115.jpg', NULL, 4, '320.00000');
INSERT INTO shop_product_variants (`id`, `product_id`, `price`, `number`, `stock`, `position`, `mainImage`, `smallImage`, `external_id`, `currency`, `price_in_main`) VALUES (116, 105, '39.98000', '', 2, 0, '105_vM116.jpg', '105_vS116.jpg', NULL, 4, '39.98000');
INSERT INTO shop_product_variants (`id`, `product_id`, `price`, `number`, `stock`, `position`, `mainImage`, `smallImage`, `external_id`, `currency`, `price_in_main`) VALUES (117, 106, '272.04999', '', 0, 0, '106_vM117.jpg', '106_vS117.jpg', NULL, 4, '272.04999');
INSERT INTO shop_product_variants (`id`, `product_id`, `price`, `number`, `stock`, `position`, `mainImage`, `smallImage`, `external_id`, `currency`, `price_in_main`) VALUES (118, 107, '87.71000', '', 5, 0, '107_vM118.jpg', '107_vS118.jpg', NULL, 4, '87.71000');
INSERT INTO shop_product_variants (`id`, `product_id`, `price`, `number`, `stock`, `position`, `mainImage`, `smallImage`, `external_id`, `currency`, `price_in_main`) VALUES (119, 108, '88.00000', '', 2, 0, NULL, NULL, NULL, 4, '88.00000');
INSERT INTO shop_product_variants (`id`, `product_id`, `price`, `number`, `stock`, `position`, `mainImage`, `smallImage`, `external_id`, `currency`, `price_in_main`) VALUES (120, 109, '49.35000', '', 9, 0, '109_vM120.jpg', '109_vS120.jpg', NULL, 4, '49.35000');
INSERT INTO shop_product_variants (`id`, `product_id`, `price`, `number`, `stock`, `position`, `mainImage`, `smallImage`, `external_id`, `currency`, `price_in_main`) VALUES (121, 110, '14.78000', '', 5, 0, '110_vM121.jpg', '110_vS121.jpg', NULL, 4, '14.78000');
INSERT INTO shop_product_variants (`id`, `product_id`, `price`, `number`, `stock`, `position`, `mainImage`, `smallImage`, `external_id`, `currency`, `price_in_main`) VALUES (122, 111, '8.16000', '', 7, 0, '111_vM122.jpg', '111_vS122.jpg', NULL, 4, '8.16000');
INSERT INTO shop_product_variants (`id`, `product_id`, `price`, `number`, `stock`, `position`, `mainImage`, `smallImage`, `external_id`, `currency`, `price_in_main`) VALUES (123, 112, '5.20000', '', 6, 0, '112_vM123.jpg', '112_vS123.jpg', NULL, 4, '5.20000');
INSERT INTO shop_product_variants (`id`, `product_id`, `price`, `number`, `stock`, `position`, `mainImage`, `smallImage`, `external_id`, `currency`, `price_in_main`) VALUES (124, 113, '4.40000', '', 9, 0, '113_vM124.jpg', '113_vS124.jpg', NULL, 4, '4.40000');
INSERT INTO shop_product_variants (`id`, `product_id`, `price`, `number`, `stock`, `position`, `mainImage`, `smallImage`, `external_id`, `currency`, `price_in_main`) VALUES (125, 114, '8.00000', '', 3, 0, '114_vM125.jpg', '114_vS125.jpg', NULL, 4, '8.00000');
INSERT INTO shop_product_variants (`id`, `product_id`, `price`, `number`, `stock`, `position`, `mainImage`, `smallImage`, `external_id`, `currency`, `price_in_main`) VALUES (126, 115, '18.00000', '', 5, 0, '115_vM126.jpg', '115_vS126.jpg', NULL, 4, '18.00000');
INSERT INTO shop_product_variants (`id`, `product_id`, `price`, `number`, `stock`, `position`, `mainImage`, `smallImage`, `external_id`, `currency`, `price_in_main`) VALUES (127, 116, '24.40000', '', 6, 0, '116_vM127.jpg', '116_vS127.jpg', NULL, 4, '24.40000');
INSERT INTO shop_product_variants (`id`, `product_id`, `price`, `number`, `stock`, `position`, `mainImage`, `smallImage`, `external_id`, `currency`, `price_in_main`) VALUES (128, 117, '18.89000', '', 7, 0, '117_vM128.jpg', '117_vS128.jpg', NULL, 4, '18.89000');
INSERT INTO shop_product_variants (`id`, `product_id`, `price`, `number`, `stock`, `position`, `mainImage`, `smallImage`, `external_id`, `currency`, `price_in_main`) VALUES (129, 118, '22.40000', '', 2, 0, '118_vM129.jpg', '118_vS129.jpg', NULL, 4, '22.40000');
INSERT INTO shop_product_variants (`id`, `product_id`, `price`, `number`, `stock`, `position`, `mainImage`, `smallImage`, `external_id`, `currency`, `price_in_main`) VALUES (130, 119, '27.60000', '', 5, 0, '119_vM130.jpg', '119_vS130.jpg', NULL, 4, '27.60000');
INSERT INTO shop_product_variants (`id`, `product_id`, `price`, `number`, `stock`, `position`, `mainImage`, `smallImage`, `external_id`, `currency`, `price_in_main`) VALUES (131, 120, '12.28000', '', 6, 0, '120_vM131.jpg', NULL, NULL, 4, '12.28000');
INSERT INTO shop_product_variants (`id`, `product_id`, `price`, `number`, `stock`, `position`, `mainImage`, `smallImage`, `external_id`, `currency`, `price_in_main`) VALUES (132, 121, '11.27000', '', 4, 0, '121_vM132.jpg', '121_vS132.jpg', NULL, 4, '11.27000');
INSERT INTO shop_product_variants (`id`, `product_id`, `price`, `number`, `stock`, `position`, `mainImage`, `smallImage`, `external_id`, `currency`, `price_in_main`) VALUES (133, 122, '14.00000', '', 6, 0, '122_vM133.jpg', NULL, NULL, 4, '14.00000');
INSERT INTO shop_product_variants (`id`, `product_id`, `price`, `number`, `stock`, `position`, `mainImage`, `smallImage`, `external_id`, `currency`, `price_in_main`) VALUES (134, 123, '16.80000', '', 1, 0, '123_vM134.jpg', '123_vS134.jpg', NULL, 4, '16.80000');
INSERT INTO shop_product_variants (`id`, `product_id`, `price`, `number`, `stock`, `position`, `mainImage`, `smallImage`, `external_id`, `currency`, `price_in_main`) VALUES (135, 124, '13.60000', '', 2, 0, '124_vM135.jpg', '124_vS135.jpg', NULL, 4, '13.60000');
INSERT INTO shop_product_variants (`id`, `product_id`, `price`, `number`, `stock`, `position`, `mainImage`, `smallImage`, `external_id`, `currency`, `price_in_main`) VALUES (210, 100, '69.95000', '', 1, 1, '100_vM210.jpg', '100_vS210.jpg', NULL, 4, '69.95000');
INSERT INTO shop_product_variants (`id`, `product_id`, `price`, `number`, `stock`, `position`, `mainImage`, `smallImage`, `external_id`, `currency`, `price_in_main`) VALUES (211, 110, '14.78000', '', 2, 1, '110_vM211.jpg', '110_vS211.jpg', NULL, 4, '14.78000');
INSERT INTO shop_product_variants (`id`, `product_id`, `price`, `number`, `stock`, `position`, `mainImage`, `smallImage`, `external_id`, `currency`, `price_in_main`) VALUES (212, 86, '62.00000', '', 0, 1, '86_vM212.jpg', '86_vS212.jpg', NULL, 4, '62.00000');
INSERT INTO shop_product_variants (`id`, `product_id`, `price`, `number`, `stock`, `position`, `mainImage`, `smallImage`, `external_id`, `currency`, `price_in_main`) VALUES (213, 185, '200.00000', '123456', 5, 0, '185_main.jpg', '185_small.jpg', NULL, 4, '200.00000');
INSERT INTO shop_product_variants (`id`, `product_id`, `price`, `number`, `stock`, `position`, `mainImage`, `smallImage`, `external_id`, `currency`, `price_in_main`) VALUES (214, 186, '750.00000', ' 130835', 4, 0, '186_vM214.jpg', '186_vS214.jpg', NULL, 4, '750.00000');
INSERT INTO shop_product_variants (`id`, `product_id`, `price`, `number`, `stock`, `position`, `mainImage`, `smallImage`, `external_id`, `currency`, `price_in_main`) VALUES (215, 187, '875.00000', ' 155763', 0, 0, '187_vM215.jpg', '187_vS215.jpg', NULL, 4, '875.00000');
INSERT INTO shop_product_variants (`id`, `product_id`, `price`, `number`, `stock`, `position`, `mainImage`, `smallImage`, `external_id`, `currency`, `price_in_main`) VALUES (216, 188, '625.00000', '', 10, 0, '188_vM216.jpg', '188_vS216.jpg', NULL, 4, '625.00000');
INSERT INTO shop_product_variants (`id`, `product_id`, `price`, `number`, `stock`, `position`, `mainImage`, `smallImage`, `external_id`, `currency`, `price_in_main`) VALUES (217, 189, '12500.00000', '', 10, 0, '189_vM217.jpg', NULL, NULL, 4, '12500.00000');
INSERT INTO shop_product_variants (`id`, `product_id`, `price`, `number`, `stock`, `position`, `mainImage`, `smallImage`, `external_id`, `currency`, `price_in_main`) VALUES (218, 190, '625.00000', '', 5, 0, '190_vM218.jpg', NULL, NULL, 4, '625.00000');
INSERT INTO shop_product_variants (`id`, `product_id`, `price`, `number`, `stock`, `position`, `mainImage`, `smallImage`, `external_id`, `currency`, `price_in_main`) VALUES (219, 191, '825.00000', '', 8, 0, '191_vM219.jpg', '191_vS219.jpg', NULL, 4, '825.00000');


#
# TABLE STRUCTURE FOR: shop_product_variants_i18n
#

DROP TABLE IF EXISTS shop_product_variants_i18n;

CREATE TABLE `shop_product_variants_i18n` (
  `id` int(11) NOT NULL,
  `locale` varchar(5) NOT NULL,
  `name` varchar(500) DEFAULT NULL,
  PRIMARY KEY (`id`,`locale`),
  KEY `shop_product_variants_i18n_I_1` (`name`(333))
) ENGINE=MyISAM DEFAULT CHARSET=utf8;

INSERT INTO shop_product_variants_i18n (`id`, `locale`, `name`) VALUES (82, 'ru', '');
INSERT INTO shop_product_variants_i18n (`id`, `locale`, `name`) VALUES (211, 'ru', 'Серый');
INSERT INTO shop_product_variants_i18n (`id`, `locale`, `name`) VALUES (89, 'ru', '');
INSERT INTO shop_product_variants_i18n (`id`, `locale`, `name`) VALUES (90, 'ru', '');
INSERT INTO shop_product_variants_i18n (`id`, `locale`, `name`) VALUES (92, 'ru', '');
INSERT INTO shop_product_variants_i18n (`id`, `locale`, `name`) VALUES (93, 'ru', '');
INSERT INTO shop_product_variants_i18n (`id`, `locale`, `name`) VALUES (94, 'ru', '');
INSERT INTO shop_product_variants_i18n (`id`, `locale`, `name`) VALUES (95, 'ru', '');
INSERT INTO shop_product_variants_i18n (`id`, `locale`, `name`) VALUES (96, 'ru', '');
INSERT INTO shop_product_variants_i18n (`id`, `locale`, `name`) VALUES (97, 'ru', 'Черный');
INSERT INTO shop_product_variants_i18n (`id`, `locale`, `name`) VALUES (98, 'ru', '');
INSERT INTO shop_product_variants_i18n (`id`, `locale`, `name`) VALUES (99, 'ru', '');
INSERT INTO shop_product_variants_i18n (`id`, `locale`, `name`) VALUES (100, 'ru', '');
INSERT INTO shop_product_variants_i18n (`id`, `locale`, `name`) VALUES (101, 'ru', '');
INSERT INTO shop_product_variants_i18n (`id`, `locale`, `name`) VALUES (102, 'ru', 'Sony BDV-E770W Home Theater');
INSERT INTO shop_product_variants_i18n (`id`, `locale`, `name`) VALUES (103, 'ru', '');
INSERT INTO shop_product_variants_i18n (`id`, `locale`, `name`) VALUES (104, 'ru', '');
INSERT INTO shop_product_variants_i18n (`id`, `locale`, `name`) VALUES (105, 'ru', '');
INSERT INTO shop_product_variants_i18n (`id`, `locale`, `name`) VALUES (106, 'ru', '');
INSERT INTO shop_product_variants_i18n (`id`, `locale`, `name`) VALUES (107, 'ru', '');
INSERT INTO shop_product_variants_i18n (`id`, `locale`, `name`) VALUES (108, 'ru', '');
INSERT INTO shop_product_variants_i18n (`id`, `locale`, `name`) VALUES (109, 'ru', '');
INSERT INTO shop_product_variants_i18n (`id`, `locale`, `name`) VALUES (110, 'ru', '');
INSERT INTO shop_product_variants_i18n (`id`, `locale`, `name`) VALUES (111, 'ru', 'Черный');
INSERT INTO shop_product_variants_i18n (`id`, `locale`, `name`) VALUES (112, 'ru', '');
INSERT INTO shop_product_variants_i18n (`id`, `locale`, `name`) VALUES (113, 'ru', '');
INSERT INTO shop_product_variants_i18n (`id`, `locale`, `name`) VALUES (114, 'ru', '');
INSERT INTO shop_product_variants_i18n (`id`, `locale`, `name`) VALUES (115, 'ru', '');
INSERT INTO shop_product_variants_i18n (`id`, `locale`, `name`) VALUES (116, 'ru', '');
INSERT INTO shop_product_variants_i18n (`id`, `locale`, `name`) VALUES (117, 'ru', 'Panasonic KX-TG7433B Expandabledsf');
INSERT INTO shop_product_variants_i18n (`id`, `locale`, `name`) VALUES (118, 'ru', '');
INSERT INTO shop_product_variants_i18n (`id`, `locale`, `name`) VALUES (119, 'ru', '');
INSERT INTO shop_product_variants_i18n (`id`, `locale`, `name`) VALUES (120, 'ru', '');
INSERT INTO shop_product_variants_i18n (`id`, `locale`, `name`) VALUES (121, 'ru', 'Черный');
INSERT INTO shop_product_variants_i18n (`id`, `locale`, `name`) VALUES (122, 'ru', '');
INSERT INTO shop_product_variants_i18n (`id`, `locale`, `name`) VALUES (123, 'ru', '');
INSERT INTO shop_product_variants_i18n (`id`, `locale`, `name`) VALUES (124, 'ru', '');
INSERT INTO shop_product_variants_i18n (`id`, `locale`, `name`) VALUES (125, 'ru', '');
INSERT INTO shop_product_variants_i18n (`id`, `locale`, `name`) VALUES (126, 'ru', '');
INSERT INTO shop_product_variants_i18n (`id`, `locale`, `name`) VALUES (127, 'ru', '');
INSERT INTO shop_product_variants_i18n (`id`, `locale`, `name`) VALUES (128, 'ru', '');
INSERT INTO shop_product_variants_i18n (`id`, `locale`, `name`) VALUES (129, 'ru', '');
INSERT INTO shop_product_variants_i18n (`id`, `locale`, `name`) VALUES (130, 'ru', '');
INSERT INTO shop_product_variants_i18n (`id`, `locale`, `name`) VALUES (131, 'ru', '');
INSERT INTO shop_product_variants_i18n (`id`, `locale`, `name`) VALUES (132, 'ru', '');
INSERT INTO shop_product_variants_i18n (`id`, `locale`, `name`) VALUES (133, 'ru', '');
INSERT INTO shop_product_variants_i18n (`id`, `locale`, `name`) VALUES (134, 'ru', '');
INSERT INTO shop_product_variants_i18n (`id`, `locale`, `name`) VALUES (135, 'ru', '');
INSERT INTO shop_product_variants_i18n (`id`, `locale`, `name`) VALUES (105, 'en', '');
INSERT INTO shop_product_variants_i18n (`id`, `locale`, `name`) VALUES (82, 'en', '');
INSERT INTO shop_product_variants_i18n (`id`, `locale`, `name`) VALUES (90, 'en', '');
INSERT INTO shop_product_variants_i18n (`id`, `locale`, `name`) VALUES (89, 'en', '');
INSERT INTO shop_product_variants_i18n (`id`, `locale`, `name`) VALUES (93, 'en', '');
INSERT INTO shop_product_variants_i18n (`id`, `locale`, `name`) VALUES (92, 'en', '');
INSERT INTO shop_product_variants_i18n (`id`, `locale`, `name`) VALUES (103, 'en', '');
INSERT INTO shop_product_variants_i18n (`id`, `locale`, `name`) VALUES (99, 'en', '');
INSERT INTO shop_product_variants_i18n (`id`, `locale`, `name`) VALUES (98, 'en', '');
INSERT INTO shop_product_variants_i18n (`id`, `locale`, `name`) VALUES (111, 'en', '');
INSERT INTO shop_product_variants_i18n (`id`, `locale`, `name`) VALUES (106, 'en', '');
INSERT INTO shop_product_variants_i18n (`id`, `locale`, `name`) VALUES (123, 'en', '');
INSERT INTO shop_product_variants_i18n (`id`, `locale`, `name`) VALUES (121, 'en', '');
INSERT INTO shop_product_variants_i18n (`id`, `locale`, `name`) VALUES (118, 'en', '');
INSERT INTO shop_product_variants_i18n (`id`, `locale`, `name`) VALUES (117, 'en', '');
INSERT INTO shop_product_variants_i18n (`id`, `locale`, `name`) VALUES (116, 'en', '');
INSERT INTO shop_product_variants_i18n (`id`, `locale`, `name`) VALUES (127, 'en', '');
INSERT INTO shop_product_variants_i18n (`id`, `locale`, `name`) VALUES (133, 'en', '');
INSERT INTO shop_product_variants_i18n (`id`, `locale`, `name`) VALUES (132, 'en', '');
INSERT INTO shop_product_variants_i18n (`id`, `locale`, `name`) VALUES (210, 'ru', 'Белый');
INSERT INTO shop_product_variants_i18n (`id`, `locale`, `name`) VALUES (212, 'ru', 'Белый');
INSERT INTO shop_product_variants_i18n (`id`, `locale`, `name`) VALUES (213, 'ru', '');
INSERT INTO shop_product_variants_i18n (`id`, `locale`, `name`) VALUES (214, 'ru', '');
INSERT INTO shop_product_variants_i18n (`id`, `locale`, `name`) VALUES (215, 'ru', '');
INSERT INTO shop_product_variants_i18n (`id`, `locale`, `name`) VALUES (216, 'ru', '');
INSERT INTO shop_product_variants_i18n (`id`, `locale`, `name`) VALUES (217, 'ru', '');
INSERT INTO shop_product_variants_i18n (`id`, `locale`, `name`) VALUES (218, 'ru', '');
INSERT INTO shop_product_variants_i18n (`id`, `locale`, `name`) VALUES (219, 'ru', '');


#
# TABLE STRUCTURE FOR: shop_products
#

DROP TABLE IF EXISTS shop_products;

CREATE TABLE `shop_products` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `url` varchar(255) NOT NULL,
  `active` tinyint(1) DEFAULT NULL,
  `hit` tinyint(1) DEFAULT NULL,
  `brand_id` int(11) DEFAULT NULL,
  `category_id` int(11) NOT NULL,
  `related_products` varchar(255) DEFAULT NULL,
  `mainImage` varchar(255) DEFAULT NULL,
  `smallImage` varchar(255) DEFAULT NULL,
  `created` int(11) NOT NULL,
  `updated` int(11) NOT NULL,
  `old_price` float(10,2) DEFAULT NULL,
  `views` int(11) DEFAULT '0',
  `hot` tinyint(1) DEFAULT NULL,
  `action` tinyint(1) DEFAULT NULL,
  `added_to_cart_count` int(11) DEFAULT NULL,
  `enable_comments` tinyint(1) DEFAULT '1',
  `external_id` varchar(255) DEFAULT NULL,
  `mainModImage` varchar(255) DEFAULT NULL,
  `smallModImage` varchar(255) DEFAULT NULL,
  `tpl` varchar(250) DEFAULT NULL,
  `user_id` int(11) DEFAULT NULL,
  PRIMARY KEY (`id`),
  KEY `shop_products_I_2` (`url`),
  KEY `shop_products_I_3` (`brand_id`),
  KEY `shop_products_I_4` (`category_id`),
  KEY `shop_products_I_1` (`url`),
  KEY `external_id` (`external_id`)
) ENGINE=MyISAM AUTO_INCREMENT=195 DEFAULT CHARSET=utf8;

INSERT INTO shop_products (`id`, `url`, `active`, `hit`, `brand_id`, `category_id`, `related_products`, `mainImage`, `smallImage`, `created`, `updated`, `old_price`, `views`, `hot`, `action`, `added_to_cart_count`, `enable_comments`, `external_id`, `mainModImage`, `smallModImage`, `tpl`, `user_id`) VALUES (71, '71', 1, 1, 45, 40, '96', '71_main.jpg', '71_mainMod.jpg', 1307542725, 1385990692, '1150.00', 268, 1, 1, 1, 1, NULL, '71_mainMod.jpg', '71_smallMod.jpg', '', NULL);
INSERT INTO shop_products (`id`, `url`, `active`, `hit`, `brand_id`, `category_id`, `related_products`, `mainImage`, `smallImage`, `created`, `updated`, `old_price`, `views`, `hot`, `action`, `added_to_cart_count`, `enable_comments`, `external_id`, `mainModImage`, `smallModImage`, `tpl`, `user_id`) VALUES (96, '96', 1, 1, 45, 40, '100', '96_vM107.jpg', '96_vS107.jpg', 1307542081, 1385990711, '0.00', 6, NULL, NULL, NULL, 1, NULL, '96_mainMod.jpg', '96_smallMod.jpg', '', NULL);
INSERT INTO shop_products (`id`, `url`, `active`, `hit`, `brand_id`, `category_id`, `related_products`, `mainImage`, `smallImage`, `created`, `updated`, `old_price`, `views`, `hot`, `action`, `added_to_cart_count`, `enable_comments`, `external_id`, `mainModImage`, `smallModImage`, `tpl`, `user_id`) VALUES (78, '78', 1, 0, 45, 40, '', '191_vM219.jpg', '191_vS219.jpg', 1307543572, 1385990731, '0.00', 11, NULL, NULL, 2, 1, NULL, '191_mainMod.jpg', '191_smallMod.jpg', '', NULL);
INSERT INTO shop_products (`id`, `url`, `active`, `hit`, `brand_id`, `category_id`, `related_products`, `mainImage`, `smallImage`, `created`, `updated`, `old_price`, `views`, `hot`, `action`, `added_to_cart_count`, `enable_comments`, `external_id`, `mainModImage`, `smallModImage`, `tpl`, `user_id`) VALUES (79, '79', 1, NULL, 0, 40, '', '79_main.jpg', '79_mainMod.jpg', 1307544450, 1385990749, '0.00', 25, 1, NULL, 1, 1, NULL, '79_mainMod.jpg', '79_smallMod.jpg', '', NULL);
INSERT INTO shop_products (`id`, `url`, `active`, `hit`, `brand_id`, `category_id`, `related_products`, `mainImage`, `smallImage`, `created`, `updated`, `old_price`, `views`, `hot`, `action`, `added_to_cart_count`, `enable_comments`, `external_id`, `mainModImage`, `smallModImage`, `tpl`, `user_id`) VALUES (81, '81', 1, 1, 44, 40, '', '81_vM92.jpg', '81_vS92.jpg', 1307544442, 1385990775, '0.00', 26, 1, 1, 18, 1, NULL, '81_mainMod.jpg', '81_smallMod.jpg', '', NULL);
INSERT INTO shop_products (`id`, `url`, `active`, `hit`, `brand_id`, `category_id`, `related_products`, `mainImage`, `smallImage`, `created`, `updated`, `old_price`, `views`, `hot`, `action`, `added_to_cart_count`, `enable_comments`, `external_id`, `mainModImage`, `smallModImage`, `tpl`, `user_id`) VALUES (82, '82', 1, NULL, 0, 40, '', '82_main.jpg', '82_small.jpg', 1307542064, 1385989942, '0.00', 165, NULL, 1, NULL, 1, NULL, '82_mainMod.jpg', '82_smallMod.jpg', '', NULL);
INSERT INTO shop_products (`id`, `url`, `active`, `hit`, `brand_id`, `category_id`, `related_products`, `mainImage`, `smallImage`, `created`, `updated`, `old_price`, `views`, `hot`, `action`, `added_to_cart_count`, `enable_comments`, `external_id`, `mainModImage`, `smallModImage`, `tpl`, `user_id`) VALUES (83, '83', 1, NULL, 44, 40, '', '83_main.jpg', '83_small.jpg', 1307545378, 1385990791, '0.00', 11, NULL, 1, 6, 1, NULL, '83_mainMod.jpg', '83_smallMod.jpg', '', NULL);
INSERT INTO shop_products (`id`, `url`, `active`, `hit`, `brand_id`, `category_id`, `related_products`, `mainImage`, `smallImage`, `created`, `updated`, `old_price`, `views`, `hot`, `action`, `added_to_cart_count`, `enable_comments`, `external_id`, `mainModImage`, `smallModImage`, `tpl`, `user_id`) VALUES (84, '84', 1, NULL, 0, 40, '', '84_main.jpg', '84_small.jpg', 1307541602, 1385988607, '0.00', NULL, NULL, 1, NULL, 1, NULL, '84_mainMod.jpg', '84_smallMod.jpg', '', NULL);
INSERT INTO shop_products (`id`, `url`, `active`, `hit`, `brand_id`, `category_id`, `related_products`, `mainImage`, `smallImage`, `created`, `updated`, `old_price`, `views`, `hot`, `action`, `added_to_cart_count`, `enable_comments`, `external_id`, `mainModImage`, `smallModImage`, `tpl`, `user_id`) VALUES (85, '85', 1, 0, 44, 40, '', '85_vM96.jpg', '85_vS96.jpg', 1307544238, 1385988813, '0.00', 6, NULL, NULL, NULL, 1, NULL, '85_mainMod.jpg', '85_smallMod.jpg', '', NULL);
INSERT INTO shop_products (`id`, `url`, `active`, `hit`, `brand_id`, `category_id`, `related_products`, `mainImage`, `smallImage`, `created`, `updated`, `old_price`, `views`, `hot`, `action`, `added_to_cart_count`, `enable_comments`, `external_id`, `mainModImage`, `smallModImage`, `tpl`, `user_id`) VALUES (86, '86', 1, NULL, 0, 40, '', '86_main.jpg', '86_small.jpg', 1307545023, 1385991169, '0.00', 16, NULL, NULL, NULL, 1, NULL, '86_mainMod.jpg', '86_smallMod.jpg', '', NULL);
INSERT INTO shop_products (`id`, `url`, `active`, `hit`, `brand_id`, `category_id`, `related_products`, `mainImage`, `smallImage`, `created`, `updated`, `old_price`, `views`, `hot`, `action`, `added_to_cart_count`, `enable_comments`, `external_id`, `mainModImage`, `smallModImage`, `tpl`, `user_id`) VALUES (87, '87', 1, NULL, 0, 40, '', '87_main.jpg', '87_mainMod.jpg', 1307541766, 1385990846, '0.00', 33, NULL, NULL, 2, 1, NULL, '87_mainMod.jpg', '87_smallMod.jpg', '', NULL);
INSERT INTO shop_products (`id`, `url`, `active`, `hit`, `brand_id`, `category_id`, `related_products`, `mainImage`, `smallImage`, `created`, `updated`, `old_price`, `views`, `hot`, `action`, `added_to_cart_count`, `enable_comments`, `external_id`, `mainModImage`, `smallModImage`, `tpl`, `user_id`) VALUES (88, '88', 1, NULL, 0, 40, '', '88_main.jpg', '88_small.jpg', 1307544977, 1385990871, '0.00', 23, NULL, NULL, NULL, 1, NULL, '88_mainMod.jpg', '88_smallMod.jpg', '', NULL);
INSERT INTO shop_products (`id`, `url`, `active`, `hit`, `brand_id`, `category_id`, `related_products`, `mainImage`, `smallImage`, `created`, `updated`, `old_price`, `views`, `hot`, `action`, `added_to_cart_count`, `enable_comments`, `external_id`, `mainModImage`, `smallModImage`, `tpl`, `user_id`) VALUES (95, '95', 1, NULL, 0, 40, '', '95_main.jpg', '95_small.jpg', 1307542081, 1385991997, '0.00', 4, NULL, NULL, NULL, 1, NULL, '95_mainMod.jpg', '95_smallMod.jpg', '', NULL);
INSERT INTO shop_products (`id`, `url`, `active`, `hit`, `brand_id`, `category_id`, `related_products`, `mainImage`, `smallImage`, `created`, `updated`, `old_price`, `views`, `hot`, `action`, `added_to_cart_count`, `enable_comments`, `external_id`, `mainModImage`, `smallModImage`, `tpl`, `user_id`) VALUES (89, '89', 1, NULL, 0, 40, '', '89_main.jpg', '89_small.jpg', 1307541636, 1385991147, '0.00', 6, NULL, NULL, NULL, 1, NULL, '89_mainMod.jpg', '89_smallMod.jpg', '', NULL);
INSERT INTO shop_products (`id`, `url`, `active`, `hit`, `brand_id`, `category_id`, `related_products`, `mainImage`, `smallImage`, `created`, `updated`, `old_price`, `views`, `hot`, `action`, `added_to_cart_count`, `enable_comments`, `external_id`, `mainModImage`, `smallModImage`, `tpl`, `user_id`) VALUES (90, '90', 1, NULL, 28, 41, '', '90_main.jpg', '90_small.jpg', 1307543337, 1355496381, '0.00', 4, NULL, NULL, 1, 1, NULL, '90_mainMod.jpg', '90_smallMod.jpg', '', NULL);
INSERT INTO shop_products (`id`, `url`, `active`, `hit`, `brand_id`, `category_id`, `related_products`, `mainImage`, `smallImage`, `created`, `updated`, `old_price`, `views`, `hot`, `action`, `added_to_cart_count`, `enable_comments`, `external_id`, `mainModImage`, `smallModImage`, `tpl`, `user_id`) VALUES (91, '91', 1, NULL, 0, 41, '', '91_main.jpg', '91_small.jpg', 1307544214, 1385991121, '0.00', 3, NULL, NULL, NULL, 1, NULL, '91_mainMod.jpg', '91_smallMod.jpg', '', NULL);
INSERT INTO shop_products (`id`, `url`, `active`, `hit`, `brand_id`, `category_id`, `related_products`, `mainImage`, `smallImage`, `created`, `updated`, `old_price`, `views`, `hot`, `action`, `added_to_cart_count`, `enable_comments`, `external_id`, `mainModImage`, `smallModImage`, `tpl`, `user_id`) VALUES (92, '92', 1, NULL, 28, 40, '', '92_main.jpg', '92_small.jpg', 1307544791, 1355496417, '0.00', 2, NULL, NULL, 1, 1, NULL, '92_mainMod.jpg', '92_smallMod.jpg', '', NULL);
INSERT INTO shop_products (`id`, `url`, `active`, `hit`, `brand_id`, `category_id`, `related_products`, `mainImage`, `smallImage`, `created`, `updated`, `old_price`, `views`, `hot`, `action`, `added_to_cart_count`, `enable_comments`, `external_id`, `mainModImage`, `smallModImage`, `tpl`, `user_id`) VALUES (93, '93', 1, NULL, 0, 40, '', '93_main.jpg', '93_small.jpg', 1307542628, 1385991302, '0.00', 3, NULL, NULL, 1, 1, NULL, '93_mainMod.jpg', '93_smallMod.jpg', '', NULL);
INSERT INTO shop_products (`id`, `url`, `active`, `hit`, `brand_id`, `category_id`, `related_products`, `mainImage`, `smallImage`, `created`, `updated`, `old_price`, `views`, `hot`, `action`, `added_to_cart_count`, `enable_comments`, `external_id`, `mainModImage`, `smallModImage`, `tpl`, `user_id`) VALUES (94, '94', 1, 1, 36, 43, '', '94_main.jpg', '94_small.jpg', 1307544425, 1355496438, '0.00', 44, 1, 1, 3, 1, NULL, '94_mainMod.jpg', '94_smallMod.jpg', '', NULL);
INSERT INTO shop_products (`id`, `url`, `active`, `hit`, `brand_id`, `category_id`, `related_products`, `mainImage`, `smallImage`, `created`, `updated`, `old_price`, `views`, `hot`, `action`, `added_to_cart_count`, `enable_comments`, `external_id`, `mainModImage`, `smallModImage`, `tpl`, `user_id`) VALUES (97, '97', 1, NULL, 26, 45, '', '97_main.jpg', '97_small.jpg', 1307541628, 1355496499, '0.00', 36, NULL, NULL, NULL, 1, NULL, '97_mainMod.jpg', '97_smallMod.jpg', '', NULL);
INSERT INTO shop_products (`id`, `url`, `active`, `hit`, `brand_id`, `category_id`, `related_products`, `mainImage`, `smallImage`, `created`, `updated`, `old_price`, `views`, `hot`, `action`, `added_to_cart_count`, `enable_comments`, `external_id`, `mainModImage`, `smallModImage`, `tpl`, `user_id`) VALUES (98, '98', 1, 1, 0, 45, '', '98_main.jpg', '98_small.jpg', 1307542730, 1385991064, '0.00', 19, NULL, NULL, NULL, 1, NULL, '98_mainMod.jpg', '98_smallMod.jpg', '', NULL);
INSERT INTO shop_products (`id`, `url`, `active`, `hit`, `brand_id`, `category_id`, `related_products`, `mainImage`, `smallImage`, `created`, `updated`, `old_price`, `views`, `hot`, `action`, `added_to_cart_count`, `enable_comments`, `external_id`, `mainModImage`, `smallModImage`, `tpl`, `user_id`) VALUES (99, '99', 1, NULL, 0, 45, '', '99_main.jpg', '99_small.jpg', 1307543877, 1385991046, '0.00', 7, NULL, NULL, NULL, 1, NULL, '99_mainMod.jpg', '99_smallMod.jpg', '', NULL);
INSERT INTO shop_products (`id`, `url`, `active`, `hit`, `brand_id`, `category_id`, `related_products`, `mainImage`, `smallImage`, `created`, `updated`, `old_price`, `views`, `hot`, `action`, `added_to_cart_count`, `enable_comments`, `external_id`, `mainModImage`, `smallModImage`, `tpl`, `user_id`) VALUES (100, '100', 1, NULL, 0, 46, '', '100_main.jpg', '100_small.jpg', 1307543018, 1385991031, '0.00', 66, NULL, NULL, 4, 1, NULL, '100_mainMod.jpg', '100_smallMod.jpg', '', NULL);
INSERT INTO shop_products (`id`, `url`, `active`, `hit`, `brand_id`, `category_id`, `related_products`, `mainImage`, `smallImage`, `created`, `updated`, `old_price`, `views`, `hot`, `action`, `added_to_cart_count`, `enable_comments`, `external_id`, `mainModImage`, `smallModImage`, `tpl`, `user_id`) VALUES (101, '101', 1, NULL, 0, 46, '', '101_main.jpg', '101_small.jpg', 1307543107, 1385991020, '0.00', NULL, NULL, NULL, NULL, 1, NULL, '101_mainMod.jpg', '101_smallMod.jpg', '', NULL);
INSERT INTO shop_products (`id`, `url`, `active`, `hit`, `brand_id`, `category_id`, `related_products`, `mainImage`, `smallImage`, `created`, `updated`, `old_price`, `views`, `hot`, `action`, `added_to_cart_count`, `enable_comments`, `external_id`, `mainModImage`, `smallModImage`, `tpl`, `user_id`) VALUES (102, '102', 1, 1, 37, 40, '', '102_main.jpg', '102_small.jpg', 1307545161, 1355844036, '550.00', 42, 0, 1, 3, 1, NULL, '102_mainMod.jpg', '102_smallMod.jpg', '', NULL);
INSERT INTO shop_products (`id`, `url`, `active`, `hit`, `brand_id`, `category_id`, `related_products`, `mainImage`, `smallImage`, `created`, `updated`, `old_price`, `views`, `hot`, `action`, `added_to_cart_count`, `enable_comments`, `external_id`, `mainModImage`, `smallModImage`, `tpl`, `user_id`) VALUES (103, '103', 1, 1, 37, 40, '', '103_main.jpg', '103_small.jpg', 1307543901, 1355844048, '86.00', NULL, 0, 1, NULL, 1, NULL, '103_mainMod.jpg', '103_smallMod.jpg', '', NULL);
INSERT INTO shop_products (`id`, `url`, `active`, `hit`, `brand_id`, `category_id`, `related_products`, `mainImage`, `smallImage`, `created`, `updated`, `old_price`, `views`, `hot`, `action`, `added_to_cart_count`, `enable_comments`, `external_id`, `mainModImage`, `smallModImage`, `tpl`, `user_id`) VALUES (104, '104', 1, 1, 0, 40, '', '104_main.jpg', '104_small.jpg', 1307543227, 1385123065, '800.00', NULL, 0, 1, NULL, 1, NULL, '104_mainMod.jpg', '104_smallMod.jpg', '', NULL);
INSERT INTO shop_products (`id`, `url`, `active`, `hit`, `brand_id`, `category_id`, `related_products`, `mainImage`, `smallImage`, `created`, `updated`, `old_price`, `views`, `hot`, `action`, `added_to_cart_count`, `enable_comments`, `external_id`, `mainModImage`, `smallModImage`, `tpl`, `user_id`) VALUES (105, '105', 1, NULL, 29, 40, '', '105_main.jpg', '105_small.jpg', 1307543429, 1355497850, '0.00', 13, NULL, NULL, 2, 1, NULL, '105_mainMod.jpg', '105_smallMod.jpg', '', NULL);
INSERT INTO shop_products (`id`, `url`, `active`, `hit`, `brand_id`, `category_id`, `related_products`, `mainImage`, `smallImage`, `created`, `updated`, `old_price`, `views`, `hot`, `action`, `added_to_cart_count`, `enable_comments`, `external_id`, `mainModImage`, `smallModImage`, `tpl`, `user_id`) VALUES (106, '106', 1, 1, 29, 40, '', '106_main.jpg', '106_small.jpg', 1307543089, 1355763302, '0.00', 27, NULL, NULL, 2, 1, NULL, '106_mainMod.jpg', '106_smallMod.jpg', '', NULL);
INSERT INTO shop_products (`id`, `url`, `active`, `hit`, `brand_id`, `category_id`, `related_products`, `mainImage`, `smallImage`, `created`, `updated`, `old_price`, `views`, `hot`, `action`, `added_to_cart_count`, `enable_comments`, `external_id`, `mainModImage`, `smallModImage`, `tpl`, `user_id`) VALUES (107, '107', 1, NULL, 0, 40, '', '107_main.jpg', '107_small.jpg', 1307541701, 1355496710, '0.00', 4, NULL, NULL, NULL, 1, NULL, '107_mainMod.jpg', '107_smallMod.jpg', '', NULL);
INSERT INTO shop_products (`id`, `url`, `active`, `hit`, `brand_id`, `category_id`, `related_products`, `mainImage`, `smallImage`, `created`, `updated`, `old_price`, `views`, `hot`, `action`, `added_to_cart_count`, `enable_comments`, `external_id`, `mainModImage`, `smallModImage`, `tpl`, `user_id`) VALUES (108, '108', 1, 1, 0, 40, '', '108_main.jpg', '108_small.jpg', 1307544069, 1355496690, '0.00', 133, NULL, NULL, 5, 1, NULL, '108_mainMod.jpg', '108_smallMod.jpg', '', NULL);
INSERT INTO shop_products (`id`, `url`, `active`, `hit`, `brand_id`, `category_id`, `related_products`, `mainImage`, `smallImage`, `created`, `updated`, `old_price`, `views`, `hot`, `action`, `added_to_cart_count`, `enable_comments`, `external_id`, `mainModImage`, `smallModImage`, `tpl`, `user_id`) VALUES (109, '109', 1, NULL, 29, 40, '', '109_main.jpg', '109_small.jpg', 1307544627, 1355496650, '0.00', 3, NULL, NULL, 1, 1, NULL, '109_mainMod.jpg', '109_smallMod.jpg', '', NULL);
INSERT INTO shop_products (`id`, `url`, `active`, `hit`, `brand_id`, `category_id`, `related_products`, `mainImage`, `smallImage`, `created`, `updated`, `old_price`, `views`, `hot`, `action`, `added_to_cart_count`, `enable_comments`, `external_id`, `mainModImage`, `smallModImage`, `tpl`, `user_id`) VALUES (110, '110', 1, NULL, 0, 40, '', '110_main.jpg', '110_small.jpg', 1307543831, 1355496634, '0.00', 61, NULL, NULL, 2, 1, NULL, '110_mainMod.jpg', '110_smallMod.jpg', '', NULL);
INSERT INTO shop_products (`id`, `url`, `active`, `hit`, `brand_id`, `category_id`, `related_products`, `mainImage`, `smallImage`, `created`, `updated`, `old_price`, `views`, `hot`, `action`, `added_to_cart_count`, `enable_comments`, `external_id`, `mainModImage`, `smallModImage`, `tpl`, `user_id`) VALUES (111, '111', 1, NULL, 0, 40, '', '111_main.jpg', '111_small.jpg', 1307543077, 1355496626, '0.00', NULL, NULL, NULL, NULL, 1, NULL, '111_mainMod.jpg', '111_smallMod.jpg', '', NULL);
INSERT INTO shop_products (`id`, `url`, `active`, `hit`, `brand_id`, `category_id`, `related_products`, `mainImage`, `smallImage`, `created`, `updated`, `old_price`, `views`, `hot`, `action`, `added_to_cart_count`, `enable_comments`, `external_id`, `mainModImage`, `smallModImage`, `tpl`, `user_id`) VALUES (112, '112', 1, NULL, 39, 40, '', '112_main.jpg', '112_small.jpg', 1307543753, 1355496967, '0.00', 5, NULL, NULL, 1, 1, NULL, '112_mainMod.jpg', '112_smallMod.jpg', '', NULL);
INSERT INTO shop_products (`id`, `url`, `active`, `hit`, `brand_id`, `category_id`, `related_products`, `mainImage`, `smallImage`, `created`, `updated`, `old_price`, `views`, `hot`, `action`, `added_to_cart_count`, `enable_comments`, `external_id`, `mainModImage`, `smallModImage`, `tpl`, `user_id`) VALUES (113, '113', 1, NULL, 35, 40, '', '113_main.jpg', '113_small.jpg', 1307542831, 1355496921, '0.00', NULL, NULL, NULL, NULL, 1, NULL, '113_mainMod.jpg', '113_smallMod.jpg', '', NULL);
INSERT INTO shop_products (`id`, `url`, `active`, `hit`, `brand_id`, `category_id`, `related_products`, `mainImage`, `smallImage`, `created`, `updated`, `old_price`, `views`, `hot`, `action`, `added_to_cart_count`, `enable_comments`, `external_id`, `mainModImage`, `smallModImage`, `tpl`, `user_id`) VALUES (114, '114', 1, NULL, 28, 40, '', '114_main.jpg', '114_small.jpg', 1307543699, 1355496903, '0.00', 1, NULL, NULL, NULL, 1, NULL, '114_mainMod.jpg', '114_smallMod.jpg', '', NULL);
INSERT INTO shop_products (`id`, `url`, `active`, `hit`, `brand_id`, `category_id`, `related_products`, `mainImage`, `smallImage`, `created`, `updated`, `old_price`, `views`, `hot`, `action`, `added_to_cart_count`, `enable_comments`, `external_id`, `mainModImage`, `smallModImage`, `tpl`, `user_id`) VALUES (115, '115', 1, NULL, 30, 40, '', '115_main.jpg', '115_small.jpg', 1307543689, 1355496893, '0.00', 17, NULL, NULL, 1, 1, NULL, '115_mainMod.jpg', '115_smallMod.jpg', '', NULL);
INSERT INTO shop_products (`id`, `url`, `active`, `hit`, `brand_id`, `category_id`, `related_products`, `mainImage`, `smallImage`, `created`, `updated`, `old_price`, `views`, `hot`, `action`, `added_to_cart_count`, `enable_comments`, `external_id`, `mainModImage`, `smallModImage`, `tpl`, `user_id`) VALUES (116, '116', 1, NULL, 0, 40, '', '116_main.jpg', '116_small.jpg', 1307542992, 1355496886, '0.00', NULL, NULL, NULL, 1, 1, NULL, '116_mainMod.jpg', '116_smallMod.jpg', '', NULL);
INSERT INTO shop_products (`id`, `url`, `active`, `hit`, `brand_id`, `category_id`, `related_products`, `mainImage`, `smallImage`, `created`, `updated`, `old_price`, `views`, `hot`, `action`, `added_to_cart_count`, `enable_comments`, `external_id`, `mainModImage`, `smallModImage`, `tpl`, `user_id`) VALUES (117, '117', 1, NULL, 0, 40, '', '117_main.jpg', '117_small.jpg', 1307542495, 1355496876, '0.00', NULL, NULL, NULL, NULL, 1, NULL, '117_mainMod.jpg', '117_smallMod.jpg', '', NULL);
INSERT INTO shop_products (`id`, `url`, `active`, `hit`, `brand_id`, `category_id`, `related_products`, `mainImage`, `smallImage`, `created`, `updated`, `old_price`, `views`, `hot`, `action`, `added_to_cart_count`, `enable_comments`, `external_id`, `mainModImage`, `smallModImage`, `tpl`, `user_id`) VALUES (118, '118', 1, NULL, 30, 40, '', '118_main.jpg', '118_small.jpg', 1307543269, 1355496864, '0.00', 1, NULL, NULL, NULL, 1, NULL, '118_mainMod.jpg', '118_smallMod.jpg', '', NULL);
INSERT INTO shop_products (`id`, `url`, `active`, `hit`, `brand_id`, `category_id`, `related_products`, `mainImage`, `smallImage`, `created`, `updated`, `old_price`, `views`, `hot`, `action`, `added_to_cart_count`, `enable_comments`, `external_id`, `mainModImage`, `smallModImage`, `tpl`, `user_id`) VALUES (119, '119', 1, 1, 30, 40, '', '119_main.jpg', '119_small.jpg', 1307543316, 1355496856, '0.00', 7, NULL, NULL, NULL, 1, NULL, '119_mainMod.jpg', '119_smallMod.jpg', '', NULL);
INSERT INTO shop_products (`id`, `url`, `active`, `hit`, `brand_id`, `category_id`, `related_products`, `mainImage`, `smallImage`, `created`, `updated`, `old_price`, `views`, `hot`, `action`, `added_to_cart_count`, `enable_comments`, `external_id`, `mainModImage`, `smallModImage`, `tpl`, `user_id`) VALUES (120, '120', 1, NULL, 30, 40, '', '120_main.jpg', '120_small.jpg', 1307542029, 1355496824, '0.00', 9, NULL, NULL, 2, 1, NULL, '120_mainMod.jpg', '120_smallMod.jpg', '', NULL);
INSERT INTO shop_products (`id`, `url`, `active`, `hit`, `brand_id`, `category_id`, `related_products`, `mainImage`, `smallImage`, `created`, `updated`, `old_price`, `views`, `hot`, `action`, `added_to_cart_count`, `enable_comments`, `external_id`, `mainModImage`, `smallModImage`, `tpl`, `user_id`) VALUES (121, '121', 1, NULL, 30, 40, '', '121_main.jpg', '121_small.jpg', 1307543909, 1355497245, '0.00', 5, NULL, NULL, 2, 1, NULL, '121_mainMod.jpg', '121_smallMod.jpg', '', NULL);
INSERT INTO shop_products (`id`, `url`, `active`, `hit`, `brand_id`, `category_id`, `related_products`, `mainImage`, `smallImage`, `created`, `updated`, `old_price`, `views`, `hot`, `action`, `added_to_cart_count`, `enable_comments`, `external_id`, `mainModImage`, `smallModImage`, `tpl`, `user_id`) VALUES (122, '122', 1, NULL, 29, 40, '', '122_main.jpg', '122_small.jpg', 1307543511, 1355497077, '0.00', 1, NULL, NULL, 2, 1, NULL, '122_mainMod.jpg', '122_smallMod.jpg', '', NULL);
INSERT INTO shop_products (`id`, `url`, `active`, `hit`, `brand_id`, `category_id`, `related_products`, `mainImage`, `smallImage`, `created`, `updated`, `old_price`, `views`, `hot`, `action`, `added_to_cart_count`, `enable_comments`, `external_id`, `mainModImage`, `smallModImage`, `tpl`, `user_id`) VALUES (123, '123', 1, NULL, 0, 40, '', '123_main.jpg', '123_small.jpg', 1307543925, 1355497060, '0.00', 25, NULL, NULL, 1, 1, NULL, '123_mainMod.jpg', '123_smallMod.jpg', '', NULL);
INSERT INTO shop_products (`id`, `url`, `active`, `hit`, `brand_id`, `category_id`, `related_products`, `mainImage`, `smallImage`, `created`, `updated`, `old_price`, `views`, `hot`, `action`, `added_to_cart_count`, `enable_comments`, `external_id`, `mainModImage`, `smallModImage`, `tpl`, `user_id`) VALUES (124, '124', 1, NULL, 0, 40, '', '124_main.jpg', '124_small.jpg', 1307542680, 1355497269, '0.00', NULL, NULL, NULL, 1, 1, NULL, '124_mainMod.jpg', '124_smallMod.jpg', '', NULL);
INSERT INTO shop_products (`id`, `url`, `active`, `hit`, `brand_id`, `category_id`, `related_products`, `mainImage`, `smallImage`, `created`, `updated`, `old_price`, `views`, `hot`, `action`, `added_to_cart_count`, `enable_comments`, `external_id`, `mainModImage`, `smallModImage`, `tpl`, `user_id`) VALUES (185, 'apple-iphone-5-16gb-black-slate', 1, 0, 0, 40, '108,111,107', '185_main.jpg', '185_small.jpg', 1355428800, 1385397078, '0.00', 74, NULL, NULL, 3, 1, NULL, '185_mainMod.jpg', '185_smallMod.jpg', '', NULL);
INSERT INTO shop_products (`id`, `url`, `active`, `hit`, `brand_id`, `category_id`, `related_products`, `mainImage`, `smallImage`, `created`, `updated`, `old_price`, `views`, `hot`, `action`, `added_to_cart_count`, `enable_comments`, `external_id`, `mainModImage`, `smallModImage`, `tpl`, `user_id`) VALUES (186, 'samsung-ue32eh4030wxua', 1, NULL, 0, 40, '', '186_main.jpg', '186_mainMod.jpg', 1355688000, 1355745194, '0.00', 23, NULL, NULL, 1, 1, NULL, '186_mainMod.jpg', '186_smallMod.jpg', '', NULL);
INSERT INTO shop_products (`id`, `url`, `active`, `hit`, `brand_id`, `category_id`, `related_products`, `mainImage`, `smallImage`, `created`, `updated`, `old_price`, `views`, `hot`, `action`, `added_to_cart_count`, `enable_comments`, `external_id`, `mainModImage`, `smallModImage`, `tpl`, `user_id`) VALUES (187, 'samsung-ue40es6307uxua', 1, NULL, 28, 40, '', '187_main.jpg', '187_mainMod.jpg', 1355688000, 1355745685, '0.00', 1, NULL, NULL, NULL, 1, NULL, '187_mainMod.jpg', '187_smallMod.jpg', '', NULL);
INSERT INTO shop_products (`id`, `url`, `active`, `hit`, `brand_id`, `category_id`, `related_products`, `mainImage`, `smallImage`, `created`, `updated`, `old_price`, `views`, `hot`, `action`, `added_to_cart_count`, `enable_comments`, `external_id`, `mainModImage`, `smallModImage`, `tpl`, `user_id`) VALUES (188, 'lg-32ls359t', 1, NULL, 29, 40, '', '188_main.jpg', '188_mainMod.jpg', 1355688000, 1355746100, '0.00', 9, NULL, NULL, 2, 1, NULL, '188_mainMod.jpg', '188_smallMod.jpg', '', NULL);
INSERT INTO shop_products (`id`, `url`, `active`, `hit`, `brand_id`, `category_id`, `related_products`, `mainImage`, `smallImage`, `created`, `updated`, `old_price`, `views`, `hot`, `action`, `added_to_cart_count`, `enable_comments`, `external_id`, `mainModImage`, `smallModImage`, `tpl`, `user_id`) VALUES (189, 'lg-47lm580t', 1, 1, 35, 40, '', '189_main.jpg', '189_mainMod.jpg', 1355688000, 1355750041, '0.00', 144, 1, 1, 4, 1, NULL, '189_mainMod.jpg', '189_smallMod.jpg', '', NULL);
INSERT INTO shop_products (`id`, `url`, `active`, `hit`, `brand_id`, `category_id`, `related_products`, `mainImage`, `smallImage`, `created`, `updated`, `old_price`, `views`, `hot`, `action`, `added_to_cart_count`, `enable_comments`, `external_id`, `mainModImage`, `smallModImage`, `tpl`, `user_id`) VALUES (190, 'samsung-le40d550k1wxua', 1, 1, 28, 40, '', '190_main.jpg', '190_mainMod.jpg', 1355688000, 1355747897, '0.00', 54, NULL, NULL, NULL, 1, NULL, '190_mainMod.jpg', '190_smallMod.jpg', '', NULL);
INSERT INTO shop_products (`id`, `url`, `active`, `hit`, `brand_id`, `category_id`, `related_products`, `mainImage`, `smallImage`, `created`, `updated`, `old_price`, `views`, `hot`, `action`, `added_to_cart_count`, `enable_comments`, `external_id`, `mainModImage`, `smallModImage`, `tpl`, `user_id`) VALUES (191, 'sony-kdl-22ex553', 1, NULL, 26, 40, '', '191_main.jpg', '191_mainMod.jpg', 1355688000, 1355749805, '0.00', 71, 1, 1, 2, 1, NULL, '191_mainMod.jpg', '191_smallMod.jpg', '', NULL);


#
# TABLE STRUCTURE FOR: shop_products_i18n
#

DROP TABLE IF EXISTS shop_products_i18n;

CREATE TABLE `shop_products_i18n` (
  `id` int(11) NOT NULL,
  `locale` varchar(5) NOT NULL,
  `name` varchar(500) NOT NULL,
  `short_description` text,
  `full_description` text,
  `meta_title` varchar(255) DEFAULT NULL,
  `meta_description` varchar(255) DEFAULT NULL,
  `meta_keywords` varchar(255) DEFAULT NULL,
  PRIMARY KEY (`id`,`locale`),
  KEY `shop_products_i18n_I_1` (`name`(333))
) ENGINE=MyISAM DEFAULT CHARSET=utf8;

INSERT INTO shop_products_i18n (`id`, `locale`, `name`, `short_description`, `full_description`, `meta_title`, `meta_description`, `meta_keywords`) VALUES (71, 'ru', 'Sony KDL46EX710', '<p>ЖК ТВ: технология Motionflow 100Hz, эко-функции, экран с Edge LED, диагональ 117 см / 46, Full HD 1080, Wireless LAN Ready</p>', '<p><strong>Множество функций для вашего отдыха</strong><br /> Супертонкий <strong>EX710</strong> очень просто перемещать из комнаты в комнату. Великолепное ТВ-изображение и потрясающий просмотр в Full HD. Дизайн без лишних проводов для удобного размещения в любом пространстве. Онлайн-развлечения для приятного отдыха на многие часы. Отличные функции и экономия электричества.<br /> <br /> <strong>Потрясающий просмотр в качестве Full HD</strong><br /> Передовая технология подсветки Edge LED помогает реализовывать бесподобное качество изображения в ультра-тонком корпусе. Технология Motionflow 100Hz позволяет добиться бесподобной контрастности и четкости, а также насыщенных цветов и плавного отображения динамичных сцен &ndash; максимум удовольствия от любимых фильмов и видеоигр.<br /> <br /> <strong>Порядок без проводов</strong><br /> Эта модель позволит сэкономить место в доме. Тонкий корпус с гладкими поверхностями идеально впишется в интерьер вашей комнаты. Телевизор также предусматривает соединение по Wi-Fi, что позволит подключиться к Интернету, без использования неприглядных проводов.<br /> <br /> <strong>Развлечения и экономия электроэнергии</strong><br /> Данная модель позволяет экономить электричество. Датчик присутствия определяет, когда в комнате никого нет, и выключает телевизор автоматически. Датчик освещения автоматически подбирает оптимальные настройки яркости изображения в соответствии с освещением и экономит электроэнергию при низком освещении.</p>', '', '', '');
INSERT INTO shop_products_i18n (`id`, `locale`, `name`, `short_description`, `full_description`, `meta_title`, `meta_description`, `meta_keywords`) VALUES (96, 'ru', 'Canon VIXIA HF R11 Digital', '<p><strong>Тип</strong>: компактный, <strong> Количество мегапикселей</strong>: 12,1, <strong> Оптическое увеличение</strong>: 5, <strong> Слот для карт памяти</strong>: SD, SDHC, SDXC, <strong> Питание</strong>: Li-Ion аккумулятор, <strong> Вес, г</strong>: 198</p>', '<p>&nbsp;</p>\r\n<h3>Система HS&nbsp;</h3>\r\n<p>В представленной модели установлена специальная система HS, в которую входят процессор DIGIC 5 и 12,1-мегапиксельный сенсор. Их совместная работа обеспечивает фото с низким уровнем шума, высокой детализацией и естественной цветопередачей. Вы получите великолепный результат и при плохом освещении без использования штатива и вспышки.&nbsp;</p>\r\n<h3>Универсальный объектив</h3>\r\n<p>В отзывах о Canon PowerShot S100 Silver упоминают и об универсальных возможностях объектива. 24-миллиметровый широкоугольный объектив легко справится и с пейзажами, и с портретами, и с макросъемкой, а 5-кратный зум приблизит удаленные объекты. Благодаря интеллектуальному стабилизатору изображения камера автоматически выберет наиболее подходящий режим оптической стабилизации из 7-ми возможных вариантов.&nbsp;&lt;p&gt;&lt;a href=\"http://repka.ua/products/cifrovye-fotoapparaty/canon-powershot-s100-silver/42633.html?gclid=CM2qwKHIl7QCFYJP3godkBEAfA\"&gt;.&lt;/a&gt;&lt;/p&gt;</p>', '', '', '');
INSERT INTO shop_products_i18n (`id`, `locale`, `name`, `short_description`, `full_description`, `meta_title`, `meta_description`, `meta_keywords`) VALUES (78, 'ru', 'Sony KDL-22EX553', '<p>22 // 1366x768 пикс // 50 Гц // LED подсветка // эфирный (DVB-T) // кабельный (DVB-C) // HDMI: 2 шт // Компонентный //Композитный // SCART // USB // LAN // Линейный</p>', '<p>&lt;div&gt;&lt;strong&gt;KDL-22EX553&lt;br&gt; Новый способ просмотра ТВ&lt;/strong&gt;&lt;/div&gt;&lt;br&gt; 55 см / 22\", телевизор HD Ready с технологией подсветки Edge LED, X-Reality, встроенным Wi-Fi&reg; и интернет-телевидением от Sony&lt;br&gt; Наслаждайтесь четким отображением на тонком экране Edge LED&lt;br&gt; Wi-Fi обеспечивает быстрый доступ к функции просмотра пропущенных программ, фильмам и приложениям&lt;br&gt; Для более комфортного просмотра предусматривается изменение угла наклона телевизора&lt;br&gt; &lt;br&gt; &lt;div&gt;&lt;strong&gt;Мир развлечений на кончиках пальцев&lt;/strong&gt;&lt;/div&gt;&lt;br&gt; Начните революцию интернет-телевидения у себя дома. Откройте увлекательный новый мир передачи контента по запросу, просмотра пропущенных программ, приложений и многого другого, и все это - с четким, детализированным изображением, на большом и тонком ЖК-экране. Пришло время управлять центром развлечений в вашем доме.&lt;br&gt; &lt;br&gt; &lt;div&gt;&lt;strong&gt;Четкое, реалистичное изображение&lt;/strong&gt;&lt;/div&gt;&lt;br&gt; X-Reality обеспечивает более четкое и реалистичное HD-изображение, вне зависимости от источника: будь то интернет-канал, DVD-диск или любительский клип. Кроме того, эта технология убирает эффект мерцания, гарантируя более плавное отображение динамичных спортивных передач.&lt;br&gt; &lt;br&gt; &lt;div&gt;&lt;strong&gt;Новый дизайн, легкие материалы&lt;/strong&gt;&lt;/div&gt;&lt;br&gt; Телевизоры серии HX75 выполнены из контрастных материалов и имеют безукоризненный дизайн. Вас восхитит легкость этого телевизора, который располагается на подставке в форме мольберта, позволяющей вращать его в вертикальной и горизонтальной плоскости для идеального угла обзора.&lt;br&gt; &lt;br&gt; &lt;div&gt;&lt;strong&gt;Беспроводной доступ к онлайн-развлечениям&lt;/strong&gt;&lt;/div&gt;&lt;br&gt; Теперь доступ к контенту сетевого сервиса Sony Entertainment Network &mdash; HD-фильмам, миллионам музыкальных композиций, любимым телеканалам, веб-браузеру, приложениям Twitter&trade;, Facebook&reg;, YouTube&trade;, Skype&trade; и многому другому &mdash; осуществляется с помощью дистанционного пульта или мобильного устройства с поддержкой распознавания голоса.&lt;br&gt; &lt;br&gt; &lt;div&gt;&lt;strong&gt;Энергосберегающие функции телевизоров&lt;/strong&gt;&lt;/div&gt;&lt;br&gt; Новая функция затемнения LED Frame автоматически подстраивает яркость подсветки при просмотре и снижает потребление энергии, позволяя экономить деньги. При этом изображение остается резким и высококонтрастным.</p>', '', '', '');
INSERT INTO shop_products_i18n (`id`, `locale`, `name`, `short_description`, `full_description`, `meta_title`, `meta_description`, `meta_keywords`) VALUES (79, 'ru', 'Panasonic DVD-S38 DVD', '<p>DVD-S38 - DVD-плеер&nbsp; для домашнего использования.</p>', '<p>DVD-S38 - DVD-плеер&nbsp; для домашнего использования. <br /> <br /> &bull; Высококачественное изображение: <br /> С технологией 1080p Up-Conversion и цифроаналоговым преобразователем видеосигнала 108 МГц/12 бит <br /> С прогрессивной разверткой и цифроаналоговым преобразователем видеосигнала 108 МГц/12 бит <br /> <br /> &bull; Слайд-шоу JPEG с музыкой MP3 <br /> <br /> &bull; Экологичные материалы и компактный дизайн (ширина 360 мм)</p>', '', '', '');
INSERT INTO shop_products_i18n (`id`, `locale`, `name`, `short_description`, `full_description`, `meta_title`, `meta_description`, `meta_keywords`) VALUES (81, 'ru', 'Samsung DVD-H1080 - 1080p', '<p>DVD-плеер/выход HDMI/воспроизведение с USB-накопителей/поддержка видео в формате MPEG4, DivX</p>', '<p>Чем занять выдавшийся свободным вечер? Посмотреть телевизор? Но там, как назло, нет ничего интересного. Сходить в гости? Но на улице холодно и ветрено. А может, взять свежий DVD с фильмом и насладиться хорошим кино? Было бы неплохо, но вот беда &mdash; у вас все еще нет DVD-проигрывателя и вы смотрите кассеты на допотопном видеомагнитофоне. Значит, надо срочно обзаводиться более прогрессивным устройством. Ну а как же запись любимых телепередач, которые идут именно тогда, когда вы заняты? Как же старые видеоархивы? Все решаемо, ведь современный DVD-проигрыватель &mdash; это не обязательно только воспроизведение DVD-дисков. Есть модели, совмещенные с классическим видеомагнитофоном; устройства, способные самостоятельно записывать DVD-диски; аппараты, оснащенные жесткими дисками для записи телевизионных программ. Осталось только определиться, что вам нужно, и сделать правильный выбор.<br /> <br /> DVD &ndash; формат оптических носителей последнего поколения. DVD-диски значительно объемнее и быстрее, чем обычные CD. Они могут содержать видеоматериалы кинотеатрального качества, музыкальные файлы, цифровые фотографии и компьютерные данные. Цель DVD &ndash; объединить мультимедиа, компьютерную и деловую информацию в одном универсальном формате. DVD уже практически вытеснил лазерные диски, видеокассеты и игровые картриджи и, возможно, в скором будущем вытеснит и CD-диски. Формат DVD обладает широкой поддержкой среди основных производителей электроники и компьютерных изделий, а также среди звукозаписывающих и кино- студий. По этой причине DVD завоевал столь огромную популярность среди покупателей и стал самым распространенным форматом всего за три года. К 2003 году, за шесть лет существования, в мире насчитывалось уже более 250 миллионов DVD-устройств: DVD-плееры, рекордеры, компьютерные DVD-приводы и игровые приставки, - что сделало DVD передовым стандартом видеоиндустрии.</p>', '', '', '');
INSERT INTO shop_products_i18n (`id`, `locale`, `name`, `short_description`, `full_description`, `meta_title`, `meta_description`, `meta_keywords`) VALUES (82, 'ru', 'Samsung BD-C5500 Blu-ray', '<p>Тип оборудования Blu-ray плеер Цвета, использованные в оформлении черный Механизм загрузки дисков лоток Поддерживаемые типы дисков (воспроизведение) CD-R, CD-RW, DVD-R, DVD+R, DVD-RW, DVD+RW, BD-R, BD-RE Поддерживаемые размеры дисков 12 см, 8 см Разъемы и выходы Разъемы на передней панели USB 2.0 Type A</p>', '<p>Чем занять выдавшийся свободным вечер? Посмотреть телевизор? Но там, как назло, нет ничего интересного. Сходить в гости? Но на улице холодно и ветрено. А может, взять свежий DVD с фильмом и насладиться хорошим кино? Было бы неплохо, но вот беда &mdash; у вас все еще нет DVD-проигрывателя и вы смотрите кассеты на допотопном видеомагнитофоне. Значит, надо срочно обзаводиться более прогрессивным устройством. Ну а как же запись любимых телепередач, которые идут именно тогда, когда вы заняты? Как же старые видеоархивы? Все решаемо, ведь современный DVD-проигрыватель &mdash; это не обязательно только воспроизведение DVD-дисков. Есть модели, совмещенные с классическим видеомагнитофоном; устройства, способные самостоятельно записывать DVD-диски; аппараты, оснащенные жесткими дисками для записи телевизионных программ. Осталось только определиться, что вам нужно, и сделать правильный выбор.<br /> <br /> DVD &ndash; формат оптических носителей последнего поколения. DVD-диски значительно объемнее и быстрее, чем обычные CD. Они могут содержать видеоматериалы кинотеатрального качества, музыкальные файлы, цифровые фотографии и компьютерные данные. Цель DVD &ndash; объединить мультимедиа, компьютерную и деловую информацию в одном универсальном формате. DVD уже практически вытеснил лазерные диски, видеокассеты и игровые картриджи и, возможно, в скором будущем вытеснит и CD-диски. Формат DVD обладает широкой поддержкой среди основных производителей электроники и компьютерных изделий, а также среди звукозаписывающих и кино- студий. По этой причине DVD завоевал столь огромную популярность среди покупателей и стал самым распространенным форматом всего за три года. К 2003 году, за шесть лет существования, в мире насчитывалось уже более 250 миллионов DVD-устройств: DVD-плееры, рекордеры, компьютерные DVD-приводы и игровые приставки, - что сделало DVD передовым стандартом видеоиндустрии.</p>', '', '', '');
INSERT INTO shop_products_i18n (`id`, `locale`, `name`, `short_description`, `full_description`, `meta_title`, `meta_description`, `meta_keywords`) VALUES (83, 'ru', 'Sony BDP-S470 Network', '<p>Проигрыватель Blu-ray дисков SONY BDP-S470 B -Сверхсовременный высококачественный проигрыватель дисков Blu-ray Sony , позволяющий воспроизводить как обычные диски Blu-ray, так и диски Blu-ray 3D &mdash; с 3D-видео.</p>', '<p>Плеер дисков Blu-ray Disc 3D Ready с мгновенным доступом к онлайн-видеоматериалам!<br /> BRAVIA Internet Video, Wireless LAN ready, Entertainment Database Browser с Gracenote.<br /> Единое дизайнерское решение с линейкой техники домашних развлечений<br /> Мгновенный доступ к бесплатным фильмам и другому онлайн-содержимому<br /> iPhone/iPod touch для управления Blu-ray Disc<br /> Домашние развлечения нового поколения, в том числе потрясающая 3D-динамика на экране 3D-телевизора.<br /> Абсолютно новая модель плеера Blu-ray Disc: доступ к онлайн-контенту, работа с ПК и беспроводное подключение к Интернету.<br /> DLNA &mdash; позволяет плееру Sony Blu-ray Disc Player обмениваться информацией с другими DLNA-устройствами в доме и создавать домашнюю сеть для цифровых материалов. <br /> Новый дизайн 2010 г. BRAVIA Monolith: превосходные материалы и стильный минималистичный внешний вид. Подберите к своему телевизору BRAVIA и домашнему кинотеатру плеер Blu-ray Disc в едином стиле.<br /> Функция BRAVIA Internet Video &mdash; это доступ к онлайн-контенту. Смотрите телевизор так, как вы сами пожелаете с функцией просмотра пропущенных программ. Находите любимые записи в Интернете на таких интернет-сайтах по запросу, как YouTube и Dailymotion.<br /> Функция WLAN ready позволяет выходить в сеть без проводов: просто подключите ключ USB WIFI (приобретается дополнительно) &mdash; и вы в сети одним нажатием кнопки<br /> Полный контроль при помощи iPhone: управление работой плеера Blu-ray Disc, просмотр информации на диске и поиск связанного контента на Youtube &mdash; все это при помощи интерфейса на вашем сенсорном экране.<br /> Сверхбыстрая скорость работы: включение за 3 секунды, открытие лотка за 2 секунды и ускоренная загрузка.<br /> Просмотр фильмов Blu-ray Disc в формате Full HD 1080p и улучшенный просмотр фильмов из вашей DVD-коллекции.<br /> Узнать дополнительную информацию о фильме с диска Blu-ray Disc вы можете с помощью браузера по базе данных развлечений (Entertainment Database Browser) с технологией Gracenote.</p>', '', '', '');
INSERT INTO shop_products_i18n (`id`, `locale`, `name`, `short_description`, `full_description`, `meta_title`, `meta_description`, `meta_keywords`) VALUES (84, 'ru', 'Panasonic DMP-BD45 Ultra-Fast', '<div>\r\n<div>Проигрыватели Blu-ray Panasonic&nbsp;DMP-BD45 Ultra-Fast</div>\r\n</div>', '<p>Процессор цветности PHL Reference Chroma Plus<br /> PHL Reference Chroma Processor Plus - это высококачественная интегральная схема, созданная для точной обработки каждого пикселя Blu-Ray видеосигнала в вертикальном направлении. Она воспроизводит цветовую информацию с удвоенной точностью по сравнению с обычными системами, чтобы поддерживать достоверность и резкость цветопередачи.<br /> <br /> Сверхбыстрая 0, 5-сек загрузка<br /> Время перехода из режима ожидания в рабочий режим значительно сократилось по сравнению с прежними моделями. Благодаря этому усовершенствованию вы сможете быстрее начать просмотр, не теряя времени на ожидание.</p>', '', '', '');
INSERT INTO shop_products_i18n (`id`, `locale`, `name`, `short_description`, `full_description`, `meta_title`, `meta_description`, `meta_keywords`) VALUES (85, 'ru', 'LG BD570 Network Audio', '<p>Програвач BD LG BD570 (V-DAC 162 МГц/12bit, A-DAC 192 кГц/24bit, 1080p/60 Гц, BD-ROM, BD-R, BD-RE, DVD-R/RW, DVD+R/RW, CD-R/RW, MP3, WMA, JPEG, DivX, XviD, MKV(H.264), AVCHD, Dolby True HD/DTS HD MA/DTS / Dolby Digital, BD Live 2.0, Gracenote, NetCast (Youtube, Picassa, AccuWeather), DLNA/CIFS, HDMI 1.3, USB 2.0, Подкючение внешнего HDD, 430 х 45 х...</p>', '<p>&amp;lt;p&amp;gt;LG BD570 является необычным Blu-ray плеером: встроенный модуль беспроводной связи Wi-Fi позволяет новой модели подключаться к домашней беспроводной сети и Интернету, расширяя тем самым возможности домашних развлечений.&amp;lt;br&amp;gt; &ldquo;Люди не должны ограничивать себя только просмотром фильмов, которые выходят на дисках, - сказал Саймон Канг (Simon Kang), исполнительный директор и президент компании LG Home Entertainment. &ndash; Они должны иметь доступ к дополнительному медиа контенту из Интернета. Мы добавили в BD570 эту возможность, позволяющую передавать большой объем аудио-, видеофайлов и прочих развлечений прямо на экран телевизора&rdquo;.&amp;lt;br&amp;gt; &amp;lt;br&amp;gt; Беспроводный доступ в Интернет, который обеспечивает новая модель Blu-Ray проигрывателя LG, позволяет его владельцам смотреть потоковое видео с сайта YouTube или фотографии из веб- альбома Picasa на большом экране Full HD телевизора, а не на маленьком экране компьютерного монитора. Также с помощью BD570 можно дополнить содержимое Blu- Ray диска, загрузив дополнительную информацию через профиль BD Live 2. 0. Беспроводное подключение обеспечивает удобный доступ к информационным сайтам, например прогнозу погоды от Accuweather, а благодаря интуитивно понятному интерфейсу пользоваться BD570 сможет даже ребенок.&amp;lt;br&amp;gt; &amp;lt;br&amp;gt; &amp;lt;br&amp;gt; Во многих семьях накопились уже целые медиа- библиотеки, состоящие из большого числа фильмов, музыки, домашнего видео и фотографий. BD570 помогает собрать подобные медиа- файлы воедино, подключаясь ко всем компьютерам или DNLA- совместимым устройствам хранения данных, входящим в домашнюю сеть, посредством Wi- Fi и позволяет просматривать всю эту информацию на экране телевизора. Также плеер способен воспроизводить фильмы в формате DivX или MKV непосредственно с внешних жестких дисков или флэш- накопителей, подключенных по USB.&amp;lt;br&amp;gt; &amp;lt;br&amp;gt; Интерфейс HDMI позволяет подключать LG BD570 к большинству современных телевизоров с помощью единственного кабеля, обеспечивая зрителям максимально качественное изображение как при воспроизведении Blu- Ray дисков, так и обычных DVD, которые он декодирует в разрешении до 1080p. &amp;lt;/p&amp;gt;</p>', '', '', '');
INSERT INTO shop_products_i18n (`id`, `locale`, `name`, `short_description`, `full_description`, `meta_title`, `meta_description`, `meta_keywords`) VALUES (86, 'ru', 'Samsung BD-C6900 1080p 3D Blu-ray', '<p>Програвач Blu-ray Samsung BD-C6900 (3D Blu-ray, BD-R/RE, DVD-Video, DVD/DVD&plusmn;R/DVD&plusmn;RW, USB Storage, MPEG2, H.264,VC-1, AVCHD, DivX HD, MKV, MP4, WMV9, HD JPEG, Internet@TV, All Share Ethernet, HDMI (V.1.4 + 3D)430 x 205 x 43/1,8кг, чорний)</p>', '<p>&nbsp;</p>\r\n<div>Чем занять выдавшийся свободным вечер? Посмотреть телевизор? Но там, как назло, нет ничего интересного. Сходить в гости? Но на улице холодно и ветрено. А может, взять свежий DVD с фильмом и насладиться хорошим кино? Было бы неплохо, но вот беда &mdash; у вас все еще нет DVD-проигрывателя и вы смотрите кассеты на допотопном видеомагнитофоне. Значит, надо срочно обзаводиться более прогрессивным устройством. Ну а как же запись любимых телепередач, которые идут именно тогда, когда вы заняты? Как же старые видеоархивы? Все решаемо, ведь современный DVD-проигрыватель &mdash; это не обязательно только воспроизведение DVD-дисков. Есть модели, совмещенные с классическим видеомагнитофоном; устройства, способные самостоятельно записывать DVD-диски; аппараты, оснащенные жесткими дисками для записи телевизионных программ. Осталось только определиться, что вам нужно, и сделать правильный выбор.<br /> <br /> DVD &ndash; формат оптических носителей последнего поколения. DVD-диски значительно объемнее и быстрее, чем обычные CD. Они могут содержать видеоматериалы кинотеатрального качества, музыкальные файлы, цифровые фотографии и компьютерные данные. Цель DVD &ndash; объединить мультимедиа, компьютерную и деловую информацию в одном универсальном формате. DVD уже практически вытеснил лазерные диски, видеокассеты и игровые картриджи и, возможно, в скором будущем вытеснит и CD-диски. Формат DVD обладает широкой поддержкой среди основных производителей электроники и компьютерных изделий, а также среди звукозаписывающих и кино- студий. По этой причине DVD завоевал столь огромную популярность среди покупателей и стал самым распространенным форматом всего за три года. К 2003 году, за шесть лет существования, в мире насчитывалось уже более 250 миллионов DVD-устройств: DVD-плееры, рекордеры, компьютерные DVD-приводы и игровые приставки, - что сделало DVD передовым стандартом видеоиндустрии.</div>', '', '', '');
INSERT INTO shop_products_i18n (`id`, `locale`, `name`, `short_description`, `full_description`, `meta_title`, `meta_description`, `meta_keywords`) VALUES (87, 'ru', 'Sony HT-SS370 Home Theater', '', '<p>Высоко технологический продукт, который поможет Вам оценить качество на высшем уровне.<br /><br />Все продукты доступны в наличии, а наши менеджеры помогу Вам произвести покупку в кратчайшие сроки.<br /><br />На все продукты мы предоставляем гарантию качества.<br /><br />Приобретайте только в нашем Интернет-магазине по лучшим ценам.</p>', '', '', '');
INSERT INTO shop_products_i18n (`id`, `locale`, `name`, `short_description`, `full_description`, `meta_title`, `meta_description`, `meta_keywords`) VALUES (88, 'ru', 'Samsung HW-C770BS 7.1 Channel', '', '<p>Высоко технологический продукт, который поможет Вам оценить качество на высшем уровне.<br /><br />Все продукты доступны в наличии, а наши менеджеры помогу Вам произвести покупку в кратчайшие сроки.<br /><br />На все продукты мы предоставляем гарантию качества.<br /><br />Приобретайте только в нашем Интернет-магазине по лучшим ценам.</p>', '', '', '');
INSERT INTO shop_products_i18n (`id`, `locale`, `name`, `short_description`, `full_description`, `meta_title`, `meta_description`, `meta_keywords`) VALUES (95, 'ru', 'Canon EOS Rebel T2i 18 Megapixel Digital', '', '<p>Высоко технологический продукт, который поможет Вам оценить качество на высшем уровне.<br /><br />Все продукты доступны в наличии, а наши менеджеры помогу Вам произвести покупку в кратчайшие сроки.<br /><br />На все продукты мы предоставляем гарантию качества.<br /><br />Приобретайте только в нашем Интернет-магазине по лучшим ценам.</p>', '', '', '');
INSERT INTO shop_products_i18n (`id`, `locale`, `name`, `short_description`, `full_description`, `meta_title`, `meta_description`, `meta_keywords`) VALUES (89, 'ru', 'Panasonic SCPTX7 Home Theater', '', '<p>Высоко технологический продукт, который поможет Вам оценить качество на высшем уровне.<br /><br />Все продукты доступны в наличии, а наши менеджеры помогу Вам произвести покупку в кратчайшие сроки.<br /><br />На все продукты мы предоставляем гарантию качества.<br /><br />Приобретайте только в нашем Интернет-магазине по лучшим ценам.</p>', '', '', '');
INSERT INTO shop_products_i18n (`id`, `locale`, `name`, `short_description`, `full_description`, `meta_title`, `meta_description`, `meta_keywords`) VALUES (90, 'ru', 'Samsung HT-C7530W 5.1 Channel', ' ', '<p>Высоко технологический продукт, который поможет Вам оценить качество на высшем уровне.<br><br>Все продукты доступны в наличии, а наши менеджеры помогу Вам произвести покупку в кратчайшие сроки.<br><br>На все продукты мы предоставляем гарантию качества.<br><br>Приобретайте только в нашем Интернет-магазине по лучшим ценам.</p>  ', '', '', '');
INSERT INTO shop_products_i18n (`id`, `locale`, `name`, `short_description`, `full_description`, `meta_title`, `meta_description`, `meta_keywords`) VALUES (91, 'ru', 'Sony BDV-E770W Home Theater', '', '<p>Высоко технологический продукт, который поможет Вам оценить качество на высшем уровне.<br /><br />Все продукты доступны в наличии, а наши менеджеры помогу Вам произвести покупку в кратчайшие сроки.<br /><br />На все продукты мы предоставляем гарантию качества.<br /><br />Приобретайте только в нашем Интернет-магазине по лучшим ценам.</p>', '', '', '');
INSERT INTO shop_products_i18n (`id`, `locale`, `name`, `short_description`, `full_description`, `meta_title`, `meta_description`, `meta_keywords`) VALUES (92, 'ru', 'Samsung HW-C700 7.2 Channel', ' ', '<p>Высоко технологический продукт, который поможет Вам оценить качество на высшем уровне.<br><br>Все продукты доступны в наличии, а наши менеджеры помогу Вам произвести покупку в кратчайшие сроки.<br><br>На все продукты мы предоставляем гарантию качества.<br><br>Приобретайте только в нашем Интернет-магазине по лучшим ценам.</p>  ', '', '', '');
INSERT INTO shop_products_i18n (`id`, `locale`, `name`, `short_description`, `full_description`, `meta_title`, `meta_description`, `meta_keywords`) VALUES (93, 'ru', 'Yamaha HS80M Powered Speaker', '<p>Изящные спикеры с белым конусом, используемые в мониторах HS-ряда обеспечивают превосходное звучание, которое улучшено тщательно спроектируемым корпусом</p>', '<p>Изящные спикеры с белым конусом, используемые в мониторах HS-ряда обеспечивают превосходное звучание, которое улучшено тщательно спроектируемым корпусом. Комбинация винтов и специально разработанного кольца устраняют вибрацию и резонанс, разрешая спикеру выдавать ровный звуковой диапазон. Другая особенность, которая повышает работу басового спикера - специально отобранный магнит. Динамик для передачи высокого тона использует передовой проект гладкого контура, который минимизирует потери так, чтобы высокочастотные детали воспроизводились с превосходной точностью.</p>', '', '', '');
INSERT INTO shop_products_i18n (`id`, `locale`, `name`, `short_description`, `full_description`, `meta_title`, `meta_description`, `meta_keywords`) VALUES (94, 'ru', 'Yamaha NSIW760 Speaker', ' ', '<p>Высоко технологический продукт, который поможет Вам оценить качество на высшем уровне.<br><br>Все продукты доступны в наличии, а наши менеджеры помогу Вам произвести покупку в кратчайшие сроки.<br><br>На все продукты мы предоставляем гарантию качества.<br><br>Приобретайте только в нашем Интернет-магазине по лучшим ценам.</p>  ', '', '', '');
INSERT INTO shop_products_i18n (`id`, `locale`, `name`, `short_description`, `full_description`, `meta_title`, `meta_description`, `meta_keywords`) VALUES (97, 'ru', 'Sony Handycam HDR-CX3', 'Flash, AVCHD, Full HD, 1920x1080, 1/4, 1CMOS, фоторежим, zoom 12x/160x, \nMS Duo, SD, SDHC, 112x52x64 мм, 320 г  ', '<p>Запись до 13 ч видео Full HD великолепного качества на встроенную память\n 32 ГБ, и еще больше — с дополнительной картой памяти. Великолепный \nдизайн, передовые оптические технологии и удобные функции помогают \nснимать прекрасные видеофильмы и фотографии с исключительным уровнем \nдетализации.<br>\n<br>\n<strong>Мало света – не проблема</strong><br>\nМногие камеры плохо снимают в условиях низкой освещенности, делая \nзернистые, шумные кадры. Сверхчувствительная матрица CMOS Exmor R™ \nсокращает шум и улучшает четкость. А в сочетании с мощным процессором \nBIONZ камера обеспечивает отличные результаты при плохом свете, в темных\n помещениях и сумерках.<br>\n<br>\n<strong>Уместить больше в одном кадре</strong><br>\nТеперь при съемке праздника, дня рождения и других знаменательных \nсобытий точно никто не останется за кадром. Высококачественный объектив G\n от Sony в камере Handycam® теперь снабжен улучшенными возможностями \nширокоугольной съемки, и снимает почти в 2 раза больше, чем предыдущие \nмодели.<br>\n<br>\n<strong>Двигайтесь. Используйте зум. Делайте снимки: Еще больше четкости</strong><br>\nБез штатива снимки часто получаются смазанные. Новый оптический режим \nSteadyShot Active Mode обеспечивает коррекцию дрожания камеры в трех \nнаправлениях, на любом значении зума, даже если вы снимаете на ходу. \nКамера обладает в десять раз более эффективной стабилизацией изображения\n при широкоугольной съемке.<br>\n<br>\n<strong>Наилучшее качество изображения в стандарте Full HD</strong><br>\nЧем больше бит содержит каждый кадр, тем лучше качество изображения. Для\n наиболее ответственных видеосъемок в камере FX Mode предусмотрен режим с\n разрешением 1920x1080/50i и скоростью передачи данных 24 Мб/с — самое \nвысокое возможное значение для формата AVCHD.<br>\n<br>\n<strong>Ловите момент</strong><br>\nФункция Golf Shot позволяет снимать серию кадров на высокой скорости. \nОтличный способ улучшить свою технику удара... или запечатлеть любую \nдинамичную сцену в мельчайших подробностях.  </p>  ', '', '', '');
INSERT INTO shop_products_i18n (`id`, `locale`, `name`, `short_description`, `full_description`, `meta_title`, `meta_description`, `meta_keywords`) VALUES (98, 'ru', 'Samsung NX10 14 Megapixel Digital', '<p>Матрица 23,4x15,6мм, 14,6 Мп / Объектив: 18-55mm OIS / поддержка карт памяти SD/SDHC / AMOLED-дисплей 3\" / поддержка RAW / HD-видео / питание от литий-ионного аккумулятора / 123 x 87 x 39,8 мм, 353 г / черный</p>', '<p><em>Samsung NX10</em> &mdash; 14,6 Мп камера со сменной оптикой и электронным видоискателем. Так как оптического видоискателя с зеркалом и призмой для прямого визирования через объектив у нее нет, корпус получился существенно более компактным, чем у зеркалок. Отсутствие зеркала позволило максимально приблизить объектив к матрице. Что, в свою очередь, дает возможность делать короткофокусные объективы более простыми и компактными, чем у камер с зеркальной системой видоискателя.</p>', '', '', '');
INSERT INTO shop_products_i18n (`id`, `locale`, `name`, `short_description`, `full_description`, `meta_title`, `meta_description`, `meta_keywords`) VALUES (99, 'ru', 'Samsung NX100 Interchangeable Lens', '<p>Матрица 23.5</p>', '<p>Матрица 23.5 &times; 15.7 мм, 20.3 Мп / объектив: 20-50 мм / поддержка карт памяти SD/SDHC/SDXC / LCD-дисплей 3\" / FullHD-видео / Wi-Fi / питание от литий-ионного аккумулятора / 114 x 62.5 x 37.5 мм, 220.4 г / черный </p>', '', '', '');
INSERT INTO shop_products_i18n (`id`, `locale`, `name`, `short_description`, `full_description`, `meta_title`, `meta_description`, `meta_keywords`) VALUES (100, 'ru', 'Canon PIXMA iP100 Photo Printer', '<p>принтер струменевий з акумулятором iP100 with battery</p>', '<p>Принцип действия струйных принтеров похож на матричные принтеры тем, что изображение на носителе формируется из точек. Но вместо головок с иголками в струйных принтерах используется матрица сопел (т. н. головка), печатающая жидкими красителями. Печатающая головка может быть встроена в картриджи с красителями (в основном такой подход используется компаниями Hewlett-Packard, Lexmark), а может и является деталью принтера, а сменные картриджи содержат только краситель (Epson, Canon).<br /> <br /> При длительном простое принтера (неделя и больше) происходит высыхание остатков красителя на соплах печатающей головки (особенно критично засорение сопел печатающей матрицы принтеров Epson, Canon). Принтер умеет сам автоматически чистить печатающую головку. Но также возможно провести принудительную очистку сопел из соответствующего раздела настройки драйвера принтера. При прочистке сопел печатающей головки происходит интенсивный расход красителя. Если штатными средствами принтера не удалось очистить сопла печатающей головки, то дальнейшая очистка и/или замена печатающей головки проводится в ремонтных мастерских. Замена картриджа, содержащего печатающую головку, на новый проблем не вызывает.<br /> <br /> Для уменьшения стоимости печати и улучшения некоторых других характеристик печати также применяют систему непрерывной подачи чернил (СНПЧ).</p>', '', '', '');
INSERT INTO shop_products_i18n (`id`, `locale`, `name`, `short_description`, `full_description`, `meta_title`, `meta_description`, `meta_keywords`) VALUES (101, 'ru', 'Canon PIXMA iP4820 Premium', '', '<p>Высоко технологический продукт, который поможет Вам оценить качество на высшем уровне.<br /><br />Все продукты доступны в наличии, а наши менеджеры помогу Вам произвести покупку в кратчайшие сроки.<br /><br />На все продукты мы предоставляем гарантию качества.<br /><br />Приобретайте только в нашем Интернет-магазине по лучшим ценам.</p>', '', '', '');
INSERT INTO shop_products_i18n (`id`, `locale`, `name`, `short_description`, `full_description`, `meta_title`, `meta_description`, `meta_keywords`) VALUES (102, 'ru', 'Epson Stylus R1900 Photo Printer', 'Epson Stylus Photo R1900, компакт-диск с драйверам и программным \nобеспечением, руководство по установке, руководство пользователя, кабель\n питания,&nbsp; СНПЧ Epson Stylus Photo R1900, полностью заправленаня \nчернилами (по 130 мл в каждом цвете), гарантийный талон, Инструкция по \nустановке и эксплуатации СНПЧ  ', '<p>Epson Stylus Photo R1900, компакт-диск с драйверам и программным \nобеспечением, руководство по установке, руководство пользователя, кабель\n питания,&nbsp; СНПЧ Epson Stylus Photo R1900, полностью заправленаня \nчернилами (по 130 мл в каждом цвете), гарантийный талон, Инструкция по \nустановке и эксплуатации СНПЧ  <br></p>  ', '', '', '');
INSERT INTO shop_products_i18n (`id`, `locale`, `name`, `short_description`, `full_description`, `meta_title`, `meta_description`, `meta_keywords`) VALUES (103, 'ru', 'Epson Stylus C88+ Inkjet Printer', ' ', '<p>Высоко технологический продукт, который поможет Вам оценить качество на высшем уровне.<br><br>Все продукты доступны в наличии, а наши менеджеры помогу Вам произвести покупку в кратчайшие сроки.<br><br>На все продукты мы предоставляем гарантию качества.<br><br>Приобретайте только в нашем Интернет-магазине по лучшим ценам.</p>  ', '', '', '');
INSERT INTO shop_products_i18n (`id`, `locale`, `name`, `short_description`, `full_description`, `meta_title`, `meta_description`, `meta_keywords`) VALUES (104, 'ru', 'Epson Stylus Photo R2880 Color', '<p>Насладитесь удивительным результатам на каждом документе по доступной цене с помощью этого мощного струйного принтера</p>', '<p>Насладитесь удивительным результатам на каждом документе по доступной цене с помощью этого мощного струйного принтера. DURABrite &reg; Ultra пигментные чернила производит яркие, долговечные результаты, которые, несомненно, впечатляет. Продукция полей, готовых к отпечатки кадров в популярных размерах до 8 1/2 х 11 дюймов Удобный, раздельных картриджей позволяет заменять только цвета вам нужно. Особенности USB и параллельный порт подключения для дополнительного удобства и совместимости. Большой 120-листов лоток для бумаги максимальную производительность. Максимальная скорость печати (черный): 23,0 промилле; сети Ready: Нет, Тип принтера: струйный; Разрешение печати (цветной) (ширина х высота): 5760 х 1440 точек на дюйм. </p>', '', '', '');
INSERT INTO shop_products_i18n (`id`, `locale`, `name`, `short_description`, `full_description`, `meta_title`, `meta_description`, `meta_keywords`) VALUES (105, 'ru', 'Panasonic KX-TG6582T Cordless Phone', ' ', '<p>Высоко технологический продукт, который поможет Вам оценить качество на высшем уровне.<br><br>Все продукты доступны в наличии, а наши менеджеры помогу Вам произвести покупку в кратчайшие сроки.<br><br>На все продукты мы предоставляем гарантию качества.<br><br>Приобретайте только в нашем Интернет-магазине по лучшим ценам.</p>  ', '', '', '');
INSERT INTO shop_products_i18n (`id`, `locale`, `name`, `short_description`, `full_description`, `meta_title`, `meta_description`, `meta_keywords`) VALUES (106, 'ru', 'Panasonic KX-TG7433B Expandable', ' ', '<p>Высоко технологический продукт, который поможет Вам оценить качество на высшем уровне.<br><br>Все продукты доступны в наличии, а наши менеджеры помогу Вам произвести покупку в кратчайшие сроки.<br><br>На все продукты мы предоставляем гарантию качества.<br><br>Приобретайте только в нашем Интернет-магазине по лучшим ценам.</p>  ', '', '', '');
INSERT INTO shop_products_i18n (`id`, `locale`, `name`, `short_description`, `full_description`, `meta_title`, `meta_description`, `meta_keywords`) VALUES (107, 'ru', 'Plantronics CS70N Wireless Earset', 'Гарнитура CS70N представляет собой модификацию популярной гарнитуры \nCS70, в которую добавлена система шумоподавления, повышающая качество \nпередаваемого звука. В отличие от предыдущей модели микрофон гарнитуры \nCS70N размещен на элегантном держателе, что позволяет существенно \nснизить уровень посторонних шумов в передаваемом звуке. Кроме того, \nпрозрачный  ', '<p>Гарнитура CS70N представляет собой модификацию популярной гарнитуры \nCS70, в которую добавлена система шумоподавления, повышающая качество \nпередаваемого звука. В отличие от предыдущей модели микрофон гарнитуры \nCS70N размещен на элегантном держателе, что позволяет существенно \nснизить уровень посторонних шумов в передаваемом звуке. Кроме того, \nпрозрачный держатель микрофона делает гарнитуру практически незаметной. \nCS70N состоит из базового блока и самой гарнитуры. Базовый блок \nвыполняет функцию радиоадаптера для подключения гарнитуры к офисным \nтелефонным аппаратам, служит подставкой для гарнитуры, а также выполняет\n роль зарядного устройства. Время работы гарнитуры составляет 5 часов в \nрежиме разговора и 28 часов в режиме ожидания. Для возможности \nудаленного принятия вызова, в комплект CS70N™ входит специальное \nустройство - микролифт HL10, а функция IntelliStand™ позволяет \nавтоматически осуществлять прием вызова снятием гарнитуры с подставки \nбез нажатия на кнопку принятия вызова. Вес гарнитуры составляет всего 22\n грамма. В комплекте с системой CS70N поставляются 3 гелевые подушечки \nразных размеров, что позволяет, оптимально подобрать вариант крепления \nгарнитуры для комфортного использования.  </p>  ', '', '', '');
INSERT INTO shop_products_i18n (`id`, `locale`, `name`, `short_description`, `full_description`, `meta_title`, `meta_description`, `meta_keywords`) VALUES (108, 'ru', 'Plantronics CS55 Wireless Earset', ' ', '<p>Высоко технологический продукт, который поможет Вам оценить качество на высшем уровне.<br><br>Все продукты доступны в наличии, а наши менеджеры помогу Вам произвести покупку в кратчайшие сроки.<br><br>На все продукты мы предоставляем гарантию качества.<br><br>Приобретайте только в нашем Интернет-магазине по лучшим ценам.</p>  ', '', '', '');
INSERT INTO shop_products_i18n (`id`, `locale`, `name`, `short_description`, `full_description`, `meta_title`, `meta_description`, `meta_keywords`) VALUES (109, 'ru', 'Panasonic KX-TG6445 Cordless Phone', ' ', '<p>Высоко технологический продукт, который поможет Вам оценить качество на высшем уровне.<br><br>Все продукты доступны в наличии, а наши менеджеры помогу Вам произвести покупку в кратчайшие сроки.<br><br>На все продукты мы предоставляем гарантию качества.<br><br>Приобретайте только в нашем Интернет-магазине по лучшим ценам.</p>  ', '', '', '');
INSERT INTO shop_products_i18n (`id`, `locale`, `name`, `short_description`, `full_description`, `meta_title`, `meta_description`, `meta_keywords`) VALUES (110, 'ru', 'Motorola H720 Earset - Mono', ' ', '<p>Высоко технологический продукт, который поможет Вам оценить качество на высшем уровне.<br><br>Все продукты доступны в наличии, а наши менеджеры помогу Вам произвести покупку в кратчайшие сроки.<br><br>На все продукты мы предоставляем гарантию качества.<br><br>Приобретайте только в нашем Интернет-магазине по лучшим ценам.</p>  ', '', '', '');
INSERT INTO shop_products_i18n (`id`, `locale`, `name`, `short_description`, `full_description`, `meta_title`, `meta_description`, `meta_keywords`) VALUES (111, 'ru', 'Plantronics Discovery 665 Wireless', '- Тип: моно<br>- Тип наушников: вкладыши<br> - Bluetooth 2<br> - Вес: 9 г.  ', '<p>- Ответить-закончить разговор <br> - Ожидание вызова <br> - Голосовой набор <br> - Повтор номера <br> - Автоматическое парное соединение <br> - Автоматическая подстройка громкости <br> - Отключение микрофона <br> - Подавление шума <br> - Индикатор состояния <br> - Крепление с заушиной  <br></p>  ', '', '', '');
INSERT INTO shop_products_i18n (`id`, `locale`, `name`, `short_description`, `full_description`, `meta_title`, `meta_description`, `meta_keywords`) VALUES (112, 'ru', 'Motorola H270 Bluetooth Headset', 'Motorola H270 – это беспроводная гарнитура среднего класса.  ', '<p>Motorola H270 – это беспроводная гарнитура среднего класса. \n<br>\n<br>Устройство имеет достаточно типичный дизайн для гарнитур компании. \nКорпус выполнен из качественного пластика и хорошо собран. H270 имеет \nудобные размеры 53,5x16x12 мм и вес — 11 грамм. Благодаря этому, она \nпрактически не чувствуется даже после длительного использования. Также \nэтому способствуют ушной интерфейс True Comfort и мягкая ушная подушка. \nЗа управление отвечают кнопки регулировки громкости и \nмногофункциональная клавиша. В комплекте идёт дужка для ношения, но \nустройство можно носить и без неё.\n<br>\n<br>По функциональным возможностям Motorola H270 ничего выдающегося не \nдемонстрирует, но все функции реализированы чётко и надёжно. Встроенный \nаккумулятор обеспечит работу на протяжении 6 часов в режиме разговора и 6\n дней в режиме ожидания. Поддержка профиля Bluetooth v2.1 с EDR, \nобеспечивает быструю и надёжную связь с телефонами. Гарнитура \nдемонстрирует хорошее качество передачи речи.\n<br>\n<br>Motorola H270 – гарнитура на каждый день. Практичная и удобная, она прекрасно подойдёт водителям.  <br></p>  ', '', '', '');
INSERT INTO shop_products_i18n (`id`, `locale`, `name`, `short_description`, `full_description`, `meta_title`, `meta_description`, `meta_keywords`) VALUES (113, 'ru', 'LG HBM-210 Bluetooth Headset', ' ', '<p>Высоко технологический продукт, который поможет Вам оценить качество на высшем уровне.<br><br>Все продукты доступны в наличии, а наши менеджеры помогу Вам произвести покупку в кратчайшие сроки.<br><br>На все продукты мы предоставляем гарантию качества.<br><br>Приобретайте только в нашем Интернет-магазине по лучшим ценам.</p>  ', '', '', '');
INSERT INTO shop_products_i18n (`id`, `locale`, `name`, `short_description`, `full_description`, `meta_title`, `meta_description`, `meta_keywords`) VALUES (114, 'ru', 'Samsung AWEP450PBECSTA Bluetooth Headset Black', ' ', '<p>Высоко технологический продукт, который поможет Вам оценить качество на высшем уровне.<br><br>Все продукты доступны в наличии, а наши менеджеры помогу Вам произвести покупку в кратчайшие сроки.<br><br>На все продукты мы предоставляем гарантию качества.<br><br>Приобретайте только в нашем Интернет-магазине по лучшим ценам.</p>  ', '', '', '');
INSERT INTO shop_products_i18n (`id`, `locale`, `name`, `short_description`, `full_description`, `meta_title`, `meta_description`, `meta_keywords`) VALUES (115, 'ru', 'Pioneer TS-SW3041D Shallow-Mount Subwoofer', ' ', '<p>Высоко технологический продукт, который поможет Вам оценить качество на высшем уровне.<br><br>Все продукты доступны в наличии, а наши менеджеры помогу Вам произвести покупку в кратчайшие сроки.<br><br>На все продукты мы предоставляем гарантию качества.<br><br>Приобретайте только в нашем Интернет-магазине по лучшим ценам.</p>  ', '', '', '');
INSERT INTO shop_products_i18n (`id`, `locale`, `name`, `short_description`, `full_description`, `meta_title`, `meta_description`, `meta_keywords`) VALUES (116, 'ru', 'Pyle PLT-AB8 Subwoofer - PLTAB8', ' ', '<p>Высоко технологический продукт, который поможет Вам оценить качество на высшем уровне.<br><br>Все продукты доступны в наличии, а наши менеджеры помогу Вам произвести покупку в кратчайшие сроки.<br><br>На все продукты мы предоставляем гарантию качества.<br><br>Приобретайте только в нашем Интернет-магазине по лучшим ценам.</p>  ', '', '', '');
INSERT INTO shop_products_i18n (`id`, `locale`, `name`, `short_description`, `full_description`, `meta_title`, `meta_description`, `meta_keywords`) VALUES (117, 'ru', 'Pyle PLSQ10D Red Label Square', ' ', '<p>Высоко технологический продукт, который поможет Вам оценить качество на высшем уровне.<br><br>Все продукты доступны в наличии, а наши менеджеры помогу Вам произвести покупку в кратчайшие сроки.<br><br>На все продукты мы предоставляем гарантию качества.<br><br>Приобретайте только в нашем Интернет-магазине по лучшим ценам.</p>  ', '', '', '');
INSERT INTO shop_products_i18n (`id`, `locale`, `name`, `short_description`, `full_description`, `meta_title`, `meta_description`, `meta_keywords`) VALUES (118, 'ru', 'Pioneer TS-W251R Subwoofer', 'Автомобильный сабвуферный динамик Pioneer TS-W251R  ', '<p>Автомобильный сабвуферный динамик Pioneer TS-W251R представляет собой \nбюджетное решение проблемы баса в вашем автомобиле. Высокая \nчувствительность, непритязательность к акустическому оформлению, \nспособность работать даже под маломощными усилителями делают этот \nсабвуфер выгодным приобретением. Опять же ни для кого не секрет, что \nнизкие частоты и Pioneer это практически слова синонимы - от этого \nдинамика вы получите именно то, чего ожидаете - бас, драйв, скорость.  </p>  ', '', '', '');
INSERT INTO shop_products_i18n (`id`, `locale`, `name`, `short_description`, `full_description`, `meta_title`, `meta_description`, `meta_keywords`) VALUES (119, 'ru', 'Pioneer TSSW2541D Subwoofer', ' ', '<p>Высоко технологический продукт, который поможет Вам оценить качество на высшем уровне.<br><br>Все продукты доступны в наличии, а наши менеджеры помогу Вам произвести покупку в кратчайшие сроки.<br><br>На все продукты мы предоставляем гарантию качества.<br><br>Приобретайте только в нашем Интернет-магазине по лучшим ценам.</p>  ', '', '', '');
INSERT INTO shop_products_i18n (`id`, `locale`, `name`, `short_description`, `full_description`, `meta_title`, `meta_description`, `meta_keywords`) VALUES (120, 'ru', 'Pioneer JD-1212S 12-disc CD', '<ul><li>\n    Магазин-кассета для дисков для CD-чейнджера</li><li>\n    Вместимость 12 дисков</li></ul>  ', '<br><ul><li>\n    Магазин-кассета для дисков для CD-чейнджера</li><li>\n    Вместимость 12 дисков</li></ul>  ', '', '', '');
INSERT INTO shop_products_i18n (`id`, `locale`, `name`, `short_description`, `full_description`, `meta_title`, `meta_description`, `meta_keywords`) VALUES (121, 'ru', 'Pioneer JD-612V 6-disc CD Magazine', '<div>\n                <ul><li>\n    Магазин-кассета для дисков для CD-чейнджеров</li><li>\n    Вместимость 6 дисков</li></ul></div>  ', '<br><div>\n                <ul><li>\n    Магазин-кассета для дисков для CD-чейнджеров</li><li>\n    Вместимость 6 дисков</li></ul></div>  ', '', '', '');
INSERT INTO shop_products_i18n (`id`, `locale`, `name`, `short_description`, `full_description`, `meta_title`, `meta_description`, `meta_keywords`) VALUES (122, 'ru', 'Panasonic CX-DP880U 8-Disc', ' ', '<p>Высоко технологический продукт, который поможет Вам оценить качество на высшем уровне.<br><br>Все продукты доступны в наличии, а наши менеджеры помогу Вам произвести покупку в кратчайшие сроки.<br><br>На все продукты мы предоставляем гарантию качества.<br><br>Приобретайте только в нашем Интернет-магазине по лучшим ценам.</p>  ', '', '', '');
INSERT INTO shop_products_i18n (`id`, `locale`, `name`, `short_description`, `full_description`, `meta_title`, `meta_description`, `meta_keywords`) VALUES (123, 'ru', 'JVC - XCM200 - 12-Disc CD', ' ', '<p>Высоко технологический продукт, который поможет Вам оценить качество на высшем уровне.<br><br>Все продукты доступны в наличии, а наши менеджеры помогу Вам произвести покупку в кратчайшие сроки.<br><br>На все продукты мы предоставляем гарантию качества.<br><br>Приобретайте только в нашем Интернет-магазине по лучшим ценам.</p>  ', '', '', '');
INSERT INTO shop_products_i18n (`id`, `locale`, `name`, `short_description`, `full_description`, `meta_title`, `meta_description`, `meta_keywords`) VALUES (124, 'ru', 'JVC - CHX1500RF - FM Modulation', 'JVC CH-X1500 RF - компактный CD чейнджер с возможностью дистанционного управления.  ', '<p>JVC - Компания JVC (Victor Company of Japan) является одним из \nлидирующих мировых производителей аудио и видео продукции. Будучи \nразработчиком VHS-формата, воплощенного в фирменных видеомагнитофонах \nJVC, сегодня компания продолжает удивлять потребителей революционными \nтехническими инновациями. Многолетний опыт JVC позволяет прочно \nудерживать передовые позиции на рынке аудиовизуальной продукции. JVC \nCH-X1500 RF - компактный CD чейнджер с возможностью дистанционного \nуправления. Это автомобильный CD-чейнджер на 12 дисков. Удобство в \nуправлении и эксплуатации.  <br></p>  ', '', '', '');
INSERT INTO shop_products_i18n (`id`, `locale`, `name`, `short_description`, `full_description`, `meta_title`, `meta_description`, `meta_keywords`) VALUES (115, 'en', 'Pioneer TS-SW3041D Shallow-Mount Subwoofer', '', '<p><span id=\"result_box\" lang=\"en\"><span>High</span> <span>technology product</span> <span>that will help you</span> <span>evaluate the quality of</span> <span>the highest level.</span><br /><br /> <span>All products are available</span> <span>in stock</span><span>, and our managers</span> <span>will help you</span> <span>to make a purchase</span> <span>as soon as possible</span><span>.</span><br /><br /> <span>On</span> <span>all the products we</span> <span>offer a guarantee</span> <span>of quality.</span><br /><br /> <span>Purchase only</span> <span>from our online</span> <span>store</span> <span>at the best prices</span><span>.</span></span></p>', '', '', '');
INSERT INTO shop_products_i18n (`id`, `locale`, `name`, `short_description`, `full_description`, `meta_title`, `meta_description`, `meta_keywords`) VALUES (124, 'en', 'JVC - CHX1500RF - FM Modulation', '', '<p><span id=\"result_box\" lang=\"en\"><span>High</span> <span>technology product</span> <span>that will help you</span> <span>evaluate the quality of</span> <span>the highest level.</span><br /><br /> <span>All products are available</span> <span>in stock</span><span>, and our managers</span> <span>will help you</span> <span>to make a purchase</span> <span>as soon as possible</span><span>.</span><br /><br /> <span>On</span> <span>all the products we</span> <span>offer a guarantee</span> <span>of quality.</span><br /><br /> <span>Purchase only</span> <span>from our online</span> <span>store</span> <span>at the best prices</span><span>.</span></span></p>', '', '', '');
INSERT INTO shop_products_i18n (`id`, `locale`, `name`, `short_description`, `full_description`, `meta_title`, `meta_description`, `meta_keywords`) VALUES (123, 'en', 'JVC - XCM200 - 12-Disc CD', '', '<p><span id=\"result_box\" lang=\"en\"><span>High</span> <span>technology product</span> <span>that will help you</span> <span>evaluate the quality of</span> <span>the highest level.</span><br /><br /> <span>All products are available</span> <span>in stock</span><span>, and our managers</span> <span>will help you</span> <span>to make a purchase</span> <span>as soon as possible</span><span>.</span><br /><br /> <span>On</span> <span>all the products we</span> <span>offer a guarantee</span> <span>of quality.</span><br /><br /> <span>Purchase only</span> <span>from our online</span> <span>store</span> <span>at the best prices</span><span>.</span></span></p>', '', '', '');
INSERT INTO shop_products_i18n (`id`, `locale`, `name`, `short_description`, `full_description`, `meta_title`, `meta_description`, `meta_keywords`) VALUES (120, 'en', 'Pioneer JD-1212S 12-disc CD', '', '<p><span id=\"result_box\" lang=\"en\"><span>High</span> <span>technology product</span> <span>that will help you</span> <span>evaluate the quality of</span> <span>the highest level.</span><br /><br /> <span>All products are available</span> <span>in stock</span><span>, and our managers</span> <span>will help you</span> <span>to make a purchase</span> <span>as soon as possible</span><span>.</span><br /><br /> <span>On</span> <span>all the products we</span> <span>offer a guarantee</span> <span>of quality.</span><br /><br /> <span>Purchase only</span> <span>from our online</span> <span>store</span> <span>at the best prices</span><span>.</span></span></p>', '', '', '');
INSERT INTO shop_products_i18n (`id`, `locale`, `name`, `short_description`, `full_description`, `meta_title`, `meta_description`, `meta_keywords`) VALUES (102, 'en', 'Epson Stylus R1900 Photo Printer', '', '<p><span id=\"result_box\" lang=\"en\"><span>High</span> <span>technology product</span> <span>that will help you</span> <span>evaluate the quality of</span> <span>the highest level.</span><br /><br /> <span>All products are available</span> <span>in stock</span><span>, and our managers</span> <span>will help you</span> <span>to make a purchase</span> <span>as soon as possible</span><span>.</span><br /><br /> <span>On</span> <span>all the products we</span> <span>offer a guarantee</span> <span>of quality.</span><br /><br /> <span>Purchase only</span> <span>from our online</span> <span>store</span> <span>at the best prices</span><span>.</span></span></p>', '', '', '');
INSERT INTO shop_products_i18n (`id`, `locale`, `name`, `short_description`, `full_description`, `meta_title`, `meta_description`, `meta_keywords`) VALUES (101, 'en', 'Canon PIXMA iP4820 Premium', '', '<p><span id=\"result_box\" lang=\"en\"><span>High</span> <span>technology product</span> <span>that will help you</span> <span>evaluate the quality of</span> <span>the highest level.</span><br /><br /> <span>All products are available</span> <span>in stock</span><span>, and our managers</span> <span>will help you</span> <span>to make a purchase</span> <span>as soon as possible</span><span>.</span><br /><br /> <span>On</span> <span>all the products we</span> <span>offer a guarantee</span> <span>of quality.</span><br /><br /> <span>Purchase only</span> <span>from our online</span> <span>store</span> <span>at the best prices</span><span>.</span></span></p>', '', '', '');
INSERT INTO shop_products_i18n (`id`, `locale`, `name`, `short_description`, `full_description`, `meta_title`, `meta_description`, `meta_keywords`) VALUES (109, 'en', 'Panasonic KX-TG6445 Cordless Phone', '', '<p><span id=\"result_box\" lang=\"en\"><span>High</span> <span>technology product</span> <span>that will help you</span> <span>evaluate the quality of</span> <span>the highest level.</span><br /><br /> <span>All products are available</span> <span>in stock</span><span>, and our managers</span> <span>will help you</span> <span>to make a purchase</span> <span>as soon as possible</span><span>.</span><br /><br /> <span>On</span> <span>all the products we</span> <span>offer a guarantee</span> <span>of quality.</span><br /><br /> <span>Purchase only</span> <span>from our online</span> <span>store</span> <span>at the best prices</span><span>.</span></span></p>', '', '', '');
INSERT INTO shop_products_i18n (`id`, `locale`, `name`, `short_description`, `full_description`, `meta_title`, `meta_description`, `meta_keywords`) VALUES (108, 'en', 'Plantronics CS55 Wireless Earset', '', '<p><span id=\"result_box\" lang=\"en\"><span>High</span> <span>technology product</span> <span>that will help you</span> <span>evaluate the quality of</span> <span>the highest level.</span><br /><br /> <span>All products are available</span> <span>in stock</span><span>, and our managers</span> <span>will help you</span> <span>to make a purchase</span> <span>as soon as possible</span><span>.</span><br /><br /> <span>On</span> <span>all the products we</span> <span>offer a guarantee</span> <span>of quality.</span><br /><br /> <span>Purchase only</span> <span>from our online</span> <span>store</span> <span>at the best prices</span><span>.</span></span></p>', '', '', '');
INSERT INTO shop_products_i18n (`id`, `locale`, `name`, `short_description`, `full_description`, `meta_title`, `meta_description`, `meta_keywords`) VALUES (114, 'en', 'Samsung AWEP450PBECSTA Bluetooth Headset Black', '', '<p><span id=\"result_box\" lang=\"en\"><span>High</span> <span>technology product</span> <span>that will help you</span> <span>evaluate the quality of</span> <span>the highest level.</span><br /><br /> <span>All products are available</span> <span>in stock</span><span>, and our managers</span> <span>will help you</span> <span>to make a purchase</span> <span>as soon as possible</span><span>.</span><br /><br /> <span>On</span> <span>all the products we</span> <span>offer a guarantee</span> <span>of quality.</span><br /><br /> <span>Purchase only</span> <span>from our online</span> <span>store</span> <span>at the best prices</span><span>.</span></span></p>', '', '', '');
INSERT INTO shop_products_i18n (`id`, `locale`, `name`, `short_description`, `full_description`, `meta_title`, `meta_description`, `meta_keywords`) VALUES (113, 'en', 'LG HBM-210 Bluetooth Headset', '', '<p><span id=\"result_box\" lang=\"en\"><span>High</span> <span>technology product</span> <span>that will help you</span> <span>evaluate the quality of</span> <span>the highest level.</span><br /><br /> <span>All products are available</span> <span>in stock</span><span>, and our managers</span> <span>will help you</span> <span>to make a purchase</span> <span>as soon as possible</span><span>.</span><br /><br /> <span>On</span> <span>all the products we</span> <span>offer a guarantee</span> <span>of quality.</span><br /><br /> <span>Purchase only</span> <span>from our online</span> <span>store</span> <span>at the best prices</span><span>.</span></span></p>', '', '', '');
INSERT INTO shop_products_i18n (`id`, `locale`, `name`, `short_description`, `full_description`, `meta_title`, `meta_description`, `meta_keywords`) VALUES (111, 'en', 'Plantronics Discovery 665 Wireless', '', '<p><span id=\"result_box\" lang=\"en\"><span>High</span> <span>technology product</span> <span>that will help you</span> <span>evaluate the quality of</span> <span>the highest level.</span><br /><br /> <span>All products are available</span> <span>in stock</span><span>, and our managers</span> <span>will help you</span> <span>to make a purchase</span> <span>as soon as possible</span><span>.</span><br /><br /> <span>On</span> <span>all the products we</span> <span>offer a guarantee</span> <span>of quality.</span><br /><br /> <span>Purchase only</span> <span>from our online</span> <span>store</span> <span>at the best prices</span><span>.</span></span></p>', '', '', '');
INSERT INTO shop_products_i18n (`id`, `locale`, `name`, `short_description`, `full_description`, `meta_title`, `meta_description`, `meta_keywords`) VALUES (119, 'en', 'Pioneer TSSW2541D Subwoofer', '', '<p><span id=\"result_box\" lang=\"en\"><span>High</span> <span>technology product</span> <span>that will help you</span> <span>evaluate the quality of</span> <span>the highest level.</span><br /><br /> <span>All products are available</span> <span>in stock</span><span>, and our managers</span> <span>will help you</span> <span>to make a purchase</span> <span>as soon as possible</span><span>.</span><br /><br /> <span>On</span> <span>all the products we</span> <span>offer a guarantee</span> <span>of quality.</span><br /><br /> <span>Purchase only</span> <span>from our online</span> <span>store</span> <span>at the best prices</span><span>.</span></span></p>', '', '', '');
INSERT INTO shop_products_i18n (`id`, `locale`, `name`, `short_description`, `full_description`, `meta_title`, `meta_description`, `meta_keywords`) VALUES (118, 'en', 'Pioneer TS-W251R Subwoofer', '', '<p><span id=\"result_box\" lang=\"en\"><span>High</span> <span>technology product</span> <span>that will help you</span> <span>evaluate the quality of</span> <span>the highest level.</span><br /><br /> <span>All products are available</span> <span>in stock</span><span>, and our managers</span> <span>will help you</span> <span>to make a purchase</span> <span>as soon as possible</span><span>.</span><br /><br /> <span>On</span> <span>all the products we</span> <span>offer a guarantee</span> <span>of quality.</span><br /><br /> <span>Purchase only</span> <span>from our online</span> <span>store</span> <span>at the best prices</span><span>.</span></span></p>', '', '', '');
INSERT INTO shop_products_i18n (`id`, `locale`, `name`, `short_description`, `full_description`, `meta_title`, `meta_description`, `meta_keywords`) VALUES (117, 'en', 'Pyle PLSQ10D Red Label Square', '', '<p><span id=\"result_box\" lang=\"en\"><span>High</span> <span>technology product</span> <span>that will help you</span> <span>evaluate the quality of</span> <span>the highest level.</span><br /><br /> <span>All products are available</span> <span>in stock</span><span>, and our managers</span> <span>will help you</span> <span>to make a purchase</span> <span>as soon as possible</span><span>.</span><br /><br /> <span>On</span> <span>all the products we</span> <span>offer a guarantee</span> <span>of quality.</span><br /><br /> <span>Purchase only</span> <span>from our online</span> <span>store</span> <span>at the best prices</span><span>.</span></span></p>', '', '', '');
INSERT INTO shop_products_i18n (`id`, `locale`, `name`, `short_description`, `full_description`, `meta_title`, `meta_description`, `meta_keywords`) VALUES (83, 'en', 'Sony BDP-S470 Network', '', '', '', '', '');
INSERT INTO shop_products_i18n (`id`, `locale`, `name`, `short_description`, `full_description`, `meta_title`, `meta_description`, `meta_keywords`) VALUES (91, 'en', 'Sony BDV-E770W Home Theater1', '', '<p><span id=\"result_box\" lang=\"en\"><span>High</span> <span>technology product</span> <span>that will help you</span> <span>evaluate the quality of</span> <span>the highest level.</span><br /><br /> <span>All products are available</span> <span>in stock</span><span>, and our managers</span> <span>will help you</span> <span>to make a purchase</span> <span>as soon as possible</span><span>.</span><br /><br /> <span>On</span> <span>all the products we</span> <span>offer a guarantee</span> <span>of quality.</span><br /><br /> <span>Purchase only</span> <span>from our online</span> <span>store</span> <span>at the best prices</span><span>.</span></span></p>', '', '', '');
INSERT INTO shop_products_i18n (`id`, `locale`, `name`, `short_description`, `full_description`, `meta_title`, `meta_description`, `meta_keywords`) VALUES (90, 'en', 'Samsung HT-C7530W 5.1 Channel', '', '<p><span id=\"result_box\" lang=\"en\"><span>High</span> <span>technology product</span> <span>that will help you</span> <span>evaluate the quality of</span> <span>the highest level.</span><br /><br /> <span>All products are available</span> <span>in stock</span><span>, and our managers</span> <span>will help you</span> <span>to make a purchase</span> <span>as soon as possible</span><span>.</span><br /><br /> <span>On</span> <span>all the products we</span> <span>offer a guarantee</span> <span>of quality.</span><br /><br /> <span>Purchase only</span> <span>from our online</span> <span>store</span> <span>at the best prices</span><span>.</span></span></p>', '', '', '');
INSERT INTO shop_products_i18n (`id`, `locale`, `name`, `short_description`, `full_description`, `meta_title`, `meta_description`, `meta_keywords`) VALUES (89, 'en', 'Panasonic SCPTX7 Home Theater', '', '<p><span id=\"result_box\" lang=\"en\"><span>High</span> <span>technology product</span> <span>that will help you</span> <span>evaluate the quality of</span> <span>the highest level.</span><br /><br /> <span>All products are available</span> <span>in stock</span><span>, and our managers</span> <span>will help you</span> <span>to make a purchase</span> <span>as soon as possible</span><span>.</span><br /><br /> <span>On</span> <span>all the products we</span> <span>offer a guarantee</span> <span>of quality.</span><br /><br /> <span>Purchase only</span> <span>from our online</span> <span>store</span> <span>at the best prices</span><span>.</span></span></p>', '', '', '');
INSERT INTO shop_products_i18n (`id`, `locale`, `name`, `short_description`, `full_description`, `meta_title`, `meta_description`, `meta_keywords`) VALUES (93, 'en', 'Yamaha HS80M Powered Speaker', '', '<p><span id=\"result_box\" lang=\"en\"><span>High</span> <span>technology product</span> <span>that will help you</span> <span>evaluate the quality of</span> <span>the highest level.</span><br /><br /> <span>All products are available</span> <span>in stock</span><span>, and our managers</span> <span>will help you</span> <span>to make a purchase</span> <span>as soon as possible</span><span>.</span><br /><br /> <span>On</span> <span>all the products we</span> <span>offer a guarantee</span> <span>of quality.</span><br /><br /> <span>Purchase only</span> <span>from our online</span> <span>store</span> <span>at the best prices</span><span>.</span></span></p>', '', '', '');
INSERT INTO shop_products_i18n (`id`, `locale`, `name`, `short_description`, `full_description`, `meta_title`, `meta_description`, `meta_keywords`) VALUES (99, 'en', 'Samsung NX100 Interchangeable Lens', '', '<p><span id=\"result_box\" lang=\"en\"><span>High</span> <span>technology product</span> <span>that will help you</span> <span>evaluate the quality of</span> <span>the highest level.</span><br /><br /> <span>All products are available</span> <span>in stock</span><span>, and our managers</span> <span>will help you</span> <span>to make a purchase</span> <span>as soon as possible</span><span>.</span><br /><br /> <span>On</span> <span>all the products we</span> <span>offer a guarantee</span> <span>of quality.</span><br /><br /> <span>Purchase only</span> <span>from our online</span> <span>store</span> <span>at the best prices</span><span>.</span></span></p>', '', '', '');
INSERT INTO shop_products_i18n (`id`, `locale`, `name`, `short_description`, `full_description`, `meta_title`, `meta_description`, `meta_keywords`) VALUES (98, 'en', 'Samsung NX10 14 Megapixel Digital', '', '<p><span id=\"result_box\" lang=\"en\"><span>High</span> <span>technology product</span> <span>that will help you</span> <span>evaluate the quality of</span> <span>the highest level.</span><br /><br /> <span>All products are available</span> <span>in stock</span><span>, and our managers</span> <span>will help you</span> <span>to make a purchase</span> <span>as soon as possible</span><span>.</span><br /><br /> <span>On</span> <span>all the products we</span> <span>offer a guarantee</span> <span>of quality.</span><br /><br /> <span>Purchase only</span> <span>from our online</span> <span>store</span> <span>at the best prices</span><span>.</span></span></p>', '', '', '');
INSERT INTO shop_products_i18n (`id`, `locale`, `name`, `short_description`, `full_description`, `meta_title`, `meta_description`, `meta_keywords`) VALUES (97, 'en', 'Sony Handycam HDR-CX3', '', '<p><span id=\"result_box\" lang=\"en\"><span>High</span> <span>technology product</span> <span>that will help you</span> <span>evaluate the quality of</span> <span>the highest level.</span><br /><br /> <span>All products are available</span> <span>in stock</span><span>, and our managers</span> <span>will help you</span> <span>to make a purchase</span> <span>as soon as possible</span><span>.</span><br /><br /> <span>On</span> <span>all the products we</span> <span>offer a guarantee</span> <span>of quality.</span><br /><br /> <span>Purchase only</span> <span>from our online</span> <span>store</span> <span>at the best prices</span><span>.</span></span></p>', '', '', '');
INSERT INTO shop_products_i18n (`id`, `locale`, `name`, `short_description`, `full_description`, `meta_title`, `meta_description`, `meta_keywords`) VALUES (96, 'en', 'Canon VIXIA HF R11 Digital', '', '<p><span id=\"result_box\" lang=\"en\"><span>High</span> <span>technology product</span> <span>that will help you</span> <span>evaluate the quality of</span> <span>the highest level.</span><br /><br /> <span>All products are available</span> <span>in stock</span><span>, and our managers</span> <span>will help you</span> <span>to make a purchase</span> <span>as soon as possible</span><span>.</span><br /><br /> <span>On</span> <span>all the products we</span> <span>offer a guarantee</span> <span>of quality.</span><br /><br /> <span>Purchase only</span> <span>from our online</span> <span>store</span> <span>at the best prices</span><span>.</span></span></p>', '', '', '');
INSERT INTO shop_products_i18n (`id`, `locale`, `name`, `short_description`, `full_description`, `meta_title`, `meta_description`, `meta_keywords`) VALUES (104, 'en', 'Epson Stylus Photo R2880 Color', '', '<p><span id=\"result_box\" lang=\"en\"><span>High</span> <span>technology product</span> <span>that will help you</span> <span>evaluate the quality of</span> <span>the highest level.</span><br /><br /> <span>All products are available</span> <span>in stock</span><span>, and our managers</span> <span>will help you</span> <span>to make a purchase</span> <span>as soon as possible</span><span>.</span><br /><br /> <span>On</span> <span>all the products we</span> <span>offer a guarantee</span> <span>of quality.</span><br /><br /> <span>Purchase only</span> <span>from our online</span> <span>store</span> <span>at the best prices</span><span>.</span></span></p>', '', '', '');
INSERT INTO shop_products_i18n (`id`, `locale`, `name`, `short_description`, `full_description`, `meta_title`, `meta_description`, `meta_keywords`) VALUES (103, 'en', 'Epson Stylus C88+ Inkjet Printer', '', '<p><span id=\"result_box\" lang=\"en\"><span>High</span> <span>technology product</span> <span>that will help you</span> <span>evaluate the quality of</span> <span>the highest level.</span><br /><br /> <span>All products are available</span> <span>in stock</span><span>, and our managers</span> <span>will help you</span> <span>to make a purchase</span> <span>as soon as possible</span><span>.</span><br /><br /> <span>On</span> <span>all the products we</span> <span>offer a guarantee</span> <span>of quality.</span><br /><br /> <span>Purchase only</span> <span>from our online</span> <span>store</span> <span>at the best prices</span><span>.</span></span></p>', '', '', '');
INSERT INTO shop_products_i18n (`id`, `locale`, `name`, `short_description`, `full_description`, `meta_title`, `meta_description`, `meta_keywords`) VALUES (94, 'en', 'Yamaha NSIW760 Speaker', '', '<p><span id=\"result_box\" lang=\"en\"><span>High</span> <span>technology product</span> <span>that will help you</span> <span>evaluate the quality of</span> <span>the highest level.</span><br /><br /> <span>All products are available</span> <span>in stock</span><span>, and our managers</span> <span>will help you</span> <span>to make a purchase</span> <span>as soon as possible</span><span>.</span><br /><br /> <span>On</span> <span>all the products we</span> <span>offer a guarantee</span> <span>of quality.</span><br /><br /> <span>Purchase only</span> <span>from our online</span> <span>store</span> <span>at the best prices</span><span>.</span></span></p>', '', '', '');
INSERT INTO shop_products_i18n (`id`, `locale`, `name`, `short_description`, `full_description`, `meta_title`, `meta_description`, `meta_keywords`) VALUES (81, 'en', 'Samsung DVD-H1080 - 1080p', '', '', '', '', '');
INSERT INTO shop_products_i18n (`id`, `locale`, `name`, `short_description`, `full_description`, `meta_title`, `meta_description`, `meta_keywords`) VALUES (86, 'en', 'Samsung BD-C6900 1080p 3D Blu-ray', '', '', '', '', '');
INSERT INTO shop_products_i18n (`id`, `locale`, `name`, `short_description`, `full_description`, `meta_title`, `meta_description`, `meta_keywords`) VALUES (85, 'en', 'LG BD570 Network Audio', '', '', '', '', '');
INSERT INTO shop_products_i18n (`id`, `locale`, `name`, `short_description`, `full_description`, `meta_title`, `meta_description`, `meta_keywords`) VALUES (84, 'en', 'Panasonic DMP-BD45 Ultra-Fast', '', '', '', '', '');
INSERT INTO shop_products_i18n (`id`, `locale`, `name`, `short_description`, `full_description`, `meta_title`, `meta_description`, `meta_keywords`) VALUES (91, 'ua', 'Sony BDV-E770W Home Theater', '', '', '', '', '');
INSERT INTO shop_products_i18n (`id`, `locale`, `name`, `short_description`, `full_description`, `meta_title`, `meta_description`, `meta_keywords`) VALUES (71, 'en', 'Sony KDL46EX710 46', '', '<p><span id=\"result_box\" lang=\"en\"><span>High</span> <span>technology product</span> <span>that will help you</span> <span>evaluate the quality of</span> <span>the highest level.</span><br /><br /> <span>All products are available</span> <span>in stock</span><span>, and our managers</span> <span>will help you</span> <span>to make a purchase</span> <span>as soon as possible</span><span>.</span><br /><br /> <span>On</span> <span>all the products we</span> <span>offer a guarantee</span> <span>of quality.</span><br /><br /> <span>Purchase only</span> <span>from our online</span> <span>store</span> <span>at the best prices</span><span>.</span></span></p>', '', '', '');
INSERT INTO shop_products_i18n (`id`, `locale`, `name`, `short_description`, `full_description`, `meta_title`, `meta_description`, `meta_keywords`) VALUES (79, 'en', 'Panasonic DVD-S38 DVD', '', '', '', '', '');
INSERT INTO shop_products_i18n (`id`, `locale`, `name`, `short_description`, `full_description`, `meta_title`, `meta_description`, `meta_keywords`) VALUES (78, 'en', 'Panasonic DVD-S58 DVD Player', '', '', '', '', '');
INSERT INTO shop_products_i18n (`id`, `locale`, `name`, `short_description`, `full_description`, `meta_title`, `meta_description`, `meta_keywords`) VALUES (82, 'en', 'Samsung BD-C5500 Blu-ray', '', '', '', '', '');
INSERT INTO shop_products_i18n (`id`, `locale`, `name`, `short_description`, `full_description`, `meta_title`, `meta_description`, `meta_keywords`) VALUES (92, 'en', 'Samsung HW-C700 7.2 Channel', '', '<p><span id=\"result_box\" lang=\"en\"><span>High</span> <span>technology product</span> <span>that will help you</span> <span>evaluate the quality of</span> <span>the highest level.</span><br /><br /> <span>All products are available</span> <span>in stock</span><span>, and our managers</span> <span>will help you</span> <span>to make a purchase</span> <span>as soon as possible</span><span>.</span><br /><br /> <span>On</span> <span>all the products we</span> <span>offer a guarantee</span> <span>of quality.</span><br /><br /> <span>Purchase only</span> <span>from our online</span> <span>store</span> <span>at the best prices</span><span>.</span></span></p>', '', '', '');
INSERT INTO shop_products_i18n (`id`, `locale`, `name`, `short_description`, `full_description`, `meta_title`, `meta_description`, `meta_keywords`) VALUES (88, 'en', 'Samsung HW-C770BS 7.1 Channel', '', '<p><span id=\"result_box\" lang=\"en\"><span>High</span> <span>technology product</span> <span>that will help you</span> <span>evaluate the quality of</span> <span>the highest level.</span><br /><br /> <span>All products are available</span> <span>in stock</span><span>, and our managers</span> <span>will help you</span> <span>to make a purchase</span> <span>as soon as possible</span><span>.</span><br /><br /> <span>On</span> <span>all the products we</span> <span>offer a guarantee</span> <span>of quality.</span><br /><br /> <span>Purchase only</span> <span>from our online</span> <span>store</span> <span>at the best prices</span><span>.</span></span></p>', '', '', '');
INSERT INTO shop_products_i18n (`id`, `locale`, `name`, `short_description`, `full_description`, `meta_title`, `meta_description`, `meta_keywords`) VALUES (87, 'en', 'Sony HT-SS370 Home Theater', '', '<p><span id=\"result_box\" lang=\"en\"><span>High</span> <span>technology product</span> <span>that will help you</span> <span>evaluate the quality of</span> <span>the highest level.</span><br /><br /> <span>All products are available</span> <span>in stock</span><span>, and our managers</span> <span>will help you</span> <span>to make a purchase</span> <span>as soon as possible</span><span>.</span><br /><br /> <span>On</span> <span>all the products we</span> <span>offer a guarantee</span> <span>of quality.</span><br /><br /> <span>Purchase only</span> <span>from our online</span> <span>store</span> <span>at the best prices</span><span>.</span></span></p>', '', '', '');
INSERT INTO shop_products_i18n (`id`, `locale`, `name`, `short_description`, `full_description`, `meta_title`, `meta_description`, `meta_keywords`) VALUES (100, 'en', 'Canon PIXMA iP100 Photo Printer', '', '<p><span id=\"result_box\" lang=\"en\"><span>High</span> <span>technology product</span> <span>that will help you</span> <span>evaluate the quality of</span> <span>the highest level.</span><br /><br /> <span>All products are available</span> <span>in stock</span><span>, and our managers</span> <span>will help you</span> <span>to make a purchase</span> <span>as soon as possible</span><span>.</span><br /><br /> <span>On</span> <span>all the products we</span> <span>offer a guarantee</span> <span>of quality.</span><br /><br /> <span>Purchase only</span> <span>from our online</span> <span>store</span> <span>at the best prices</span><span>.</span></span></p>', '', '', '');
INSERT INTO shop_products_i18n (`id`, `locale`, `name`, `short_description`, `full_description`, `meta_title`, `meta_description`, `meta_keywords`) VALUES (95, 'en', 'Canon EOS Rebel T2i 18 Megapixel Digital', '', '<p><span id=\"result_box\" lang=\"en\"><span>High</span> <span>technology product</span> <span>that will help you</span> <span>evaluate the quality of</span> <span>the highest level.</span><br /><br /> <span>All products are available</span> <span>in stock</span><span>, and our managers</span> <span>will help you</span> <span>to make a purchase</span> <span>as soon as possible</span><span>.</span><br /><br /> <span>On</span> <span>all the products we</span> <span>offer a guarantee</span> <span>of quality.</span><br /><br /> <span>Purchase only</span> <span>from our online</span> <span>store</span> <span>at the best prices</span><span>.</span></span></p>', '', '', '');
INSERT INTO shop_products_i18n (`id`, `locale`, `name`, `short_description`, `full_description`, `meta_title`, `meta_description`, `meta_keywords`) VALUES (112, 'en', 'Motorola H270 Bluetooth Headset', '', '<p><span id=\"result_box\" lang=\"en\"><span>High</span> <span>technology product</span> <span>that will help you</span> <span>evaluate the quality of</span> <span>the highest level.</span><br /><br /> <span>All products are available</span> <span>in stock</span><span>, and our managers</span> <span>will help you</span> <span>to make a purchase</span> <span>as soon as possible</span><span>.</span><br /><br /> <span>On</span> <span>all the products we</span> <span>offer a guarantee</span> <span>of quality.</span><br /><br /> <span>Purchase only</span> <span>from our online</span> <span>store</span> <span>at the best prices</span><span>.</span></span></p>', '', '', '');
INSERT INTO shop_products_i18n (`id`, `locale`, `name`, `short_description`, `full_description`, `meta_title`, `meta_description`, `meta_keywords`) VALUES (110, 'en', 'Motorola H720 Earset - Mono', '', '<p><span id=\"result_box\" lang=\"en\"><span>High</span> <span>technology product</span> <span>that will help you</span> <span>evaluate the quality of</span> <span>the highest level.</span><br /><br /> <span>All products are available</span> <span>in stock</span><span>, and our managers</span> <span>will help you</span> <span>to make a purchase</span> <span>as soon as possible</span><span>.</span><br /><br /> <span>On</span> <span>all the products we</span> <span>offer a guarantee</span> <span>of quality.</span><br /><br /> <span>Purchase only</span> <span>from our online</span> <span>store</span> <span>at the best prices</span><span>.</span></span></p>', '', '', '');
INSERT INTO shop_products_i18n (`id`, `locale`, `name`, `short_description`, `full_description`, `meta_title`, `meta_description`, `meta_keywords`) VALUES (107, 'en', 'Plantronics CS70N Wireless Earset', '', '<p><span id=\"result_box\" lang=\"en\"><span>High</span> <span>technology product</span> <span>that will help you</span> <span>evaluate the quality of</span> <span>the highest level.</span><br /><br /> <span>All products are available</span> <span>in stock</span><span>, and our managers</span> <span>will help you</span> <span>to make a purchase</span> <span>as soon as possible</span><span>.</span><br /><br /> <span>On</span> <span>all the products we</span> <span>offer a guarantee</span> <span>of quality.</span><br /><br /> <span>Purchase only</span> <span>from our online</span> <span>store</span> <span>at the best prices</span><span>.</span></span></p>', '', '', '');
INSERT INTO shop_products_i18n (`id`, `locale`, `name`, `short_description`, `full_description`, `meta_title`, `meta_description`, `meta_keywords`) VALUES (106, 'en', 'Panasonic KX-TG7433B Expandable', '', '<p><span id=\"result_box\" lang=\"en\"><span>High</span> <span>technology product</span> <span>that will help you</span> <span>evaluate the quality of</span> <span>the highest level.</span><br /><br /> <span>All products are available</span> <span>in stock</span><span>, and our managers</span> <span>will help you</span> <span>to make a purchase</span> <span>as soon as possible</span><span>.</span><br /><br /> <span>On</span> <span>all the products we</span> <span>offer a guarantee</span> <span>of quality.</span><br /><br /> <span>Purchase only</span> <span>from our online</span> <span>store</span> <span>at the best prices</span><span>.</span></span></p>', '', '', '');
INSERT INTO shop_products_i18n (`id`, `locale`, `name`, `short_description`, `full_description`, `meta_title`, `meta_description`, `meta_keywords`) VALUES (105, 'en', 'Panasonic KX-TG6582T Cordless Phone', '', '<p><span id=\"result_box\" lang=\"en\"><span>High</span> <span>technology product</span> <span>that will help you</span> <span>evaluate the quality of</span> <span>the highest level.</span><br /><br /> <span>All products are available</span> <span>in stock</span><span>, and our managers</span> <span>will help you</span> <span>to make a purchase</span> <span>as soon as possible</span><span>.</span><br /><br /> <span>On</span> <span>all the products we</span> <span>offer a guarantee</span> <span>of quality.</span><br /><br /> <span>Purchase only</span> <span>from our online</span> <span>store</span> <span>at the best prices</span><span>.</span></span></p>', '', '', '');
INSERT INTO shop_products_i18n (`id`, `locale`, `name`, `short_description`, `full_description`, `meta_title`, `meta_description`, `meta_keywords`) VALUES (116, 'en', 'Pyle PLT-AB8 Subwoofer - PLTAB8', '', '<p><span id=\"result_box\" lang=\"en\"><span>High</span> <span>technology product</span> <span>that will help you</span> <span>evaluate the quality of</span> <span>the highest level.</span><br /><br /> <span>All products are available</span> <span>in stock</span><span>, and our managers</span> <span>will help you</span> <span>to make a purchase</span> <span>as soon as possible</span><span>.</span><br /><br /> <span>On</span> <span>all the products we</span> <span>offer a guarantee</span> <span>of quality.</span><br /><br /> <span>Purchase only</span> <span>from our online</span> <span>store</span> <span>at the best prices</span><span>.</span></span></p>', '', '', '');
INSERT INTO shop_products_i18n (`id`, `locale`, `name`, `short_description`, `full_description`, `meta_title`, `meta_description`, `meta_keywords`) VALUES (122, 'en', 'Panasonic CX-DP880U 8-Disc', '', '<p><span id=\"result_box\" lang=\"en\"><span>High</span> <span>technology product</span> <span>that will help you</span> <span>evaluate the quality of</span> <span>the highest level.</span><br /><br /> <span>All products are available</span> <span>in stock</span><span>, and our managers</span> <span>will help you</span> <span>to make a purchase</span> <span>as soon as possible</span><span>.</span><br /><br /> <span>On</span> <span>all the products we</span> <span>offer a guarantee</span> <span>of quality.</span><br /><br /> <span>Purchase only</span> <span>from our online</span> <span>store</span> <span>at the best prices</span><span>.</span></span></p>', '', '', '');
INSERT INTO shop_products_i18n (`id`, `locale`, `name`, `short_description`, `full_description`, `meta_title`, `meta_description`, `meta_keywords`) VALUES (121, 'en', 'Pioneer JD-612V 6-disc CD Magazine', '', '<p><span id=\"result_box\" lang=\"en\"><span>High</span> <span>technology product</span> <span>that will help you</span> <span>evaluate the quality of</span> <span>the highest level.</span><br /><br /> <span>All products are available</span> <span>in stock</span><span>, and our managers</span> <span>will help you</span> <span>to make a purchase</span> <span>as soon as possible</span><span>.</span><br /><br /> <span>On</span> <span>all the products we</span> <span>offer a guarantee</span> <span>of quality.</span><br /><br /> <span>Purchase only</span> <span>from our online</span> <span>store</span> <span>at the best prices</span><span>.</span></span></p>', '', '', '');
INSERT INTO shop_products_i18n (`id`, `locale`, `name`, `short_description`, `full_description`, `meta_title`, `meta_description`, `meta_keywords`) VALUES (185, 'ru', 'Apple iPhone 5 16GB Black Slate', '<p>Зимняя резина Amtel NordMaster позволяет водителю уверенно управлять транспортным средством в условиях обледенения дорожного полотна или на заснеженных участках трассы. Шины Amtel NordMaterимеют продуманную конструкцию, дополненную уникальным рисунком протектора, и подбор состава резин</p>', '', '', '', '');
INSERT INTO shop_products_i18n (`id`, `locale`, `name`, `short_description`, `full_description`, `meta_title`, `meta_description`, `meta_keywords`) VALUES (186, 'ru', 'Samsung UE32EH4030WXUA', '32 дюйма, 1366x768, 720p, 16:9, LED-подсветка, 300000:1, звук: 2х10 Вт, SCART, RGB, VGA, HDMI x2, USB  ', '<div>\nСупертонкий и плоский LED телевизор Samsung UE32EH4030WXUA идеально \nподойдет для вашей гостиной. При минималистичном дизайне этот телевизор \nобеспечивает кинематографическую реалистичность впечатлений во время \nпросмотра, благодаря светодиодной подсветке матрицы ТВ Samsung \nUE32EH4030WXUA. Получите удовольствие от максимальной четкости \nдинамичного изображения, насыщенности и многообразия цветовых оттенков. \n           </div>  ', '', '', '');
INSERT INTO shop_products_i18n (`id`, `locale`, `name`, `short_description`, `full_description`, `meta_title`, `meta_description`, `meta_keywords`) VALUES (187, 'ru', 'Samsung UE40ES6307UXUA', '40 дюймов, LED, 1920x1080, 16:9, Full HD, 178°/178°, 2х10 Вт, 3xHDMI, 3xUSB, Ethernet (LAN), Wi-Fi, Smart TV  ', '<strong>Новый уровень ощущений в формате 3D</strong><br>\nLED телевизоры Samsung внесли в мир развлечений совершенно новые \nощущения. Благодаря новейшим достижениям технологии 3D вы погружаетесь в\n совершенно новый мир ТВ-реальности.<br>\n<br>\n<strong>Смотрите фильмы, загружая их прямо с USB-накопителя</strong><br>\nБлагодаря функции ConnectShare Movie, вы можете росто вставить ваш USB \nнакопитель или жесткий диск в USB разъем телевизора, чтобы записанные на\n носителе фильмы, фотоснимки или музыкальные треки начали \nвоспроизводиться на экране телевизора. Теперь на большом экране \nтелевизора, установленного в гостиной, вы можете просмотреть или \nпрослушать любой контент.<br>\n<br>\n<strong>Видеозвонки по Skype на большом экране</strong><br>\nПриложение Skype для Smart TV доступно бесплатно в магазине Samsung App.\n В сочетании с отдельно приобретаемой веб-камерой Skype вы сможете \nсовершать видеозвонки своим друзьям и близким на большом экране почти \nили совсем бесплатно. С помощью пульта ДУ вы можете легко создать новые \nSkype эккаунты и получать доступ к существующим. Теперь видеосвязь \nбуквально в ваших руках.<br>\n<br>\n<strong>Доступ в Интернет без проводов</strong><br>\nВстроенная поддержка сети, широкие возможности подключения других устройств сочетаются с привлекательным дизайном.<br>\n<br>\n<strong>Наслаждайтесь приложениями, видео, Skype, серфингом в Интернете и многими другими возможностями</strong><br>\nБлагодаря вашей домашней системе развлечений вы откроете для себя новый \nмир социальных и персонализированных развлечений на обновленном портале \nSamsung Smart Hub и трех новых сервисах. Раздел Family Story позволит \nподелиться в друзьями и близкими фотоснимками, текстовыми комментариями и\n самыми знаменательными событиями вашей жизни. Кроме того, дети могут \nвоспользоваться развлекательными, обучающими и познавательными \nпрограммами в разделе Kids (Для детей). С помощью раздела \"Фитнес\" \n(Fitness) вы можете заниматься фитнесом и контролировать результаты на \nэкране телевизора. Доступ к большой библиотеке контента, приложениям на \nпортале Samsung Apps и возможность бродить по страницам Интернета \nсущественно разнообразит ваш семейный досуг и позволит получить массу \nновых положительных эмоций.  ', '', '', '');
INSERT INTO shop_products_i18n (`id`, `locale`, `name`, `short_description`, `full_description`, `meta_title`, `meta_description`, `meta_keywords`) VALUES (188, 'ru', 'LG 32LS359T', 'LED телевізор 32 LG 32LS359T (81,28 см, 16:9, HD Ready, 1366x768, \n1000000:1, 178/178, 3 мс, Pal/Secam-B/G, Pal/Secam-D/K, Pal-I/I\', \nDVB-T2, DVB-C, Triple XD Engine, 2x5 Вт, телетекст (1000), годинник, \nтаймер, CI Slot, RF In (T2/C), Composite, Full Scart, Component \n(Y,Pb,Pr), HDMI/HDCP (1.4)x2, USB 2.0 (JPEG/ MP3/ DivX), LAN, 100~240 В,\n 50-60 Гц, 755x530x288.8  ', 'LED телевізор 32\" LG 32LS359T (81, 28 см, 16:9, HD Ready, 1366x768, \n1000000:1, 178/178, 3 мс, Pal/Secam-B/G, Pal/Secam-D/K, Pal-I/I\', \nDVB-T2, DVB-C, Triple XD Engine, 2x5 Вт, телетекст (1000), годинник, \nтаймер, CI Slot, RF In (T2/C), Composite, Full Scart, Component (Y, Pb, \nPr), HDMI/HDCP (1.4)x2, USB 2.0 (JPEG/ MP3/ DivX), LAN, 100~240 В, 50-60\n Гц, 755x530x288.8 мм, 9.1 кг, білий)  ', '', '', '');
INSERT INTO shop_products_i18n (`id`, `locale`, `name`, `short_description`, `full_description`, `meta_title`, `meta_description`, `meta_keywords`) VALUES (189, 'ru', 'LG 47LM580T', '<div>\n                <div>ЖК-телевизор, 47, 16:9, 1920x1080, HDTV, 1080p (Full HD), LED-подсветка,\n 200 Гц, 3D, мощность звука 20 Вт, HDMI x3, VGA  </div></div>  ', 'ЖК-телевизор, 47\", 16:9, 1920x1080, HDTV, 1080p (Full HD), \nLED-подсветка, 200 Гц, 3D, мощность звука 20 Вт, HDMI x3, VGA  ', '', '', '');
INSERT INTO shop_products_i18n (`id`, `locale`, `name`, `short_description`, `full_description`, `meta_title`, `meta_description`, `meta_keywords`) VALUES (190, 'ru', 'Samsung LE40D550K1WXUA', '<div>\n                <div>\n                LCD телевізор 40 Samsung LE-40D550K1WXUA (Full HD 1080p \n1920х1080, 500 cd/m2, 50Hz, 10 Wx2 SRS TheaterSound, HDMI 1.4, USB, \nComponent In (Y/Pb/Pr), Composite In (AV), Digital Audio Out (Optical), \nPC In (D-sub), CI Slot, Scart, RF In (Terrestrial/Cable Input), \nheadphones, PC Audio In (Mini Jack), DVI Audio In (Mini Jack), Ethernet \n(LAN) , VESA 200х200mm</div></div>  ', 'SAMSUNG LE40D550K1WXUA - ЖК телевизор диагональю 40\". Уникальная система\n подключения устройств позволит вам централизованно управлять всем \nцифровым контентом. Технология Samsung AllShare дает возможность \nподключить ваш телевизор ко всем совместимым цифровым устройствам, чтобы\n воспроизводить файлы с них на большом экране. Для подсоединения \nустройств, не поддерживающих беспроводную связь, можно использовать \nчетыре порта HDMI . Технология ConnectShare Movie™ позволяет подключить \nотдельный жесткий диск непосредственно к телевизору для потоковой \nпередачи фильмов. Гладкий корпус без видимых стыков и супертонкая рамка \nдовершают впечатление сдержанной элегантности.  ', '', '', '');
INSERT INTO shop_products_i18n (`id`, `locale`, `name`, `short_description`, `full_description`, `meta_title`, `meta_description`, `meta_keywords`) VALUES (191, 'ru', 'Sony KDL-22EX553', '22 // 1366x768 пикс // 50 Гц // LED подсветка // эфирный (DVB-T) // \nкабельный (DVB-C) // HDMI: 2 шт // Компонентный //Композитный // SCART \n// USB // LAN // Линейный  ', '<div><strong>KDL-22EX553<br>\nНовый способ просмотра ТВ</strong></div><br>\n55 см / 22\", телевизор HD Ready с технологией подсветки Edge LED, X-Reality, встроенным Wi-Fi® и интернет-телевидением от Sony<br>\nНаслаждайтесь четким отображением на тонком экране Edge LED<br>\nWi-Fi обеспечивает быстрый доступ к функции просмотра пропущенных программ, фильмам и приложениям<br>\nДля более комфортного просмотра предусматривается изменение угла наклона телевизора<br>\n<br>\n<div><strong>Мир развлечений на кончиках пальцев</strong></div><br>\nНачните революцию интернет-телевидения у себя дома. Откройте \nувлекательный новый мир передачи контента по запросу, просмотра \nпропущенных программ, приложений и многого другого, и все это - с \nчетким, детализированным изображением, на большом и тонком ЖК-экране. \nПришло время управлять центром развлечений в вашем доме.<br>\n<br>\n<div><strong>Четкое, реалистичное изображение</strong></div><br>\nX-Reality обеспечивает более четкое и реалистичное HD-изображение, вне \nзависимости от источника: будь то интернет-канал, DVD-диск или \nлюбительский клип. Кроме того, эта технология убирает эффект мерцания, \nгарантируя более плавное отображение динамичных спортивных передач.<br>\n<br>\n<div><strong>Новый дизайн, легкие материалы</strong></div><br>\nТелевизоры серии HX75 выполнены из контрастных материалов и имеют \nбезукоризненный дизайн. Вас восхитит легкость этого телевизора, который \nрасполагается на подставке в форме мольберта, позволяющей вращать его в \nвертикальной и горизонтальной плоскости для идеального угла обзора.<br>\n<br>\n<div><strong>Беспроводной доступ к онлайн-развлечениям</strong></div><br>\nТеперь доступ к контенту сетевого сервиса Sony Entertainment Network — \nHD-фильмам, миллионам музыкальных композиций, любимым телеканалам, \nвеб-браузеру, приложениям Twitter™, Facebook®, YouTube™, Skype™ и \nмногому другому — осуществляется с помощью дистанционного пульта или \nмобильного устройства с поддержкой распознавания голоса.<br>\n<br>\n<div><strong>Энергосберегающие функции телевизоров</strong></div><br>\nНовая функция затемнения LED Frame автоматически подстраивает яркость \nподсветки при просмотре и снижает потребление энергии, позволяя \nэкономить деньги. При этом изображение остается резким и \nвысококонтрастным.  ', '', '', '');


#
# TABLE STRUCTURE FOR: shop_products_rating
#

DROP TABLE IF EXISTS shop_products_rating;

CREATE TABLE `shop_products_rating` (
  `product_id` int(11) NOT NULL,
  `votes` int(11) DEFAULT NULL,
  `rating` int(11) DEFAULT NULL,
  PRIMARY KEY (`product_id`)
) ENGINE=MyISAM DEFAULT CHARSET=utf8;

INSERT INTO shop_products_rating (`product_id`, `votes`, `rating`) VALUES (71, 3, 7);
INSERT INTO shop_products_rating (`product_id`, `votes`, `rating`) VALUES (81, 1, 5);
INSERT INTO shop_products_rating (`product_id`, `votes`, `rating`) VALUES (88, 1, 1);
INSERT INTO shop_products_rating (`product_id`, `votes`, `rating`) VALUES (76, 3, 11);
INSERT INTO shop_products_rating (`product_id`, `votes`, `rating`) VALUES (82, 3, 9);
INSERT INTO shop_products_rating (`product_id`, `votes`, `rating`) VALUES (77, 2, 7);
INSERT INTO shop_products_rating (`product_id`, `votes`, `rating`) VALUES (73, 1, 2);
INSERT INTO shop_products_rating (`product_id`, `votes`, `rating`) VALUES (108, 2, 6);
INSERT INTO shop_products_rating (`product_id`, `votes`, `rating`) VALUES (72, 1, 5);
INSERT INTO shop_products_rating (`product_id`, `votes`, `rating`) VALUES (74, 2, 8);
INSERT INTO shop_products_rating (`product_id`, `votes`, `rating`) VALUES (75, 2, 9);
INSERT INTO shop_products_rating (`product_id`, `votes`, `rating`) VALUES (94, 1, 4);
INSERT INTO shop_products_rating (`product_id`, `votes`, `rating`) VALUES (87, 1, 5);
INSERT INTO shop_products_rating (`product_id`, `votes`, `rating`) VALUES (79, 1, 5);
INSERT INTO shop_products_rating (`product_id`, `votes`, `rating`) VALUES (189, 2, 8);


#
# TABLE STRUCTURE FOR: shop_rbac_group
#

DROP TABLE IF EXISTS shop_rbac_group;

CREATE TABLE `shop_rbac_group` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `type` varchar(10) NOT NULL,
  `name` varchar(100) NOT NULL,
  `description` varchar(255) DEFAULT NULL,
  PRIMARY KEY (`id`)
) ENGINE=MyISAM AUTO_INCREMENT=60 DEFAULT CHARSET=utf8;

INSERT INTO shop_rbac_group (`id`, `type`, `name`, `description`) VALUES (1, 'shop', 'ShopAdminBanners', NULL);
INSERT INTO shop_rbac_group (`id`, `type`, `name`, `description`) VALUES (2, 'shop', 'ShopAdminBrands', NULL);
INSERT INTO shop_rbac_group (`id`, `type`, `name`, `description`) VALUES (3, 'shop', 'ShopAdminCallbacks', NULL);
INSERT INTO shop_rbac_group (`id`, `type`, `name`, `description`) VALUES (4, 'shop', 'ShopAdminCategories', NULL);
INSERT INTO shop_rbac_group (`id`, `type`, `name`, `description`) VALUES (5, 'shop', 'ShopAdminCharts', NULL);
INSERT INTO shop_rbac_group (`id`, `type`, `name`, `description`) VALUES (6, 'shop', 'ShopAdminComulativ', NULL);
INSERT INTO shop_rbac_group (`id`, `type`, `name`, `description`) VALUES (7, 'shop', 'ShopAdminCurrencies', NULL);
INSERT INTO shop_rbac_group (`id`, `type`, `name`, `description`) VALUES (8, 'shop', 'ShopAdminCustomfields', NULL);
INSERT INTO shop_rbac_group (`id`, `type`, `name`, `description`) VALUES (9, 'shop', 'ShopAdminDashboard', NULL);
INSERT INTO shop_rbac_group (`id`, `type`, `name`, `description`) VALUES (10, 'shop', 'ShopAdminDeliverymethods', NULL);
INSERT INTO shop_rbac_group (`id`, `type`, `name`, `description`) VALUES (11, 'shop', 'ShopAdminDiscounts', NULL);
INSERT INTO shop_rbac_group (`id`, `type`, `name`, `description`) VALUES (12, 'shop', 'ShopAdminGifts', NULL);
INSERT INTO shop_rbac_group (`id`, `type`, `name`, `description`) VALUES (13, 'shop', 'ShopAdminKits', NULL);
INSERT INTO shop_rbac_group (`id`, `type`, `name`, `description`) VALUES (14, 'shop', 'ShopAdminNotifications', NULL);
INSERT INTO shop_rbac_group (`id`, `type`, `name`, `description`) VALUES (15, 'shop', 'ShopAdminNotificationstatuses', NULL);
INSERT INTO shop_rbac_group (`id`, `type`, `name`, `description`) VALUES (16, 'shop', 'ShopAdminOrders', NULL);
INSERT INTO shop_rbac_group (`id`, `type`, `name`, `description`) VALUES (17, 'shop', 'ShopAdminOrderstatuses', NULL);
INSERT INTO shop_rbac_group (`id`, `type`, `name`, `description`) VALUES (18, 'shop', 'ShopAdminPaymentmethods', NULL);
INSERT INTO shop_rbac_group (`id`, `type`, `name`, `description`) VALUES (19, 'shop', 'ShopAdminProducts', NULL);
INSERT INTO shop_rbac_group (`id`, `type`, `name`, `description`) VALUES (20, 'shop', 'ShopAdminProductspy', NULL);
INSERT INTO shop_rbac_group (`id`, `type`, `name`, `description`) VALUES (21, 'shop', 'ShopAdminProperties', NULL);
INSERT INTO shop_rbac_group (`id`, `type`, `name`, `description`) VALUES (22, 'shop', 'ShopAdminRbac', NULL);
INSERT INTO shop_rbac_group (`id`, `type`, `name`, `description`) VALUES (23, 'shop', 'ShopAdminSearch', NULL);
INSERT INTO shop_rbac_group (`id`, `type`, `name`, `description`) VALUES (24, 'shop', 'ShopAdminSettings', NULL);
INSERT INTO shop_rbac_group (`id`, `type`, `name`, `description`) VALUES (25, 'shop', 'ShopAdminSystem', NULL);
INSERT INTO shop_rbac_group (`id`, `type`, `name`, `description`) VALUES (26, 'shop', 'ShopAdminUsers', NULL);
INSERT INTO shop_rbac_group (`id`, `type`, `name`, `description`) VALUES (27, 'shop', 'ShopAdminWarehouses', NULL);
INSERT INTO shop_rbac_group (`id`, `type`, `name`, `description`) VALUES (28, 'base', 'Admin', NULL);
INSERT INTO shop_rbac_group (`id`, `type`, `name`, `description`) VALUES (29, 'base', 'Admin_logs', NULL);
INSERT INTO shop_rbac_group (`id`, `type`, `name`, `description`) VALUES (30, 'base', 'Admin_search', NULL);
INSERT INTO shop_rbac_group (`id`, `type`, `name`, `description`) VALUES (31, 'base', 'Backup', NULL);
INSERT INTO shop_rbac_group (`id`, `type`, `name`, `description`) VALUES (32, 'base', 'Cache_all', NULL);
INSERT INTO shop_rbac_group (`id`, `type`, `name`, `description`) VALUES (33, 'base', 'Categories', NULL);
INSERT INTO shop_rbac_group (`id`, `type`, `name`, `description`) VALUES (34, 'base', 'Components', NULL);
INSERT INTO shop_rbac_group (`id`, `type`, `name`, `description`) VALUES (35, 'base', 'Dashboard', NULL);
INSERT INTO shop_rbac_group (`id`, `type`, `name`, `description`) VALUES (36, 'base', 'Languages', NULL);
INSERT INTO shop_rbac_group (`id`, `type`, `name`, `description`) VALUES (37, 'base', 'Login', NULL);
INSERT INTO shop_rbac_group (`id`, `type`, `name`, `description`) VALUES (39, 'base', 'Pages', NULL);
INSERT INTO shop_rbac_group (`id`, `type`, `name`, `description`) VALUES (40, 'base', 'Rbac', NULL);
INSERT INTO shop_rbac_group (`id`, `type`, `name`, `description`) VALUES (41, 'base', 'Settings', NULL);
INSERT INTO shop_rbac_group (`id`, `type`, `name`, `description`) VALUES (43, 'module', 'Cfcm', NULL);
INSERT INTO shop_rbac_group (`id`, `type`, `name`, `description`) VALUES (44, 'module', 'Comments', NULL);
INSERT INTO shop_rbac_group (`id`, `type`, `name`, `description`) VALUES (45, 'module', 'Feedback', NULL);
INSERT INTO shop_rbac_group (`id`, `type`, `name`, `description`) VALUES (46, 'module', 'Gallery', NULL);
INSERT INTO shop_rbac_group (`id`, `type`, `name`, `description`) VALUES (47, 'module', 'Group_mailer', NULL);
INSERT INTO shop_rbac_group (`id`, `type`, `name`, `description`) VALUES (48, 'module', 'Mailer', NULL);
INSERT INTO shop_rbac_group (`id`, `type`, `name`, `description`) VALUES (49, 'module', 'Menu', NULL);
INSERT INTO shop_rbac_group (`id`, `type`, `name`, `description`) VALUES (50, 'module', 'Rss', NULL);
INSERT INTO shop_rbac_group (`id`, `type`, `name`, `description`) VALUES (51, 'module', 'Sample_mail', NULL);
INSERT INTO shop_rbac_group (`id`, `type`, `name`, `description`) VALUES (53, 'module', 'Share', NULL);
INSERT INTO shop_rbac_group (`id`, `type`, `name`, `description`) VALUES (54, 'module', 'Sitemap', NULL);
INSERT INTO shop_rbac_group (`id`, `type`, `name`, `description`) VALUES (55, 'module', 'Social_servises', NULL);
INSERT INTO shop_rbac_group (`id`, `type`, `name`, `description`) VALUES (56, 'module', 'Template_editor', NULL);
INSERT INTO shop_rbac_group (`id`, `type`, `name`, `description`) VALUES (57, 'module', 'Trash', NULL);
INSERT INTO shop_rbac_group (`id`, `type`, `name`, `description`) VALUES (58, 'module', 'User_manager', NULL);
INSERT INTO shop_rbac_group (`id`, `type`, `name`, `description`) VALUES (59, 'base', 'Widgets_manager', NULL);


#
# TABLE STRUCTURE FOR: shop_rbac_group_i18n
#

DROP TABLE IF EXISTS shop_rbac_group_i18n;

CREATE TABLE `shop_rbac_group_i18n` (
  `id` int(11) NOT NULL,
  `description` varchar(200) DEFAULT NULL,
  `locale` varchar(5) NOT NULL,
  KEY `id_idx` (`id`)
) ENGINE=MyISAM DEFAULT CHARSET=utf8;

INSERT INTO shop_rbac_group_i18n (`id`, `description`, `locale`) VALUES (1, 'Управление баннерами', 'ru');
INSERT INTO shop_rbac_group_i18n (`id`, `description`, `locale`) VALUES (2, 'Управление брендами', 'ru');
INSERT INTO shop_rbac_group_i18n (`id`, `description`, `locale`) VALUES (3, 'Управление колбеками', 'ru');
INSERT INTO shop_rbac_group_i18n (`id`, `description`, `locale`) VALUES (4, 'Управление категориями товаров в магазине', 'ru');
INSERT INTO shop_rbac_group_i18n (`id`, `description`, `locale`) VALUES (5, 'Управление статистикой', 'ru');
INSERT INTO shop_rbac_group_i18n (`id`, `description`, `locale`) VALUES (6, 'Управление накопительными скидками', 'ru');
INSERT INTO shop_rbac_group_i18n (`id`, `description`, `locale`) VALUES (7, 'Управление валютами', 'ru');
INSERT INTO shop_rbac_group_i18n (`id`, `description`, `locale`) VALUES (8, 'Управление дополнительными полями для магазина', 'ru');
INSERT INTO shop_rbac_group_i18n (`id`, `description`, `locale`) VALUES (9, 'Главная страница панели управления магазином', 'ru');
INSERT INTO shop_rbac_group_i18n (`id`, `description`, `locale`) VALUES (10, 'Управление способами доставки', 'ru');
INSERT INTO shop_rbac_group_i18n (`id`, `description`, `locale`) VALUES (11, 'Управление скидками', 'ru');
INSERT INTO shop_rbac_group_i18n (`id`, `description`, `locale`) VALUES (12, 'Управление подарочными сертификатами', 'ru');
INSERT INTO shop_rbac_group_i18n (`id`, `description`, `locale`) VALUES (13, 'Управление наборами товаров', 'ru');
INSERT INTO shop_rbac_group_i18n (`id`, `description`, `locale`) VALUES (14, 'Управление уведомлениями', 'ru');
INSERT INTO shop_rbac_group_i18n (`id`, `description`, `locale`) VALUES (15, 'Управление статусами уведомлений', 'ru');
INSERT INTO shop_rbac_group_i18n (`id`, `description`, `locale`) VALUES (16, 'Управление заказами', 'ru');
INSERT INTO shop_rbac_group_i18n (`id`, `description`, `locale`) VALUES (17, 'Управление статусами заказов', 'ru');
INSERT INTO shop_rbac_group_i18n (`id`, `description`, `locale`) VALUES (18, 'Управление методами оплаты', 'ru');
INSERT INTO shop_rbac_group_i18n (`id`, `description`, `locale`) VALUES (19, 'Управление товарами', 'ru');
INSERT INTO shop_rbac_group_i18n (`id`, `description`, `locale`) VALUES (20, 'Управление слежением за товарами', 'ru');
INSERT INTO shop_rbac_group_i18n (`id`, `description`, `locale`) VALUES (21, 'Управление свойствами товаров', 'ru');
INSERT INTO shop_rbac_group_i18n (`id`, `description`, `locale`) VALUES (23, 'Управление поиском', 'ru');
INSERT INTO shop_rbac_group_i18n (`id`, `description`, `locale`) VALUES (24, 'Управление настройками магазина', 'ru');
INSERT INTO shop_rbac_group_i18n (`id`, `description`, `locale`) VALUES (25, 'Управление системой магазина (импорт\\экспорт)', 'ru');
INSERT INTO shop_rbac_group_i18n (`id`, `description`, `locale`) VALUES (26, 'Управление юзерами магазина', 'ru');
INSERT INTO shop_rbac_group_i18n (`id`, `description`, `locale`) VALUES (27, 'Управление складами', 'ru');
INSERT INTO shop_rbac_group_i18n (`id`, `description`, `locale`) VALUES (28, 'Доступ к админпанели', 'ru');
INSERT INTO shop_rbac_group_i18n (`id`, `description`, `locale`) VALUES (29, 'История событий', 'ru');
INSERT INTO shop_rbac_group_i18n (`id`, `description`, `locale`) VALUES (30, 'Управление поиском в базовой админ панели', 'ru');
INSERT INTO shop_rbac_group_i18n (`id`, `description`, `locale`) VALUES (31, 'Управление бекапами', 'ru');
INSERT INTO shop_rbac_group_i18n (`id`, `description`, `locale`) VALUES (32, 'Управление кэшем', 'ru');
INSERT INTO shop_rbac_group_i18n (`id`, `description`, `locale`) VALUES (33, 'Управление категориями сайта', 'ru');
INSERT INTO shop_rbac_group_i18n (`id`, `description`, `locale`) VALUES (34, 'Управление компонентами сайта', 'ru');
INSERT INTO shop_rbac_group_i18n (`id`, `description`, `locale`) VALUES (35, 'Управление главной станицой базовой админ панели', 'ru');
INSERT INTO shop_rbac_group_i18n (`id`, `description`, `locale`) VALUES (36, 'Управление языками', 'ru');
INSERT INTO shop_rbac_group_i18n (`id`, `description`, `locale`) VALUES (37, 'Вход в админпанель', 'ru');
INSERT INTO shop_rbac_group_i18n (`id`, `description`, `locale`) VALUES (38, 'Поиск модулей для установки', 'ru');
INSERT INTO shop_rbac_group_i18n (`id`, `description`, `locale`) VALUES (39, 'Управление страницами', 'ru');
INSERT INTO shop_rbac_group_i18n (`id`, `description`, `locale`) VALUES (40, 'Управление правами доступа', 'ru');
INSERT INTO shop_rbac_group_i18n (`id`, `description`, `locale`) VALUES (41, 'Управление базовыми настройками', 'ru');
INSERT INTO shop_rbac_group_i18n (`id`, `description`, `locale`) VALUES (42, 'Управление обновлением системы', 'ru');
INSERT INTO shop_rbac_group_i18n (`id`, `description`, `locale`) VALUES (43, 'Управление констуктором полей', 'ru');
INSERT INTO shop_rbac_group_i18n (`id`, `description`, `locale`) VALUES (44, 'Управление комментариями', 'ru');
INSERT INTO shop_rbac_group_i18n (`id`, `description`, `locale`) VALUES (45, 'Управление обратной связью', 'ru');
INSERT INTO shop_rbac_group_i18n (`id`, `description`, `locale`) VALUES (46, 'Управление галереей', 'ru');
INSERT INTO shop_rbac_group_i18n (`id`, `description`, `locale`) VALUES (47, 'Управление модулем рассылки', 'ru');
INSERT INTO shop_rbac_group_i18n (`id`, `description`, `locale`) VALUES (48, 'Управление модулем подписки и рассылки', 'ru');
INSERT INTO shop_rbac_group_i18n (`id`, `description`, `locale`) VALUES (49, 'Управление меню', 'ru');
INSERT INTO shop_rbac_group_i18n (`id`, `description`, `locale`) VALUES (50, 'Управление модулем RSS', 'ru');
INSERT INTO shop_rbac_group_i18n (`id`, `description`, `locale`) VALUES (51, 'Управление шаблонами писем', 'ru');
INSERT INTO shop_rbac_group_i18n (`id`, `description`, `locale`) VALUES (52, 'Шаблон модуля', 'ru');
INSERT INTO shop_rbac_group_i18n (`id`, `description`, `locale`) VALUES (53, 'Управление модулем кнопок соцсетей', 'ru');
INSERT INTO shop_rbac_group_i18n (`id`, `description`, `locale`) VALUES (54, 'Управление модулем карта сайта', 'ru');
INSERT INTO shop_rbac_group_i18n (`id`, `description`, `locale`) VALUES (55, 'Управление модулем интеграции с соцсетями', 'ru');
INSERT INTO shop_rbac_group_i18n (`id`, `description`, `locale`) VALUES (56, 'Управление модулем редактор шаблонов', 'ru');
INSERT INTO shop_rbac_group_i18n (`id`, `description`, `locale`) VALUES (57, 'Управление модулем перенаправления', 'ru');
INSERT INTO shop_rbac_group_i18n (`id`, `description`, `locale`) VALUES (58, 'Управление пользователями', 'ru');
INSERT INTO shop_rbac_group_i18n (`id`, `description`, `locale`) VALUES (59, 'Управление виджетами', 'ru');


#
# TABLE STRUCTURE FOR: shop_rbac_privileges
#

DROP TABLE IF EXISTS shop_rbac_privileges;

CREATE TABLE `shop_rbac_privileges` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `name` varchar(255) NOT NULL,
  `group_id` int(11) NOT NULL,
  `description` varchar(255) DEFAULT NULL,
  PRIMARY KEY (`id`),
  KEY `shop_rbac_privileges_I_1` (`name`),
  KEY `shop_rbac_privileges_FI_1` (`group_id`)
) ENGINE=MyISAM AUTO_INCREMENT=485 DEFAULT CHARSET=utf8;

INSERT INTO shop_rbac_privileges (`id`, `name`, `group_id`, `description`) VALUES (1, 'ShopAdminBanners::index', 1, NULL);
INSERT INTO shop_rbac_privileges (`id`, `name`, `group_id`, `description`) VALUES (2, 'ShopAdminBanners::create', 1, NULL);
INSERT INTO shop_rbac_privileges (`id`, `name`, `group_id`, `description`) VALUES (3, 'ShopAdminBanners::edit', 1, NULL);
INSERT INTO shop_rbac_privileges (`id`, `name`, `group_id`, `description`) VALUES (4, 'ShopAdminBanners::deleteAll', 1, NULL);
INSERT INTO shop_rbac_privileges (`id`, `name`, `group_id`, `description`) VALUES (5, 'ShopAdminBanners::translate', 1, NULL);
INSERT INTO shop_rbac_privileges (`id`, `name`, `group_id`, `description`) VALUES (6, 'ShopAdminBanners::changeActive', 1, NULL);
INSERT INTO shop_rbac_privileges (`id`, `name`, `group_id`, `description`) VALUES (7, 'ShopAdminBrands::index', 2, NULL);
INSERT INTO shop_rbac_privileges (`id`, `name`, `group_id`, `description`) VALUES (8, 'ShopAdminBrands::create', 2, NULL);
INSERT INTO shop_rbac_privileges (`id`, `name`, `group_id`, `description`) VALUES (9, 'ShopAdminBrands::edit', 2, NULL);
INSERT INTO shop_rbac_privileges (`id`, `name`, `group_id`, `description`) VALUES (10, 'ShopAdminBrands::delete', 2, NULL);
INSERT INTO shop_rbac_privileges (`id`, `name`, `group_id`, `description`) VALUES (11, 'ShopAdminBrands::c_list', 2, NULL);
INSERT INTO shop_rbac_privileges (`id`, `name`, `group_id`, `description`) VALUES (12, 'ShopAdminBrands::translate', 2, NULL);
INSERT INTO shop_rbac_privileges (`id`, `name`, `group_id`, `description`) VALUES (13, 'ShopAdminCallbacks::index', 3, NULL);
INSERT INTO shop_rbac_privileges (`id`, `name`, `group_id`, `description`) VALUES (14, 'ShopAdminCallbacks::update', 3, NULL);
INSERT INTO shop_rbac_privileges (`id`, `name`, `group_id`, `description`) VALUES (15, 'ShopAdminCallbacks::statuses', 3, NULL);
INSERT INTO shop_rbac_privileges (`id`, `name`, `group_id`, `description`) VALUES (16, 'ShopAdminCallbacks::createStatus', 3, NULL);
INSERT INTO shop_rbac_privileges (`id`, `name`, `group_id`, `description`) VALUES (17, 'ShopAdminCallbacks::updateStatus', 3, NULL);
INSERT INTO shop_rbac_privileges (`id`, `name`, `group_id`, `description`) VALUES (18, 'ShopAdminCallbacks::setDefaultStatus', 3, NULL);
INSERT INTO shop_rbac_privileges (`id`, `name`, `group_id`, `description`) VALUES (19, 'ShopAdminCallbacks::changeStatus', 3, NULL);
INSERT INTO shop_rbac_privileges (`id`, `name`, `group_id`, `description`) VALUES (20, 'ShopAdminCallbacks::reorderThemes', 3, NULL);
INSERT INTO shop_rbac_privileges (`id`, `name`, `group_id`, `description`) VALUES (21, 'ShopAdminCallbacks::changeTheme', 3, NULL);
INSERT INTO shop_rbac_privileges (`id`, `name`, `group_id`, `description`) VALUES (22, 'ShopAdminCallbacks::deleteCallback', 3, NULL);
INSERT INTO shop_rbac_privileges (`id`, `name`, `group_id`, `description`) VALUES (23, 'ShopAdminCallbacks::deleteStatus', 3, NULL);
INSERT INTO shop_rbac_privileges (`id`, `name`, `group_id`, `description`) VALUES (24, 'ShopAdminCallbacks::themes', 3, NULL);
INSERT INTO shop_rbac_privileges (`id`, `name`, `group_id`, `description`) VALUES (25, 'ShopAdminCallbacks::createTheme', 3, NULL);
INSERT INTO shop_rbac_privileges (`id`, `name`, `group_id`, `description`) VALUES (26, 'ShopAdminCallbacks::updateTheme', 3, NULL);
INSERT INTO shop_rbac_privileges (`id`, `name`, `group_id`, `description`) VALUES (27, 'ShopAdminCallbacks::deleteTheme', 3, NULL);
INSERT INTO shop_rbac_privileges (`id`, `name`, `group_id`, `description`) VALUES (28, 'ShopAdminCallbacks::search', 3, NULL);
INSERT INTO shop_rbac_privileges (`id`, `name`, `group_id`, `description`) VALUES (29, 'ShopAdminCategories::index', 4, NULL);
INSERT INTO shop_rbac_privileges (`id`, `name`, `group_id`, `description`) VALUES (30, 'ShopAdminCategories::create', 4, NULL);
INSERT INTO shop_rbac_privileges (`id`, `name`, `group_id`, `description`) VALUES (31, 'ShopAdminCategories::edit', 4, NULL);
INSERT INTO shop_rbac_privileges (`id`, `name`, `group_id`, `description`) VALUES (32, 'ShopAdminCategories::delete', 4, NULL);
INSERT INTO shop_rbac_privileges (`id`, `name`, `group_id`, `description`) VALUES (33, 'ShopAdminCategories::c_list', 4, NULL);
INSERT INTO shop_rbac_privileges (`id`, `name`, `group_id`, `description`) VALUES (34, 'ShopAdminCategories::save_positions', 4, NULL);
INSERT INTO shop_rbac_privileges (`id`, `name`, `group_id`, `description`) VALUES (35, 'ShopAdminCategories::ajax_translit', 4, NULL);
INSERT INTO shop_rbac_privileges (`id`, `name`, `group_id`, `description`) VALUES (36, 'ShopAdminCategories::translate', 4, NULL);
INSERT INTO shop_rbac_privileges (`id`, `name`, `group_id`, `description`) VALUES (37, 'ShopAdminCategories::changeActive', 4, NULL);
INSERT INTO shop_rbac_privileges (`id`, `name`, `group_id`, `description`) VALUES (38, 'ShopAdminCategories::create_tpl', 4, NULL);
INSERT INTO shop_rbac_privileges (`id`, `name`, `group_id`, `description`) VALUES (39, 'ShopAdminCategories::get_tpl_names', 4, NULL);
INSERT INTO shop_rbac_privileges (`id`, `name`, `group_id`, `description`) VALUES (40, 'ShopAdminCharts::orders', 5, NULL);
INSERT INTO shop_rbac_privileges (`id`, `name`, `group_id`, `description`) VALUES (41, 'ShopAdminCharts::byDate', 5, NULL);
INSERT INTO shop_rbac_privileges (`id`, `name`, `group_id`, `description`) VALUES (42, 'ShopAdminCharts::_createDatesDropDown', 5, NULL);
INSERT INTO shop_rbac_privileges (`id`, `name`, `group_id`, `description`) VALUES (43, 'ShopAdminComulativ::index', 6, NULL);
INSERT INTO shop_rbac_privileges (`id`, `name`, `group_id`, `description`) VALUES (44, 'ShopAdminComulativ::create', 6, NULL);
INSERT INTO shop_rbac_privileges (`id`, `name`, `group_id`, `description`) VALUES (45, 'ShopAdminComulativ::edit', 6, NULL);
INSERT INTO shop_rbac_privileges (`id`, `name`, `group_id`, `description`) VALUES (46, 'ShopAdminComulativ::allUsers', 6, NULL);
INSERT INTO shop_rbac_privileges (`id`, `name`, `group_id`, `description`) VALUES (47, 'ShopAdminComulativ::user', 6, NULL);
INSERT INTO shop_rbac_privileges (`id`, `name`, `group_id`, `description`) VALUES (48, 'ShopAdminComulativ::deleteAll', 6, NULL);
INSERT INTO shop_rbac_privileges (`id`, `name`, `group_id`, `description`) VALUES (49, 'ShopAdminComulativ::change_comulativ_dis_status', 6, NULL);
INSERT INTO shop_rbac_privileges (`id`, `name`, `group_id`, `description`) VALUES (50, 'ShopAdminCurrencies::index', 7, NULL);
INSERT INTO shop_rbac_privileges (`id`, `name`, `group_id`, `description`) VALUES (51, 'ShopAdminCurrencies::create', 7, NULL);
INSERT INTO shop_rbac_privileges (`id`, `name`, `group_id`, `description`) VALUES (52, 'ShopAdminCurrencies::edit', 7, NULL);
INSERT INTO shop_rbac_privileges (`id`, `name`, `group_id`, `description`) VALUES (53, 'ShopAdminCurrencies::makeCurrencyDefault', 7, NULL);
INSERT INTO shop_rbac_privileges (`id`, `name`, `group_id`, `description`) VALUES (54, 'ShopAdminCurrencies::makeCurrencyMain', 7, NULL);
INSERT INTO shop_rbac_privileges (`id`, `name`, `group_id`, `description`) VALUES (55, 'ShopAdminCurrencies::delete', 7, NULL);
INSERT INTO shop_rbac_privileges (`id`, `name`, `group_id`, `description`) VALUES (56, 'ShopAdminCurrencies::recount', 7, NULL);
INSERT INTO shop_rbac_privileges (`id`, `name`, `group_id`, `description`) VALUES (57, 'ShopAdminCurrencies::checkPrices', 7, NULL);
INSERT INTO shop_rbac_privileges (`id`, `name`, `group_id`, `description`) VALUES (58, 'ShopAdminCustomfields::index', 8, NULL);
INSERT INTO shop_rbac_privileges (`id`, `name`, `group_id`, `description`) VALUES (59, 'ShopAdminCustomfields::create', 8, NULL);
INSERT INTO shop_rbac_privileges (`id`, `name`, `group_id`, `description`) VALUES (60, 'ShopAdminCustomfields::edit', 8, NULL);
INSERT INTO shop_rbac_privileges (`id`, `name`, `group_id`, `description`) VALUES (61, 'ShopAdminCustomfields::deleteAll', 8, NULL);
INSERT INTO shop_rbac_privileges (`id`, `name`, `group_id`, `description`) VALUES (62, 'ShopAdminCustomfields::change_status_activ', 8, NULL);
INSERT INTO shop_rbac_privileges (`id`, `name`, `group_id`, `description`) VALUES (63, 'ShopAdminCustomfields::change_status_private', 8, NULL);
INSERT INTO shop_rbac_privileges (`id`, `name`, `group_id`, `description`) VALUES (64, 'ShopAdminCustomfields::change_status_required', 8, NULL);
INSERT INTO shop_rbac_privileges (`id`, `name`, `group_id`, `description`) VALUES (65, 'ShopAdminDashboard::index', 9, NULL);
INSERT INTO shop_rbac_privileges (`id`, `name`, `group_id`, `description`) VALUES (66, 'ShopAdminDeliverymethods::index', 10, NULL);
INSERT INTO shop_rbac_privileges (`id`, `name`, `group_id`, `description`) VALUES (67, 'ShopAdminDeliverymethods::create', 10, NULL);
INSERT INTO shop_rbac_privileges (`id`, `name`, `group_id`, `description`) VALUES (68, 'ShopAdminDeliverymethods::change_delivery_status', 10, NULL);
INSERT INTO shop_rbac_privileges (`id`, `name`, `group_id`, `description`) VALUES (69, 'ShopAdminDeliverymethods::edit', 10, NULL);
INSERT INTO shop_rbac_privileges (`id`, `name`, `group_id`, `description`) VALUES (70, 'ShopAdminDeliverymethods::deleteAll', 10, NULL);
INSERT INTO shop_rbac_privileges (`id`, `name`, `group_id`, `description`) VALUES (71, 'ShopAdminDeliverymethods::c_list', 10, NULL);
INSERT INTO shop_rbac_privileges (`id`, `name`, `group_id`, `description`) VALUES (72, 'ShopAdminDiscounts::index', 11, NULL);
INSERT INTO shop_rbac_privileges (`id`, `name`, `group_id`, `description`) VALUES (73, 'ShopAdminDiscounts::create', 11, NULL);
INSERT INTO shop_rbac_privileges (`id`, `name`, `group_id`, `description`) VALUES (74, 'ShopAdminDiscounts::change_discount_status', 11, NULL);
INSERT INTO shop_rbac_privileges (`id`, `name`, `group_id`, `description`) VALUES (75, 'ShopAdminDiscounts::edit', 11, NULL);
INSERT INTO shop_rbac_privileges (`id`, `name`, `group_id`, `description`) VALUES (76, 'ShopAdminDiscounts::deleteAll', 11, NULL);
INSERT INTO shop_rbac_privileges (`id`, `name`, `group_id`, `description`) VALUES (77, 'ShopAdminGifts::index', 12, NULL);
INSERT INTO shop_rbac_privileges (`id`, `name`, `group_id`, `description`) VALUES (78, 'ShopAdminGifts::create', 12, NULL);
INSERT INTO shop_rbac_privileges (`id`, `name`, `group_id`, `description`) VALUES (79, 'ShopAdminGifts::generateKey', 12, NULL);
INSERT INTO shop_rbac_privileges (`id`, `name`, `group_id`, `description`) VALUES (80, 'ShopAdminGifts::delete', 12, NULL);
INSERT INTO shop_rbac_privileges (`id`, `name`, `group_id`, `description`) VALUES (81, 'ShopAdminGifts::edit', 12, NULL);
INSERT INTO shop_rbac_privileges (`id`, `name`, `group_id`, `description`) VALUES (82, 'ShopAdminGifts::ChangeActive', 12, NULL);
INSERT INTO shop_rbac_privileges (`id`, `name`, `group_id`, `description`) VALUES (83, 'ShopAdminGifts::settings', 12, NULL);
INSERT INTO shop_rbac_privileges (`id`, `name`, `group_id`, `description`) VALUES (84, 'ShopAdminGifts::save_settings', 12, NULL);
INSERT INTO shop_rbac_privileges (`id`, `name`, `group_id`, `description`) VALUES (85, 'ShopAdminKits::index', 13, NULL);
INSERT INTO shop_rbac_privileges (`id`, `name`, `group_id`, `description`) VALUES (86, 'ShopAdminKits::kit_create', 13, NULL);
INSERT INTO shop_rbac_privileges (`id`, `name`, `group_id`, `description`) VALUES (87, 'ShopAdminKits::kit_edit', 13, NULL);
INSERT INTO shop_rbac_privileges (`id`, `name`, `group_id`, `description`) VALUES (88, 'ShopAdminKits::kit_save_positions', 13, NULL);
INSERT INTO shop_rbac_privileges (`id`, `name`, `group_id`, `description`) VALUES (89, 'ShopAdminKits::kit_change_active', 13, NULL);
INSERT INTO shop_rbac_privileges (`id`, `name`, `group_id`, `description`) VALUES (90, 'ShopAdminKits::kit_list', 13, NULL);
INSERT INTO shop_rbac_privileges (`id`, `name`, `group_id`, `description`) VALUES (91, 'ShopAdminKits::kit_delete', 13, NULL);
INSERT INTO shop_rbac_privileges (`id`, `name`, `group_id`, `description`) VALUES (92, 'ShopAdminKits::get_products_list', 13, NULL);
INSERT INTO shop_rbac_privileges (`id`, `name`, `group_id`, `description`) VALUES (93, 'ShopAdminNotifications::index', 14, NULL);
INSERT INTO shop_rbac_privileges (`id`, `name`, `group_id`, `description`) VALUES (94, 'ShopAdminNotifications::edit', 14, NULL);
INSERT INTO shop_rbac_privileges (`id`, `name`, `group_id`, `description`) VALUES (95, 'ShopAdminNotifications::changeStatus', 14, NULL);
INSERT INTO shop_rbac_privileges (`id`, `name`, `group_id`, `description`) VALUES (96, 'ShopAdminNotifications::notifyByEmail', 14, NULL);
INSERT INTO shop_rbac_privileges (`id`, `name`, `group_id`, `description`) VALUES (97, 'ShopAdminNotifications::deleteAll', 14, NULL);
INSERT INTO shop_rbac_privileges (`id`, `name`, `group_id`, `description`) VALUES (98, 'ShopAdminNotifications::ajaxDeleteNotifications', 14, NULL);
INSERT INTO shop_rbac_privileges (`id`, `name`, `group_id`, `description`) VALUES (99, 'ShopAdminNotifications::ajaxChangeNotificationsStatus', 14, NULL);
INSERT INTO shop_rbac_privileges (`id`, `name`, `group_id`, `description`) VALUES (100, 'ShopAdminNotifications::search', 14, NULL);
INSERT INTO shop_rbac_privileges (`id`, `name`, `group_id`, `description`) VALUES (101, 'ShopAdminNotifications::getAvailableNotification', 14, NULL);
INSERT INTO shop_rbac_privileges (`id`, `name`, `group_id`, `description`) VALUES (102, 'ShopAdminNotificationstatuses::index', 15, NULL);
INSERT INTO shop_rbac_privileges (`id`, `name`, `group_id`, `description`) VALUES (103, 'ShopAdminNotificationstatuses::create', 15, NULL);
INSERT INTO shop_rbac_privileges (`id`, `name`, `group_id`, `description`) VALUES (104, 'ShopAdminNotificationstatuses::edit', 15, NULL);
INSERT INTO shop_rbac_privileges (`id`, `name`, `group_id`, `description`) VALUES (105, 'ShopAdminNotificationstatuses::deleteAll', 15, NULL);
INSERT INTO shop_rbac_privileges (`id`, `name`, `group_id`, `description`) VALUES (106, 'ShopAdminNotificationstatuses::savePositions', 15, NULL);
INSERT INTO shop_rbac_privileges (`id`, `name`, `group_id`, `description`) VALUES (107, 'ShopAdminOrders::index', 16, NULL);
INSERT INTO shop_rbac_privileges (`id`, `name`, `group_id`, `description`) VALUES (108, 'ShopAdminOrders::edit', 16, NULL);
INSERT INTO shop_rbac_privileges (`id`, `name`, `group_id`, `description`) VALUES (109, 'ShopAdminOrders::changeStatus', 16, NULL);
INSERT INTO shop_rbac_privileges (`id`, `name`, `group_id`, `description`) VALUES (110, 'ShopAdminOrders::changePaid', 16, NULL);
INSERT INTO shop_rbac_privileges (`id`, `name`, `group_id`, `description`) VALUES (111, 'ShopAdminOrders::delete', 16, NULL);
INSERT INTO shop_rbac_privileges (`id`, `name`, `group_id`, `description`) VALUES (112, 'ShopAdminOrders::ajaxDeleteOrders', 16, NULL);
INSERT INTO shop_rbac_privileges (`id`, `name`, `group_id`, `description`) VALUES (113, 'ShopAdminOrders::ajaxChangeOrdersStatus', 16, NULL);
INSERT INTO shop_rbac_privileges (`id`, `name`, `group_id`, `description`) VALUES (114, 'ShopAdminOrders::ajaxChangeOrdersPaid', 16, NULL);
INSERT INTO shop_rbac_privileges (`id`, `name`, `group_id`, `description`) VALUES (115, 'ShopAdminOrders::ajaxEditWindow', 16, NULL);
INSERT INTO shop_rbac_privileges (`id`, `name`, `group_id`, `description`) VALUES (116, 'ShopAdminOrders::editKit', 16, NULL);
INSERT INTO shop_rbac_privileges (`id`, `name`, `group_id`, `description`) VALUES (117, 'ShopAdminOrders::ajaxEditAddToCartWindow', 16, NULL);
INSERT INTO shop_rbac_privileges (`id`, `name`, `group_id`, `description`) VALUES (118, 'ShopAdminOrders::ajaxDeleteProduct', 16, NULL);
INSERT INTO shop_rbac_privileges (`id`, `name`, `group_id`, `description`) VALUES (119, 'ShopAdminOrders::ajaxGetProductList', 16, NULL);
INSERT INTO shop_rbac_privileges (`id`, `name`, `group_id`, `description`) VALUES (120, 'ShopAdminOrders::ajaxEditOrderCart', 16, NULL);
INSERT INTO shop_rbac_privileges (`id`, `name`, `group_id`, `description`) VALUES (121, 'ShopAdminOrders::ajaxEditOrderAddToCart', 16, NULL);
INSERT INTO shop_rbac_privileges (`id`, `name`, `group_id`, `description`) VALUES (122, 'ShopAdminOrders::ajaxGetOrderCart', 16, NULL);
INSERT INTO shop_rbac_privileges (`id`, `name`, `group_id`, `description`) VALUES (123, 'ShopAdminOrders::search', 16, NULL);
INSERT INTO shop_rbac_privileges (`id`, `name`, `group_id`, `description`) VALUES (124, 'ShopAdminOrders::printChecks', 16, NULL);
INSERT INTO shop_rbac_privileges (`id`, `name`, `group_id`, `description`) VALUES (125, 'ShopAdminOrders::createPDFPage', 16, NULL);
INSERT INTO shop_rbac_privileges (`id`, `name`, `group_id`, `description`) VALUES (126, 'ShopAdminOrders::createPdf', 16, NULL);
INSERT INTO shop_rbac_privileges (`id`, `name`, `group_id`, `description`) VALUES (127, 'ShopAdminOrders::create', 16, NULL);
INSERT INTO shop_rbac_privileges (`id`, `name`, `group_id`, `description`) VALUES (128, 'ShopAdminOrderstatuses::index', 17, NULL);
INSERT INTO shop_rbac_privileges (`id`, `name`, `group_id`, `description`) VALUES (129, 'ShopAdminOrderstatuses::create', 17, NULL);
INSERT INTO shop_rbac_privileges (`id`, `name`, `group_id`, `description`) VALUES (130, 'ShopAdminOrderstatuses::edit', 17, NULL);
INSERT INTO shop_rbac_privileges (`id`, `name`, `group_id`, `description`) VALUES (131, 'ShopAdminOrderstatuses::delete', 17, NULL);
INSERT INTO shop_rbac_privileges (`id`, `name`, `group_id`, `description`) VALUES (132, 'ShopAdminOrderstatuses::ajaxDeleteWindow', 17, NULL);
INSERT INTO shop_rbac_privileges (`id`, `name`, `group_id`, `description`) VALUES (133, 'ShopAdminOrderstatuses::savePositions', 17, NULL);
INSERT INTO shop_rbac_privileges (`id`, `name`, `group_id`, `description`) VALUES (134, 'ShopAdminPaymentmethods::index', 18, NULL);
INSERT INTO shop_rbac_privileges (`id`, `name`, `group_id`, `description`) VALUES (135, 'ShopAdminPaymentmethods::create', 18, NULL);
INSERT INTO shop_rbac_privileges (`id`, `name`, `group_id`, `description`) VALUES (136, 'ShopAdminPaymentmethods::change_payment_status', 18, NULL);
INSERT INTO shop_rbac_privileges (`id`, `name`, `group_id`, `description`) VALUES (137, 'ShopAdminPaymentmethods::edit', 18, NULL);
INSERT INTO shop_rbac_privileges (`id`, `name`, `group_id`, `description`) VALUES (138, 'ShopAdminPaymentmethods::deleteAll', 18, NULL);
INSERT INTO shop_rbac_privileges (`id`, `name`, `group_id`, `description`) VALUES (139, 'ShopAdminPaymentmethods::savePositions', 18, NULL);
INSERT INTO shop_rbac_privileges (`id`, `name`, `group_id`, `description`) VALUES (140, 'ShopAdminPaymentmethods::getAdminForm', 18, NULL);
INSERT INTO shop_rbac_privileges (`id`, `name`, `group_id`, `description`) VALUES (141, 'ShopAdminProducts::index', 19, NULL);
INSERT INTO shop_rbac_privileges (`id`, `name`, `group_id`, `description`) VALUES (142, 'ShopAdminProducts::create', 19, NULL);
INSERT INTO shop_rbac_privileges (`id`, `name`, `group_id`, `description`) VALUES (143, 'ShopAdminProducts::edit', 19, NULL);
INSERT INTO shop_rbac_privileges (`id`, `name`, `group_id`, `description`) VALUES (144, 'ShopAdminProducts::saveAdditionalImages', 19, NULL);
INSERT INTO shop_rbac_privileges (`id`, `name`, `group_id`, `description`) VALUES (145, 'ShopAdminProducts::delete', 19, NULL);
INSERT INTO shop_rbac_privileges (`id`, `name`, `group_id`, `description`) VALUES (146, 'ShopAdminProducts::processImage', 19, NULL);
INSERT INTO shop_rbac_privileges (`id`, `name`, `group_id`, `description`) VALUES (147, 'ShopAdminProducts::deleteAddImage', 19, NULL);
INSERT INTO shop_rbac_privileges (`id`, `name`, `group_id`, `description`) VALUES (148, 'ShopAdminProducts::ajaxChangeActive', 19, NULL);
INSERT INTO shop_rbac_privileges (`id`, `name`, `group_id`, `description`) VALUES (149, 'ShopAdminProducts::ajaxChangeHit', 19, NULL);
INSERT INTO shop_rbac_privileges (`id`, `name`, `group_id`, `description`) VALUES (150, 'ShopAdminProducts::ajaxChangeHot', 19, NULL);
INSERT INTO shop_rbac_privileges (`id`, `name`, `group_id`, `description`) VALUES (151, 'ShopAdminProducts::ajaxChangeAction', 19, NULL);
INSERT INTO shop_rbac_privileges (`id`, `name`, `group_id`, `description`) VALUES (152, 'ShopAdminProducts::ajaxUpdatePrice', 19, NULL);
INSERT INTO shop_rbac_privileges (`id`, `name`, `group_id`, `description`) VALUES (153, 'ShopAdminProducts::ajaxCloneProducts', 19, NULL);
INSERT INTO shop_rbac_privileges (`id`, `name`, `group_id`, `description`) VALUES (154, 'ShopAdminProducts::ajaxDeleteProducts', 19, NULL);
INSERT INTO shop_rbac_privileges (`id`, `name`, `group_id`, `description`) VALUES (155, 'ShopAdminProducts::ajaxMoveWindow', 19, NULL);
INSERT INTO shop_rbac_privileges (`id`, `name`, `group_id`, `description`) VALUES (156, 'ShopAdminProducts::ajaxMoveProducts', 19, NULL);
INSERT INTO shop_rbac_privileges (`id`, `name`, `group_id`, `description`) VALUES (157, 'ShopAdminProducts::translate', 19, NULL);
INSERT INTO shop_rbac_privileges (`id`, `name`, `group_id`, `description`) VALUES (158, 'ShopAdminProducts::get_ids', 19, NULL);
INSERT INTO shop_rbac_privileges (`id`, `name`, `group_id`, `description`) VALUES (159, 'ShopAdminProducts::prev_next', 19, NULL);
INSERT INTO shop_rbac_privileges (`id`, `name`, `group_id`, `description`) VALUES (160, 'ShopAdminProductspy::index', 20, NULL);
INSERT INTO shop_rbac_privileges (`id`, `name`, `group_id`, `description`) VALUES (161, 'ShopAdminProductspy::delete', 20, NULL);
INSERT INTO shop_rbac_privileges (`id`, `name`, `group_id`, `description`) VALUES (162, 'ShopAdminProductspy::settings', 20, NULL);
INSERT INTO shop_rbac_privileges (`id`, `name`, `group_id`, `description`) VALUES (163, 'ShopAdminProperties::index', 21, NULL);
INSERT INTO shop_rbac_privileges (`id`, `name`, `group_id`, `description`) VALUES (164, 'ShopAdminProperties::create', 21, NULL);
INSERT INTO shop_rbac_privileges (`id`, `name`, `group_id`, `description`) VALUES (165, 'ShopAdminProperties::edit', 21, NULL);
INSERT INTO shop_rbac_privileges (`id`, `name`, `group_id`, `description`) VALUES (166, 'ShopAdminProperties::renderForm', 21, NULL);
INSERT INTO shop_rbac_privileges (`id`, `name`, `group_id`, `description`) VALUES (167, 'ShopAdminProperties::save_positions', 21, NULL);
INSERT INTO shop_rbac_privileges (`id`, `name`, `group_id`, `description`) VALUES (168, 'ShopAdminProperties::delete', 21, NULL);
INSERT INTO shop_rbac_privileges (`id`, `name`, `group_id`, `description`) VALUES (169, 'ShopAdminProperties::changeActive', 21, NULL);
INSERT INTO shop_rbac_privileges (`id`, `name`, `group_id`, `description`) VALUES (184, 'ShopAdminSearch::index', 23, NULL);
INSERT INTO shop_rbac_privileges (`id`, `name`, `group_id`, `description`) VALUES (185, 'ShopAdminSearch::save_positions_variant', 23, NULL);
INSERT INTO shop_rbac_privileges (`id`, `name`, `group_id`, `description`) VALUES (186, 'ShopAdminSearch::autocomplete', 23, NULL);
INSERT INTO shop_rbac_privileges (`id`, `name`, `group_id`, `description`) VALUES (187, 'ShopAdminSearch::advanced', 23, NULL);
INSERT INTO shop_rbac_privileges (`id`, `name`, `group_id`, `description`) VALUES (188, 'ShopAdminSearch::renderCustomFields', 23, NULL);
INSERT INTO shop_rbac_privileges (`id`, `name`, `group_id`, `description`) VALUES (189, 'ShopAdminSettings::index', 24, NULL);
INSERT INTO shop_rbac_privileges (`id`, `name`, `group_id`, `description`) VALUES (190, 'ShopAdminSettings::update', 24, NULL);
INSERT INTO shop_rbac_privileges (`id`, `name`, `group_id`, `description`) VALUES (191, 'ShopAdminSettings::get_fsettings', 24, NULL);
INSERT INTO shop_rbac_privileges (`id`, `name`, `group_id`, `description`) VALUES (192, 'ShopAdminSettings::get_vsettings', 24, NULL);
INSERT INTO shop_rbac_privileges (`id`, `name`, `group_id`, `description`) VALUES (193, 'ShopAdminSettings::_get_templates', 24, NULL);
INSERT INTO shop_rbac_privileges (`id`, `name`, `group_id`, `description`) VALUES (194, 'ShopAdminSettings::_load_settings', 24, NULL);
INSERT INTO shop_rbac_privileges (`id`, `name`, `group_id`, `description`) VALUES (195, 'ShopAdminSettings::runResize', 24, NULL);
INSERT INTO shop_rbac_privileges (`id`, `name`, `group_id`, `description`) VALUES (196, 'ShopAdminSystem::import', 25, NULL);
INSERT INTO shop_rbac_privileges (`id`, `name`, `group_id`, `description`) VALUES (197, 'ShopAdminSystem::export', 25, NULL);
INSERT INTO shop_rbac_privileges (`id`, `name`, `group_id`, `description`) VALUES (198, 'ShopAdminSystem::getAttributes', 25, NULL);
INSERT INTO shop_rbac_privileges (`id`, `name`, `group_id`, `description`) VALUES (199, 'ShopAdminSystem::exportUsers', 25, NULL);
INSERT INTO shop_rbac_privileges (`id`, `name`, `group_id`, `description`) VALUES (200, 'ShopAdminUsers::index', 26, NULL);
INSERT INTO shop_rbac_privileges (`id`, `name`, `group_id`, `description`) VALUES (201, 'ShopAdminUsers::search', 26, NULL);
INSERT INTO shop_rbac_privileges (`id`, `name`, `group_id`, `description`) VALUES (202, 'ShopAdminUsers::create', 26, NULL);
INSERT INTO shop_rbac_privileges (`id`, `name`, `group_id`, `description`) VALUES (203, 'ShopAdminUsers::edit', 26, NULL);
INSERT INTO shop_rbac_privileges (`id`, `name`, `group_id`, `description`) VALUES (204, 'ShopAdminUsers::deleteAll', 26, NULL);
INSERT INTO shop_rbac_privileges (`id`, `name`, `group_id`, `description`) VALUES (205, 'ShopAdminUsers::auto_complite', 26, NULL);
INSERT INTO shop_rbac_privileges (`id`, `name`, `group_id`, `description`) VALUES (206, 'ShopAdminWarehouses::index', 27, NULL);
INSERT INTO shop_rbac_privileges (`id`, `name`, `group_id`, `description`) VALUES (207, 'ShopAdminWarehouses::create', 27, NULL);
INSERT INTO shop_rbac_privileges (`id`, `name`, `group_id`, `description`) VALUES (208, 'ShopAdminWarehouses::edit', 27, NULL);
INSERT INTO shop_rbac_privileges (`id`, `name`, `group_id`, `description`) VALUES (209, 'ShopAdminWarehouses::deleteAll', 27, NULL);
INSERT INTO shop_rbac_privileges (`id`, `name`, `group_id`, `description`) VALUES (210, 'Admin::__construct', 28, NULL);
INSERT INTO shop_rbac_privileges (`id`, `name`, `group_id`, `description`) VALUES (211, 'Admin::init', 28, NULL);
INSERT INTO shop_rbac_privileges (`id`, `name`, `group_id`, `description`) VALUES (212, 'Admin::index', 28, NULL);
INSERT INTO shop_rbac_privileges (`id`, `name`, `group_id`, `description`) VALUES (213, 'Admin::sys_info', 28, NULL);
INSERT INTO shop_rbac_privileges (`id`, `name`, `group_id`, `description`) VALUES (214, 'Admin::delete_cache', 28, NULL);
INSERT INTO shop_rbac_privileges (`id`, `name`, `group_id`, `description`) VALUES (215, 'Admin::elfinder_init', 28, NULL);
INSERT INTO shop_rbac_privileges (`id`, `name`, `group_id`, `description`) VALUES (216, 'Admin::get_csrf', 28, NULL);
INSERT INTO shop_rbac_privileges (`id`, `name`, `group_id`, `description`) VALUES (217, 'Admin::sidebar_cats', 28, NULL);
INSERT INTO shop_rbac_privileges (`id`, `name`, `group_id`, `description`) VALUES (218, 'Admin::logout', 28, NULL);
INSERT INTO shop_rbac_privileges (`id`, `name`, `group_id`, `description`) VALUES (219, 'Admin::report_bug', 28, NULL);
INSERT INTO shop_rbac_privileges (`id`, `name`, `group_id`, `description`) VALUES (220, 'Admin_logs::__construct', 29, NULL);
INSERT INTO shop_rbac_privileges (`id`, `name`, `group_id`, `description`) VALUES (221, 'Admin_logs::index', 29, NULL);
INSERT INTO shop_rbac_privileges (`id`, `name`, `group_id`, `description`) VALUES (222, 'Admin_search::__construct', 30, NULL);
INSERT INTO shop_rbac_privileges (`id`, `name`, `group_id`, `description`) VALUES (223, 'Admin_search::index', 30, NULL);
INSERT INTO shop_rbac_privileges (`id`, `name`, `group_id`, `description`) VALUES (224, 'Admin_search::advanced_search', 30, NULL);
INSERT INTO shop_rbac_privileges (`id`, `name`, `group_id`, `description`) VALUES (225, 'Admin_search::do_advanced_search', 30, NULL);
INSERT INTO shop_rbac_privileges (`id`, `name`, `group_id`, `description`) VALUES (226, 'Admin_search::validate_advanced_search', 30, NULL);
INSERT INTO shop_rbac_privileges (`id`, `name`, `group_id`, `description`) VALUES (227, 'Admin_search::form_from_group', 30, NULL);
INSERT INTO shop_rbac_privileges (`id`, `name`, `group_id`, `description`) VALUES (228, 'Admin_search::_filter_pages', 30, NULL);
INSERT INTO shop_rbac_privileges (`id`, `name`, `group_id`, `description`) VALUES (229, 'Admin_search::autocomplete', 30, NULL);
INSERT INTO shop_rbac_privileges (`id`, `name`, `group_id`, `description`) VALUES (230, 'Backup::__construct', 31, NULL);
INSERT INTO shop_rbac_privileges (`id`, `name`, `group_id`, `description`) VALUES (231, 'Backup::index', 31, NULL);
INSERT INTO shop_rbac_privileges (`id`, `name`, `group_id`, `description`) VALUES (232, 'Backup::create', 31, NULL);
INSERT INTO shop_rbac_privileges (`id`, `name`, `group_id`, `description`) VALUES (233, 'Backup::force_download', 31, NULL);
INSERT INTO shop_rbac_privileges (`id`, `name`, `group_id`, `description`) VALUES (234, 'Cache_all::__construct', 32, NULL);
INSERT INTO shop_rbac_privileges (`id`, `name`, `group_id`, `description`) VALUES (235, 'Cache_all::index', 32, NULL);
INSERT INTO shop_rbac_privileges (`id`, `name`, `group_id`, `description`) VALUES (236, 'Categories::__construct', 33, NULL);
INSERT INTO shop_rbac_privileges (`id`, `name`, `group_id`, `description`) VALUES (237, 'Categories::index', 33, NULL);
INSERT INTO shop_rbac_privileges (`id`, `name`, `group_id`, `description`) VALUES (238, 'Categories::create_form', 33, NULL);
INSERT INTO shop_rbac_privileges (`id`, `name`, `group_id`, `description`) VALUES (239, 'Categories::update_block', 33, NULL);
INSERT INTO shop_rbac_privileges (`id`, `name`, `group_id`, `description`) VALUES (240, 'Categories::save_positions', 33, NULL);
INSERT INTO shop_rbac_privileges (`id`, `name`, `group_id`, `description`) VALUES (241, 'Categories::cat_list', 33, NULL);
INSERT INTO shop_rbac_privileges (`id`, `name`, `group_id`, `description`) VALUES (242, 'Categories::sub_cats', 33, NULL);
INSERT INTO shop_rbac_privileges (`id`, `name`, `group_id`, `description`) VALUES (243, 'Categories::create', 33, NULL);
INSERT INTO shop_rbac_privileges (`id`, `name`, `group_id`, `description`) VALUES (244, 'Categories::update_urls', 33, NULL);
INSERT INTO shop_rbac_privileges (`id`, `name`, `group_id`, `description`) VALUES (245, 'Categories::category_exists', 33, NULL);
INSERT INTO shop_rbac_privileges (`id`, `name`, `group_id`, `description`) VALUES (246, 'Categories::fast_add', 33, NULL);
INSERT INTO shop_rbac_privileges (`id`, `name`, `group_id`, `description`) VALUES (247, 'Categories::update_fast_block', 33, NULL);
INSERT INTO shop_rbac_privileges (`id`, `name`, `group_id`, `description`) VALUES (248, 'Categories::edit', 33, NULL);
INSERT INTO shop_rbac_privileges (`id`, `name`, `group_id`, `description`) VALUES (249, 'Categories::translate', 33, NULL);
INSERT INTO shop_rbac_privileges (`id`, `name`, `group_id`, `description`) VALUES (250, 'Categories::delete', 33, NULL);
INSERT INTO shop_rbac_privileges (`id`, `name`, `group_id`, `description`) VALUES (251, 'Categories::_get_sub_cats', 33, NULL);
INSERT INTO shop_rbac_privileges (`id`, `name`, `group_id`, `description`) VALUES (252, 'Categories::get_comments_status', 33, NULL);
INSERT INTO shop_rbac_privileges (`id`, `name`, `group_id`, `description`) VALUES (253, 'Components::__construct', 34, NULL);
INSERT INTO shop_rbac_privileges (`id`, `name`, `group_id`, `description`) VALUES (254, 'Components::index', 34, NULL);
INSERT INTO shop_rbac_privileges (`id`, `name`, `group_id`, `description`) VALUES (255, 'Components::modules_table', 34, NULL);
INSERT INTO shop_rbac_privileges (`id`, `name`, `group_id`, `description`) VALUES (256, 'Components::is_installed', 34, NULL);
INSERT INTO shop_rbac_privileges (`id`, `name`, `group_id`, `description`) VALUES (257, 'Components::install', 34, NULL);
INSERT INTO shop_rbac_privileges (`id`, `name`, `group_id`, `description`) VALUES (258, 'Components::deinstall', 34, NULL);
INSERT INTO shop_rbac_privileges (`id`, `name`, `group_id`, `description`) VALUES (259, 'Components::find_components', 34, NULL);
INSERT INTO shop_rbac_privileges (`id`, `name`, `group_id`, `description`) VALUES (260, 'Components::component_settings', 34, NULL);
INSERT INTO shop_rbac_privileges (`id`, `name`, `group_id`, `description`) VALUES (261, 'Components::save_settings', 34, NULL);
INSERT INTO shop_rbac_privileges (`id`, `name`, `group_id`, `description`) VALUES (262, 'Components::init_window', 34, NULL);
INSERT INTO shop_rbac_privileges (`id`, `name`, `group_id`, `description`) VALUES (263, 'Components::cp', 34, NULL);
INSERT INTO shop_rbac_privileges (`id`, `name`, `group_id`, `description`) VALUES (264, 'Components::run', 34, NULL);
INSERT INTO shop_rbac_privileges (`id`, `name`, `group_id`, `description`) VALUES (265, 'Components::com_info', 34, NULL);
INSERT INTO shop_rbac_privileges (`id`, `name`, `group_id`, `description`) VALUES (266, 'Components::get_module_info', 34, NULL);
INSERT INTO shop_rbac_privileges (`id`, `name`, `group_id`, `description`) VALUES (267, 'Components::change_autoload', 34, NULL);
INSERT INTO shop_rbac_privileges (`id`, `name`, `group_id`, `description`) VALUES (268, 'Components::change_url_access', 34, NULL);
INSERT INTO shop_rbac_privileges (`id`, `name`, `group_id`, `description`) VALUES (269, 'Components::save_components_positions', 34, NULL);
INSERT INTO shop_rbac_privileges (`id`, `name`, `group_id`, `description`) VALUES (270, 'Components::change_show_in_menu', 34, NULL);
INSERT INTO shop_rbac_privileges (`id`, `name`, `group_id`, `description`) VALUES (271, 'Dashboard::__construct', 35, NULL);
INSERT INTO shop_rbac_privileges (`id`, `name`, `group_id`, `description`) VALUES (272, 'Dashboard::index', 35, NULL);
INSERT INTO shop_rbac_privileges (`id`, `name`, `group_id`, `description`) VALUES (273, 'Languages::__construct', 36, NULL);
INSERT INTO shop_rbac_privileges (`id`, `name`, `group_id`, `description`) VALUES (274, 'Languages::index', 36, NULL);
INSERT INTO shop_rbac_privileges (`id`, `name`, `group_id`, `description`) VALUES (275, 'Languages::create_form', 36, NULL);
INSERT INTO shop_rbac_privileges (`id`, `name`, `group_id`, `description`) VALUES (276, 'Languages::insert', 36, NULL);
INSERT INTO shop_rbac_privileges (`id`, `name`, `group_id`, `description`) VALUES (277, 'Languages::edit', 36, NULL);
INSERT INTO shop_rbac_privileges (`id`, `name`, `group_id`, `description`) VALUES (278, 'Languages::update', 36, NULL);
INSERT INTO shop_rbac_privileges (`id`, `name`, `group_id`, `description`) VALUES (279, 'Languages::delete', 36, NULL);
INSERT INTO shop_rbac_privileges (`id`, `name`, `group_id`, `description`) VALUES (280, 'Languages::set_default', 36, NULL);
INSERT INTO shop_rbac_privileges (`id`, `name`, `group_id`, `description`) VALUES (281, 'Login::__construct', 37, NULL);
INSERT INTO shop_rbac_privileges (`id`, `name`, `group_id`, `description`) VALUES (282, 'Login::index', 37, NULL);
INSERT INTO shop_rbac_privileges (`id`, `name`, `group_id`, `description`) VALUES (283, 'Login::user_browser', 37, NULL);
INSERT INTO shop_rbac_privileges (`id`, `name`, `group_id`, `description`) VALUES (284, 'Login::do_login', 37, NULL);
INSERT INTO shop_rbac_privileges (`id`, `name`, `group_id`, `description`) VALUES (285, 'Login::forgot_password', 37, NULL);
INSERT INTO shop_rbac_privileges (`id`, `name`, `group_id`, `description`) VALUES (286, 'Login::update_captcha', 37, NULL);
INSERT INTO shop_rbac_privileges (`id`, `name`, `group_id`, `description`) VALUES (287, 'Login::captcha_check', 37, NULL);
INSERT INTO shop_rbac_privileges (`id`, `name`, `group_id`, `description`) VALUES (288, 'Mod_search::__construct', 38, NULL);
INSERT INTO shop_rbac_privileges (`id`, `name`, `group_id`, `description`) VALUES (289, 'Mod_search::index', 38, NULL);
INSERT INTO shop_rbac_privileges (`id`, `name`, `group_id`, `description`) VALUES (290, 'Mod_search::category', 38, NULL);
INSERT INTO shop_rbac_privileges (`id`, `name`, `group_id`, `description`) VALUES (291, 'Mod_search::display_install_window', 38, NULL);
INSERT INTO shop_rbac_privileges (`id`, `name`, `group_id`, `description`) VALUES (292, 'Mod_search::connect_ftp', 38, NULL);
INSERT INTO shop_rbac_privileges (`id`, `name`, `group_id`, `description`) VALUES (293, 'Pages::__construct', 39, NULL);
INSERT INTO shop_rbac_privileges (`id`, `name`, `group_id`, `description`) VALUES (294, 'Pages::index', 39, NULL);
INSERT INTO shop_rbac_privileges (`id`, `name`, `group_id`, `description`) VALUES (295, 'Pages::add', 39, NULL);
INSERT INTO shop_rbac_privileges (`id`, `name`, `group_id`, `description`) VALUES (296, 'Pages::_set_page_roles', 39, NULL);
INSERT INTO shop_rbac_privileges (`id`, `name`, `group_id`, `description`) VALUES (297, 'Pages::edit', 39, NULL);
INSERT INTO shop_rbac_privileges (`id`, `name`, `group_id`, `description`) VALUES (298, 'Pages::update', 39, NULL);
INSERT INTO shop_rbac_privileges (`id`, `name`, `group_id`, `description`) VALUES (299, 'Pages::delete', 39, NULL);
INSERT INTO shop_rbac_privileges (`id`, `name`, `group_id`, `description`) VALUES (300, 'Pages::ajax_translit', 39, NULL);
INSERT INTO shop_rbac_privileges (`id`, `name`, `group_id`, `description`) VALUES (301, 'Pages::save_positions', 39, NULL);
INSERT INTO shop_rbac_privileges (`id`, `name`, `group_id`, `description`) VALUES (302, 'Pages::delete_pages', 39, NULL);
INSERT INTO shop_rbac_privileges (`id`, `name`, `group_id`, `description`) VALUES (303, 'Pages::move_pages', 39, NULL);
INSERT INTO shop_rbac_privileges (`id`, `name`, `group_id`, `description`) VALUES (304, 'Pages::show_move_window', 39, NULL);
INSERT INTO shop_rbac_privileges (`id`, `name`, `group_id`, `description`) VALUES (305, 'Pages::json_tags', 39, NULL);
INSERT INTO shop_rbac_privileges (`id`, `name`, `group_id`, `description`) VALUES (306, 'Pages::ajax_create_keywords', 39, NULL);
INSERT INTO shop_rbac_privileges (`id`, `name`, `group_id`, `description`) VALUES (307, 'Pages::ajax_create_description', 39, NULL);
INSERT INTO shop_rbac_privileges (`id`, `name`, `group_id`, `description`) VALUES (308, 'Pages::ajax_change_status', 39, NULL);
INSERT INTO shop_rbac_privileges (`id`, `name`, `group_id`, `description`) VALUES (309, 'Pages::GetPagesByCategory', 39, NULL);
INSERT INTO shop_rbac_privileges (`id`, `name`, `group_id`, `description`) VALUES (310, 'Rbac::__construct', 40, NULL);
INSERT INTO shop_rbac_privileges (`id`, `name`, `group_id`, `description`) VALUES (311, 'Settings::__construct', 41, NULL);
INSERT INTO shop_rbac_privileges (`id`, `name`, `group_id`, `description`) VALUES (312, 'Settings::index', 41, NULL);
INSERT INTO shop_rbac_privileges (`id`, `name`, `group_id`, `description`) VALUES (313, 'Settings::main_page', 41, NULL);
INSERT INTO shop_rbac_privileges (`id`, `name`, `group_id`, `description`) VALUES (314, 'Settings::_get_templates', 41, NULL);
INSERT INTO shop_rbac_privileges (`id`, `name`, `group_id`, `description`) VALUES (315, 'Settings::save', 41, NULL);
INSERT INTO shop_rbac_privileges (`id`, `name`, `group_id`, `description`) VALUES (316, 'Settings::switch_admin_lang', 41, NULL);
INSERT INTO shop_rbac_privileges (`id`, `name`, `group_id`, `description`) VALUES (317, 'Settings::save_main', 41, NULL);
INSERT INTO shop_rbac_privileges (`id`, `name`, `group_id`, `description`) VALUES (318, 'Sys_upgrade::__construct', 42, NULL);
INSERT INTO shop_rbac_privileges (`id`, `name`, `group_id`, `description`) VALUES (319, 'Sys_upgrade::index', 42, NULL);
INSERT INTO shop_rbac_privileges (`id`, `name`, `group_id`, `description`) VALUES (320, 'Sys_upgrade::make_upgrade', 42, NULL);
INSERT INTO shop_rbac_privileges (`id`, `name`, `group_id`, `description`) VALUES (321, 'Sys_upgrade::_check_status', 42, NULL);
INSERT INTO shop_rbac_privileges (`id`, `name`, `group_id`, `description`) VALUES (322, 'cfcm::__construct', 43, NULL);
INSERT INTO shop_rbac_privileges (`id`, `name`, `group_id`, `description`) VALUES (323, 'cfcm::_set_forms_config', 43, NULL);
INSERT INTO shop_rbac_privileges (`id`, `name`, `group_id`, `description`) VALUES (324, 'cfcm::index', 43, NULL);
INSERT INTO shop_rbac_privileges (`id`, `name`, `group_id`, `description`) VALUES (325, 'cfcm::create_field', 43, NULL);
INSERT INTO shop_rbac_privileges (`id`, `name`, `group_id`, `description`) VALUES (326, 'cfcm::edit_field_data_type', 43, NULL);
INSERT INTO shop_rbac_privileges (`id`, `name`, `group_id`, `description`) VALUES (327, 'cfcm::delete_field', 43, NULL);
INSERT INTO shop_rbac_privileges (`id`, `name`, `group_id`, `description`) VALUES (328, 'cfcm::edit_field', 43, NULL);
INSERT INTO shop_rbac_privileges (`id`, `name`, `group_id`, `description`) VALUES (329, 'cfcm::create_group', 43, NULL);
INSERT INTO shop_rbac_privileges (`id`, `name`, `group_id`, `description`) VALUES (330, 'cfcm::edit_group', 43, NULL);
INSERT INTO shop_rbac_privileges (`id`, `name`, `group_id`, `description`) VALUES (331, 'cfcm::delete_group', 43, NULL);
INSERT INTO shop_rbac_privileges (`id`, `name`, `group_id`, `description`) VALUES (332, 'cfcm::form_from_category_group', 43, NULL);
INSERT INTO shop_rbac_privileges (`id`, `name`, `group_id`, `description`) VALUES (333, 'cfcm::get_form_attributes', 43, NULL);
INSERT INTO shop_rbac_privileges (`id`, `name`, `group_id`, `description`) VALUES (334, 'cfcm::save_weight', 43, NULL);
INSERT INTO shop_rbac_privileges (`id`, `name`, `group_id`, `description`) VALUES (335, 'cfcm::render', 43, NULL);
INSERT INTO shop_rbac_privileges (`id`, `name`, `group_id`, `description`) VALUES (336, 'cfcm::get_url', 43, NULL);
INSERT INTO shop_rbac_privileges (`id`, `name`, `group_id`, `description`) VALUES (337, 'cfcm::get_form', 43, NULL);
INSERT INTO shop_rbac_privileges (`id`, `name`, `group_id`, `description`) VALUES (338, 'comments::__construct', 44, NULL);
INSERT INTO shop_rbac_privileges (`id`, `name`, `group_id`, `description`) VALUES (339, 'comments::index', 44, NULL);
INSERT INTO shop_rbac_privileges (`id`, `name`, `group_id`, `description`) VALUES (340, 'comments::proccess_child_comments', 44, NULL);
INSERT INTO shop_rbac_privileges (`id`, `name`, `group_id`, `description`) VALUES (341, 'comments::render', 44, NULL);
INSERT INTO shop_rbac_privileges (`id`, `name`, `group_id`, `description`) VALUES (342, 'comments::edit', 44, NULL);
INSERT INTO shop_rbac_privileges (`id`, `name`, `group_id`, `description`) VALUES (343, 'comments::update', 44, NULL);
INSERT INTO shop_rbac_privileges (`id`, `name`, `group_id`, `description`) VALUES (344, 'comments::update_status', 44, NULL);
INSERT INTO shop_rbac_privileges (`id`, `name`, `group_id`, `description`) VALUES (345, 'comments::delete', 44, NULL);
INSERT INTO shop_rbac_privileges (`id`, `name`, `group_id`, `description`) VALUES (346, 'comments::delete_many', 44, NULL);
INSERT INTO shop_rbac_privileges (`id`, `name`, `group_id`, `description`) VALUES (347, 'comments::show_settings', 44, NULL);
INSERT INTO shop_rbac_privileges (`id`, `name`, `group_id`, `description`) VALUES (348, 'comments::update_settings', 44, NULL);
INSERT INTO shop_rbac_privileges (`id`, `name`, `group_id`, `description`) VALUES (349, 'feedback::__construct', 45, NULL);
INSERT INTO shop_rbac_privileges (`id`, `name`, `group_id`, `description`) VALUES (350, 'feedback::index', 45, NULL);
INSERT INTO shop_rbac_privileges (`id`, `name`, `group_id`, `description`) VALUES (351, 'feedback::settings', 45, NULL);
INSERT INTO shop_rbac_privileges (`id`, `name`, `group_id`, `description`) VALUES (352, 'gallery::__construct', 46, NULL);
INSERT INTO shop_rbac_privileges (`id`, `name`, `group_id`, `description`) VALUES (353, 'gallery::index', 46, NULL);
INSERT INTO shop_rbac_privileges (`id`, `name`, `group_id`, `description`) VALUES (354, 'gallery::category', 46, NULL);
INSERT INTO shop_rbac_privileges (`id`, `name`, `group_id`, `description`) VALUES (355, 'gallery::settings', 46, NULL);
INSERT INTO shop_rbac_privileges (`id`, `name`, `group_id`, `description`) VALUES (356, 'gallery::create_album', 46, NULL);
INSERT INTO shop_rbac_privileges (`id`, `name`, `group_id`, `description`) VALUES (357, 'gallery::update_album', 46, NULL);
INSERT INTO shop_rbac_privileges (`id`, `name`, `group_id`, `description`) VALUES (358, 'gallery::edit_album_params', 46, NULL);
INSERT INTO shop_rbac_privileges (`id`, `name`, `group_id`, `description`) VALUES (359, 'gallery::delete_album', 46, NULL);
INSERT INTO shop_rbac_privileges (`id`, `name`, `group_id`, `description`) VALUES (360, 'gallery::show_crate_album', 46, NULL);
INSERT INTO shop_rbac_privileges (`id`, `name`, `group_id`, `description`) VALUES (361, 'gallery::edit_album', 46, NULL);
INSERT INTO shop_rbac_privileges (`id`, `name`, `group_id`, `description`) VALUES (362, 'gallery::edit_image', 46, NULL);
INSERT INTO shop_rbac_privileges (`id`, `name`, `group_id`, `description`) VALUES (363, 'gallery::rename_image', 46, NULL);
INSERT INTO shop_rbac_privileges (`id`, `name`, `group_id`, `description`) VALUES (364, 'gallery::delete_image', 46, NULL);
INSERT INTO shop_rbac_privileges (`id`, `name`, `group_id`, `description`) VALUES (365, 'gallery::update_info', 46, NULL);
INSERT INTO shop_rbac_privileges (`id`, `name`, `group_id`, `description`) VALUES (366, 'gallery::update_positions', 46, NULL);
INSERT INTO shop_rbac_privileges (`id`, `name`, `group_id`, `description`) VALUES (367, 'gallery::update_album_positions', 46, NULL);
INSERT INTO shop_rbac_privileges (`id`, `name`, `group_id`, `description`) VALUES (368, 'gallery::update_img_positions', 46, NULL);
INSERT INTO shop_rbac_privileges (`id`, `name`, `group_id`, `description`) VALUES (369, 'gallery::show_create_category', 46, NULL);
INSERT INTO shop_rbac_privileges (`id`, `name`, `group_id`, `description`) VALUES (370, 'gallery::create_category', 46, NULL);
INSERT INTO shop_rbac_privileges (`id`, `name`, `group_id`, `description`) VALUES (371, 'gallery::edit_category', 46, NULL);
INSERT INTO shop_rbac_privileges (`id`, `name`, `group_id`, `description`) VALUES (372, 'gallery::update_category', 46, NULL);
INSERT INTO shop_rbac_privileges (`id`, `name`, `group_id`, `description`) VALUES (373, 'gallery::delete_category', 46, NULL);
INSERT INTO shop_rbac_privileges (`id`, `name`, `group_id`, `description`) VALUES (374, 'gallery::upload_image', 46, NULL);
INSERT INTO shop_rbac_privileges (`id`, `name`, `group_id`, `description`) VALUES (375, 'gallery::upload_archive', 46, NULL);
INSERT INTO shop_rbac_privileges (`id`, `name`, `group_id`, `description`) VALUES (376, 'group_mailer::__construct', 47, NULL);
INSERT INTO shop_rbac_privileges (`id`, `name`, `group_id`, `description`) VALUES (377, 'group_mailer::index', 47, NULL);
INSERT INTO shop_rbac_privileges (`id`, `name`, `group_id`, `description`) VALUES (378, 'group_mailer::send_email', 47, NULL);
INSERT INTO shop_rbac_privileges (`id`, `name`, `group_id`, `description`) VALUES (379, 'mailer::__construct', 48, NULL);
INSERT INTO shop_rbac_privileges (`id`, `name`, `group_id`, `description`) VALUES (380, 'mailer::index', 48, NULL);
INSERT INTO shop_rbac_privileges (`id`, `name`, `group_id`, `description`) VALUES (381, 'mailer::send_email', 48, NULL);
INSERT INTO shop_rbac_privileges (`id`, `name`, `group_id`, `description`) VALUES (382, 'mailer::delete', 48, NULL);
INSERT INTO shop_rbac_privileges (`id`, `name`, `group_id`, `description`) VALUES (383, 'menu::__construct', 49, NULL);
INSERT INTO shop_rbac_privileges (`id`, `name`, `group_id`, `description`) VALUES (384, 'menu::index', 49, NULL);
INSERT INTO shop_rbac_privileges (`id`, `name`, `group_id`, `description`) VALUES (385, 'menu::menu_item', 49, NULL);
INSERT INTO shop_rbac_privileges (`id`, `name`, `group_id`, `description`) VALUES (386, 'menu::list_menu_items', 49, NULL);
INSERT INTO shop_rbac_privileges (`id`, `name`, `group_id`, `description`) VALUES (387, 'menu::create_item', 49, NULL);
INSERT INTO shop_rbac_privileges (`id`, `name`, `group_id`, `description`) VALUES (388, 'menu::display_selector', 49, NULL);
INSERT INTO shop_rbac_privileges (`id`, `name`, `group_id`, `description`) VALUES (389, 'menu::get_name_by_id', 49, NULL);
INSERT INTO shop_rbac_privileges (`id`, `name`, `group_id`, `description`) VALUES (390, 'menu::delete_item', 49, NULL);
INSERT INTO shop_rbac_privileges (`id`, `name`, `group_id`, `description`) VALUES (391, 'menu::edit_item', 49, NULL);
INSERT INTO shop_rbac_privileges (`id`, `name`, `group_id`, `description`) VALUES (392, 'menu::process_root', 49, NULL);
INSERT INTO shop_rbac_privileges (`id`, `name`, `group_id`, `description`) VALUES (393, 'menu::insert_menu_item', 49, NULL);
INSERT INTO shop_rbac_privileges (`id`, `name`, `group_id`, `description`) VALUES (394, 'menu::save_positions', 49, NULL);
INSERT INTO shop_rbac_privileges (`id`, `name`, `group_id`, `description`) VALUES (395, 'menu::create_menu', 49, NULL);
INSERT INTO shop_rbac_privileges (`id`, `name`, `group_id`, `description`) VALUES (396, 'menu::edit_menu', 49, NULL);
INSERT INTO shop_rbac_privileges (`id`, `name`, `group_id`, `description`) VALUES (397, 'menu::update_menu', 49, NULL);
INSERT INTO shop_rbac_privileges (`id`, `name`, `group_id`, `description`) VALUES (398, 'menu::check_menu_data', 49, NULL);
INSERT INTO shop_rbac_privileges (`id`, `name`, `group_id`, `description`) VALUES (399, 'menu::delete_menu', 49, NULL);
INSERT INTO shop_rbac_privileges (`id`, `name`, `group_id`, `description`) VALUES (400, 'menu::create_tpl', 49, NULL);
INSERT INTO shop_rbac_privileges (`id`, `name`, `group_id`, `description`) VALUES (401, 'menu::get_pages', 49, NULL);
INSERT INTO shop_rbac_privileges (`id`, `name`, `group_id`, `description`) VALUES (402, 'menu::search_pages', 49, NULL);
INSERT INTO shop_rbac_privileges (`id`, `name`, `group_id`, `description`) VALUES (403, 'menu::get_item', 49, NULL);
INSERT INTO shop_rbac_privileges (`id`, `name`, `group_id`, `description`) VALUES (404, 'menu::display_tpl', 49, NULL);
INSERT INTO shop_rbac_privileges (`id`, `name`, `group_id`, `description`) VALUES (405, 'menu::fetch_tpl', 49, NULL);
INSERT INTO shop_rbac_privileges (`id`, `name`, `group_id`, `description`) VALUES (406, 'menu::translate_window', 49, NULL);
INSERT INTO shop_rbac_privileges (`id`, `name`, `group_id`, `description`) VALUES (407, 'menu::translate_item', 49, NULL);
INSERT INTO shop_rbac_privileges (`id`, `name`, `group_id`, `description`) VALUES (408, 'menu::_get_langs', 49, NULL);
INSERT INTO shop_rbac_privileges (`id`, `name`, `group_id`, `description`) VALUES (409, 'menu::render', 49, NULL);
INSERT INTO shop_rbac_privileges (`id`, `name`, `group_id`, `description`) VALUES (410, 'menu::change_hidden', 49, NULL);
INSERT INTO shop_rbac_privileges (`id`, `name`, `group_id`, `description`) VALUES (411, 'menu::get_children_items', 49, NULL);
INSERT INTO shop_rbac_privileges (`id`, `name`, `group_id`, `description`) VALUES (412, 'rss::__construct', 50, NULL);
INSERT INTO shop_rbac_privileges (`id`, `name`, `group_id`, `description`) VALUES (413, 'rss::index', 50, NULL);
INSERT INTO shop_rbac_privileges (`id`, `name`, `group_id`, `description`) VALUES (414, 'rss::render', 50, NULL);
INSERT INTO shop_rbac_privileges (`id`, `name`, `group_id`, `description`) VALUES (415, 'rss::settings_update', 50, NULL);
INSERT INTO shop_rbac_privileges (`id`, `name`, `group_id`, `description`) VALUES (416, 'rss::display_tpl', 50, NULL);
INSERT INTO shop_rbac_privileges (`id`, `name`, `group_id`, `description`) VALUES (417, 'rss::fetch_tpl', 50, NULL);
INSERT INTO shop_rbac_privileges (`id`, `name`, `group_id`, `description`) VALUES (418, 'sample_mail::__construct', 51, NULL);
INSERT INTO shop_rbac_privileges (`id`, `name`, `group_id`, `description`) VALUES (419, 'sample_mail::create', 51, NULL);
INSERT INTO shop_rbac_privileges (`id`, `name`, `group_id`, `description`) VALUES (420, 'sample_mail::edit', 51, NULL);
INSERT INTO shop_rbac_privileges (`id`, `name`, `group_id`, `description`) VALUES (421, 'sample_mail::render', 51, NULL);
INSERT INTO shop_rbac_privileges (`id`, `name`, `group_id`, `description`) VALUES (422, 'sample_mail::index', 51, NULL);
INSERT INTO shop_rbac_privileges (`id`, `name`, `group_id`, `description`) VALUES (423, 'sample_mail::delete', 51, NULL);
INSERT INTO shop_rbac_privileges (`id`, `name`, `group_id`, `description`) VALUES (424, 'sample_module::__construct', 52, NULL);
INSERT INTO shop_rbac_privileges (`id`, `name`, `group_id`, `description`) VALUES (425, 'sample_module::index', 52, NULL);
INSERT INTO shop_rbac_privileges (`id`, `name`, `group_id`, `description`) VALUES (426, 'share::__construct', 53, NULL);
INSERT INTO shop_rbac_privileges (`id`, `name`, `group_id`, `description`) VALUES (427, 'share::index', 53, NULL);
INSERT INTO shop_rbac_privileges (`id`, `name`, `group_id`, `description`) VALUES (428, 'share::update_settings', 53, NULL);
INSERT INTO shop_rbac_privileges (`id`, `name`, `group_id`, `description`) VALUES (429, 'share::get_settings', 53, NULL);
INSERT INTO shop_rbac_privileges (`id`, `name`, `group_id`, `description`) VALUES (430, 'share::render', 53, NULL);
INSERT INTO shop_rbac_privileges (`id`, `name`, `group_id`, `description`) VALUES (431, 'sitemap::__construct', 54, NULL);
INSERT INTO shop_rbac_privileges (`id`, `name`, `group_id`, `description`) VALUES (432, 'sitemap::index', 54, NULL);
INSERT INTO shop_rbac_privileges (`id`, `name`, `group_id`, `description`) VALUES (433, 'sitemap::_load_settings', 54, NULL);
INSERT INTO shop_rbac_privileges (`id`, `name`, `group_id`, `description`) VALUES (434, 'sitemap::update_settings', 54, NULL);
INSERT INTO shop_rbac_privileges (`id`, `name`, `group_id`, `description`) VALUES (435, 'sitemap::display_tpl', 54, NULL);
INSERT INTO shop_rbac_privileges (`id`, `name`, `group_id`, `description`) VALUES (436, 'sitemap::fetch_tpl', 54, NULL);
INSERT INTO shop_rbac_privileges (`id`, `name`, `group_id`, `description`) VALUES (437, 'sitemap::render', 54, NULL);
INSERT INTO shop_rbac_privileges (`id`, `name`, `group_id`, `description`) VALUES (438, 'social_servises::__construct', 55, NULL);
INSERT INTO shop_rbac_privileges (`id`, `name`, `group_id`, `description`) VALUES (439, 'social_servises::index', 55, NULL);
INSERT INTO shop_rbac_privileges (`id`, `name`, `group_id`, `description`) VALUES (440, 'social_servises::update_settings', 55, NULL);
INSERT INTO shop_rbac_privileges (`id`, `name`, `group_id`, `description`) VALUES (441, 'social_servises::get_fsettings', 55, NULL);
INSERT INTO shop_rbac_privileges (`id`, `name`, `group_id`, `description`) VALUES (442, 'social_servises::get_vsettings', 55, NULL);
INSERT INTO shop_rbac_privileges (`id`, `name`, `group_id`, `description`) VALUES (443, 'social_servises::_get_templates', 55, NULL);
INSERT INTO shop_rbac_privileges (`id`, `name`, `group_id`, `description`) VALUES (444, 'social_servises::render', 55, NULL);
INSERT INTO shop_rbac_privileges (`id`, `name`, `group_id`, `description`) VALUES (445, 'template_editor::index', 56, NULL);
INSERT INTO shop_rbac_privileges (`id`, `name`, `group_id`, `description`) VALUES (446, 'template_editor::render', 56, NULL);
INSERT INTO shop_rbac_privileges (`id`, `name`, `group_id`, `description`) VALUES (447, 'trash::__construct', 57, NULL);
INSERT INTO shop_rbac_privileges (`id`, `name`, `group_id`, `description`) VALUES (448, 'trash::index', 57, NULL);
INSERT INTO shop_rbac_privileges (`id`, `name`, `group_id`, `description`) VALUES (449, 'trash::create_trash', 57, NULL);
INSERT INTO shop_rbac_privileges (`id`, `name`, `group_id`, `description`) VALUES (450, 'trash::edit_trash', 57, NULL);
INSERT INTO shop_rbac_privileges (`id`, `name`, `group_id`, `description`) VALUES (451, 'trash::delete_trash', 57, NULL);
INSERT INTO shop_rbac_privileges (`id`, `name`, `group_id`, `description`) VALUES (452, 'user_manager::__construct', 58, NULL);
INSERT INTO shop_rbac_privileges (`id`, `name`, `group_id`, `description`) VALUES (453, 'user_manager::index', 58, NULL);
INSERT INTO shop_rbac_privileges (`id`, `name`, `group_id`, `description`) VALUES (454, 'user_manager::set_tpl_roles', 58, NULL);
INSERT INTO shop_rbac_privileges (`id`, `name`, `group_id`, `description`) VALUES (455, 'user_manager::getRolesTable', 58, NULL);
INSERT INTO shop_rbac_privileges (`id`, `name`, `group_id`, `description`) VALUES (456, 'user_manager::genre_user_table', 58, NULL);
INSERT INTO shop_rbac_privileges (`id`, `name`, `group_id`, `description`) VALUES (457, 'user_manager::auto_complit', 58, NULL);
INSERT INTO shop_rbac_privileges (`id`, `name`, `group_id`, `description`) VALUES (458, 'user_manager::create_user', 58, NULL);
INSERT INTO shop_rbac_privileges (`id`, `name`, `group_id`, `description`) VALUES (459, 'user_manager::actions', 58, NULL);
INSERT INTO shop_rbac_privileges (`id`, `name`, `group_id`, `description`) VALUES (460, 'user_manager::search', 58, NULL);
INSERT INTO shop_rbac_privileges (`id`, `name`, `group_id`, `description`) VALUES (461, 'user_manager::edit_user', 58, NULL);
INSERT INTO shop_rbac_privileges (`id`, `name`, `group_id`, `description`) VALUES (462, 'user_manager::update_user', 58, NULL);
INSERT INTO shop_rbac_privileges (`id`, `name`, `group_id`, `description`) VALUES (463, 'user_manager::groups_index', 58, NULL);
INSERT INTO shop_rbac_privileges (`id`, `name`, `group_id`, `description`) VALUES (464, 'user_manager::create', 58, NULL);
INSERT INTO shop_rbac_privileges (`id`, `name`, `group_id`, `description`) VALUES (465, 'user_manager::edit', 58, NULL);
INSERT INTO shop_rbac_privileges (`id`, `name`, `group_id`, `description`) VALUES (466, 'user_manager::save', 58, NULL);
INSERT INTO shop_rbac_privileges (`id`, `name`, `group_id`, `description`) VALUES (467, 'user_manager::delete', 58, NULL);
INSERT INTO shop_rbac_privileges (`id`, `name`, `group_id`, `description`) VALUES (468, 'user_manager::deleteAll', 58, NULL);
INSERT INTO shop_rbac_privileges (`id`, `name`, `group_id`, `description`) VALUES (469, 'user_manager::update_role_perms', 58, NULL);
INSERT INTO shop_rbac_privileges (`id`, `name`, `group_id`, `description`) VALUES (470, 'user_manager::show_edit_prems_tpl', 58, NULL);
INSERT INTO shop_rbac_privileges (`id`, `name`, `group_id`, `description`) VALUES (471, 'user_manager::get_permissions_table', 58, NULL);
INSERT INTO shop_rbac_privileges (`id`, `name`, `group_id`, `description`) VALUES (472, 'user_manager::get_group_names', 58, NULL);
INSERT INTO shop_rbac_privileges (`id`, `name`, `group_id`, `description`) VALUES (473, 'Widgets_manager::__construct', 59, NULL);
INSERT INTO shop_rbac_privileges (`id`, `name`, `group_id`, `description`) VALUES (474, 'Widgets_manager::index', 59, NULL);
INSERT INTO shop_rbac_privileges (`id`, `name`, `group_id`, `description`) VALUES (475, 'Widgets_manager::create', 59, NULL);
INSERT INTO shop_rbac_privileges (`id`, `name`, `group_id`, `description`) VALUES (476, 'Widgets_manager::create_tpl', 59, NULL);
INSERT INTO shop_rbac_privileges (`id`, `name`, `group_id`, `description`) VALUES (477, 'Widgets_manager::edit', 59, NULL);
INSERT INTO shop_rbac_privileges (`id`, `name`, `group_id`, `description`) VALUES (478, 'Widgets_manager::update_widget', 59, NULL);
INSERT INTO shop_rbac_privileges (`id`, `name`, `group_id`, `description`) VALUES (479, 'Widgets_manager::update_config', 59, NULL);
INSERT INTO shop_rbac_privileges (`id`, `name`, `group_id`, `description`) VALUES (480, 'Widgets_manager::delete', 59, NULL);
INSERT INTO shop_rbac_privileges (`id`, `name`, `group_id`, `description`) VALUES (481, 'Widgets_manager::get', 59, NULL);
INSERT INTO shop_rbac_privileges (`id`, `name`, `group_id`, `description`) VALUES (482, 'Widgets_manager::edit_html_widget', 59, NULL);
INSERT INTO shop_rbac_privileges (`id`, `name`, `group_id`, `description`) VALUES (483, 'Widgets_manager::edit_module_widget', 59, NULL);
INSERT INTO shop_rbac_privileges (`id`, `name`, `group_id`, `description`) VALUES (484, 'Widgets_manager::display_create_tpl', 59, NULL);


#
# TABLE STRUCTURE FOR: shop_rbac_privileges_i18n
#

DROP TABLE IF EXISTS shop_rbac_privileges_i18n;

CREATE TABLE `shop_rbac_privileges_i18n` (
  `id` int(11) NOT NULL,
  `title` varchar(45) NOT NULL,
  `description` varchar(200) DEFAULT NULL,
  `locale` varchar(45) NOT NULL,
  KEY `id_idx` (`id`)
) ENGINE=MyISAM DEFAULT CHARSET=utf8;

INSERT INTO shop_rbac_privileges_i18n (`id`, `title`, `description`, `locale`) VALUES (473, 'Управление виджетами', 'Доступ к управлению виджетами', 'ru');
INSERT INTO shop_rbac_privileges_i18n (`id`, `title`, `description`, `locale`) VALUES (1, 'Список баннеров', 'Доступ к списку баннеров', 'ru');
INSERT INTO shop_rbac_privileges_i18n (`id`, `title`, `description`, `locale`) VALUES (2, 'Создание баннера', 'Доступ к созданию баннера', 'ru');
INSERT INTO shop_rbac_privileges_i18n (`id`, `title`, `description`, `locale`) VALUES (3, 'Редактирование баннера', 'Доступ к редактированию баннера', 'ru');
INSERT INTO shop_rbac_privileges_i18n (`id`, `title`, `description`, `locale`) VALUES (4, 'Удаление баннера', 'Доступ к удалению баннера', 'ru');
INSERT INTO shop_rbac_privileges_i18n (`id`, `title`, `description`, `locale`) VALUES (5, 'Перевод баннера', 'Доступ к переводу баннера', 'ru');
INSERT INTO shop_rbac_privileges_i18n (`id`, `title`, `description`, `locale`) VALUES (6, 'Активность баннера', 'Управление активностью баннера', 'ru');
INSERT INTO shop_rbac_privileges_i18n (`id`, `title`, `description`, `locale`) VALUES (7, 'Список брендов', 'Доступ к списку брендов', 'ru');
INSERT INTO shop_rbac_privileges_i18n (`id`, `title`, `description`, `locale`) VALUES (8, 'Создание бренда', 'Доступ к созданию бренда', 'ru');
INSERT INTO shop_rbac_privileges_i18n (`id`, `title`, `description`, `locale`) VALUES (9, 'Редактирование бренда', 'Доступ к редактированию бренда', 'ru');
INSERT INTO shop_rbac_privileges_i18n (`id`, `title`, `description`, `locale`) VALUES (10, 'Удаление бренда', 'Доступ к удалению бренда', 'ru');
INSERT INTO shop_rbac_privileges_i18n (`id`, `title`, `description`, `locale`) VALUES (11, 'Список брендов', 'Доступ к списку брендов', 'ru');
INSERT INTO shop_rbac_privileges_i18n (`id`, `title`, `description`, `locale`) VALUES (12, 'Перевод бренда', 'Доступ к переводу бренда', 'ru');
INSERT INTO shop_rbac_privileges_i18n (`id`, `title`, `description`, `locale`) VALUES (13, 'Список колбеков', 'Доступ к просмотру колбеков', 'ru');
INSERT INTO shop_rbac_privileges_i18n (`id`, `title`, `description`, `locale`) VALUES (14, 'Редактирование колбека', 'Доступ к редактированию колбеков', 'ru');
INSERT INTO shop_rbac_privileges_i18n (`id`, `title`, `description`, `locale`) VALUES (15, 'Статусы колбеков', 'Просмотр статусов колбеков', 'ru');
INSERT INTO shop_rbac_privileges_i18n (`id`, `title`, `description`, `locale`) VALUES (16, 'Создание статуса колбеков', 'Доступ к созданию статусов колбеков', 'ru');
INSERT INTO shop_rbac_privileges_i18n (`id`, `title`, `description`, `locale`) VALUES (17, 'Редактирование статуса колбека', 'Доступ к редактированию статуса колбека', 'ru');
INSERT INTO shop_rbac_privileges_i18n (`id`, `title`, `description`, `locale`) VALUES (18, 'Установка статуса колбека по-умолчанию', 'Доступ к установке статуса колбека по-умолчанию', 'ru');
INSERT INTO shop_rbac_privileges_i18n (`id`, `title`, `description`, `locale`) VALUES (19, 'Изменение статуса колбека', 'Доступ к изменению статуса колбека', 'ru');
INSERT INTO shop_rbac_privileges_i18n (`id`, `title`, `description`, `locale`) VALUES (20, 'Смена порядка статусов колбеков', 'Доступ к изменению порядка статусов колбеков', 'ru');
INSERT INTO shop_rbac_privileges_i18n (`id`, `title`, `description`, `locale`) VALUES (21, 'Изменение темы колбека', 'Доступ к изменению статуса колбека', 'ru');
INSERT INTO shop_rbac_privileges_i18n (`id`, `title`, `description`, `locale`) VALUES (22, 'Удаление колбека', 'Доступ к удалению колбека', 'ru');
INSERT INTO shop_rbac_privileges_i18n (`id`, `title`, `description`, `locale`) VALUES (23, 'Удаление статуса', 'Доступ к удалению статуса колбека', 'ru');
INSERT INTO shop_rbac_privileges_i18n (`id`, `title`, `description`, `locale`) VALUES (24, 'Просмотр тем колбеков', 'Доступ к просмотру тем колбеков', 'ru');
INSERT INTO shop_rbac_privileges_i18n (`id`, `title`, `description`, `locale`) VALUES (25, 'Создание тем колбеков', 'Доступ к созданию тем колбеков', 'ru');
INSERT INTO shop_rbac_privileges_i18n (`id`, `title`, `description`, `locale`) VALUES (26, 'Редактирование темы колбека', 'Доступ к редактированию темы колбека', 'ru');
INSERT INTO shop_rbac_privileges_i18n (`id`, `title`, `description`, `locale`) VALUES (27, 'Удаление темы колбека', 'Доступ к удалению темы колбека', 'ru');
INSERT INTO shop_rbac_privileges_i18n (`id`, `title`, `description`, `locale`) VALUES (28, 'Поиск колбеков', 'Доступ к поиску колбеков', 'ru');
INSERT INTO shop_rbac_privileges_i18n (`id`, `title`, `description`, `locale`) VALUES (29, 'Просмотр категорий магазина', 'Доступ к просмотру категорий магазина', 'ru');
INSERT INTO shop_rbac_privileges_i18n (`id`, `title`, `description`, `locale`) VALUES (30, 'Создание категории магазина', 'Доступ к созданию категории магазина', 'ru');
INSERT INTO shop_rbac_privileges_i18n (`id`, `title`, `description`, `locale`) VALUES (31, 'Редактирование категории магазина', 'Доступ к редактированию категории магазина', 'ru');
INSERT INTO shop_rbac_privileges_i18n (`id`, `title`, `description`, `locale`) VALUES (32, 'Удаление категории магазина', 'Доступ к удалению категории магазина', 'ru');
INSERT INTO shop_rbac_privileges_i18n (`id`, `title`, `description`, `locale`) VALUES (33, 'Просмотр списка категорий магазина', 'Доступ к просмотру списка категорий магазина', 'ru');
INSERT INTO shop_rbac_privileges_i18n (`id`, `title`, `description`, `locale`) VALUES (34, 'Изменение порядка категорий магазина', 'Доступ к изменению порядка категорий магазина', 'ru');
INSERT INTO shop_rbac_privileges_i18n (`id`, `title`, `description`, `locale`) VALUES (35, 'Транслитерация строки', 'Доступ к транслитерации строки', 'ru');
INSERT INTO shop_rbac_privileges_i18n (`id`, `title`, `description`, `locale`) VALUES (36, 'Перевод категории магазина', 'Доступ к переводу категории магазина', 'ru');
INSERT INTO shop_rbac_privileges_i18n (`id`, `title`, `description`, `locale`) VALUES (37, 'Смена активности категории магазина', 'Доступ к изменению активности категории магазина', 'ru');
INSERT INTO shop_rbac_privileges_i18n (`id`, `title`, `description`, `locale`) VALUES (38, 'Создание шаблона категории', 'Доступ к созданию шаблона категории магазина', 'ru');
INSERT INTO shop_rbac_privileges_i18n (`id`, `title`, `description`, `locale`) VALUES (39, 'Список доступных шаблонов для категорий магаз', 'Доступ к списку доступных шаблонов для категорий магазина', 'ru');
INSERT INTO shop_rbac_privileges_i18n (`id`, `title`, `description`, `locale`) VALUES (40, 'Просмотр статистики заказов', 'Доступ к просмотру статистики заказов', 'ru');
INSERT INTO shop_rbac_privileges_i18n (`id`, `title`, `description`, `locale`) VALUES (41, 'Фильтр заказов по дате', 'Доступ к фильтру заказов по дате', 'ru');
INSERT INTO shop_rbac_privileges_i18n (`id`, `title`, `description`, `locale`) VALUES (42, 'ShopAdminCharts::_createDatesDropDown', '', 'ru');
INSERT INTO shop_rbac_privileges_i18n (`id`, `title`, `description`, `locale`) VALUES (43, 'Просмотр списка накопительных скидок', 'Доступ к просмотру списка накопительных скидок', 'ru');
INSERT INTO shop_rbac_privileges_i18n (`id`, `title`, `description`, `locale`) VALUES (44, 'Создание накопительной скидки', 'Доступ к созданию накопительной скидки', 'ru');
INSERT INTO shop_rbac_privileges_i18n (`id`, `title`, `description`, `locale`) VALUES (45, 'Редактирование накопительной скидки', 'Доступ к редактированию накопительной скидки', 'ru');
INSERT INTO shop_rbac_privileges_i18n (`id`, `title`, `description`, `locale`) VALUES (46, 'Просмотр списка пользовательских скидок', 'Доступ к просмотру списка пользовательских скидок', 'ru');
INSERT INTO shop_rbac_privileges_i18n (`id`, `title`, `description`, `locale`) VALUES (47, 'Просмотр скидки пользователя', 'Доступ к просмотру скидки пользователя', 'ru');
INSERT INTO shop_rbac_privileges_i18n (`id`, `title`, `description`, `locale`) VALUES (48, 'Удаление всех скидок', 'Доступ к удалению всех скидок', 'ru');
INSERT INTO shop_rbac_privileges_i18n (`id`, `title`, `description`, `locale`) VALUES (49, 'Смена статуса скидки', 'Доступ к смене статуса скидки', 'ru');
INSERT INTO shop_rbac_privileges_i18n (`id`, `title`, `description`, `locale`) VALUES (50, 'Просмотр списка валют', 'Доступ к просмотру списка валют', 'ru');
INSERT INTO shop_rbac_privileges_i18n (`id`, `title`, `description`, `locale`) VALUES (51, 'Создание валюты', 'Доступ к созданию валюты', 'ru');
INSERT INTO shop_rbac_privileges_i18n (`id`, `title`, `description`, `locale`) VALUES (52, 'Редактирование валюты', 'Доступ к редактированию валюты', 'ru');
INSERT INTO shop_rbac_privileges_i18n (`id`, `title`, `description`, `locale`) VALUES (53, 'Установка валюты по-умолчанию', 'Доступ к установке валюты по-умолчанию', 'ru');
INSERT INTO shop_rbac_privileges_i18n (`id`, `title`, `description`, `locale`) VALUES (54, 'Установка главной валюты', 'Доступ к установке главной валюты', 'ru');
INSERT INTO shop_rbac_privileges_i18n (`id`, `title`, `description`, `locale`) VALUES (55, 'Удаление валюты', 'Доступ к удалению валюты', 'ru');
INSERT INTO shop_rbac_privileges_i18n (`id`, `title`, `description`, `locale`) VALUES (56, 'Пересчет цен', 'Доступ к пересчету цен', 'ru');
INSERT INTO shop_rbac_privileges_i18n (`id`, `title`, `description`, `locale`) VALUES (57, 'Проверка цен в базе данных', 'Доступ к проверке цен в базе данных и их исправление', 'ru');
INSERT INTO shop_rbac_privileges_i18n (`id`, `title`, `description`, `locale`) VALUES (58, 'Просмотр списка дополнительных полей для мага', 'Доступ к просмотру списка дополнительных полей магазина', 'ru');
INSERT INTO shop_rbac_privileges_i18n (`id`, `title`, `description`, `locale`) VALUES (59, 'Создание дополнительного поля для магазина', 'Доступ к созданию дополнительного поля для магазина', 'ru');
INSERT INTO shop_rbac_privileges_i18n (`id`, `title`, `description`, `locale`) VALUES (60, 'Редактирование дополнительного поля для магаз', 'Доступ к редактированию дополнительного поля для магазина', 'ru');
INSERT INTO shop_rbac_privileges_i18n (`id`, `title`, `description`, `locale`) VALUES (61, 'Удаление всех дополнительных полей для магази', 'Доступ к удалению всех дополнительных полей для магазина', 'ru');
INSERT INTO shop_rbac_privileges_i18n (`id`, `title`, `description`, `locale`) VALUES (62, 'Смена активности дополнительного поля для маг', 'Доступ к смене активности дополнительного поля для магазина', 'ru');
INSERT INTO shop_rbac_privileges_i18n (`id`, `title`, `description`, `locale`) VALUES (63, 'Смена приватности дополнительного полю', 'Доступ к изменению приватности дополнительного поля', 'ru');
INSERT INTO shop_rbac_privileges_i18n (`id`, `title`, `description`, `locale`) VALUES (64, 'Смена необходимости дополнительного поля для ', 'Доступ к изменению необходимости дополнительного поля для магазина', 'ru');
INSERT INTO shop_rbac_privileges_i18n (`id`, `title`, `description`, `locale`) VALUES (65, 'Просмотр дашборда админ панели магазина', 'Доступ к просмотру дашборда админ панели магазина', 'ru');
INSERT INTO shop_rbac_privileges_i18n (`id`, `title`, `description`, `locale`) VALUES (66, 'Просмотр списка способов доставки', 'Доступ к просмотру списка способов доставки', 'ru');
INSERT INTO shop_rbac_privileges_i18n (`id`, `title`, `description`, `locale`) VALUES (67, 'Создание способа доставки', 'Доступ к созданию способа доставки', 'ru');
INSERT INTO shop_rbac_privileges_i18n (`id`, `title`, `description`, `locale`) VALUES (68, 'Смена статуса способа доставки', 'Доступ к смене статуса способа доставки', 'ru');
INSERT INTO shop_rbac_privileges_i18n (`id`, `title`, `description`, `locale`) VALUES (69, 'Редактирование способа доставки', 'Доступ к редактированию способа доставки', 'ru');
INSERT INTO shop_rbac_privileges_i18n (`id`, `title`, `description`, `locale`) VALUES (70, 'Удаление способа доставки', 'Доступ к удалению способа доставки', 'ru');
INSERT INTO shop_rbac_privileges_i18n (`id`, `title`, `description`, `locale`) VALUES (71, 'ShopAdminDeliverymethods::c_list', '', 'ru');
INSERT INTO shop_rbac_privileges_i18n (`id`, `title`, `description`, `locale`) VALUES (72, 'Просмотр списка постоянных скидок', 'Доступ к просмотру списка постоянных скидок', 'ru');
INSERT INTO shop_rbac_privileges_i18n (`id`, `title`, `description`, `locale`) VALUES (73, 'Создание постоянной скидки', 'Доступ к созданию постоянной скидки', 'ru');
INSERT INTO shop_rbac_privileges_i18n (`id`, `title`, `description`, `locale`) VALUES (74, 'Смена статуса постоянной скидки', 'Доступ к смене статуса постоянной скидки', 'ru');
INSERT INTO shop_rbac_privileges_i18n (`id`, `title`, `description`, `locale`) VALUES (75, 'Редактирование постоянной скидки', 'Доступ к редактированию постоянной скидки', 'ru');
INSERT INTO shop_rbac_privileges_i18n (`id`, `title`, `description`, `locale`) VALUES (76, 'Удаление постоянной скидки', 'Доступ к удалению постоянной скидки', 'ru');
INSERT INTO shop_rbac_privileges_i18n (`id`, `title`, `description`, `locale`) VALUES (77, 'Просмотр списка подарочных сертификатов', 'Доступ к просмотру списка подарочных сертификатов', 'ru');
INSERT INTO shop_rbac_privileges_i18n (`id`, `title`, `description`, `locale`) VALUES (78, 'Создание подарочного сертификата', 'Доступ к созданию подарочного сертификата', 'ru');
INSERT INTO shop_rbac_privileges_i18n (`id`, `title`, `description`, `locale`) VALUES (79, 'Создание кода для подарочного сертификата', 'Доступ к соданию кода для подарочного сертификата', 'ru');
INSERT INTO shop_rbac_privileges_i18n (`id`, `title`, `description`, `locale`) VALUES (80, 'Удаление подарочного сертификата', 'Доступ к удалению подарочного сертификата', 'ru');
INSERT INTO shop_rbac_privileges_i18n (`id`, `title`, `description`, `locale`) VALUES (81, 'Редактирование подарочного сертификата', 'Доступ к редактированию подарочного сертификата', 'ru');
INSERT INTO shop_rbac_privileges_i18n (`id`, `title`, `description`, `locale`) VALUES (82, 'Смена активности подарочного сертификата', 'Доступ к смене активности подарочного сертификата', 'ru');
INSERT INTO shop_rbac_privileges_i18n (`id`, `title`, `description`, `locale`) VALUES (83, 'Настройки подарочных сертификатов', 'Доступ к настройкам подарочных сертификатов', 'ru');
INSERT INTO shop_rbac_privileges_i18n (`id`, `title`, `description`, `locale`) VALUES (84, 'Сохранение настроек подарочных сертификатов', 'Доступ к сохранению настроек подарочных сертификатов', 'ru');
INSERT INTO shop_rbac_privileges_i18n (`id`, `title`, `description`, `locale`) VALUES (85, 'Просмотр списка наборов товаров', 'Доступ к просмотру списка наборов товаров', 'ru');
INSERT INTO shop_rbac_privileges_i18n (`id`, `title`, `description`, `locale`) VALUES (86, 'Создание набора товаров', 'Доступ к созданию набора товаров', 'ru');
INSERT INTO shop_rbac_privileges_i18n (`id`, `title`, `description`, `locale`) VALUES (87, 'Редактирование набора товаров', 'Доступ к редактированию набора товаров', 'ru');
INSERT INTO shop_rbac_privileges_i18n (`id`, `title`, `description`, `locale`) VALUES (88, 'Смена порядка наборов товаров', 'Доступ к смене порядка наборо товаров', 'ru');
INSERT INTO shop_rbac_privileges_i18n (`id`, `title`, `description`, `locale`) VALUES (89, 'Смена активности набора товаров', 'Доступ к смене активности набора товаров', 'ru');
INSERT INTO shop_rbac_privileges_i18n (`id`, `title`, `description`, `locale`) VALUES (90, 'ShopAdminKits::kit_list', '', 'ru');
INSERT INTO shop_rbac_privileges_i18n (`id`, `title`, `description`, `locale`) VALUES (91, 'Удаление набора товаров', 'Доступ к удалению набора товаров', 'ru');
INSERT INTO shop_rbac_privileges_i18n (`id`, `title`, `description`, `locale`) VALUES (92, 'Получение списка товаров', 'Доступ к получению списка товаров', 'ru');
INSERT INTO shop_rbac_privileges_i18n (`id`, `title`, `description`, `locale`) VALUES (93, 'Просмотр списка уведовлений', 'Доступ к просмотру списка уведомлений', 'ru');
INSERT INTO shop_rbac_privileges_i18n (`id`, `title`, `description`, `locale`) VALUES (94, 'Редактирование уведомления', 'Доступ к редактированию уведомления', 'ru');
INSERT INTO shop_rbac_privileges_i18n (`id`, `title`, `description`, `locale`) VALUES (95, 'Смена статуса уведомления', 'Доступ к смене статуса уведомления', 'ru');
INSERT INTO shop_rbac_privileges_i18n (`id`, `title`, `description`, `locale`) VALUES (96, 'Уведомление по почте', 'Доступ к уведомлению по почте', 'ru');
INSERT INTO shop_rbac_privileges_i18n (`id`, `title`, `description`, `locale`) VALUES (97, 'Удаление уведомления', 'Доступ к удалению уведомления', 'ru');
INSERT INTO shop_rbac_privileges_i18n (`id`, `title`, `description`, `locale`) VALUES (98, 'Удаление уведомления', 'Доступ к удалению уведомления', 'ru');
INSERT INTO shop_rbac_privileges_i18n (`id`, `title`, `description`, `locale`) VALUES (99, 'Смена статуса уведомления', 'Доступ к смене статуса уведомления', 'ru');
INSERT INTO shop_rbac_privileges_i18n (`id`, `title`, `description`, `locale`) VALUES (100, 'Поиск уведомления', 'Доступ к поиску уведомления', 'ru');
INSERT INTO shop_rbac_privileges_i18n (`id`, `title`, `description`, `locale`) VALUES (101, 'Поиск новых событий', 'Доступ к поиску новых событий', 'ru');
INSERT INTO shop_rbac_privileges_i18n (`id`, `title`, `description`, `locale`) VALUES (102, 'Просмотр статусов уведомлений', 'Доступ к просмотру статусов уведомлений', 'ru');
INSERT INTO shop_rbac_privileges_i18n (`id`, `title`, `description`, `locale`) VALUES (103, 'Создание статуса уведомления', 'Доступ к созданию статуса уведомления', 'ru');
INSERT INTO shop_rbac_privileges_i18n (`id`, `title`, `description`, `locale`) VALUES (104, 'Редактирование статуса уведомления', 'Доступ к редактированию статуса увдеомления', 'ru');
INSERT INTO shop_rbac_privileges_i18n (`id`, `title`, `description`, `locale`) VALUES (105, 'Удаление статуса уведомления', 'Доступ к удалению статуса уведомления', 'ru');
INSERT INTO shop_rbac_privileges_i18n (`id`, `title`, `description`, `locale`) VALUES (106, 'Смена порядка статусов уведомлений', 'Доступ к смене порядка статусов уведомлений', 'ru');
INSERT INTO shop_rbac_privileges_i18n (`id`, `title`, `description`, `locale`) VALUES (107, 'Просмотр списка заказов', 'Доступ к просмотру списка заказов', 'ru');
INSERT INTO shop_rbac_privileges_i18n (`id`, `title`, `description`, `locale`) VALUES (108, 'Редактирование заказа', 'Доступ к редактированию заказа', 'ru');
INSERT INTO shop_rbac_privileges_i18n (`id`, `title`, `description`, `locale`) VALUES (109, 'Смена статуса заказа', 'Доступ к смене статуса заказа', 'ru');
INSERT INTO shop_rbac_privileges_i18n (`id`, `title`, `description`, `locale`) VALUES (110, 'Смена статуса оплаты заказа', 'Доступ к смене  статуса оплаты заказа', 'ru');
INSERT INTO shop_rbac_privileges_i18n (`id`, `title`, `description`, `locale`) VALUES (111, 'Удаление заказа', 'Доступ к удалению статуса заказа', 'ru');
INSERT INTO shop_rbac_privileges_i18n (`id`, `title`, `description`, `locale`) VALUES (112, 'Удаление статуса заказа', 'Доступ к удалению статуса заказа', 'ru');
INSERT INTO shop_rbac_privileges_i18n (`id`, `title`, `description`, `locale`) VALUES (113, 'Смена статусов заказов', 'Доступ к смене статусов заказов', 'ru');
INSERT INTO shop_rbac_privileges_i18n (`id`, `title`, `description`, `locale`) VALUES (114, 'Смена статуса оплаты заказов', 'Доступ к смене статусов оплаты заказов', 'ru');
INSERT INTO shop_rbac_privileges_i18n (`id`, `title`, `description`, `locale`) VALUES (115, 'Отображение окна редактирования', 'Доступ к окну редактирования', 'ru');
INSERT INTO shop_rbac_privileges_i18n (`id`, `title`, `description`, `locale`) VALUES (116, 'Окно редактирования набора товаров', 'Доступ к окну редактирования набора товаров', 'ru');
INSERT INTO shop_rbac_privileges_i18n (`id`, `title`, `description`, `locale`) VALUES (117, 'Окно добавления товара к заказу', 'Доступ к окну добавления товаров к заказу', 'ru');
INSERT INTO shop_rbac_privileges_i18n (`id`, `title`, `description`, `locale`) VALUES (118, 'Удаление товара из заказа', 'Доступ к удалению товара из заказа', 'ru');
INSERT INTO shop_rbac_privileges_i18n (`id`, `title`, `description`, `locale`) VALUES (119, 'Получение списка товаров', 'Доступ к получению списка товаров', 'ru');
INSERT INTO shop_rbac_privileges_i18n (`id`, `title`, `description`, `locale`) VALUES (120, 'Редактирование товара в заказе', 'Доступ к редактированию товара в заказе', 'ru');
INSERT INTO shop_rbac_privileges_i18n (`id`, `title`, `description`, `locale`) VALUES (121, 'Добавление товара к заказу', 'Доступ к добавлению товара к заказу', 'ru');
INSERT INTO shop_rbac_privileges_i18n (`id`, `title`, `description`, `locale`) VALUES (122, 'Получение списка товаров в заказе', 'Доступ к получению списка товаров в заказе', 'ru');
INSERT INTO shop_rbac_privileges_i18n (`id`, `title`, `description`, `locale`) VALUES (123, 'Поиск заказа', 'Доступ к поиску заказа', 'ru');
INSERT INTO shop_rbac_privileges_i18n (`id`, `title`, `description`, `locale`) VALUES (124, 'Создание чеков', 'Доступ созданию чека', 'ru');
INSERT INTO shop_rbac_privileges_i18n (`id`, `title`, `description`, `locale`) VALUES (125, 'Создание pdf чека', 'Доступ созданию pdf чека', 'ru');
INSERT INTO shop_rbac_privileges_i18n (`id`, `title`, `description`, `locale`) VALUES (126, 'Создание чека', 'Доступ к созданию чека', 'ru');
INSERT INTO shop_rbac_privileges_i18n (`id`, `title`, `description`, `locale`) VALUES (127, 'Создание заказа', 'Доступ к созданию заказа', 'ru');
INSERT INTO shop_rbac_privileges_i18n (`id`, `title`, `description`, `locale`) VALUES (128, 'Просмотр списка статусов заказов', 'Доступ к просмотру списка статусов заказов', 'ru');
INSERT INTO shop_rbac_privileges_i18n (`id`, `title`, `description`, `locale`) VALUES (129, 'Создание статуса заказа', 'Доступ к созданию статуса заказа', 'ru');
INSERT INTO shop_rbac_privileges_i18n (`id`, `title`, `description`, `locale`) VALUES (130, 'Редактирование статуса заказа', 'Доступ к редактированию статуса заказа', 'ru');
INSERT INTO shop_rbac_privileges_i18n (`id`, `title`, `description`, `locale`) VALUES (131, 'Удаление статуса заказа', 'Доступ к удалению статуса заказа', 'ru');
INSERT INTO shop_rbac_privileges_i18n (`id`, `title`, `description`, `locale`) VALUES (132, 'Отображение окна удаления', 'Доступ к отображению окна удаления', 'ru');
INSERT INTO shop_rbac_privileges_i18n (`id`, `title`, `description`, `locale`) VALUES (133, 'Смена порядка статусов заказов', 'Доступ к смене порядка статусов заказов', 'ru');
INSERT INTO shop_rbac_privileges_i18n (`id`, `title`, `description`, `locale`) VALUES (134, 'Просмотр списка методов оплаты', 'Доступ к просмотру списка методов оплаты', 'ru');
INSERT INTO shop_rbac_privileges_i18n (`id`, `title`, `description`, `locale`) VALUES (135, 'Создание метода оплаты', 'Доступ к созданию метода оплаты', 'ru');
INSERT INTO shop_rbac_privileges_i18n (`id`, `title`, `description`, `locale`) VALUES (136, 'Смена статуса способа оплаты', 'Доступ к смене статуса способа оплаты', 'ru');
INSERT INTO shop_rbac_privileges_i18n (`id`, `title`, `description`, `locale`) VALUES (137, 'Редактирование способа оплаты', 'Доступ к редактированию способа оплаты', 'ru');
INSERT INTO shop_rbac_privileges_i18n (`id`, `title`, `description`, `locale`) VALUES (138, 'Удаление способа оплаты', 'Доступ к удалению способа оплаты', 'ru');
INSERT INTO shop_rbac_privileges_i18n (`id`, `title`, `description`, `locale`) VALUES (139, 'Смена порядка способов оплаты', 'Доступ к смене порядка способов оплаты', 'ru');
INSERT INTO shop_rbac_privileges_i18n (`id`, `title`, `description`, `locale`) VALUES (140, 'Отображение настроек способа оплаты', 'Доступ к отображению настроек способа оплаты', 'ru');
INSERT INTO shop_rbac_privileges_i18n (`id`, `title`, `description`, `locale`) VALUES (141, 'ShopAdminProducts::index', '', 'ru');
INSERT INTO shop_rbac_privileges_i18n (`id`, `title`, `description`, `locale`) VALUES (142, 'Создание продукта', 'Доступ к созданию продукта', 'ru');
INSERT INTO shop_rbac_privileges_i18n (`id`, `title`, `description`, `locale`) VALUES (143, 'Редактирование товара', 'Доступ к редактированию товара', 'ru');
INSERT INTO shop_rbac_privileges_i18n (`id`, `title`, `description`, `locale`) VALUES (144, 'Сохранение дополнительных изображений', 'Доступ к сохренению дополнительных изображений', 'ru');
INSERT INTO shop_rbac_privileges_i18n (`id`, `title`, `description`, `locale`) VALUES (145, 'Удаление товара', 'Доступ к удалению товара', 'ru');
INSERT INTO shop_rbac_privileges_i18n (`id`, `title`, `description`, `locale`) VALUES (146, 'Обработка изображений', 'Доступ к обработке изображений', 'ru');
INSERT INTO shop_rbac_privileges_i18n (`id`, `title`, `description`, `locale`) VALUES (147, 'Удаление дополнительных изображений', 'Доступ к удалению дополнительных изображений', 'ru');
INSERT INTO shop_rbac_privileges_i18n (`id`, `title`, `description`, `locale`) VALUES (148, 'Смена активности товара', 'Доступ к смене активности товара', 'ru');
INSERT INTO shop_rbac_privileges_i18n (`id`, `title`, `description`, `locale`) VALUES (149, 'Смена пункта \"Хит\" для товара', 'Доступ к смене пункта \"Хит\" для товара', 'ru');
INSERT INTO shop_rbac_privileges_i18n (`id`, `title`, `description`, `locale`) VALUES (150, 'Смена пункта \"Новинка\" для товара', 'Доступ к смене пункта \"Новинка\" для товара', 'ru');
INSERT INTO shop_rbac_privileges_i18n (`id`, `title`, `description`, `locale`) VALUES (151, 'Смена пункта \"Акция\" для товара', 'Доступ к смене пункта \"Акция\" для товара', 'ru');
INSERT INTO shop_rbac_privileges_i18n (`id`, `title`, `description`, `locale`) VALUES (152, 'Обновление цены', 'Доступ к обновлению цены товара', 'ru');
INSERT INTO shop_rbac_privileges_i18n (`id`, `title`, `description`, `locale`) VALUES (153, 'Копирование товаров', 'Доступ к копированию товаров', 'ru');
INSERT INTO shop_rbac_privileges_i18n (`id`, `title`, `description`, `locale`) VALUES (154, 'Удаление товаров', 'Доступ к удалению товаров', 'ru');
INSERT INTO shop_rbac_privileges_i18n (`id`, `title`, `description`, `locale`) VALUES (155, 'Просмотр окна перемещения товаров', 'Доступ к окну перемещения товаров', 'ru');
INSERT INTO shop_rbac_privileges_i18n (`id`, `title`, `description`, `locale`) VALUES (156, 'Перемещение товаров', 'Доступ к перемещению товаров', 'ru');
INSERT INTO shop_rbac_privileges_i18n (`id`, `title`, `description`, `locale`) VALUES (157, 'Перевод товара', 'Доступ к переводу товара', 'ru');
INSERT INTO shop_rbac_privileges_i18n (`id`, `title`, `description`, `locale`) VALUES (158, 'Получение списка id товаров', 'Доступ к получению списка id товаров', 'ru');
INSERT INTO shop_rbac_privileges_i18n (`id`, `title`, `description`, `locale`) VALUES (159, 'Переключение товаров', 'Доступ к переключению товаров', 'ru');
INSERT INTO shop_rbac_privileges_i18n (`id`, `title`, `description`, `locale`) VALUES (160, 'Просмотр списка слежения', 'Доступ к просмотру списка слежения', 'ru');
INSERT INTO shop_rbac_privileges_i18n (`id`, `title`, `description`, `locale`) VALUES (161, 'Удаления слежения', 'Доступ к удалению слежения', 'ru');
INSERT INTO shop_rbac_privileges_i18n (`id`, `title`, `description`, `locale`) VALUES (162, 'Настройки слежения за товарами', 'Доступ к настройкам слежения за товаром', 'ru');
INSERT INTO shop_rbac_privileges_i18n (`id`, `title`, `description`, `locale`) VALUES (163, 'Просмотр списка свойств', 'Доступ к просмотру списка свойств', 'ru');
INSERT INTO shop_rbac_privileges_i18n (`id`, `title`, `description`, `locale`) VALUES (164, 'Создание свойства товара', 'Доступ к созданию свойства товара', 'ru');
INSERT INTO shop_rbac_privileges_i18n (`id`, `title`, `description`, `locale`) VALUES (165, 'Редактирование свойства товара', 'Доступ к редактированию свойства товара', 'ru');
INSERT INTO shop_rbac_privileges_i18n (`id`, `title`, `description`, `locale`) VALUES (166, 'ShopAdminProperties::renderForm', '', 'ru');
INSERT INTO shop_rbac_privileges_i18n (`id`, `title`, `description`, `locale`) VALUES (167, 'Смена порядка свойств', 'Доступ к смене порядка свойств', 'ru');
INSERT INTO shop_rbac_privileges_i18n (`id`, `title`, `description`, `locale`) VALUES (168, 'Удаление свойств', 'Доступ к удалению свойств', 'ru');
INSERT INTO shop_rbac_privileges_i18n (`id`, `title`, `description`, `locale`) VALUES (169, 'Смена активности свойства', 'Доступ к смене активности свойства', 'ru');
INSERT INTO shop_rbac_privileges_i18n (`id`, `title`, `description`, `locale`) VALUES (180, 'ShopAdminRbac::group_create', '', 'ru');
INSERT INTO shop_rbac_privileges_i18n (`id`, `title`, `description`, `locale`) VALUES (181, 'ShopAdminRbac::group_edit', '', 'ru');
INSERT INTO shop_rbac_privileges_i18n (`id`, `title`, `description`, `locale`) VALUES (182, 'ShopAdminRbac::group_list', '', 'ru');
INSERT INTO shop_rbac_privileges_i18n (`id`, `title`, `description`, `locale`) VALUES (183, 'ShopAdminRbac::group_delete', '', 'ru');
INSERT INTO shop_rbac_privileges_i18n (`id`, `title`, `description`, `locale`) VALUES (184, 'Просмотр списка товаров', 'Доступ к просмотру списка товаров', 'ru');
INSERT INTO shop_rbac_privileges_i18n (`id`, `title`, `description`, `locale`) VALUES (185, 'Смена порядка вариантов товаров', 'Доступ к смене порядка вариантов товаров', 'ru');
INSERT INTO shop_rbac_privileges_i18n (`id`, `title`, `description`, `locale`) VALUES (186, 'Автодополнение к поиску', 'Доступ к автодополнению к поиску', 'ru');
INSERT INTO shop_rbac_privileges_i18n (`id`, `title`, `description`, `locale`) VALUES (187, 'Продвинутый поиск', 'Доступ к продвинутому поиску', 'ru');
INSERT INTO shop_rbac_privileges_i18n (`id`, `title`, `description`, `locale`) VALUES (188, 'ShopAdminSearch::renderCustomFields', '', 'ru');
INSERT INTO shop_rbac_privileges_i18n (`id`, `title`, `description`, `locale`) VALUES (189, 'Свойства магазина', 'Доступ к свойствам магазина', 'ru');
INSERT INTO shop_rbac_privileges_i18n (`id`, `title`, `description`, `locale`) VALUES (190, 'Изменение свойств магазина', 'Доступ к изменению свойств магазина', 'ru');
INSERT INTO shop_rbac_privileges_i18n (`id`, `title`, `description`, `locale`) VALUES (191, 'Получение настроек для интеграции с фейсбуком', 'Доступ к настройкам интеграции с фейсбуком', 'ru');
INSERT INTO shop_rbac_privileges_i18n (`id`, `title`, `description`, `locale`) VALUES (192, 'Получение настроек интеграции с вк', 'Доступ к настройкам интеграции с вк', 'ru');
INSERT INTO shop_rbac_privileges_i18n (`id`, `title`, `description`, `locale`) VALUES (193, 'Получение списка шаблонов', 'Доступ к получению списка шаблонов', 'ru');
INSERT INTO shop_rbac_privileges_i18n (`id`, `title`, `description`, `locale`) VALUES (194, 'Загрузка настроек', 'Доступ к загрузке настроек', 'ru');
INSERT INTO shop_rbac_privileges_i18n (`id`, `title`, `description`, `locale`) VALUES (195, 'Запуск ресайза изображений', 'Доступ к запуску ресайза изображений', 'ru');
INSERT INTO shop_rbac_privileges_i18n (`id`, `title`, `description`, `locale`) VALUES (196, 'Импорт товаров', 'Доступ к импорту товаров', 'ru');
INSERT INTO shop_rbac_privileges_i18n (`id`, `title`, `description`, `locale`) VALUES (197, 'Экспорт товаров', 'Доступ к экспорту товаров', 'ru');
INSERT INTO shop_rbac_privileges_i18n (`id`, `title`, `description`, `locale`) VALUES (198, 'Получение атрибутов', 'Доступ к получению атрибутов', 'ru');
INSERT INTO shop_rbac_privileges_i18n (`id`, `title`, `description`, `locale`) VALUES (199, 'Экспорт пользователей', 'Доступ к экспорту пользователей', 'ru');
INSERT INTO shop_rbac_privileges_i18n (`id`, `title`, `description`, `locale`) VALUES (200, 'Просмотр списка пользователей', 'Доступ к просмотру списка пользователей', 'ru');
INSERT INTO shop_rbac_privileges_i18n (`id`, `title`, `description`, `locale`) VALUES (201, 'Поиск пользователей', 'Доступ к поиску пользователей', 'ru');
INSERT INTO shop_rbac_privileges_i18n (`id`, `title`, `description`, `locale`) VALUES (202, 'Создание пользователя', 'Доступ к созданию пользователя', 'ru');
INSERT INTO shop_rbac_privileges_i18n (`id`, `title`, `description`, `locale`) VALUES (203, 'Редактирование пользователя', 'Доступ к редактированию пользователя', 'ru');
INSERT INTO shop_rbac_privileges_i18n (`id`, `title`, `description`, `locale`) VALUES (204, 'Удаление пользователя', 'Доступ к удалению пользователя', 'ru');
INSERT INTO shop_rbac_privileges_i18n (`id`, `title`, `description`, `locale`) VALUES (205, 'Автодополнение списка пользователей', 'Достпу к автодополнению списка пользователей', 'ru');
INSERT INTO shop_rbac_privileges_i18n (`id`, `title`, `description`, `locale`) VALUES (206, 'Просмотр списка складов', 'Доступ к просмотру списка складов', 'ru');
INSERT INTO shop_rbac_privileges_i18n (`id`, `title`, `description`, `locale`) VALUES (207, 'Создание склада', 'Доступ к созданию склада', 'ru');
INSERT INTO shop_rbac_privileges_i18n (`id`, `title`, `description`, `locale`) VALUES (208, 'Редактирование склада', 'Доступ к редактированию склада', 'ru');
INSERT INTO shop_rbac_privileges_i18n (`id`, `title`, `description`, `locale`) VALUES (209, 'Удаление склада', 'Доступ к удалению склада', 'ru');
INSERT INTO shop_rbac_privileges_i18n (`id`, `title`, `description`, `locale`) VALUES (210, 'Доступ к админпанели', 'Доступ к админпанели', 'ru');
INSERT INTO shop_rbac_privileges_i18n (`id`, `title`, `description`, `locale`) VALUES (211, 'Инициализация настроек', 'Доступ к инициализации настроек', 'ru');
INSERT INTO shop_rbac_privileges_i18n (`id`, `title`, `description`, `locale`) VALUES (212, 'Просмотр дашборда базовой админки', 'Доступ к просмотру дашборда базовой админки', 'ru');
INSERT INTO shop_rbac_privileges_i18n (`id`, `title`, `description`, `locale`) VALUES (213, 'Просмотр информации о системе', 'Доступ к просмотру информации о системе', 'ru');
INSERT INTO shop_rbac_privileges_i18n (`id`, `title`, `description`, `locale`) VALUES (214, 'Очистка кеша', 'Доступ к очистке кеша', 'ru');
INSERT INTO shop_rbac_privileges_i18n (`id`, `title`, `description`, `locale`) VALUES (215, 'Инициализация elfinder', 'Доступ к инициализации elfinder', 'ru');
INSERT INTO shop_rbac_privileges_i18n (`id`, `title`, `description`, `locale`) VALUES (216, 'Получение защитного токена', 'Доступ к получению токена', 'ru');
INSERT INTO shop_rbac_privileges_i18n (`id`, `title`, `description`, `locale`) VALUES (217, 'Admin::sidebar_cats', '', 'ru');
INSERT INTO shop_rbac_privileges_i18n (`id`, `title`, `description`, `locale`) VALUES (218, 'Выход с админки', 'Доступ к выходу с админки', 'ru');
INSERT INTO shop_rbac_privileges_i18n (`id`, `title`, `description`, `locale`) VALUES (219, 'Сообщить о ошибке', 'Доступ к сообщению о ошибке', 'ru');
INSERT INTO shop_rbac_privileges_i18n (`id`, `title`, `description`, `locale`) VALUES (220, 'История событий', 'Доступ к истории событий', 'ru');
INSERT INTO shop_rbac_privileges_i18n (`id`, `title`, `description`, `locale`) VALUES (221, 'Просмотр истории событий', 'Доступ к просмотру истории событий', 'ru');
INSERT INTO shop_rbac_privileges_i18n (`id`, `title`, `description`, `locale`) VALUES (222, 'Поиск в базовой версии', 'Доступ к поиску в базовой версии', 'ru');
INSERT INTO shop_rbac_privileges_i18n (`id`, `title`, `description`, `locale`) VALUES (223, 'Admin_search::index', '', 'ru');
INSERT INTO shop_rbac_privileges_i18n (`id`, `title`, `description`, `locale`) VALUES (224, 'Продвинутый поиск в базовой версии', 'Доступ к продвинутому поиску в базовой версии', 'ru');
INSERT INTO shop_rbac_privileges_i18n (`id`, `title`, `description`, `locale`) VALUES (225, 'Произвести поиск в базовой версии', 'Произвести поиск в базовой версии', 'ru');
INSERT INTO shop_rbac_privileges_i18n (`id`, `title`, `description`, `locale`) VALUES (226, 'Валидация поиска в базовой версии', 'Доступ к валидации поиска в базовой версии', 'ru');
INSERT INTO shop_rbac_privileges_i18n (`id`, `title`, `description`, `locale`) VALUES (227, 'Admin_search::form_from_group', '', 'ru');
INSERT INTO shop_rbac_privileges_i18n (`id`, `title`, `description`, `locale`) VALUES (228, 'Фильтрация страниц', 'Доступ к фильтрации страниц', 'ru');
INSERT INTO shop_rbac_privileges_i18n (`id`, `title`, `description`, `locale`) VALUES (229, 'Автодополнение поиска', 'Доступ к автодополнению поиска', 'ru');
INSERT INTO shop_rbac_privileges_i18n (`id`, `title`, `description`, `locale`) VALUES (230, 'Управление бекапами', 'Доступ к управлению бекапами', 'ru');
INSERT INTO shop_rbac_privileges_i18n (`id`, `title`, `description`, `locale`) VALUES (231, 'Подготовка резервного копирования', 'Доступ к подготовке резервного копирования', 'ru');
INSERT INTO shop_rbac_privileges_i18n (`id`, `title`, `description`, `locale`) VALUES (232, 'Создание бекапа', 'Доступ к созданию бекапа', 'ru');
INSERT INTO shop_rbac_privileges_i18n (`id`, `title`, `description`, `locale`) VALUES (233, 'Закачка резервной копии', 'Доступ к созданию резервной копии', 'ru');
INSERT INTO shop_rbac_privileges_i18n (`id`, `title`, `description`, `locale`) VALUES (234, 'Управление кешем', 'Достпу к управлению кешем', 'ru');
INSERT INTO shop_rbac_privileges_i18n (`id`, `title`, `description`, `locale`) VALUES (235, 'Управление кешем', 'Доступ к управлению кешем', 'ru');
INSERT INTO shop_rbac_privileges_i18n (`id`, `title`, `description`, `locale`) VALUES (236, 'Управление категориями сайта', 'Доступ к управлению категориями сайта', 'ru');
INSERT INTO shop_rbac_privileges_i18n (`id`, `title`, `description`, `locale`) VALUES (237, 'Просмотр списка категорий сайта', 'Доступ к просмотру списка категорий сайта', 'ru');
INSERT INTO shop_rbac_privileges_i18n (`id`, `title`, `description`, `locale`) VALUES (238, 'Отображение формы создания категории', 'Доступ к отображению формы создания категории', 'ru');
INSERT INTO shop_rbac_privileges_i18n (`id`, `title`, `description`, `locale`) VALUES (239, 'Обноление категории', 'Доступ к обновлению категорий', 'ru');
INSERT INTO shop_rbac_privileges_i18n (`id`, `title`, `description`, `locale`) VALUES (240, 'Смена порядка категорий сайта', 'Доступ к смене порядка категорий сайта', 'ru');
INSERT INTO shop_rbac_privileges_i18n (`id`, `title`, `description`, `locale`) VALUES (241, 'Просмотр списка категорий сайта', 'Доступ к просмотру списка категорий сайта', 'ru');
INSERT INTO shop_rbac_privileges_i18n (`id`, `title`, `description`, `locale`) VALUES (242, 'Подкатегории', 'Доступ к подкатегориям', 'ru');
INSERT INTO shop_rbac_privileges_i18n (`id`, `title`, `description`, `locale`) VALUES (243, 'Создание категории сайта', 'Доступ к категории сайта', 'ru');
INSERT INTO shop_rbac_privileges_i18n (`id`, `title`, `description`, `locale`) VALUES (244, 'Обновление урлов', 'Доступ к обновлению урлов', 'ru');
INSERT INTO shop_rbac_privileges_i18n (`id`, `title`, `description`, `locale`) VALUES (245, 'Проверка сушествования категории сайта', 'Доступ к проверке сушествования категории сайта', 'ru');
INSERT INTO shop_rbac_privileges_i18n (`id`, `title`, `description`, `locale`) VALUES (246, 'Быстрое добавление категории', 'Доступ к быстрому добавлению категории', 'ru');
INSERT INTO shop_rbac_privileges_i18n (`id`, `title`, `description`, `locale`) VALUES (247, 'Быстрое обновление блока', 'Доступ к быстрому обновлению блока', 'ru');
INSERT INTO shop_rbac_privileges_i18n (`id`, `title`, `description`, `locale`) VALUES (248, 'Редактирование категорий сайта', 'Доступ к редактированию категории сайта', 'ru');
INSERT INTO shop_rbac_privileges_i18n (`id`, `title`, `description`, `locale`) VALUES (249, 'Перевод категории сайта', 'Доступ к переводу категории сайта', 'ru');
INSERT INTO shop_rbac_privileges_i18n (`id`, `title`, `description`, `locale`) VALUES (250, 'Удаление категории сайта', 'Доступ к удалению категории сайта', 'ru');
INSERT INTO shop_rbac_privileges_i18n (`id`, `title`, `description`, `locale`) VALUES (251, 'Получение подкатегорий', 'Доступ к получению подкатегорий', 'ru');
INSERT INTO shop_rbac_privileges_i18n (`id`, `title`, `description`, `locale`) VALUES (252, 'Получение статуса комментариев', 'Доступ к получению статусув комментариев', 'ru');
INSERT INTO shop_rbac_privileges_i18n (`id`, `title`, `description`, `locale`) VALUES (253, 'Доступ к компонентам', 'Доступ к компонентам', 'ru');
INSERT INTO shop_rbac_privileges_i18n (`id`, `title`, `description`, `locale`) VALUES (254, 'Управление компонентами системы', 'Доступ к управлению компонентами системы', 'ru');
INSERT INTO shop_rbac_privileges_i18n (`id`, `title`, `description`, `locale`) VALUES (255, 'Просмотр списка компонентов сайта', 'Доступ к просмотру списка компонентов сайта', 'ru');
INSERT INTO shop_rbac_privileges_i18n (`id`, `title`, `description`, `locale`) VALUES (256, 'Проверка установки компонента', 'Доступ к проверке установки компонента', 'ru');
INSERT INTO shop_rbac_privileges_i18n (`id`, `title`, `description`, `locale`) VALUES (257, 'Установка модуля', 'Доступ к установке модуля', 'ru');
INSERT INTO shop_rbac_privileges_i18n (`id`, `title`, `description`, `locale`) VALUES (258, 'Удаление модуля', 'Доступ к удалению модуля', 'ru');
INSERT INTO shop_rbac_privileges_i18n (`id`, `title`, `description`, `locale`) VALUES (259, 'Поиск компонентов', 'Доступ к поиску компонентов', 'ru');
INSERT INTO shop_rbac_privileges_i18n (`id`, `title`, `description`, `locale`) VALUES (260, 'Настройки модуля', 'Доступ к настройкам модуля', 'ru');
INSERT INTO shop_rbac_privileges_i18n (`id`, `title`, `description`, `locale`) VALUES (261, 'Сохранение настроек модулей', 'Доступ к сохранению настроек модулей', 'ru');
INSERT INTO shop_rbac_privileges_i18n (`id`, `title`, `description`, `locale`) VALUES (262, 'Переход к админчасти модуля', 'Доступ к админчасти модуля', 'ru');
INSERT INTO shop_rbac_privileges_i18n (`id`, `title`, `description`, `locale`) VALUES (263, 'Запук модулей', 'Доступ к запуску модулей', 'ru');
INSERT INTO shop_rbac_privileges_i18n (`id`, `title`, `description`, `locale`) VALUES (264, 'Запук методов модулей', 'Доступ к запуску методов модулей', 'ru');
INSERT INTO shop_rbac_privileges_i18n (`id`, `title`, `description`, `locale`) VALUES (265, 'Получение информации о компонентах', 'Доступ к получению информации о компонентах', 'ru');
INSERT INTO shop_rbac_privileges_i18n (`id`, `title`, `description`, `locale`) VALUES (266, 'Получение информации о модуле', 'Доступ к получению информации о модуле', 'ru');
INSERT INTO shop_rbac_privileges_i18n (`id`, `title`, `description`, `locale`) VALUES (267, 'Смена статуса автозагрузки модуля', 'Доступ к смене статуса автозагрузки модуля', 'ru');
INSERT INTO shop_rbac_privileges_i18n (`id`, `title`, `description`, `locale`) VALUES (268, 'Смена доступа по url к модулю', 'Смена доступа по url к модулю', 'ru');
INSERT INTO shop_rbac_privileges_i18n (`id`, `title`, `description`, `locale`) VALUES (269, 'Смена порядка компонентов в списке', 'Доступ к смене порядка компонентов в списке', 'ru');
INSERT INTO shop_rbac_privileges_i18n (`id`, `title`, `description`, `locale`) VALUES (270, 'Включение\\отключение отображения модуля в мен', 'Доступ к включению\\отключению отображения модуля в меню', 'ru');
INSERT INTO shop_rbac_privileges_i18n (`id`, `title`, `description`, `locale`) VALUES (271, 'Отображение дашборда админки', 'Доступ к отображению дашборда админки', 'ru');
INSERT INTO shop_rbac_privileges_i18n (`id`, `title`, `description`, `locale`) VALUES (272, 'Отображение дашборда админки', 'Доступ к отображению дашборда админки', 'ru');
INSERT INTO shop_rbac_privileges_i18n (`id`, `title`, `description`, `locale`) VALUES (273, 'Управление языками', 'Доступ к управлению языками', 'ru');
INSERT INTO shop_rbac_privileges_i18n (`id`, `title`, `description`, `locale`) VALUES (274, 'Просмотр списка языков', 'Достпу к просмотру списка языков', 'ru');
INSERT INTO shop_rbac_privileges_i18n (`id`, `title`, `description`, `locale`) VALUES (275, 'Отображение формы создания языка', 'Доступ к отображению формы создания языка', 'ru');
INSERT INTO shop_rbac_privileges_i18n (`id`, `title`, `description`, `locale`) VALUES (276, 'Создание языка', 'Доступ к созданию языка', 'ru');
INSERT INTO shop_rbac_privileges_i18n (`id`, `title`, `description`, `locale`) VALUES (277, 'Редактирование языка', 'Доступ к редактированию языка', 'ru');
INSERT INTO shop_rbac_privileges_i18n (`id`, `title`, `description`, `locale`) VALUES (278, 'Обновление языка', 'Доступ к обновлению языка', 'ru');
INSERT INTO shop_rbac_privileges_i18n (`id`, `title`, `description`, `locale`) VALUES (279, 'Удаление языка', 'Доступ к удалению языка', 'ru');
INSERT INTO shop_rbac_privileges_i18n (`id`, `title`, `description`, `locale`) VALUES (280, 'Установка языка по-умолчанию', 'Доступ к установке языка по-умолчанию', 'ru');
INSERT INTO shop_rbac_privileges_i18n (`id`, `title`, `description`, `locale`) VALUES (281, 'Вход в админ панель', 'Доступ к входу в админ панель', 'ru');
INSERT INTO shop_rbac_privileges_i18n (`id`, `title`, `description`, `locale`) VALUES (282, 'Вход в админ панель', 'Доступ к входу в админ панель', 'ru');
INSERT INTO shop_rbac_privileges_i18n (`id`, `title`, `description`, `locale`) VALUES (283, 'Проверка браузера пользователя', 'Доступ к проверке браузера пользователя', 'ru');
INSERT INTO shop_rbac_privileges_i18n (`id`, `title`, `description`, `locale`) VALUES (284, 'Вход', 'Вход', 'ru');
INSERT INTO shop_rbac_privileges_i18n (`id`, `title`, `description`, `locale`) VALUES (285, 'Восстановление пароля', 'Восстановление пароля', 'ru');
INSERT INTO shop_rbac_privileges_i18n (`id`, `title`, `description`, `locale`) VALUES (286, 'Обновление капчи', 'Доступ к обновлению капчи', 'ru');
INSERT INTO shop_rbac_privileges_i18n (`id`, `title`, `description`, `locale`) VALUES (287, 'Проверка капчи', 'Доступ к проверке капчи', 'ru');
INSERT INTO shop_rbac_privileges_i18n (`id`, `title`, `description`, `locale`) VALUES (288, 'Mod_search::__construct', '', 'ru');
INSERT INTO shop_rbac_privileges_i18n (`id`, `title`, `description`, `locale`) VALUES (289, 'Mod_search::index', '', 'ru');
INSERT INTO shop_rbac_privileges_i18n (`id`, `title`, `description`, `locale`) VALUES (290, 'Mod_search::category', '', 'ru');
INSERT INTO shop_rbac_privileges_i18n (`id`, `title`, `description`, `locale`) VALUES (291, 'Mod_search::display_install_window', '', 'ru');
INSERT INTO shop_rbac_privileges_i18n (`id`, `title`, `description`, `locale`) VALUES (292, 'Mod_search::connect_ftp', '', 'ru');
INSERT INTO shop_rbac_privileges_i18n (`id`, `title`, `description`, `locale`) VALUES (293, 'Управление страницами', 'Доступ к управлению страницами', 'ru');
INSERT INTO shop_rbac_privileges_i18n (`id`, `title`, `description`, `locale`) VALUES (294, 'Просмотр списка страниц', 'Доступ к просмотру списка страниц', 'ru');
INSERT INTO shop_rbac_privileges_i18n (`id`, `title`, `description`, `locale`) VALUES (295, 'Добавление страницы', 'Доступ к добавлению страницы', 'ru');
INSERT INTO shop_rbac_privileges_i18n (`id`, `title`, `description`, `locale`) VALUES (296, 'Pages::_set_page_roles', '', 'ru');
INSERT INTO shop_rbac_privileges_i18n (`id`, `title`, `description`, `locale`) VALUES (297, 'Редактирование страницы', 'Доступ к редактированию страницы', 'ru');
INSERT INTO shop_rbac_privileges_i18n (`id`, `title`, `description`, `locale`) VALUES (298, 'Обновление страницы', 'Доступ к редактированию страницы', 'ru');
INSERT INTO shop_rbac_privileges_i18n (`id`, `title`, `description`, `locale`) VALUES (299, 'Удаление страницы', 'Доступ к удалению страницы', 'ru');
INSERT INTO shop_rbac_privileges_i18n (`id`, `title`, `description`, `locale`) VALUES (300, 'Транслит слов', 'Доступ к транслиту слов', 'ru');
INSERT INTO shop_rbac_privileges_i18n (`id`, `title`, `description`, `locale`) VALUES (301, 'Смена порядка страниц', 'Доступ к смене порядка страниц', 'ru');
INSERT INTO shop_rbac_privileges_i18n (`id`, `title`, `description`, `locale`) VALUES (302, 'Удаление страниц', 'Доступ к удалению страниц', 'ru');
INSERT INTO shop_rbac_privileges_i18n (`id`, `title`, `description`, `locale`) VALUES (303, 'Перемещение страниц', 'Доступ к перемещению страниц', 'ru');
INSERT INTO shop_rbac_privileges_i18n (`id`, `title`, `description`, `locale`) VALUES (304, 'Отображение страницы перемещения', 'Доступ к отображению страницы перемещения', 'ru');
INSERT INTO shop_rbac_privileges_i18n (`id`, `title`, `description`, `locale`) VALUES (305, 'Теги', 'Теги', 'ru');
INSERT INTO shop_rbac_privileges_i18n (`id`, `title`, `description`, `locale`) VALUES (306, 'Создание ключевых слов', 'Доступ к созданию ключевых слов', 'ru');
INSERT INTO shop_rbac_privileges_i18n (`id`, `title`, `description`, `locale`) VALUES (307, 'Создание описания', 'Доступ к созданию описания', 'ru');
INSERT INTO shop_rbac_privileges_i18n (`id`, `title`, `description`, `locale`) VALUES (308, 'Смена статуса', 'Доступ к смене статуса', 'ru');
INSERT INTO shop_rbac_privileges_i18n (`id`, `title`, `description`, `locale`) VALUES (309, 'Фильтр страниц по категории', 'Доступ к фильтру страниц по категории', 'ru');
INSERT INTO shop_rbac_privileges_i18n (`id`, `title`, `description`, `locale`) VALUES (310, 'Управление доступом', 'Управление доступом', 'ru');
INSERT INTO shop_rbac_privileges_i18n (`id`, `title`, `description`, `locale`) VALUES (311, 'Настройки сайта', 'Доступ к настройкам сайта', 'ru');
INSERT INTO shop_rbac_privileges_i18n (`id`, `title`, `description`, `locale`) VALUES (312, 'Настройки сайта', 'Доступ к настройкам сайта', 'ru');
INSERT INTO shop_rbac_privileges_i18n (`id`, `title`, `description`, `locale`) VALUES (313, 'Settings::main_page', '', 'ru');
INSERT INTO shop_rbac_privileges_i18n (`id`, `title`, `description`, `locale`) VALUES (314, 'Список папок с шаблонами', 'Список папок с шаблонами', 'ru');
INSERT INTO shop_rbac_privileges_i18n (`id`, `title`, `description`, `locale`) VALUES (315, 'Сохранение настроек', 'Доступ к сохранению настроек сайта', 'ru');
INSERT INTO shop_rbac_privileges_i18n (`id`, `title`, `description`, `locale`) VALUES (316, 'Переключение языка в админке', 'Доступ к переключению языка в админке', 'ru');
INSERT INTO shop_rbac_privileges_i18n (`id`, `title`, `description`, `locale`) VALUES (317, 'Settings::save_main', '', 'ru');
INSERT INTO shop_rbac_privileges_i18n (`id`, `title`, `description`, `locale`) VALUES (318, 'Обновление системы', 'Доступ к обновлению системы', 'ru');
INSERT INTO shop_rbac_privileges_i18n (`id`, `title`, `description`, `locale`) VALUES (319, 'Обновление системы', 'Доступ к обновлению системы', 'ru');
INSERT INTO shop_rbac_privileges_i18n (`id`, `title`, `description`, `locale`) VALUES (320, 'Запуск обновления системы', 'Доступ к запуску обновления системы', 'ru');
INSERT INTO shop_rbac_privileges_i18n (`id`, `title`, `description`, `locale`) VALUES (321, 'Проверка статуса обновления системы', 'Доступ к проверке статуса обновления системы', 'ru');
INSERT INTO shop_rbac_privileges_i18n (`id`, `title`, `description`, `locale`) VALUES (322, 'Управление дополнительными полями', 'Доступ к управлению дополнительными полями', 'ru');
INSERT INTO shop_rbac_privileges_i18n (`id`, `title`, `description`, `locale`) VALUES (323, 'Настройки форм', 'Доступ к настройкам форм', 'ru');
INSERT INTO shop_rbac_privileges_i18n (`id`, `title`, `description`, `locale`) VALUES (324, 'Управление дополнительными полями', 'Доступ к управлению дополнительными полями', 'ru');
INSERT INTO shop_rbac_privileges_i18n (`id`, `title`, `description`, `locale`) VALUES (325, 'Создание дополнительного поля', 'Доступ к созданию дополнительного поля', 'ru');
INSERT INTO shop_rbac_privileges_i18n (`id`, `title`, `description`, `locale`) VALUES (326, 'Редактирование типа дополнительного поля', 'Доступ к редактированию типа дополнительного поля', 'ru');
INSERT INTO shop_rbac_privileges_i18n (`id`, `title`, `description`, `locale`) VALUES (327, 'Удаление дополнительного поля', 'Доступ к удалению дополнительного поля', 'ru');
INSERT INTO shop_rbac_privileges_i18n (`id`, `title`, `description`, `locale`) VALUES (328, 'Редактирование дополнительного поля', 'Доступ к редактированию дополнительного поля', 'ru');
INSERT INTO shop_rbac_privileges_i18n (`id`, `title`, `description`, `locale`) VALUES (329, 'Создание групы полей', 'Доступ к созданию групы полей', 'ru');
INSERT INTO shop_rbac_privileges_i18n (`id`, `title`, `description`, `locale`) VALUES (330, 'Редактирование групы полей', 'Доступ к редактированию групы полей', 'ru');
INSERT INTO shop_rbac_privileges_i18n (`id`, `title`, `description`, `locale`) VALUES (331, 'Удаление групы полей', 'Доступ к удалению групы полей', 'ru');
INSERT INTO shop_rbac_privileges_i18n (`id`, `title`, `description`, `locale`) VALUES (332, 'cfcm::form_from_category_group', '', 'ru');
INSERT INTO shop_rbac_privileges_i18n (`id`, `title`, `description`, `locale`) VALUES (333, 'Получение атрибутов формы', 'Доступ к получению атрибутов формы', 'ru');
INSERT INTO shop_rbac_privileges_i18n (`id`, `title`, `description`, `locale`) VALUES (334, 'Сохранение важности', 'Доступ к сохранению важности', 'ru');
INSERT INTO shop_rbac_privileges_i18n (`id`, `title`, `description`, `locale`) VALUES (335, 'Отображение поля', 'Доступ к отображению поля', 'ru');
INSERT INTO shop_rbac_privileges_i18n (`id`, `title`, `description`, `locale`) VALUES (336, 'Получение адреса', 'Доступ к получению адреса', 'ru');
INSERT INTO shop_rbac_privileges_i18n (`id`, `title`, `description`, `locale`) VALUES (337, 'Получение формы', 'Доступ к форме', 'ru');
INSERT INTO shop_rbac_privileges_i18n (`id`, `title`, `description`, `locale`) VALUES (338, 'Управление комментариями', 'Доступ к управлению комментариями', 'ru');
INSERT INTO shop_rbac_privileges_i18n (`id`, `title`, `description`, `locale`) VALUES (339, 'Отображения списка комментариев', 'Доступ к отображению списка комментариев', 'ru');
INSERT INTO shop_rbac_privileges_i18n (`id`, `title`, `description`, `locale`) VALUES (340, 'Обработка подкомментариев', 'Доступ к обработке подкомментариев', 'ru');
INSERT INTO shop_rbac_privileges_i18n (`id`, `title`, `description`, `locale`) VALUES (341, 'comments::render', '', 'ru');
INSERT INTO shop_rbac_privileges_i18n (`id`, `title`, `description`, `locale`) VALUES (342, 'Редактирование комментария', 'Доступ к редактированию комментария', 'ru');
INSERT INTO shop_rbac_privileges_i18n (`id`, `title`, `description`, `locale`) VALUES (343, 'Обновление комментария', 'Доступ к обновлению комментария', 'ru');
INSERT INTO shop_rbac_privileges_i18n (`id`, `title`, `description`, `locale`) VALUES (344, 'Обновление статуса комментария', 'Доступ к обновлению статуса комментария', 'ru');
INSERT INTO shop_rbac_privileges_i18n (`id`, `title`, `description`, `locale`) VALUES (345, 'Удаление комментария', 'Доступ к удалению комментария', 'ru');
INSERT INTO shop_rbac_privileges_i18n (`id`, `title`, `description`, `locale`) VALUES (346, 'Множественное удаление комментариев', 'Доступ к множественному удалению комментариев', 'ru');
INSERT INTO shop_rbac_privileges_i18n (`id`, `title`, `description`, `locale`) VALUES (347, 'Отображение настроек модуля комментарии', 'Доступ к отображению настроек модуля комментарии', 'ru');
INSERT INTO shop_rbac_privileges_i18n (`id`, `title`, `description`, `locale`) VALUES (348, 'Обновление настроек комментариев', 'Доступ к обновлению настроек комментариев', 'ru');
INSERT INTO shop_rbac_privileges_i18n (`id`, `title`, `description`, `locale`) VALUES (349, 'Управление обратноей связью', 'Доступ к управлению обратной связью', 'ru');
INSERT INTO shop_rbac_privileges_i18n (`id`, `title`, `description`, `locale`) VALUES (350, 'Настройки модуля обратная связь', 'Доступ к настройкам модуля обратная связь', 'ru');
INSERT INTO shop_rbac_privileges_i18n (`id`, `title`, `description`, `locale`) VALUES (351, 'Получение настроек модуля обратная связь', 'Доступ к получению настроек модуля обратная связь', 'ru');
INSERT INTO shop_rbac_privileges_i18n (`id`, `title`, `description`, `locale`) VALUES (352, 'Управление галереей', 'Доступ к галерее', 'ru');
INSERT INTO shop_rbac_privileges_i18n (`id`, `title`, `description`, `locale`) VALUES (353, 'Список категорий галереи', 'Доступ к списку категорий галереи', 'ru');
INSERT INTO shop_rbac_privileges_i18n (`id`, `title`, `description`, `locale`) VALUES (354, 'Категория галереи', 'Доступ к категории галереи', 'ru');
INSERT INTO shop_rbac_privileges_i18n (`id`, `title`, `description`, `locale`) VALUES (355, 'Настройки галереи', 'Доступ к настройкам галереи', 'ru');
INSERT INTO shop_rbac_privileges_i18n (`id`, `title`, `description`, `locale`) VALUES (356, 'Создание альбома', 'Доступ к созданию альбома', 'ru');
INSERT INTO shop_rbac_privileges_i18n (`id`, `title`, `description`, `locale`) VALUES (357, 'Редактирование альбома', 'Доступ к редактированию альбома', 'ru');
INSERT INTO shop_rbac_privileges_i18n (`id`, `title`, `description`, `locale`) VALUES (358, 'Редактирование настроек альбома', 'Доступ к редактированию настроек альбома', 'ru');
INSERT INTO shop_rbac_privileges_i18n (`id`, `title`, `description`, `locale`) VALUES (359, 'Удаление альбома', 'Доступ к удалению альбома', 'ru');
INSERT INTO shop_rbac_privileges_i18n (`id`, `title`, `description`, `locale`) VALUES (360, 'Отображение формы содания альбома', 'Доступ к форме создания альбома', 'ru');
INSERT INTO shop_rbac_privileges_i18n (`id`, `title`, `description`, `locale`) VALUES (361, 'Редактирование альбома', 'Доступ к редактированию альбома', 'ru');
INSERT INTO shop_rbac_privileges_i18n (`id`, `title`, `description`, `locale`) VALUES (362, 'Редактирование изображения', 'Доступ к редактированию изображения', 'ru');
INSERT INTO shop_rbac_privileges_i18n (`id`, `title`, `description`, `locale`) VALUES (363, 'Переименование изображения', 'Доступ к переименованию изображения', 'ru');
INSERT INTO shop_rbac_privileges_i18n (`id`, `title`, `description`, `locale`) VALUES (364, 'Удаление изображения', 'Доступ к удалению изображения', 'ru');
INSERT INTO shop_rbac_privileges_i18n (`id`, `title`, `description`, `locale`) VALUES (365, 'Обновление информации', 'Доступ к обновлению информации', 'ru');
INSERT INTO shop_rbac_privileges_i18n (`id`, `title`, `description`, `locale`) VALUES (366, 'Смена порядка категорий', 'Доступ к смене порядка категорий', 'ru');
INSERT INTO shop_rbac_privileges_i18n (`id`, `title`, `description`, `locale`) VALUES (367, 'Смена порядка альбомов', 'Доступ к смене порядка альбомов', 'ru');
INSERT INTO shop_rbac_privileges_i18n (`id`, `title`, `description`, `locale`) VALUES (368, 'Смена порядка изображений', 'Доступ к смене порядка изображений', 'ru');
INSERT INTO shop_rbac_privileges_i18n (`id`, `title`, `description`, `locale`) VALUES (369, 'Отображение формы создания категории', 'Доступ к отображению формы создания категории', 'ru');
INSERT INTO shop_rbac_privileges_i18n (`id`, `title`, `description`, `locale`) VALUES (370, 'Создание категории', 'Доступ к созданию категории', 'ru');
INSERT INTO shop_rbac_privileges_i18n (`id`, `title`, `description`, `locale`) VALUES (371, 'Редактирование категории', 'Доступ к редактированию категории', 'ru');
INSERT INTO shop_rbac_privileges_i18n (`id`, `title`, `description`, `locale`) VALUES (372, 'Обновление категории', 'Доступ к обновлению категории', 'ru');
INSERT INTO shop_rbac_privileges_i18n (`id`, `title`, `description`, `locale`) VALUES (373, 'Удаление категории', 'Доступ к удалению категории', 'ru');
INSERT INTO shop_rbac_privileges_i18n (`id`, `title`, `description`, `locale`) VALUES (374, 'Загрузка изображений', 'Доступ к загрузке изображений', 'ru');
INSERT INTO shop_rbac_privileges_i18n (`id`, `title`, `description`, `locale`) VALUES (375, 'Загрузка архива', 'Доступ к загрузке архива', 'ru');
INSERT INTO shop_rbac_privileges_i18n (`id`, `title`, `description`, `locale`) VALUES (376, 'Управление модулем рассылки', 'Управление модулем рассылки', 'ru');
INSERT INTO shop_rbac_privileges_i18n (`id`, `title`, `description`, `locale`) VALUES (377, 'Отправка писем групам', 'Доступ к отправке писем групам', 'ru');
INSERT INTO shop_rbac_privileges_i18n (`id`, `title`, `description`, `locale`) VALUES (378, 'Отправка писем групам', 'Доступ к отправке писем групам', 'ru');
INSERT INTO shop_rbac_privileges_i18n (`id`, `title`, `description`, `locale`) VALUES (379, 'Отправка писем подписчикам', 'Доступк отправке писем подписчикам', 'ru');
INSERT INTO shop_rbac_privileges_i18n (`id`, `title`, `description`, `locale`) VALUES (380, 'Отправка писем подписчикам', 'Доступк отправке писем подписчикам', 'ru');
INSERT INTO shop_rbac_privileges_i18n (`id`, `title`, `description`, `locale`) VALUES (381, 'Отправка писем подписчикам', 'Доступк отправке писем подписчикам', 'ru');
INSERT INTO shop_rbac_privileges_i18n (`id`, `title`, `description`, `locale`) VALUES (382, 'Удаление подписчиков', 'Доступ к удалению подписчиков', 'ru');
INSERT INTO shop_rbac_privileges_i18n (`id`, `title`, `description`, `locale`) VALUES (383, 'Управление меню', 'Доступ к управлению меню', 'ru');
INSERT INTO shop_rbac_privileges_i18n (`id`, `title`, `description`, `locale`) VALUES (384, 'Список меню сайта', 'Доступ к списку меню сайта', 'ru');
INSERT INTO shop_rbac_privileges_i18n (`id`, `title`, `description`, `locale`) VALUES (385, 'Отображение меню', 'Доступ к отображению меню', 'ru');
INSERT INTO shop_rbac_privileges_i18n (`id`, `title`, `description`, `locale`) VALUES (386, 'menu::list_menu_items', '', 'ru');
INSERT INTO shop_rbac_privileges_i18n (`id`, `title`, `description`, `locale`) VALUES (387, 'Создание пункта меню', 'Доступ к созданию пункта меню', 'ru');
INSERT INTO shop_rbac_privileges_i18n (`id`, `title`, `description`, `locale`) VALUES (388, 'menu::display_selector', '', 'ru');
INSERT INTO shop_rbac_privileges_i18n (`id`, `title`, `description`, `locale`) VALUES (389, 'menu::get_name_by_id', '', 'ru');
INSERT INTO shop_rbac_privileges_i18n (`id`, `title`, `description`, `locale`) VALUES (390, 'Удаление пункта меню', 'Доступ к удалению пункта меню', 'ru');
INSERT INTO shop_rbac_privileges_i18n (`id`, `title`, `description`, `locale`) VALUES (391, 'Редактирование пункта меню', 'Доступ к редактированию пункта меню', 'ru');
INSERT INTO shop_rbac_privileges_i18n (`id`, `title`, `description`, `locale`) VALUES (392, 'menu::process_root', '', 'ru');
INSERT INTO shop_rbac_privileges_i18n (`id`, `title`, `description`, `locale`) VALUES (393, 'menu::insert_menu_item', '', 'ru');
INSERT INTO shop_rbac_privileges_i18n (`id`, `title`, `description`, `locale`) VALUES (394, 'Смена порядка меню', 'Доступ к смене порядка меню', 'ru');
INSERT INTO shop_rbac_privileges_i18n (`id`, `title`, `description`, `locale`) VALUES (395, 'Создание меню', 'Доступ к созданию меню', 'ru');
INSERT INTO shop_rbac_privileges_i18n (`id`, `title`, `description`, `locale`) VALUES (396, 'Редактирование меню', 'Доступ к редактированию меню', 'ru');
INSERT INTO shop_rbac_privileges_i18n (`id`, `title`, `description`, `locale`) VALUES (397, 'Обновление меню', 'Доступ к обновлению меню', 'ru');
INSERT INTO shop_rbac_privileges_i18n (`id`, `title`, `description`, `locale`) VALUES (398, 'Проверка данных меню', 'Доступ к проверке данных меню', 'ru');
INSERT INTO shop_rbac_privileges_i18n (`id`, `title`, `description`, `locale`) VALUES (399, 'Удаление меню', 'Доступ к удалению меню', 'ru');
INSERT INTO shop_rbac_privileges_i18n (`id`, `title`, `description`, `locale`) VALUES (400, 'Отображение формы создания меню', 'Доступ к отображению формы создания меню', 'ru');
INSERT INTO shop_rbac_privileges_i18n (`id`, `title`, `description`, `locale`) VALUES (401, 'Получение списка страниц', 'Доступ к получению списка страниц', 'ru');
INSERT INTO shop_rbac_privileges_i18n (`id`, `title`, `description`, `locale`) VALUES (402, 'Поиск страниц', 'Доступ к поиску страниц', 'ru');
INSERT INTO shop_rbac_privileges_i18n (`id`, `title`, `description`, `locale`) VALUES (403, 'menu::get_item', '', 'ru');
INSERT INTO shop_rbac_privileges_i18n (`id`, `title`, `description`, `locale`) VALUES (404, 'menu::display_tpl', '', 'ru');
INSERT INTO shop_rbac_privileges_i18n (`id`, `title`, `description`, `locale`) VALUES (405, 'menu::fetch_tpl', '', 'ru');
INSERT INTO shop_rbac_privileges_i18n (`id`, `title`, `description`, `locale`) VALUES (406, 'Отображение окна перевода пункта меню', 'Доступ к отображению окна перевода пункта меню', 'ru');
INSERT INTO shop_rbac_privileges_i18n (`id`, `title`, `description`, `locale`) VALUES (407, 'Перевод пункта меню', 'Доступ к переводу пункта меню', 'ru');
INSERT INTO shop_rbac_privileges_i18n (`id`, `title`, `description`, `locale`) VALUES (408, 'Получение списка языков', 'Доступ к получению списка языков', 'ru');
INSERT INTO shop_rbac_privileges_i18n (`id`, `title`, `description`, `locale`) VALUES (409, 'menu::render', '', 'ru');
INSERT INTO shop_rbac_privileges_i18n (`id`, `title`, `description`, `locale`) VALUES (410, 'Смена активности меню', 'Доступ к смене активности меню', 'ru');
INSERT INTO shop_rbac_privileges_i18n (`id`, `title`, `description`, `locale`) VALUES (411, 'Получение дочерних елементов', 'Доступ к получению дочерних елементов', 'ru');
INSERT INTO shop_rbac_privileges_i18n (`id`, `title`, `description`, `locale`) VALUES (412, 'Управление rss', 'Управление rss', 'ru');
INSERT INTO shop_rbac_privileges_i18n (`id`, `title`, `description`, `locale`) VALUES (413, 'Управление rss', 'Управление rss', 'ru');
INSERT INTO shop_rbac_privileges_i18n (`id`, `title`, `description`, `locale`) VALUES (414, 'rss::render', '', 'ru');
INSERT INTO shop_rbac_privileges_i18n (`id`, `title`, `description`, `locale`) VALUES (415, 'rss::settings_update', '', 'ru');
INSERT INTO shop_rbac_privileges_i18n (`id`, `title`, `description`, `locale`) VALUES (416, 'rss::display_tpl', '', 'ru');
INSERT INTO shop_rbac_privileges_i18n (`id`, `title`, `description`, `locale`) VALUES (417, 'rss::fetch_tpl', '', 'ru');
INSERT INTO shop_rbac_privileges_i18n (`id`, `title`, `description`, `locale`) VALUES (418, 'Управление шаблонами писем', 'Доступ к управлению шаблонами писем', 'ru');
INSERT INTO shop_rbac_privileges_i18n (`id`, `title`, `description`, `locale`) VALUES (419, 'Создание шаблона письма', 'Доступ к созданию шаблона письма', 'ru');
INSERT INTO shop_rbac_privileges_i18n (`id`, `title`, `description`, `locale`) VALUES (420, 'Редактирование шаблона письма', 'Доступ к редактированию шаблона письма', 'ru');
INSERT INTO shop_rbac_privileges_i18n (`id`, `title`, `description`, `locale`) VALUES (421, 'sample_mail::render', '', 'ru');
INSERT INTO shop_rbac_privileges_i18n (`id`, `title`, `description`, `locale`) VALUES (422, 'Список шаблонов писем', 'Доступ к списку шаблонов писем', 'ru');
INSERT INTO shop_rbac_privileges_i18n (`id`, `title`, `description`, `locale`) VALUES (423, 'Удаление шаблона письма', 'Доступ к удалению шаблона письма', 'ru');
INSERT INTO shop_rbac_privileges_i18n (`id`, `title`, `description`, `locale`) VALUES (424, 'sample_module::__construct', '', 'ru');
INSERT INTO shop_rbac_privileges_i18n (`id`, `title`, `description`, `locale`) VALUES (425, 'sample_module::index', '', 'ru');
INSERT INTO shop_rbac_privileges_i18n (`id`, `title`, `description`, `locale`) VALUES (426, 'Управление кнопками соцсетей', 'Доступ к управлению кнопками соцсетей', 'ru');
INSERT INTO shop_rbac_privileges_i18n (`id`, `title`, `description`, `locale`) VALUES (427, 'Управление кнопками соцсетей', 'Доступ к управлению кнопками соцсетей', 'ru');
INSERT INTO shop_rbac_privileges_i18n (`id`, `title`, `description`, `locale`) VALUES (428, 'Обновление настроек модуля кнопок соцсетей', 'Доступ к обновлению настроек модуля кнопок соцсетей', 'ru');
INSERT INTO shop_rbac_privileges_i18n (`id`, `title`, `description`, `locale`) VALUES (429, 'Получение настроек модуля кнопок соцсетей', 'Доступ к настройкам модуля кнопок соцсетей', 'ru');
INSERT INTO shop_rbac_privileges_i18n (`id`, `title`, `description`, `locale`) VALUES (430, 'share::render', '', 'ru');
INSERT INTO shop_rbac_privileges_i18n (`id`, `title`, `description`, `locale`) VALUES (431, 'Управление картой сайта', 'Доступ к управлению картой сайта', 'ru');
INSERT INTO shop_rbac_privileges_i18n (`id`, `title`, `description`, `locale`) VALUES (432, 'Настройки карты сайта', 'Доступ к настройкам карты сайта', 'ru');
INSERT INTO shop_rbac_privileges_i18n (`id`, `title`, `description`, `locale`) VALUES (433, 'sitemap::_load_settings', '', 'ru');
INSERT INTO shop_rbac_privileges_i18n (`id`, `title`, `description`, `locale`) VALUES (434, 'Обновление настроек катры сайта', 'Доступ к обновлению настроек карты сайта', 'ru');
INSERT INTO shop_rbac_privileges_i18n (`id`, `title`, `description`, `locale`) VALUES (435, 'sitemap::display_tpl', '', 'ru');
INSERT INTO shop_rbac_privileges_i18n (`id`, `title`, `description`, `locale`) VALUES (436, 'sitemap::fetch_tpl', '', 'ru');
INSERT INTO shop_rbac_privileges_i18n (`id`, `title`, `description`, `locale`) VALUES (437, 'sitemap::render', '', 'ru');
INSERT INTO shop_rbac_privileges_i18n (`id`, `title`, `description`, `locale`) VALUES (438, 'Управление интеграцией с соцсетями', 'Доступ к управлению интеграцией с соцсетями', 'ru');
INSERT INTO shop_rbac_privileges_i18n (`id`, `title`, `description`, `locale`) VALUES (439, 'Настройки модуля интеграции с соцсетями', 'Достпу к настройкам модуля интеграции с соцсетями', 'ru');
INSERT INTO shop_rbac_privileges_i18n (`id`, `title`, `description`, `locale`) VALUES (440, 'Обновление настроек модуля', 'Доступ к обновлению настроек модуля', 'ru');
INSERT INTO shop_rbac_privileges_i18n (`id`, `title`, `description`, `locale`) VALUES (441, 'social_servises::get_fsettings', '', 'ru');
INSERT INTO shop_rbac_privileges_i18n (`id`, `title`, `description`, `locale`) VALUES (442, 'social_servises::get_vsettings', '', 'ru');
INSERT INTO shop_rbac_privileges_i18n (`id`, `title`, `description`, `locale`) VALUES (443, 'social_servises::_get_templates', '', 'ru');
INSERT INTO shop_rbac_privileges_i18n (`id`, `title`, `description`, `locale`) VALUES (444, 'social_servises::render', '', 'ru');
INSERT INTO shop_rbac_privileges_i18n (`id`, `title`, `description`, `locale`) VALUES (445, 'Редактор шаблонов', 'Доступ к редактору шаблонов', 'ru');
INSERT INTO shop_rbac_privileges_i18n (`id`, `title`, `description`, `locale`) VALUES (446, 'template_editor::render', '', 'ru');
INSERT INTO shop_rbac_privileges_i18n (`id`, `title`, `description`, `locale`) VALUES (447, 'Управление редиректами с удаленнных товаров', 'Управление редиректами с удаленнных товаров', 'ru');
INSERT INTO shop_rbac_privileges_i18n (`id`, `title`, `description`, `locale`) VALUES (448, 'Список редиректов', 'Доступ к списку редиректов', 'ru');
INSERT INTO shop_rbac_privileges_i18n (`id`, `title`, `description`, `locale`) VALUES (449, 'Создание редиректа', 'Доступ к созданию редиректа', 'ru');
INSERT INTO shop_rbac_privileges_i18n (`id`, `title`, `description`, `locale`) VALUES (450, 'Редактирование редиректа', 'Доступ к редактированию редиректа', 'ru');
INSERT INTO shop_rbac_privileges_i18n (`id`, `title`, `description`, `locale`) VALUES (451, 'Удаление редаректа', 'Доступ к удалению редиректа', 'ru');
INSERT INTO shop_rbac_privileges_i18n (`id`, `title`, `description`, `locale`) VALUES (452, 'Управление пользователями', 'Доступ к управлению пользователями', 'ru');
INSERT INTO shop_rbac_privileges_i18n (`id`, `title`, `description`, `locale`) VALUES (453, 'Список пользователей', 'Доступ к списку пользователей', 'ru');
INSERT INTO shop_rbac_privileges_i18n (`id`, `title`, `description`, `locale`) VALUES (454, 'user_manager::set_tpl_roles', '', 'ru');
INSERT INTO shop_rbac_privileges_i18n (`id`, `title`, `description`, `locale`) VALUES (455, 'user_manager::getRolesTable', '', 'ru');
INSERT INTO shop_rbac_privileges_i18n (`id`, `title`, `description`, `locale`) VALUES (456, 'Создание списка юзеров', 'Доступ к созданию списка юзеров', 'ru');
INSERT INTO shop_rbac_privileges_i18n (`id`, `title`, `description`, `locale`) VALUES (457, 'user_manager::auto_complit', '', 'ru');
INSERT INTO shop_rbac_privileges_i18n (`id`, `title`, `description`, `locale`) VALUES (458, 'Создание юзера', 'Доступ к созданию юзера', 'ru');
INSERT INTO shop_rbac_privileges_i18n (`id`, `title`, `description`, `locale`) VALUES (459, 'user_manager::actions', '', 'ru');
INSERT INTO shop_rbac_privileges_i18n (`id`, `title`, `description`, `locale`) VALUES (460, 'Поиск пользователей', 'Доступ к поиску пользователей', 'ru');
INSERT INTO shop_rbac_privileges_i18n (`id`, `title`, `description`, `locale`) VALUES (461, 'Редактирование юзера', 'Доступ к редактированию юзера', 'ru');
INSERT INTO shop_rbac_privileges_i18n (`id`, `title`, `description`, `locale`) VALUES (462, 'Обновление информации о пользователе', 'Доступ к обновлению информации о пользователе', 'ru');
INSERT INTO shop_rbac_privileges_i18n (`id`, `title`, `description`, `locale`) VALUES (463, 'user_manager::groups_index', '', 'ru');
INSERT INTO shop_rbac_privileges_i18n (`id`, `title`, `description`, `locale`) VALUES (464, 'user_manager::create', '', 'ru');
INSERT INTO shop_rbac_privileges_i18n (`id`, `title`, `description`, `locale`) VALUES (465, 'user_manager::edit', '', 'ru');
INSERT INTO shop_rbac_privileges_i18n (`id`, `title`, `description`, `locale`) VALUES (466, 'user_manager::save', '', 'ru');
INSERT INTO shop_rbac_privileges_i18n (`id`, `title`, `description`, `locale`) VALUES (467, 'user_manager::delete', '', 'ru');
INSERT INTO shop_rbac_privileges_i18n (`id`, `title`, `description`, `locale`) VALUES (468, 'Удаление пользователя', 'Доступ к удалению пользвателя', 'ru');
INSERT INTO shop_rbac_privileges_i18n (`id`, `title`, `description`, `locale`) VALUES (469, 'user_manager::update_role_perms', '', 'ru');
INSERT INTO shop_rbac_privileges_i18n (`id`, `title`, `description`, `locale`) VALUES (470, 'user_manager::show_edit_prems_tpl', '', 'ru');
INSERT INTO shop_rbac_privileges_i18n (`id`, `title`, `description`, `locale`) VALUES (471, 'user_manager::get_permissions_table', '', 'ru');
INSERT INTO shop_rbac_privileges_i18n (`id`, `title`, `description`, `locale`) VALUES (472, 'user_manager::get_group_names', '', 'ru');
INSERT INTO shop_rbac_privileges_i18n (`id`, `title`, `description`, `locale`) VALUES (474, 'Список виджетов', 'Доступ к списку виджетов', 'ru');
INSERT INTO shop_rbac_privileges_i18n (`id`, `title`, `description`, `locale`) VALUES (475, 'Создание виджета', 'Доступ к созданию виджета', 'ru');
INSERT INTO shop_rbac_privileges_i18n (`id`, `title`, `description`, `locale`) VALUES (476, 'Отображение формы создания виджета', 'Доступ к отображению формы создания виджета', 'ru');
INSERT INTO shop_rbac_privileges_i18n (`id`, `title`, `description`, `locale`) VALUES (477, 'Редактирование виджетов', 'Доступ к отображению формы создания виджета', 'ru');
INSERT INTO shop_rbac_privileges_i18n (`id`, `title`, `description`, `locale`) VALUES (478, 'Обновление виджета', 'Доступ к обновлению виджетов', 'ru');
INSERT INTO shop_rbac_privileges_i18n (`id`, `title`, `description`, `locale`) VALUES (479, 'Обновление настроек виджета', 'Доступ к обновлению настроек виджета', 'ru');
INSERT INTO shop_rbac_privileges_i18n (`id`, `title`, `description`, `locale`) VALUES (480, 'Удаление виджета', 'Доступ к удалению виджета', 'ru');
INSERT INTO shop_rbac_privileges_i18n (`id`, `title`, `description`, `locale`) VALUES (482, 'Редактирование html виджета', 'Доступ к редактированию html виджета', 'ru');
INSERT INTO shop_rbac_privileges_i18n (`id`, `title`, `description`, `locale`) VALUES (483, 'Редактирование модульного виджета', 'Доступ к редактированию модульного виджета', 'ru');


#
# TABLE STRUCTURE FOR: shop_rbac_roles
#

DROP TABLE IF EXISTS shop_rbac_roles;

CREATE TABLE `shop_rbac_roles` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `name` varchar(255) NOT NULL,
  `importance` int(11) DEFAULT NULL,
  `description` varchar(255) DEFAULT NULL,
  PRIMARY KEY (`id`),
  UNIQUE KEY `unique_name` (`name`)
) ENGINE=MyISAM AUTO_INCREMENT=4 DEFAULT CHARSET=utf8;

INSERT INTO shop_rbac_roles (`id`, `name`, `importance`, `description`) VALUES (1, 'Administrator', 1, NULL);
INSERT INTO shop_rbac_roles (`id`, `name`, `importance`, `description`) VALUES (2, 'Sales_manager', 2, NULL);
INSERT INTO shop_rbac_roles (`id`, `name`, `importance`, `description`) VALUES (3, 'Content_manager', 3, NULL);


#
# TABLE STRUCTURE FOR: shop_rbac_roles_i18n
#

DROP TABLE IF EXISTS shop_rbac_roles_i18n;

CREATE TABLE `shop_rbac_roles_i18n` (
  `id` int(11) NOT NULL,
  `alt_name` varchar(45) DEFAULT NULL,
  `locale` varchar(5) NOT NULL,
  `description` varchar(200) DEFAULT NULL,
  KEY `role_id_idx` (`id`)
) ENGINE=MyISAM DEFAULT CHARSET=utf8;

INSERT INTO shop_rbac_roles_i18n (`id`, `alt_name`, `locale`, `description`) VALUES (1, 'Администратор', 'ru', 'Доступны все елементы управления админкой');
INSERT INTO shop_rbac_roles_i18n (`id`, `alt_name`, `locale`, `description`) VALUES (2, 'Продавец', 'ru', 'Имеет доступ только к заказам и пользователям');
INSERT INTO shop_rbac_roles_i18n (`id`, `alt_name`, `locale`, `description`) VALUES (3, 'Контент-менеджер', 'ru', 'Доступ к вкладке товары, наполнитель контента');


#
# TABLE STRUCTURE FOR: shop_rbac_roles_privileges
#

DROP TABLE IF EXISTS shop_rbac_roles_privileges;

CREATE TABLE `shop_rbac_roles_privileges` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `role_id` int(11) NOT NULL,
  `privilege_id` int(11) NOT NULL,
  PRIMARY KEY (`id`),
  UNIQUE KEY `rolepriv` (`role_id`,`privilege_id`),
  KEY `shop_rbac_roles_privileges_FK_2` (`privilege_id`)
) ENGINE=MyISAM AUTO_INCREMENT=612 DEFAULT CHARSET=utf8;

INSERT INTO shop_rbac_roles_privileges (`id`, `role_id`, `privilege_id`) VALUES (1, 1, 1);
INSERT INTO shop_rbac_roles_privileges (`id`, `role_id`, `privilege_id`) VALUES (2, 1, 2);
INSERT INTO shop_rbac_roles_privileges (`id`, `role_id`, `privilege_id`) VALUES (3, 1, 3);
INSERT INTO shop_rbac_roles_privileges (`id`, `role_id`, `privilege_id`) VALUES (4, 1, 4);
INSERT INTO shop_rbac_roles_privileges (`id`, `role_id`, `privilege_id`) VALUES (5, 1, 5);
INSERT INTO shop_rbac_roles_privileges (`id`, `role_id`, `privilege_id`) VALUES (6, 1, 6);
INSERT INTO shop_rbac_roles_privileges (`id`, `role_id`, `privilege_id`) VALUES (7, 1, 7);
INSERT INTO shop_rbac_roles_privileges (`id`, `role_id`, `privilege_id`) VALUES (8, 1, 8);
INSERT INTO shop_rbac_roles_privileges (`id`, `role_id`, `privilege_id`) VALUES (9, 1, 9);
INSERT INTO shop_rbac_roles_privileges (`id`, `role_id`, `privilege_id`) VALUES (10, 1, 10);
INSERT INTO shop_rbac_roles_privileges (`id`, `role_id`, `privilege_id`) VALUES (11, 1, 11);
INSERT INTO shop_rbac_roles_privileges (`id`, `role_id`, `privilege_id`) VALUES (12, 1, 12);
INSERT INTO shop_rbac_roles_privileges (`id`, `role_id`, `privilege_id`) VALUES (13, 1, 13);
INSERT INTO shop_rbac_roles_privileges (`id`, `role_id`, `privilege_id`) VALUES (14, 1, 14);
INSERT INTO shop_rbac_roles_privileges (`id`, `role_id`, `privilege_id`) VALUES (15, 1, 15);
INSERT INTO shop_rbac_roles_privileges (`id`, `role_id`, `privilege_id`) VALUES (16, 1, 16);
INSERT INTO shop_rbac_roles_privileges (`id`, `role_id`, `privilege_id`) VALUES (17, 1, 17);
INSERT INTO shop_rbac_roles_privileges (`id`, `role_id`, `privilege_id`) VALUES (18, 1, 18);
INSERT INTO shop_rbac_roles_privileges (`id`, `role_id`, `privilege_id`) VALUES (19, 1, 19);
INSERT INTO shop_rbac_roles_privileges (`id`, `role_id`, `privilege_id`) VALUES (20, 1, 20);
INSERT INTO shop_rbac_roles_privileges (`id`, `role_id`, `privilege_id`) VALUES (21, 1, 21);
INSERT INTO shop_rbac_roles_privileges (`id`, `role_id`, `privilege_id`) VALUES (22, 1, 22);
INSERT INTO shop_rbac_roles_privileges (`id`, `role_id`, `privilege_id`) VALUES (23, 1, 23);
INSERT INTO shop_rbac_roles_privileges (`id`, `role_id`, `privilege_id`) VALUES (24, 1, 24);
INSERT INTO shop_rbac_roles_privileges (`id`, `role_id`, `privilege_id`) VALUES (25, 1, 25);
INSERT INTO shop_rbac_roles_privileges (`id`, `role_id`, `privilege_id`) VALUES (26, 1, 26);
INSERT INTO shop_rbac_roles_privileges (`id`, `role_id`, `privilege_id`) VALUES (27, 1, 27);
INSERT INTO shop_rbac_roles_privileges (`id`, `role_id`, `privilege_id`) VALUES (28, 1, 28);
INSERT INTO shop_rbac_roles_privileges (`id`, `role_id`, `privilege_id`) VALUES (29, 1, 29);
INSERT INTO shop_rbac_roles_privileges (`id`, `role_id`, `privilege_id`) VALUES (30, 1, 30);
INSERT INTO shop_rbac_roles_privileges (`id`, `role_id`, `privilege_id`) VALUES (31, 1, 31);
INSERT INTO shop_rbac_roles_privileges (`id`, `role_id`, `privilege_id`) VALUES (32, 1, 32);
INSERT INTO shop_rbac_roles_privileges (`id`, `role_id`, `privilege_id`) VALUES (33, 1, 33);
INSERT INTO shop_rbac_roles_privileges (`id`, `role_id`, `privilege_id`) VALUES (34, 1, 34);
INSERT INTO shop_rbac_roles_privileges (`id`, `role_id`, `privilege_id`) VALUES (35, 1, 35);
INSERT INTO shop_rbac_roles_privileges (`id`, `role_id`, `privilege_id`) VALUES (36, 1, 36);
INSERT INTO shop_rbac_roles_privileges (`id`, `role_id`, `privilege_id`) VALUES (37, 1, 37);
INSERT INTO shop_rbac_roles_privileges (`id`, `role_id`, `privilege_id`) VALUES (38, 1, 38);
INSERT INTO shop_rbac_roles_privileges (`id`, `role_id`, `privilege_id`) VALUES (39, 1, 39);
INSERT INTO shop_rbac_roles_privileges (`id`, `role_id`, `privilege_id`) VALUES (40, 1, 40);
INSERT INTO shop_rbac_roles_privileges (`id`, `role_id`, `privilege_id`) VALUES (41, 1, 41);
INSERT INTO shop_rbac_roles_privileges (`id`, `role_id`, `privilege_id`) VALUES (42, 1, 42);
INSERT INTO shop_rbac_roles_privileges (`id`, `role_id`, `privilege_id`) VALUES (43, 1, 43);
INSERT INTO shop_rbac_roles_privileges (`id`, `role_id`, `privilege_id`) VALUES (44, 1, 44);
INSERT INTO shop_rbac_roles_privileges (`id`, `role_id`, `privilege_id`) VALUES (45, 1, 45);
INSERT INTO shop_rbac_roles_privileges (`id`, `role_id`, `privilege_id`) VALUES (46, 1, 46);
INSERT INTO shop_rbac_roles_privileges (`id`, `role_id`, `privilege_id`) VALUES (47, 1, 47);
INSERT INTO shop_rbac_roles_privileges (`id`, `role_id`, `privilege_id`) VALUES (48, 1, 48);
INSERT INTO shop_rbac_roles_privileges (`id`, `role_id`, `privilege_id`) VALUES (49, 1, 49);
INSERT INTO shop_rbac_roles_privileges (`id`, `role_id`, `privilege_id`) VALUES (50, 1, 50);
INSERT INTO shop_rbac_roles_privileges (`id`, `role_id`, `privilege_id`) VALUES (51, 1, 51);
INSERT INTO shop_rbac_roles_privileges (`id`, `role_id`, `privilege_id`) VALUES (52, 1, 52);
INSERT INTO shop_rbac_roles_privileges (`id`, `role_id`, `privilege_id`) VALUES (53, 1, 53);
INSERT INTO shop_rbac_roles_privileges (`id`, `role_id`, `privilege_id`) VALUES (54, 1, 54);
INSERT INTO shop_rbac_roles_privileges (`id`, `role_id`, `privilege_id`) VALUES (55, 1, 55);
INSERT INTO shop_rbac_roles_privileges (`id`, `role_id`, `privilege_id`) VALUES (56, 1, 56);
INSERT INTO shop_rbac_roles_privileges (`id`, `role_id`, `privilege_id`) VALUES (57, 1, 57);
INSERT INTO shop_rbac_roles_privileges (`id`, `role_id`, `privilege_id`) VALUES (58, 1, 58);
INSERT INTO shop_rbac_roles_privileges (`id`, `role_id`, `privilege_id`) VALUES (59, 1, 59);
INSERT INTO shop_rbac_roles_privileges (`id`, `role_id`, `privilege_id`) VALUES (60, 1, 60);
INSERT INTO shop_rbac_roles_privileges (`id`, `role_id`, `privilege_id`) VALUES (61, 1, 61);
INSERT INTO shop_rbac_roles_privileges (`id`, `role_id`, `privilege_id`) VALUES (62, 1, 62);
INSERT INTO shop_rbac_roles_privileges (`id`, `role_id`, `privilege_id`) VALUES (63, 1, 63);
INSERT INTO shop_rbac_roles_privileges (`id`, `role_id`, `privilege_id`) VALUES (64, 1, 64);
INSERT INTO shop_rbac_roles_privileges (`id`, `role_id`, `privilege_id`) VALUES (65, 1, 65);
INSERT INTO shop_rbac_roles_privileges (`id`, `role_id`, `privilege_id`) VALUES (66, 1, 66);
INSERT INTO shop_rbac_roles_privileges (`id`, `role_id`, `privilege_id`) VALUES (67, 1, 67);
INSERT INTO shop_rbac_roles_privileges (`id`, `role_id`, `privilege_id`) VALUES (68, 1, 68);
INSERT INTO shop_rbac_roles_privileges (`id`, `role_id`, `privilege_id`) VALUES (69, 1, 69);
INSERT INTO shop_rbac_roles_privileges (`id`, `role_id`, `privilege_id`) VALUES (70, 1, 70);
INSERT INTO shop_rbac_roles_privileges (`id`, `role_id`, `privilege_id`) VALUES (71, 1, 71);
INSERT INTO shop_rbac_roles_privileges (`id`, `role_id`, `privilege_id`) VALUES (72, 1, 72);
INSERT INTO shop_rbac_roles_privileges (`id`, `role_id`, `privilege_id`) VALUES (73, 1, 73);
INSERT INTO shop_rbac_roles_privileges (`id`, `role_id`, `privilege_id`) VALUES (74, 1, 74);
INSERT INTO shop_rbac_roles_privileges (`id`, `role_id`, `privilege_id`) VALUES (75, 1, 75);
INSERT INTO shop_rbac_roles_privileges (`id`, `role_id`, `privilege_id`) VALUES (76, 1, 76);
INSERT INTO shop_rbac_roles_privileges (`id`, `role_id`, `privilege_id`) VALUES (77, 1, 77);
INSERT INTO shop_rbac_roles_privileges (`id`, `role_id`, `privilege_id`) VALUES (78, 1, 78);
INSERT INTO shop_rbac_roles_privileges (`id`, `role_id`, `privilege_id`) VALUES (79, 1, 79);
INSERT INTO shop_rbac_roles_privileges (`id`, `role_id`, `privilege_id`) VALUES (80, 1, 80);
INSERT INTO shop_rbac_roles_privileges (`id`, `role_id`, `privilege_id`) VALUES (81, 1, 81);
INSERT INTO shop_rbac_roles_privileges (`id`, `role_id`, `privilege_id`) VALUES (82, 1, 82);
INSERT INTO shop_rbac_roles_privileges (`id`, `role_id`, `privilege_id`) VALUES (83, 1, 83);
INSERT INTO shop_rbac_roles_privileges (`id`, `role_id`, `privilege_id`) VALUES (84, 1, 84);
INSERT INTO shop_rbac_roles_privileges (`id`, `role_id`, `privilege_id`) VALUES (85, 1, 85);
INSERT INTO shop_rbac_roles_privileges (`id`, `role_id`, `privilege_id`) VALUES (86, 1, 86);
INSERT INTO shop_rbac_roles_privileges (`id`, `role_id`, `privilege_id`) VALUES (87, 1, 87);
INSERT INTO shop_rbac_roles_privileges (`id`, `role_id`, `privilege_id`) VALUES (88, 1, 88);
INSERT INTO shop_rbac_roles_privileges (`id`, `role_id`, `privilege_id`) VALUES (89, 1, 89);
INSERT INTO shop_rbac_roles_privileges (`id`, `role_id`, `privilege_id`) VALUES (90, 1, 90);
INSERT INTO shop_rbac_roles_privileges (`id`, `role_id`, `privilege_id`) VALUES (91, 1, 91);
INSERT INTO shop_rbac_roles_privileges (`id`, `role_id`, `privilege_id`) VALUES (92, 1, 92);
INSERT INTO shop_rbac_roles_privileges (`id`, `role_id`, `privilege_id`) VALUES (93, 1, 93);
INSERT INTO shop_rbac_roles_privileges (`id`, `role_id`, `privilege_id`) VALUES (94, 1, 94);
INSERT INTO shop_rbac_roles_privileges (`id`, `role_id`, `privilege_id`) VALUES (95, 1, 95);
INSERT INTO shop_rbac_roles_privileges (`id`, `role_id`, `privilege_id`) VALUES (96, 1, 96);
INSERT INTO shop_rbac_roles_privileges (`id`, `role_id`, `privilege_id`) VALUES (97, 1, 97);
INSERT INTO shop_rbac_roles_privileges (`id`, `role_id`, `privilege_id`) VALUES (98, 1, 98);
INSERT INTO shop_rbac_roles_privileges (`id`, `role_id`, `privilege_id`) VALUES (99, 1, 99);
INSERT INTO shop_rbac_roles_privileges (`id`, `role_id`, `privilege_id`) VALUES (100, 1, 100);
INSERT INTO shop_rbac_roles_privileges (`id`, `role_id`, `privilege_id`) VALUES (101, 1, 101);
INSERT INTO shop_rbac_roles_privileges (`id`, `role_id`, `privilege_id`) VALUES (102, 1, 102);
INSERT INTO shop_rbac_roles_privileges (`id`, `role_id`, `privilege_id`) VALUES (103, 1, 103);
INSERT INTO shop_rbac_roles_privileges (`id`, `role_id`, `privilege_id`) VALUES (104, 1, 104);
INSERT INTO shop_rbac_roles_privileges (`id`, `role_id`, `privilege_id`) VALUES (105, 1, 105);
INSERT INTO shop_rbac_roles_privileges (`id`, `role_id`, `privilege_id`) VALUES (106, 1, 106);
INSERT INTO shop_rbac_roles_privileges (`id`, `role_id`, `privilege_id`) VALUES (107, 1, 107);
INSERT INTO shop_rbac_roles_privileges (`id`, `role_id`, `privilege_id`) VALUES (108, 1, 108);
INSERT INTO shop_rbac_roles_privileges (`id`, `role_id`, `privilege_id`) VALUES (109, 1, 109);
INSERT INTO shop_rbac_roles_privileges (`id`, `role_id`, `privilege_id`) VALUES (110, 1, 110);
INSERT INTO shop_rbac_roles_privileges (`id`, `role_id`, `privilege_id`) VALUES (111, 1, 111);
INSERT INTO shop_rbac_roles_privileges (`id`, `role_id`, `privilege_id`) VALUES (112, 1, 112);
INSERT INTO shop_rbac_roles_privileges (`id`, `role_id`, `privilege_id`) VALUES (113, 1, 113);
INSERT INTO shop_rbac_roles_privileges (`id`, `role_id`, `privilege_id`) VALUES (114, 1, 114);
INSERT INTO shop_rbac_roles_privileges (`id`, `role_id`, `privilege_id`) VALUES (115, 1, 115);
INSERT INTO shop_rbac_roles_privileges (`id`, `role_id`, `privilege_id`) VALUES (116, 1, 116);
INSERT INTO shop_rbac_roles_privileges (`id`, `role_id`, `privilege_id`) VALUES (117, 1, 117);
INSERT INTO shop_rbac_roles_privileges (`id`, `role_id`, `privilege_id`) VALUES (118, 1, 118);
INSERT INTO shop_rbac_roles_privileges (`id`, `role_id`, `privilege_id`) VALUES (119, 1, 119);
INSERT INTO shop_rbac_roles_privileges (`id`, `role_id`, `privilege_id`) VALUES (120, 1, 120);
INSERT INTO shop_rbac_roles_privileges (`id`, `role_id`, `privilege_id`) VALUES (121, 1, 121);
INSERT INTO shop_rbac_roles_privileges (`id`, `role_id`, `privilege_id`) VALUES (122, 1, 122);
INSERT INTO shop_rbac_roles_privileges (`id`, `role_id`, `privilege_id`) VALUES (123, 1, 123);
INSERT INTO shop_rbac_roles_privileges (`id`, `role_id`, `privilege_id`) VALUES (124, 1, 124);
INSERT INTO shop_rbac_roles_privileges (`id`, `role_id`, `privilege_id`) VALUES (125, 1, 125);
INSERT INTO shop_rbac_roles_privileges (`id`, `role_id`, `privilege_id`) VALUES (126, 1, 126);
INSERT INTO shop_rbac_roles_privileges (`id`, `role_id`, `privilege_id`) VALUES (127, 1, 127);
INSERT INTO shop_rbac_roles_privileges (`id`, `role_id`, `privilege_id`) VALUES (128, 1, 128);
INSERT INTO shop_rbac_roles_privileges (`id`, `role_id`, `privilege_id`) VALUES (129, 1, 129);
INSERT INTO shop_rbac_roles_privileges (`id`, `role_id`, `privilege_id`) VALUES (130, 1, 130);
INSERT INTO shop_rbac_roles_privileges (`id`, `role_id`, `privilege_id`) VALUES (131, 1, 131);
INSERT INTO shop_rbac_roles_privileges (`id`, `role_id`, `privilege_id`) VALUES (132, 1, 132);
INSERT INTO shop_rbac_roles_privileges (`id`, `role_id`, `privilege_id`) VALUES (133, 1, 133);
INSERT INTO shop_rbac_roles_privileges (`id`, `role_id`, `privilege_id`) VALUES (134, 1, 134);
INSERT INTO shop_rbac_roles_privileges (`id`, `role_id`, `privilege_id`) VALUES (135, 1, 135);
INSERT INTO shop_rbac_roles_privileges (`id`, `role_id`, `privilege_id`) VALUES (136, 1, 136);
INSERT INTO shop_rbac_roles_privileges (`id`, `role_id`, `privilege_id`) VALUES (137, 1, 137);
INSERT INTO shop_rbac_roles_privileges (`id`, `role_id`, `privilege_id`) VALUES (138, 1, 138);
INSERT INTO shop_rbac_roles_privileges (`id`, `role_id`, `privilege_id`) VALUES (139, 1, 139);
INSERT INTO shop_rbac_roles_privileges (`id`, `role_id`, `privilege_id`) VALUES (140, 1, 140);
INSERT INTO shop_rbac_roles_privileges (`id`, `role_id`, `privilege_id`) VALUES (141, 1, 141);
INSERT INTO shop_rbac_roles_privileges (`id`, `role_id`, `privilege_id`) VALUES (142, 1, 142);
INSERT INTO shop_rbac_roles_privileges (`id`, `role_id`, `privilege_id`) VALUES (143, 1, 143);
INSERT INTO shop_rbac_roles_privileges (`id`, `role_id`, `privilege_id`) VALUES (144, 1, 144);
INSERT INTO shop_rbac_roles_privileges (`id`, `role_id`, `privilege_id`) VALUES (145, 1, 145);
INSERT INTO shop_rbac_roles_privileges (`id`, `role_id`, `privilege_id`) VALUES (146, 1, 146);
INSERT INTO shop_rbac_roles_privileges (`id`, `role_id`, `privilege_id`) VALUES (147, 1, 147);
INSERT INTO shop_rbac_roles_privileges (`id`, `role_id`, `privilege_id`) VALUES (148, 1, 148);
INSERT INTO shop_rbac_roles_privileges (`id`, `role_id`, `privilege_id`) VALUES (149, 1, 149);
INSERT INTO shop_rbac_roles_privileges (`id`, `role_id`, `privilege_id`) VALUES (150, 1, 150);
INSERT INTO shop_rbac_roles_privileges (`id`, `role_id`, `privilege_id`) VALUES (151, 1, 151);
INSERT INTO shop_rbac_roles_privileges (`id`, `role_id`, `privilege_id`) VALUES (152, 1, 152);
INSERT INTO shop_rbac_roles_privileges (`id`, `role_id`, `privilege_id`) VALUES (153, 1, 153);
INSERT INTO shop_rbac_roles_privileges (`id`, `role_id`, `privilege_id`) VALUES (154, 1, 154);
INSERT INTO shop_rbac_roles_privileges (`id`, `role_id`, `privilege_id`) VALUES (155, 1, 155);
INSERT INTO shop_rbac_roles_privileges (`id`, `role_id`, `privilege_id`) VALUES (156, 1, 156);
INSERT INTO shop_rbac_roles_privileges (`id`, `role_id`, `privilege_id`) VALUES (157, 1, 157);
INSERT INTO shop_rbac_roles_privileges (`id`, `role_id`, `privilege_id`) VALUES (158, 1, 158);
INSERT INTO shop_rbac_roles_privileges (`id`, `role_id`, `privilege_id`) VALUES (159, 1, 159);
INSERT INTO shop_rbac_roles_privileges (`id`, `role_id`, `privilege_id`) VALUES (160, 1, 160);
INSERT INTO shop_rbac_roles_privileges (`id`, `role_id`, `privilege_id`) VALUES (161, 1, 161);
INSERT INTO shop_rbac_roles_privileges (`id`, `role_id`, `privilege_id`) VALUES (162, 1, 162);
INSERT INTO shop_rbac_roles_privileges (`id`, `role_id`, `privilege_id`) VALUES (163, 1, 163);
INSERT INTO shop_rbac_roles_privileges (`id`, `role_id`, `privilege_id`) VALUES (164, 1, 164);
INSERT INTO shop_rbac_roles_privileges (`id`, `role_id`, `privilege_id`) VALUES (165, 1, 165);
INSERT INTO shop_rbac_roles_privileges (`id`, `role_id`, `privilege_id`) VALUES (166, 1, 166);
INSERT INTO shop_rbac_roles_privileges (`id`, `role_id`, `privilege_id`) VALUES (167, 1, 167);
INSERT INTO shop_rbac_roles_privileges (`id`, `role_id`, `privilege_id`) VALUES (168, 1, 168);
INSERT INTO shop_rbac_roles_privileges (`id`, `role_id`, `privilege_id`) VALUES (169, 1, 169);
INSERT INTO shop_rbac_roles_privileges (`id`, `role_id`, `privilege_id`) VALUES (170, 1, 170);
INSERT INTO shop_rbac_roles_privileges (`id`, `role_id`, `privilege_id`) VALUES (171, 1, 171);
INSERT INTO shop_rbac_roles_privileges (`id`, `role_id`, `privilege_id`) VALUES (172, 1, 172);
INSERT INTO shop_rbac_roles_privileges (`id`, `role_id`, `privilege_id`) VALUES (173, 1, 173);
INSERT INTO shop_rbac_roles_privileges (`id`, `role_id`, `privilege_id`) VALUES (174, 1, 174);
INSERT INTO shop_rbac_roles_privileges (`id`, `role_id`, `privilege_id`) VALUES (175, 1, 175);
INSERT INTO shop_rbac_roles_privileges (`id`, `role_id`, `privilege_id`) VALUES (176, 1, 176);
INSERT INTO shop_rbac_roles_privileges (`id`, `role_id`, `privilege_id`) VALUES (177, 1, 177);
INSERT INTO shop_rbac_roles_privileges (`id`, `role_id`, `privilege_id`) VALUES (178, 1, 178);
INSERT INTO shop_rbac_roles_privileges (`id`, `role_id`, `privilege_id`) VALUES (179, 1, 179);
INSERT INTO shop_rbac_roles_privileges (`id`, `role_id`, `privilege_id`) VALUES (180, 1, 180);
INSERT INTO shop_rbac_roles_privileges (`id`, `role_id`, `privilege_id`) VALUES (181, 1, 181);
INSERT INTO shop_rbac_roles_privileges (`id`, `role_id`, `privilege_id`) VALUES (182, 1, 182);
INSERT INTO shop_rbac_roles_privileges (`id`, `role_id`, `privilege_id`) VALUES (183, 1, 183);
INSERT INTO shop_rbac_roles_privileges (`id`, `role_id`, `privilege_id`) VALUES (184, 1, 184);
INSERT INTO shop_rbac_roles_privileges (`id`, `role_id`, `privilege_id`) VALUES (185, 1, 185);
INSERT INTO shop_rbac_roles_privileges (`id`, `role_id`, `privilege_id`) VALUES (186, 1, 186);
INSERT INTO shop_rbac_roles_privileges (`id`, `role_id`, `privilege_id`) VALUES (187, 1, 187);
INSERT INTO shop_rbac_roles_privileges (`id`, `role_id`, `privilege_id`) VALUES (188, 1, 188);
INSERT INTO shop_rbac_roles_privileges (`id`, `role_id`, `privilege_id`) VALUES (189, 1, 189);
INSERT INTO shop_rbac_roles_privileges (`id`, `role_id`, `privilege_id`) VALUES (190, 1, 190);
INSERT INTO shop_rbac_roles_privileges (`id`, `role_id`, `privilege_id`) VALUES (191, 1, 191);
INSERT INTO shop_rbac_roles_privileges (`id`, `role_id`, `privilege_id`) VALUES (192, 1, 192);
INSERT INTO shop_rbac_roles_privileges (`id`, `role_id`, `privilege_id`) VALUES (193, 1, 193);
INSERT INTO shop_rbac_roles_privileges (`id`, `role_id`, `privilege_id`) VALUES (194, 1, 194);
INSERT INTO shop_rbac_roles_privileges (`id`, `role_id`, `privilege_id`) VALUES (195, 1, 195);
INSERT INTO shop_rbac_roles_privileges (`id`, `role_id`, `privilege_id`) VALUES (196, 1, 196);
INSERT INTO shop_rbac_roles_privileges (`id`, `role_id`, `privilege_id`) VALUES (197, 1, 197);
INSERT INTO shop_rbac_roles_privileges (`id`, `role_id`, `privilege_id`) VALUES (198, 1, 198);
INSERT INTO shop_rbac_roles_privileges (`id`, `role_id`, `privilege_id`) VALUES (199, 1, 199);
INSERT INTO shop_rbac_roles_privileges (`id`, `role_id`, `privilege_id`) VALUES (200, 1, 200);
INSERT INTO shop_rbac_roles_privileges (`id`, `role_id`, `privilege_id`) VALUES (201, 1, 201);
INSERT INTO shop_rbac_roles_privileges (`id`, `role_id`, `privilege_id`) VALUES (202, 1, 202);
INSERT INTO shop_rbac_roles_privileges (`id`, `role_id`, `privilege_id`) VALUES (203, 1, 203);
INSERT INTO shop_rbac_roles_privileges (`id`, `role_id`, `privilege_id`) VALUES (204, 1, 204);
INSERT INTO shop_rbac_roles_privileges (`id`, `role_id`, `privilege_id`) VALUES (205, 1, 205);
INSERT INTO shop_rbac_roles_privileges (`id`, `role_id`, `privilege_id`) VALUES (206, 1, 206);
INSERT INTO shop_rbac_roles_privileges (`id`, `role_id`, `privilege_id`) VALUES (207, 1, 207);
INSERT INTO shop_rbac_roles_privileges (`id`, `role_id`, `privilege_id`) VALUES (208, 1, 208);
INSERT INTO shop_rbac_roles_privileges (`id`, `role_id`, `privilege_id`) VALUES (209, 1, 209);
INSERT INTO shop_rbac_roles_privileges (`id`, `role_id`, `privilege_id`) VALUES (210, 1, 210);
INSERT INTO shop_rbac_roles_privileges (`id`, `role_id`, `privilege_id`) VALUES (211, 1, 211);
INSERT INTO shop_rbac_roles_privileges (`id`, `role_id`, `privilege_id`) VALUES (212, 1, 212);
INSERT INTO shop_rbac_roles_privileges (`id`, `role_id`, `privilege_id`) VALUES (213, 1, 213);
INSERT INTO shop_rbac_roles_privileges (`id`, `role_id`, `privilege_id`) VALUES (214, 1, 214);
INSERT INTO shop_rbac_roles_privileges (`id`, `role_id`, `privilege_id`) VALUES (215, 1, 215);
INSERT INTO shop_rbac_roles_privileges (`id`, `role_id`, `privilege_id`) VALUES (216, 1, 216);
INSERT INTO shop_rbac_roles_privileges (`id`, `role_id`, `privilege_id`) VALUES (217, 1, 217);
INSERT INTO shop_rbac_roles_privileges (`id`, `role_id`, `privilege_id`) VALUES (218, 1, 218);
INSERT INTO shop_rbac_roles_privileges (`id`, `role_id`, `privilege_id`) VALUES (219, 1, 219);
INSERT INTO shop_rbac_roles_privileges (`id`, `role_id`, `privilege_id`) VALUES (220, 1, 220);
INSERT INTO shop_rbac_roles_privileges (`id`, `role_id`, `privilege_id`) VALUES (221, 1, 221);
INSERT INTO shop_rbac_roles_privileges (`id`, `role_id`, `privilege_id`) VALUES (222, 1, 222);
INSERT INTO shop_rbac_roles_privileges (`id`, `role_id`, `privilege_id`) VALUES (223, 1, 223);
INSERT INTO shop_rbac_roles_privileges (`id`, `role_id`, `privilege_id`) VALUES (224, 1, 224);
INSERT INTO shop_rbac_roles_privileges (`id`, `role_id`, `privilege_id`) VALUES (225, 1, 225);
INSERT INTO shop_rbac_roles_privileges (`id`, `role_id`, `privilege_id`) VALUES (226, 1, 226);
INSERT INTO shop_rbac_roles_privileges (`id`, `role_id`, `privilege_id`) VALUES (227, 1, 227);
INSERT INTO shop_rbac_roles_privileges (`id`, `role_id`, `privilege_id`) VALUES (228, 1, 228);
INSERT INTO shop_rbac_roles_privileges (`id`, `role_id`, `privilege_id`) VALUES (229, 1, 229);
INSERT INTO shop_rbac_roles_privileges (`id`, `role_id`, `privilege_id`) VALUES (230, 1, 230);
INSERT INTO shop_rbac_roles_privileges (`id`, `role_id`, `privilege_id`) VALUES (231, 1, 231);
INSERT INTO shop_rbac_roles_privileges (`id`, `role_id`, `privilege_id`) VALUES (232, 1, 232);
INSERT INTO shop_rbac_roles_privileges (`id`, `role_id`, `privilege_id`) VALUES (233, 1, 233);
INSERT INTO shop_rbac_roles_privileges (`id`, `role_id`, `privilege_id`) VALUES (234, 1, 234);
INSERT INTO shop_rbac_roles_privileges (`id`, `role_id`, `privilege_id`) VALUES (235, 1, 235);
INSERT INTO shop_rbac_roles_privileges (`id`, `role_id`, `privilege_id`) VALUES (236, 1, 236);
INSERT INTO shop_rbac_roles_privileges (`id`, `role_id`, `privilege_id`) VALUES (237, 1, 237);
INSERT INTO shop_rbac_roles_privileges (`id`, `role_id`, `privilege_id`) VALUES (238, 1, 238);
INSERT INTO shop_rbac_roles_privileges (`id`, `role_id`, `privilege_id`) VALUES (239, 1, 239);
INSERT INTO shop_rbac_roles_privileges (`id`, `role_id`, `privilege_id`) VALUES (240, 1, 240);
INSERT INTO shop_rbac_roles_privileges (`id`, `role_id`, `privilege_id`) VALUES (241, 1, 241);
INSERT INTO shop_rbac_roles_privileges (`id`, `role_id`, `privilege_id`) VALUES (242, 1, 242);
INSERT INTO shop_rbac_roles_privileges (`id`, `role_id`, `privilege_id`) VALUES (243, 1, 243);
INSERT INTO shop_rbac_roles_privileges (`id`, `role_id`, `privilege_id`) VALUES (244, 1, 244);
INSERT INTO shop_rbac_roles_privileges (`id`, `role_id`, `privilege_id`) VALUES (245, 1, 245);
INSERT INTO shop_rbac_roles_privileges (`id`, `role_id`, `privilege_id`) VALUES (246, 1, 246);
INSERT INTO shop_rbac_roles_privileges (`id`, `role_id`, `privilege_id`) VALUES (247, 1, 247);
INSERT INTO shop_rbac_roles_privileges (`id`, `role_id`, `privilege_id`) VALUES (248, 1, 248);
INSERT INTO shop_rbac_roles_privileges (`id`, `role_id`, `privilege_id`) VALUES (249, 1, 249);
INSERT INTO shop_rbac_roles_privileges (`id`, `role_id`, `privilege_id`) VALUES (250, 1, 250);
INSERT INTO shop_rbac_roles_privileges (`id`, `role_id`, `privilege_id`) VALUES (251, 1, 251);
INSERT INTO shop_rbac_roles_privileges (`id`, `role_id`, `privilege_id`) VALUES (252, 1, 252);
INSERT INTO shop_rbac_roles_privileges (`id`, `role_id`, `privilege_id`) VALUES (253, 1, 253);
INSERT INTO shop_rbac_roles_privileges (`id`, `role_id`, `privilege_id`) VALUES (254, 1, 254);
INSERT INTO shop_rbac_roles_privileges (`id`, `role_id`, `privilege_id`) VALUES (255, 1, 255);
INSERT INTO shop_rbac_roles_privileges (`id`, `role_id`, `privilege_id`) VALUES (256, 1, 256);
INSERT INTO shop_rbac_roles_privileges (`id`, `role_id`, `privilege_id`) VALUES (257, 1, 257);
INSERT INTO shop_rbac_roles_privileges (`id`, `role_id`, `privilege_id`) VALUES (258, 1, 258);
INSERT INTO shop_rbac_roles_privileges (`id`, `role_id`, `privilege_id`) VALUES (259, 1, 259);
INSERT INTO shop_rbac_roles_privileges (`id`, `role_id`, `privilege_id`) VALUES (260, 1, 260);
INSERT INTO shop_rbac_roles_privileges (`id`, `role_id`, `privilege_id`) VALUES (261, 1, 261);
INSERT INTO shop_rbac_roles_privileges (`id`, `role_id`, `privilege_id`) VALUES (262, 1, 262);
INSERT INTO shop_rbac_roles_privileges (`id`, `role_id`, `privilege_id`) VALUES (263, 1, 263);
INSERT INTO shop_rbac_roles_privileges (`id`, `role_id`, `privilege_id`) VALUES (264, 1, 264);
INSERT INTO shop_rbac_roles_privileges (`id`, `role_id`, `privilege_id`) VALUES (265, 1, 265);
INSERT INTO shop_rbac_roles_privileges (`id`, `role_id`, `privilege_id`) VALUES (266, 1, 266);
INSERT INTO shop_rbac_roles_privileges (`id`, `role_id`, `privilege_id`) VALUES (267, 1, 267);
INSERT INTO shop_rbac_roles_privileges (`id`, `role_id`, `privilege_id`) VALUES (268, 1, 268);
INSERT INTO shop_rbac_roles_privileges (`id`, `role_id`, `privilege_id`) VALUES (269, 1, 269);
INSERT INTO shop_rbac_roles_privileges (`id`, `role_id`, `privilege_id`) VALUES (270, 1, 270);
INSERT INTO shop_rbac_roles_privileges (`id`, `role_id`, `privilege_id`) VALUES (271, 1, 271);
INSERT INTO shop_rbac_roles_privileges (`id`, `role_id`, `privilege_id`) VALUES (272, 1, 272);
INSERT INTO shop_rbac_roles_privileges (`id`, `role_id`, `privilege_id`) VALUES (273, 1, 273);
INSERT INTO shop_rbac_roles_privileges (`id`, `role_id`, `privilege_id`) VALUES (274, 1, 274);
INSERT INTO shop_rbac_roles_privileges (`id`, `role_id`, `privilege_id`) VALUES (275, 1, 275);
INSERT INTO shop_rbac_roles_privileges (`id`, `role_id`, `privilege_id`) VALUES (276, 1, 276);
INSERT INTO shop_rbac_roles_privileges (`id`, `role_id`, `privilege_id`) VALUES (277, 1, 277);
INSERT INTO shop_rbac_roles_privileges (`id`, `role_id`, `privilege_id`) VALUES (278, 1, 278);
INSERT INTO shop_rbac_roles_privileges (`id`, `role_id`, `privilege_id`) VALUES (279, 1, 279);
INSERT INTO shop_rbac_roles_privileges (`id`, `role_id`, `privilege_id`) VALUES (280, 1, 280);
INSERT INTO shop_rbac_roles_privileges (`id`, `role_id`, `privilege_id`) VALUES (281, 1, 281);
INSERT INTO shop_rbac_roles_privileges (`id`, `role_id`, `privilege_id`) VALUES (282, 1, 282);
INSERT INTO shop_rbac_roles_privileges (`id`, `role_id`, `privilege_id`) VALUES (283, 1, 283);
INSERT INTO shop_rbac_roles_privileges (`id`, `role_id`, `privilege_id`) VALUES (284, 1, 284);
INSERT INTO shop_rbac_roles_privileges (`id`, `role_id`, `privilege_id`) VALUES (285, 1, 285);
INSERT INTO shop_rbac_roles_privileges (`id`, `role_id`, `privilege_id`) VALUES (286, 1, 286);
INSERT INTO shop_rbac_roles_privileges (`id`, `role_id`, `privilege_id`) VALUES (287, 1, 287);
INSERT INTO shop_rbac_roles_privileges (`id`, `role_id`, `privilege_id`) VALUES (288, 1, 288);
INSERT INTO shop_rbac_roles_privileges (`id`, `role_id`, `privilege_id`) VALUES (289, 1, 289);
INSERT INTO shop_rbac_roles_privileges (`id`, `role_id`, `privilege_id`) VALUES (290, 1, 290);
INSERT INTO shop_rbac_roles_privileges (`id`, `role_id`, `privilege_id`) VALUES (291, 1, 291);
INSERT INTO shop_rbac_roles_privileges (`id`, `role_id`, `privilege_id`) VALUES (292, 1, 292);
INSERT INTO shop_rbac_roles_privileges (`id`, `role_id`, `privilege_id`) VALUES (293, 1, 293);
INSERT INTO shop_rbac_roles_privileges (`id`, `role_id`, `privilege_id`) VALUES (294, 1, 294);
INSERT INTO shop_rbac_roles_privileges (`id`, `role_id`, `privilege_id`) VALUES (295, 1, 295);
INSERT INTO shop_rbac_roles_privileges (`id`, `role_id`, `privilege_id`) VALUES (296, 1, 296);
INSERT INTO shop_rbac_roles_privileges (`id`, `role_id`, `privilege_id`) VALUES (297, 1, 297);
INSERT INTO shop_rbac_roles_privileges (`id`, `role_id`, `privilege_id`) VALUES (298, 1, 298);
INSERT INTO shop_rbac_roles_privileges (`id`, `role_id`, `privilege_id`) VALUES (299, 1, 299);
INSERT INTO shop_rbac_roles_privileges (`id`, `role_id`, `privilege_id`) VALUES (300, 1, 300);
INSERT INTO shop_rbac_roles_privileges (`id`, `role_id`, `privilege_id`) VALUES (301, 1, 301);
INSERT INTO shop_rbac_roles_privileges (`id`, `role_id`, `privilege_id`) VALUES (302, 1, 302);
INSERT INTO shop_rbac_roles_privileges (`id`, `role_id`, `privilege_id`) VALUES (303, 1, 303);
INSERT INTO shop_rbac_roles_privileges (`id`, `role_id`, `privilege_id`) VALUES (304, 1, 304);
INSERT INTO shop_rbac_roles_privileges (`id`, `role_id`, `privilege_id`) VALUES (305, 1, 305);
INSERT INTO shop_rbac_roles_privileges (`id`, `role_id`, `privilege_id`) VALUES (306, 1, 306);
INSERT INTO shop_rbac_roles_privileges (`id`, `role_id`, `privilege_id`) VALUES (307, 1, 307);
INSERT INTO shop_rbac_roles_privileges (`id`, `role_id`, `privilege_id`) VALUES (308, 1, 308);
INSERT INTO shop_rbac_roles_privileges (`id`, `role_id`, `privilege_id`) VALUES (309, 1, 309);
INSERT INTO shop_rbac_roles_privileges (`id`, `role_id`, `privilege_id`) VALUES (310, 1, 310);
INSERT INTO shop_rbac_roles_privileges (`id`, `role_id`, `privilege_id`) VALUES (311, 1, 311);
INSERT INTO shop_rbac_roles_privileges (`id`, `role_id`, `privilege_id`) VALUES (312, 1, 312);
INSERT INTO shop_rbac_roles_privileges (`id`, `role_id`, `privilege_id`) VALUES (313, 1, 313);
INSERT INTO shop_rbac_roles_privileges (`id`, `role_id`, `privilege_id`) VALUES (314, 1, 314);
INSERT INTO shop_rbac_roles_privileges (`id`, `role_id`, `privilege_id`) VALUES (315, 1, 315);
INSERT INTO shop_rbac_roles_privileges (`id`, `role_id`, `privilege_id`) VALUES (316, 1, 316);
INSERT INTO shop_rbac_roles_privileges (`id`, `role_id`, `privilege_id`) VALUES (317, 1, 317);
INSERT INTO shop_rbac_roles_privileges (`id`, `role_id`, `privilege_id`) VALUES (318, 1, 318);
INSERT INTO shop_rbac_roles_privileges (`id`, `role_id`, `privilege_id`) VALUES (319, 1, 319);
INSERT INTO shop_rbac_roles_privileges (`id`, `role_id`, `privilege_id`) VALUES (320, 1, 320);
INSERT INTO shop_rbac_roles_privileges (`id`, `role_id`, `privilege_id`) VALUES (321, 1, 321);
INSERT INTO shop_rbac_roles_privileges (`id`, `role_id`, `privilege_id`) VALUES (322, 1, 322);
INSERT INTO shop_rbac_roles_privileges (`id`, `role_id`, `privilege_id`) VALUES (323, 1, 323);
INSERT INTO shop_rbac_roles_privileges (`id`, `role_id`, `privilege_id`) VALUES (324, 1, 324);
INSERT INTO shop_rbac_roles_privileges (`id`, `role_id`, `privilege_id`) VALUES (325, 1, 325);
INSERT INTO shop_rbac_roles_privileges (`id`, `role_id`, `privilege_id`) VALUES (326, 1, 326);
INSERT INTO shop_rbac_roles_privileges (`id`, `role_id`, `privilege_id`) VALUES (327, 1, 327);
INSERT INTO shop_rbac_roles_privileges (`id`, `role_id`, `privilege_id`) VALUES (328, 1, 328);
INSERT INTO shop_rbac_roles_privileges (`id`, `role_id`, `privilege_id`) VALUES (329, 1, 329);
INSERT INTO shop_rbac_roles_privileges (`id`, `role_id`, `privilege_id`) VALUES (330, 1, 330);
INSERT INTO shop_rbac_roles_privileges (`id`, `role_id`, `privilege_id`) VALUES (331, 1, 331);
INSERT INTO shop_rbac_roles_privileges (`id`, `role_id`, `privilege_id`) VALUES (332, 1, 332);
INSERT INTO shop_rbac_roles_privileges (`id`, `role_id`, `privilege_id`) VALUES (333, 1, 333);
INSERT INTO shop_rbac_roles_privileges (`id`, `role_id`, `privilege_id`) VALUES (334, 1, 334);
INSERT INTO shop_rbac_roles_privileges (`id`, `role_id`, `privilege_id`) VALUES (335, 1, 335);
INSERT INTO shop_rbac_roles_privileges (`id`, `role_id`, `privilege_id`) VALUES (336, 1, 336);
INSERT INTO shop_rbac_roles_privileges (`id`, `role_id`, `privilege_id`) VALUES (337, 1, 337);
INSERT INTO shop_rbac_roles_privileges (`id`, `role_id`, `privilege_id`) VALUES (338, 1, 338);
INSERT INTO shop_rbac_roles_privileges (`id`, `role_id`, `privilege_id`) VALUES (339, 1, 339);
INSERT INTO shop_rbac_roles_privileges (`id`, `role_id`, `privilege_id`) VALUES (340, 1, 340);
INSERT INTO shop_rbac_roles_privileges (`id`, `role_id`, `privilege_id`) VALUES (341, 1, 341);
INSERT INTO shop_rbac_roles_privileges (`id`, `role_id`, `privilege_id`) VALUES (342, 1, 342);
INSERT INTO shop_rbac_roles_privileges (`id`, `role_id`, `privilege_id`) VALUES (343, 1, 343);
INSERT INTO shop_rbac_roles_privileges (`id`, `role_id`, `privilege_id`) VALUES (344, 1, 344);
INSERT INTO shop_rbac_roles_privileges (`id`, `role_id`, `privilege_id`) VALUES (345, 1, 345);
INSERT INTO shop_rbac_roles_privileges (`id`, `role_id`, `privilege_id`) VALUES (346, 1, 346);
INSERT INTO shop_rbac_roles_privileges (`id`, `role_id`, `privilege_id`) VALUES (347, 1, 347);
INSERT INTO shop_rbac_roles_privileges (`id`, `role_id`, `privilege_id`) VALUES (348, 1, 348);
INSERT INTO shop_rbac_roles_privileges (`id`, `role_id`, `privilege_id`) VALUES (349, 1, 349);
INSERT INTO shop_rbac_roles_privileges (`id`, `role_id`, `privilege_id`) VALUES (350, 1, 350);
INSERT INTO shop_rbac_roles_privileges (`id`, `role_id`, `privilege_id`) VALUES (351, 1, 351);
INSERT INTO shop_rbac_roles_privileges (`id`, `role_id`, `privilege_id`) VALUES (352, 1, 352);
INSERT INTO shop_rbac_roles_privileges (`id`, `role_id`, `privilege_id`) VALUES (353, 1, 353);
INSERT INTO shop_rbac_roles_privileges (`id`, `role_id`, `privilege_id`) VALUES (354, 1, 354);
INSERT INTO shop_rbac_roles_privileges (`id`, `role_id`, `privilege_id`) VALUES (355, 1, 355);
INSERT INTO shop_rbac_roles_privileges (`id`, `role_id`, `privilege_id`) VALUES (356, 1, 356);
INSERT INTO shop_rbac_roles_privileges (`id`, `role_id`, `privilege_id`) VALUES (357, 1, 357);
INSERT INTO shop_rbac_roles_privileges (`id`, `role_id`, `privilege_id`) VALUES (358, 1, 358);
INSERT INTO shop_rbac_roles_privileges (`id`, `role_id`, `privilege_id`) VALUES (359, 1, 359);
INSERT INTO shop_rbac_roles_privileges (`id`, `role_id`, `privilege_id`) VALUES (360, 1, 360);
INSERT INTO shop_rbac_roles_privileges (`id`, `role_id`, `privilege_id`) VALUES (361, 1, 361);
INSERT INTO shop_rbac_roles_privileges (`id`, `role_id`, `privilege_id`) VALUES (362, 1, 362);
INSERT INTO shop_rbac_roles_privileges (`id`, `role_id`, `privilege_id`) VALUES (363, 1, 363);
INSERT INTO shop_rbac_roles_privileges (`id`, `role_id`, `privilege_id`) VALUES (364, 1, 364);
INSERT INTO shop_rbac_roles_privileges (`id`, `role_id`, `privilege_id`) VALUES (365, 1, 365);
INSERT INTO shop_rbac_roles_privileges (`id`, `role_id`, `privilege_id`) VALUES (366, 1, 366);
INSERT INTO shop_rbac_roles_privileges (`id`, `role_id`, `privilege_id`) VALUES (367, 1, 367);
INSERT INTO shop_rbac_roles_privileges (`id`, `role_id`, `privilege_id`) VALUES (368, 1, 368);
INSERT INTO shop_rbac_roles_privileges (`id`, `role_id`, `privilege_id`) VALUES (369, 1, 369);
INSERT INTO shop_rbac_roles_privileges (`id`, `role_id`, `privilege_id`) VALUES (370, 1, 370);
INSERT INTO shop_rbac_roles_privileges (`id`, `role_id`, `privilege_id`) VALUES (371, 1, 371);
INSERT INTO shop_rbac_roles_privileges (`id`, `role_id`, `privilege_id`) VALUES (372, 1, 372);
INSERT INTO shop_rbac_roles_privileges (`id`, `role_id`, `privilege_id`) VALUES (373, 1, 373);
INSERT INTO shop_rbac_roles_privileges (`id`, `role_id`, `privilege_id`) VALUES (374, 1, 374);
INSERT INTO shop_rbac_roles_privileges (`id`, `role_id`, `privilege_id`) VALUES (375, 1, 375);
INSERT INTO shop_rbac_roles_privileges (`id`, `role_id`, `privilege_id`) VALUES (376, 1, 376);
INSERT INTO shop_rbac_roles_privileges (`id`, `role_id`, `privilege_id`) VALUES (377, 1, 377);
INSERT INTO shop_rbac_roles_privileges (`id`, `role_id`, `privilege_id`) VALUES (378, 1, 378);
INSERT INTO shop_rbac_roles_privileges (`id`, `role_id`, `privilege_id`) VALUES (379, 1, 379);
INSERT INTO shop_rbac_roles_privileges (`id`, `role_id`, `privilege_id`) VALUES (380, 1, 380);
INSERT INTO shop_rbac_roles_privileges (`id`, `role_id`, `privilege_id`) VALUES (381, 1, 381);
INSERT INTO shop_rbac_roles_privileges (`id`, `role_id`, `privilege_id`) VALUES (382, 1, 382);
INSERT INTO shop_rbac_roles_privileges (`id`, `role_id`, `privilege_id`) VALUES (383, 1, 383);
INSERT INTO shop_rbac_roles_privileges (`id`, `role_id`, `privilege_id`) VALUES (384, 1, 384);
INSERT INTO shop_rbac_roles_privileges (`id`, `role_id`, `privilege_id`) VALUES (385, 1, 385);
INSERT INTO shop_rbac_roles_privileges (`id`, `role_id`, `privilege_id`) VALUES (386, 1, 386);
INSERT INTO shop_rbac_roles_privileges (`id`, `role_id`, `privilege_id`) VALUES (387, 1, 387);
INSERT INTO shop_rbac_roles_privileges (`id`, `role_id`, `privilege_id`) VALUES (388, 1, 388);
INSERT INTO shop_rbac_roles_privileges (`id`, `role_id`, `privilege_id`) VALUES (389, 1, 389);
INSERT INTO shop_rbac_roles_privileges (`id`, `role_id`, `privilege_id`) VALUES (390, 1, 390);
INSERT INTO shop_rbac_roles_privileges (`id`, `role_id`, `privilege_id`) VALUES (391, 1, 391);
INSERT INTO shop_rbac_roles_privileges (`id`, `role_id`, `privilege_id`) VALUES (392, 1, 392);
INSERT INTO shop_rbac_roles_privileges (`id`, `role_id`, `privilege_id`) VALUES (393, 1, 393);
INSERT INTO shop_rbac_roles_privileges (`id`, `role_id`, `privilege_id`) VALUES (394, 1, 394);
INSERT INTO shop_rbac_roles_privileges (`id`, `role_id`, `privilege_id`) VALUES (395, 1, 395);
INSERT INTO shop_rbac_roles_privileges (`id`, `role_id`, `privilege_id`) VALUES (396, 1, 396);
INSERT INTO shop_rbac_roles_privileges (`id`, `role_id`, `privilege_id`) VALUES (397, 1, 397);
INSERT INTO shop_rbac_roles_privileges (`id`, `role_id`, `privilege_id`) VALUES (398, 1, 398);
INSERT INTO shop_rbac_roles_privileges (`id`, `role_id`, `privilege_id`) VALUES (399, 1, 399);
INSERT INTO shop_rbac_roles_privileges (`id`, `role_id`, `privilege_id`) VALUES (400, 1, 400);
INSERT INTO shop_rbac_roles_privileges (`id`, `role_id`, `privilege_id`) VALUES (401, 1, 401);
INSERT INTO shop_rbac_roles_privileges (`id`, `role_id`, `privilege_id`) VALUES (402, 1, 402);
INSERT INTO shop_rbac_roles_privileges (`id`, `role_id`, `privilege_id`) VALUES (403, 1, 403);
INSERT INTO shop_rbac_roles_privileges (`id`, `role_id`, `privilege_id`) VALUES (404, 1, 404);
INSERT INTO shop_rbac_roles_privileges (`id`, `role_id`, `privilege_id`) VALUES (405, 1, 405);
INSERT INTO shop_rbac_roles_privileges (`id`, `role_id`, `privilege_id`) VALUES (406, 1, 406);
INSERT INTO shop_rbac_roles_privileges (`id`, `role_id`, `privilege_id`) VALUES (407, 1, 407);
INSERT INTO shop_rbac_roles_privileges (`id`, `role_id`, `privilege_id`) VALUES (408, 1, 408);
INSERT INTO shop_rbac_roles_privileges (`id`, `role_id`, `privilege_id`) VALUES (409, 1, 409);
INSERT INTO shop_rbac_roles_privileges (`id`, `role_id`, `privilege_id`) VALUES (410, 1, 410);
INSERT INTO shop_rbac_roles_privileges (`id`, `role_id`, `privilege_id`) VALUES (411, 1, 411);
INSERT INTO shop_rbac_roles_privileges (`id`, `role_id`, `privilege_id`) VALUES (412, 1, 412);
INSERT INTO shop_rbac_roles_privileges (`id`, `role_id`, `privilege_id`) VALUES (413, 1, 413);
INSERT INTO shop_rbac_roles_privileges (`id`, `role_id`, `privilege_id`) VALUES (414, 1, 414);
INSERT INTO shop_rbac_roles_privileges (`id`, `role_id`, `privilege_id`) VALUES (415, 1, 415);
INSERT INTO shop_rbac_roles_privileges (`id`, `role_id`, `privilege_id`) VALUES (416, 1, 416);
INSERT INTO shop_rbac_roles_privileges (`id`, `role_id`, `privilege_id`) VALUES (417, 1, 417);
INSERT INTO shop_rbac_roles_privileges (`id`, `role_id`, `privilege_id`) VALUES (418, 1, 418);
INSERT INTO shop_rbac_roles_privileges (`id`, `role_id`, `privilege_id`) VALUES (419, 1, 419);
INSERT INTO shop_rbac_roles_privileges (`id`, `role_id`, `privilege_id`) VALUES (420, 1, 420);
INSERT INTO shop_rbac_roles_privileges (`id`, `role_id`, `privilege_id`) VALUES (421, 1, 421);
INSERT INTO shop_rbac_roles_privileges (`id`, `role_id`, `privilege_id`) VALUES (422, 1, 422);
INSERT INTO shop_rbac_roles_privileges (`id`, `role_id`, `privilege_id`) VALUES (423, 1, 423);
INSERT INTO shop_rbac_roles_privileges (`id`, `role_id`, `privilege_id`) VALUES (424, 1, 424);
INSERT INTO shop_rbac_roles_privileges (`id`, `role_id`, `privilege_id`) VALUES (425, 1, 425);
INSERT INTO shop_rbac_roles_privileges (`id`, `role_id`, `privilege_id`) VALUES (426, 1, 426);
INSERT INTO shop_rbac_roles_privileges (`id`, `role_id`, `privilege_id`) VALUES (427, 1, 427);
INSERT INTO shop_rbac_roles_privileges (`id`, `role_id`, `privilege_id`) VALUES (428, 1, 428);
INSERT INTO shop_rbac_roles_privileges (`id`, `role_id`, `privilege_id`) VALUES (429, 1, 429);
INSERT INTO shop_rbac_roles_privileges (`id`, `role_id`, `privilege_id`) VALUES (430, 1, 430);
INSERT INTO shop_rbac_roles_privileges (`id`, `role_id`, `privilege_id`) VALUES (431, 1, 431);
INSERT INTO shop_rbac_roles_privileges (`id`, `role_id`, `privilege_id`) VALUES (432, 1, 432);
INSERT INTO shop_rbac_roles_privileges (`id`, `role_id`, `privilege_id`) VALUES (433, 1, 433);
INSERT INTO shop_rbac_roles_privileges (`id`, `role_id`, `privilege_id`) VALUES (434, 1, 434);
INSERT INTO shop_rbac_roles_privileges (`id`, `role_id`, `privilege_id`) VALUES (435, 1, 435);
INSERT INTO shop_rbac_roles_privileges (`id`, `role_id`, `privilege_id`) VALUES (436, 1, 436);
INSERT INTO shop_rbac_roles_privileges (`id`, `role_id`, `privilege_id`) VALUES (437, 1, 437);
INSERT INTO shop_rbac_roles_privileges (`id`, `role_id`, `privilege_id`) VALUES (438, 1, 438);
INSERT INTO shop_rbac_roles_privileges (`id`, `role_id`, `privilege_id`) VALUES (439, 1, 439);
INSERT INTO shop_rbac_roles_privileges (`id`, `role_id`, `privilege_id`) VALUES (440, 1, 440);
INSERT INTO shop_rbac_roles_privileges (`id`, `role_id`, `privilege_id`) VALUES (441, 1, 441);
INSERT INTO shop_rbac_roles_privileges (`id`, `role_id`, `privilege_id`) VALUES (442, 1, 442);
INSERT INTO shop_rbac_roles_privileges (`id`, `role_id`, `privilege_id`) VALUES (443, 1, 443);
INSERT INTO shop_rbac_roles_privileges (`id`, `role_id`, `privilege_id`) VALUES (444, 1, 444);
INSERT INTO shop_rbac_roles_privileges (`id`, `role_id`, `privilege_id`) VALUES (445, 1, 445);
INSERT INTO shop_rbac_roles_privileges (`id`, `role_id`, `privilege_id`) VALUES (446, 1, 446);
INSERT INTO shop_rbac_roles_privileges (`id`, `role_id`, `privilege_id`) VALUES (447, 1, 447);
INSERT INTO shop_rbac_roles_privileges (`id`, `role_id`, `privilege_id`) VALUES (448, 1, 448);
INSERT INTO shop_rbac_roles_privileges (`id`, `role_id`, `privilege_id`) VALUES (449, 1, 449);
INSERT INTO shop_rbac_roles_privileges (`id`, `role_id`, `privilege_id`) VALUES (450, 1, 450);
INSERT INTO shop_rbac_roles_privileges (`id`, `role_id`, `privilege_id`) VALUES (451, 1, 451);
INSERT INTO shop_rbac_roles_privileges (`id`, `role_id`, `privilege_id`) VALUES (452, 1, 452);
INSERT INTO shop_rbac_roles_privileges (`id`, `role_id`, `privilege_id`) VALUES (453, 1, 453);
INSERT INTO shop_rbac_roles_privileges (`id`, `role_id`, `privilege_id`) VALUES (454, 1, 454);
INSERT INTO shop_rbac_roles_privileges (`id`, `role_id`, `privilege_id`) VALUES (455, 1, 455);
INSERT INTO shop_rbac_roles_privileges (`id`, `role_id`, `privilege_id`) VALUES (456, 1, 456);
INSERT INTO shop_rbac_roles_privileges (`id`, `role_id`, `privilege_id`) VALUES (457, 1, 457);
INSERT INTO shop_rbac_roles_privileges (`id`, `role_id`, `privilege_id`) VALUES (458, 1, 458);
INSERT INTO shop_rbac_roles_privileges (`id`, `role_id`, `privilege_id`) VALUES (459, 1, 459);
INSERT INTO shop_rbac_roles_privileges (`id`, `role_id`, `privilege_id`) VALUES (460, 1, 460);
INSERT INTO shop_rbac_roles_privileges (`id`, `role_id`, `privilege_id`) VALUES (461, 1, 461);
INSERT INTO shop_rbac_roles_privileges (`id`, `role_id`, `privilege_id`) VALUES (462, 1, 462);
INSERT INTO shop_rbac_roles_privileges (`id`, `role_id`, `privilege_id`) VALUES (463, 1, 463);
INSERT INTO shop_rbac_roles_privileges (`id`, `role_id`, `privilege_id`) VALUES (464, 1, 464);
INSERT INTO shop_rbac_roles_privileges (`id`, `role_id`, `privilege_id`) VALUES (465, 1, 465);
INSERT INTO shop_rbac_roles_privileges (`id`, `role_id`, `privilege_id`) VALUES (466, 1, 466);
INSERT INTO shop_rbac_roles_privileges (`id`, `role_id`, `privilege_id`) VALUES (467, 1, 467);
INSERT INTO shop_rbac_roles_privileges (`id`, `role_id`, `privilege_id`) VALUES (468, 1, 468);
INSERT INTO shop_rbac_roles_privileges (`id`, `role_id`, `privilege_id`) VALUES (469, 1, 469);
INSERT INTO shop_rbac_roles_privileges (`id`, `role_id`, `privilege_id`) VALUES (470, 1, 470);
INSERT INTO shop_rbac_roles_privileges (`id`, `role_id`, `privilege_id`) VALUES (471, 1, 471);
INSERT INTO shop_rbac_roles_privileges (`id`, `role_id`, `privilege_id`) VALUES (472, 1, 472);
INSERT INTO shop_rbac_roles_privileges (`id`, `role_id`, `privilege_id`) VALUES (473, 1, 473);
INSERT INTO shop_rbac_roles_privileges (`id`, `role_id`, `privilege_id`) VALUES (474, 1, 474);
INSERT INTO shop_rbac_roles_privileges (`id`, `role_id`, `privilege_id`) VALUES (475, 1, 475);
INSERT INTO shop_rbac_roles_privileges (`id`, `role_id`, `privilege_id`) VALUES (476, 1, 476);
INSERT INTO shop_rbac_roles_privileges (`id`, `role_id`, `privilege_id`) VALUES (477, 1, 477);
INSERT INTO shop_rbac_roles_privileges (`id`, `role_id`, `privilege_id`) VALUES (478, 1, 478);
INSERT INTO shop_rbac_roles_privileges (`id`, `role_id`, `privilege_id`) VALUES (479, 1, 479);
INSERT INTO shop_rbac_roles_privileges (`id`, `role_id`, `privilege_id`) VALUES (480, 1, 480);
INSERT INTO shop_rbac_roles_privileges (`id`, `role_id`, `privilege_id`) VALUES (481, 1, 481);
INSERT INTO shop_rbac_roles_privileges (`id`, `role_id`, `privilege_id`) VALUES (482, 1, 482);
INSERT INTO shop_rbac_roles_privileges (`id`, `role_id`, `privilege_id`) VALUES (483, 1, 483);
INSERT INTO shop_rbac_roles_privileges (`id`, `role_id`, `privilege_id`) VALUES (484, 1, 484);
INSERT INTO shop_rbac_roles_privileges (`id`, `role_id`, `privilege_id`) VALUES (485, 2, 200);
INSERT INTO shop_rbac_roles_privileges (`id`, `role_id`, `privilege_id`) VALUES (486, 2, 201);
INSERT INTO shop_rbac_roles_privileges (`id`, `role_id`, `privilege_id`) VALUES (487, 2, 202);
INSERT INTO shop_rbac_roles_privileges (`id`, `role_id`, `privilege_id`) VALUES (488, 2, 203);
INSERT INTO shop_rbac_roles_privileges (`id`, `role_id`, `privilege_id`) VALUES (489, 2, 204);
INSERT INTO shop_rbac_roles_privileges (`id`, `role_id`, `privilege_id`) VALUES (490, 2, 205);
INSERT INTO shop_rbac_roles_privileges (`id`, `role_id`, `privilege_id`) VALUES (491, 2, 107);
INSERT INTO shop_rbac_roles_privileges (`id`, `role_id`, `privilege_id`) VALUES (492, 2, 108);
INSERT INTO shop_rbac_roles_privileges (`id`, `role_id`, `privilege_id`) VALUES (493, 2, 109);
INSERT INTO shop_rbac_roles_privileges (`id`, `role_id`, `privilege_id`) VALUES (494, 2, 110);
INSERT INTO shop_rbac_roles_privileges (`id`, `role_id`, `privilege_id`) VALUES (495, 2, 111);
INSERT INTO shop_rbac_roles_privileges (`id`, `role_id`, `privilege_id`) VALUES (496, 2, 112);
INSERT INTO shop_rbac_roles_privileges (`id`, `role_id`, `privilege_id`) VALUES (497, 2, 113);
INSERT INTO shop_rbac_roles_privileges (`id`, `role_id`, `privilege_id`) VALUES (498, 2, 114);
INSERT INTO shop_rbac_roles_privileges (`id`, `role_id`, `privilege_id`) VALUES (499, 2, 115);
INSERT INTO shop_rbac_roles_privileges (`id`, `role_id`, `privilege_id`) VALUES (500, 2, 116);
INSERT INTO shop_rbac_roles_privileges (`id`, `role_id`, `privilege_id`) VALUES (501, 2, 117);
INSERT INTO shop_rbac_roles_privileges (`id`, `role_id`, `privilege_id`) VALUES (502, 2, 118);
INSERT INTO shop_rbac_roles_privileges (`id`, `role_id`, `privilege_id`) VALUES (503, 2, 119);
INSERT INTO shop_rbac_roles_privileges (`id`, `role_id`, `privilege_id`) VALUES (504, 2, 120);
INSERT INTO shop_rbac_roles_privileges (`id`, `role_id`, `privilege_id`) VALUES (505, 2, 121);
INSERT INTO shop_rbac_roles_privileges (`id`, `role_id`, `privilege_id`) VALUES (506, 2, 122);
INSERT INTO shop_rbac_roles_privileges (`id`, `role_id`, `privilege_id`) VALUES (507, 2, 123);
INSERT INTO shop_rbac_roles_privileges (`id`, `role_id`, `privilege_id`) VALUES (508, 2, 124);
INSERT INTO shop_rbac_roles_privileges (`id`, `role_id`, `privilege_id`) VALUES (509, 2, 125);
INSERT INTO shop_rbac_roles_privileges (`id`, `role_id`, `privilege_id`) VALUES (510, 2, 126);
INSERT INTO shop_rbac_roles_privileges (`id`, `role_id`, `privilege_id`) VALUES (511, 2, 127);
INSERT INTO shop_rbac_roles_privileges (`id`, `role_id`, `privilege_id`) VALUES (512, 2, 281);
INSERT INTO shop_rbac_roles_privileges (`id`, `role_id`, `privilege_id`) VALUES (513, 2, 282);
INSERT INTO shop_rbac_roles_privileges (`id`, `role_id`, `privilege_id`) VALUES (514, 2, 283);
INSERT INTO shop_rbac_roles_privileges (`id`, `role_id`, `privilege_id`) VALUES (515, 2, 284);
INSERT INTO shop_rbac_roles_privileges (`id`, `role_id`, `privilege_id`) VALUES (516, 2, 285);
INSERT INTO shop_rbac_roles_privileges (`id`, `role_id`, `privilege_id`) VALUES (517, 2, 286);
INSERT INTO shop_rbac_roles_privileges (`id`, `role_id`, `privilege_id`) VALUES (518, 2, 287);
INSERT INTO shop_rbac_roles_privileges (`id`, `role_id`, `privilege_id`) VALUES (519, 2, 210);
INSERT INTO shop_rbac_roles_privileges (`id`, `role_id`, `privilege_id`) VALUES (520, 2, 211);
INSERT INTO shop_rbac_roles_privileges (`id`, `role_id`, `privilege_id`) VALUES (521, 2, 212);
INSERT INTO shop_rbac_roles_privileges (`id`, `role_id`, `privilege_id`) VALUES (522, 2, 213);
INSERT INTO shop_rbac_roles_privileges (`id`, `role_id`, `privilege_id`) VALUES (523, 2, 214);
INSERT INTO shop_rbac_roles_privileges (`id`, `role_id`, `privilege_id`) VALUES (524, 2, 215);
INSERT INTO shop_rbac_roles_privileges (`id`, `role_id`, `privilege_id`) VALUES (525, 2, 216);
INSERT INTO shop_rbac_roles_privileges (`id`, `role_id`, `privilege_id`) VALUES (526, 2, 217);
INSERT INTO shop_rbac_roles_privileges (`id`, `role_id`, `privilege_id`) VALUES (527, 2, 218);
INSERT INTO shop_rbac_roles_privileges (`id`, `role_id`, `privilege_id`) VALUES (528, 2, 219);
INSERT INTO shop_rbac_roles_privileges (`id`, `role_id`, `privilege_id`) VALUES (529, 2, 65);
INSERT INTO shop_rbac_roles_privileges (`id`, `role_id`, `privilege_id`) VALUES (530, 3, 65);
INSERT INTO shop_rbac_roles_privileges (`id`, `role_id`, `privilege_id`) VALUES (531, 3, 184);
INSERT INTO shop_rbac_roles_privileges (`id`, `role_id`, `privilege_id`) VALUES (532, 3, 185);
INSERT INTO shop_rbac_roles_privileges (`id`, `role_id`, `privilege_id`) VALUES (533, 3, 186);
INSERT INTO shop_rbac_roles_privileges (`id`, `role_id`, `privilege_id`) VALUES (534, 3, 187);
INSERT INTO shop_rbac_roles_privileges (`id`, `role_id`, `privilege_id`) VALUES (535, 3, 188);
INSERT INTO shop_rbac_roles_privileges (`id`, `role_id`, `privilege_id`) VALUES (536, 3, 1);
INSERT INTO shop_rbac_roles_privileges (`id`, `role_id`, `privilege_id`) VALUES (537, 3, 2);
INSERT INTO shop_rbac_roles_privileges (`id`, `role_id`, `privilege_id`) VALUES (538, 3, 3);
INSERT INTO shop_rbac_roles_privileges (`id`, `role_id`, `privilege_id`) VALUES (539, 3, 4);
INSERT INTO shop_rbac_roles_privileges (`id`, `role_id`, `privilege_id`) VALUES (540, 3, 5);
INSERT INTO shop_rbac_roles_privileges (`id`, `role_id`, `privilege_id`) VALUES (541, 3, 6);
INSERT INTO shop_rbac_roles_privileges (`id`, `role_id`, `privilege_id`) VALUES (542, 3, 7);
INSERT INTO shop_rbac_roles_privileges (`id`, `role_id`, `privilege_id`) VALUES (543, 3, 8);
INSERT INTO shop_rbac_roles_privileges (`id`, `role_id`, `privilege_id`) VALUES (544, 3, 9);
INSERT INTO shop_rbac_roles_privileges (`id`, `role_id`, `privilege_id`) VALUES (545, 3, 10);
INSERT INTO shop_rbac_roles_privileges (`id`, `role_id`, `privilege_id`) VALUES (546, 3, 11);
INSERT INTO shop_rbac_roles_privileges (`id`, `role_id`, `privilege_id`) VALUES (547, 3, 12);
INSERT INTO shop_rbac_roles_privileges (`id`, `role_id`, `privilege_id`) VALUES (548, 3, 163);
INSERT INTO shop_rbac_roles_privileges (`id`, `role_id`, `privilege_id`) VALUES (549, 3, 164);
INSERT INTO shop_rbac_roles_privileges (`id`, `role_id`, `privilege_id`) VALUES (550, 3, 165);
INSERT INTO shop_rbac_roles_privileges (`id`, `role_id`, `privilege_id`) VALUES (551, 3, 166);
INSERT INTO shop_rbac_roles_privileges (`id`, `role_id`, `privilege_id`) VALUES (552, 3, 167);
INSERT INTO shop_rbac_roles_privileges (`id`, `role_id`, `privilege_id`) VALUES (553, 3, 168);
INSERT INTO shop_rbac_roles_privileges (`id`, `role_id`, `privilege_id`) VALUES (554, 3, 169);
INSERT INTO shop_rbac_roles_privileges (`id`, `role_id`, `privilege_id`) VALUES (555, 3, 85);
INSERT INTO shop_rbac_roles_privileges (`id`, `role_id`, `privilege_id`) VALUES (556, 3, 86);
INSERT INTO shop_rbac_roles_privileges (`id`, `role_id`, `privilege_id`) VALUES (557, 3, 87);
INSERT INTO shop_rbac_roles_privileges (`id`, `role_id`, `privilege_id`) VALUES (558, 3, 88);
INSERT INTO shop_rbac_roles_privileges (`id`, `role_id`, `privilege_id`) VALUES (559, 3, 89);
INSERT INTO shop_rbac_roles_privileges (`id`, `role_id`, `privilege_id`) VALUES (560, 3, 90);
INSERT INTO shop_rbac_roles_privileges (`id`, `role_id`, `privilege_id`) VALUES (561, 3, 91);
INSERT INTO shop_rbac_roles_privileges (`id`, `role_id`, `privilege_id`) VALUES (562, 3, 92);
INSERT INTO shop_rbac_roles_privileges (`id`, `role_id`, `privilege_id`) VALUES (563, 3, 29);
INSERT INTO shop_rbac_roles_privileges (`id`, `role_id`, `privilege_id`) VALUES (564, 3, 30);
INSERT INTO shop_rbac_roles_privileges (`id`, `role_id`, `privilege_id`) VALUES (565, 3, 31);
INSERT INTO shop_rbac_roles_privileges (`id`, `role_id`, `privilege_id`) VALUES (566, 3, 32);
INSERT INTO shop_rbac_roles_privileges (`id`, `role_id`, `privilege_id`) VALUES (567, 3, 33);
INSERT INTO shop_rbac_roles_privileges (`id`, `role_id`, `privilege_id`) VALUES (568, 3, 34);
INSERT INTO shop_rbac_roles_privileges (`id`, `role_id`, `privilege_id`) VALUES (569, 3, 35);
INSERT INTO shop_rbac_roles_privileges (`id`, `role_id`, `privilege_id`) VALUES (570, 3, 36);
INSERT INTO shop_rbac_roles_privileges (`id`, `role_id`, `privilege_id`) VALUES (571, 3, 37);
INSERT INTO shop_rbac_roles_privileges (`id`, `role_id`, `privilege_id`) VALUES (572, 3, 38);
INSERT INTO shop_rbac_roles_privileges (`id`, `role_id`, `privilege_id`) VALUES (573, 3, 39);
INSERT INTO shop_rbac_roles_privileges (`id`, `role_id`, `privilege_id`) VALUES (574, 3, 141);
INSERT INTO shop_rbac_roles_privileges (`id`, `role_id`, `privilege_id`) VALUES (575, 3, 142);
INSERT INTO shop_rbac_roles_privileges (`id`, `role_id`, `privilege_id`) VALUES (576, 3, 143);
INSERT INTO shop_rbac_roles_privileges (`id`, `role_id`, `privilege_id`) VALUES (577, 3, 144);
INSERT INTO shop_rbac_roles_privileges (`id`, `role_id`, `privilege_id`) VALUES (578, 3, 145);
INSERT INTO shop_rbac_roles_privileges (`id`, `role_id`, `privilege_id`) VALUES (579, 3, 146);
INSERT INTO shop_rbac_roles_privileges (`id`, `role_id`, `privilege_id`) VALUES (580, 3, 147);
INSERT INTO shop_rbac_roles_privileges (`id`, `role_id`, `privilege_id`) VALUES (581, 3, 148);
INSERT INTO shop_rbac_roles_privileges (`id`, `role_id`, `privilege_id`) VALUES (582, 3, 149);
INSERT INTO shop_rbac_roles_privileges (`id`, `role_id`, `privilege_id`) VALUES (583, 3, 150);
INSERT INTO shop_rbac_roles_privileges (`id`, `role_id`, `privilege_id`) VALUES (584, 3, 151);
INSERT INTO shop_rbac_roles_privileges (`id`, `role_id`, `privilege_id`) VALUES (585, 3, 152);
INSERT INTO shop_rbac_roles_privileges (`id`, `role_id`, `privilege_id`) VALUES (586, 3, 153);
INSERT INTO shop_rbac_roles_privileges (`id`, `role_id`, `privilege_id`) VALUES (587, 3, 154);
INSERT INTO shop_rbac_roles_privileges (`id`, `role_id`, `privilege_id`) VALUES (588, 3, 155);
INSERT INTO shop_rbac_roles_privileges (`id`, `role_id`, `privilege_id`) VALUES (589, 3, 156);
INSERT INTO shop_rbac_roles_privileges (`id`, `role_id`, `privilege_id`) VALUES (590, 3, 157);
INSERT INTO shop_rbac_roles_privileges (`id`, `role_id`, `privilege_id`) VALUES (591, 3, 158);
INSERT INTO shop_rbac_roles_privileges (`id`, `role_id`, `privilege_id`) VALUES (592, 3, 159);
INSERT INTO shop_rbac_roles_privileges (`id`, `role_id`, `privilege_id`) VALUES (593, 3, 271);
INSERT INTO shop_rbac_roles_privileges (`id`, `role_id`, `privilege_id`) VALUES (594, 3, 272);
INSERT INTO shop_rbac_roles_privileges (`id`, `role_id`, `privilege_id`) VALUES (595, 3, 281);
INSERT INTO shop_rbac_roles_privileges (`id`, `role_id`, `privilege_id`) VALUES (596, 3, 282);
INSERT INTO shop_rbac_roles_privileges (`id`, `role_id`, `privilege_id`) VALUES (597, 3, 283);
INSERT INTO shop_rbac_roles_privileges (`id`, `role_id`, `privilege_id`) VALUES (598, 3, 284);
INSERT INTO shop_rbac_roles_privileges (`id`, `role_id`, `privilege_id`) VALUES (599, 3, 285);
INSERT INTO shop_rbac_roles_privileges (`id`, `role_id`, `privilege_id`) VALUES (600, 3, 286);
INSERT INTO shop_rbac_roles_privileges (`id`, `role_id`, `privilege_id`) VALUES (601, 3, 287);
INSERT INTO shop_rbac_roles_privileges (`id`, `role_id`, `privilege_id`) VALUES (602, 3, 210);
INSERT INTO shop_rbac_roles_privileges (`id`, `role_id`, `privilege_id`) VALUES (603, 3, 211);
INSERT INTO shop_rbac_roles_privileges (`id`, `role_id`, `privilege_id`) VALUES (604, 3, 212);
INSERT INTO shop_rbac_roles_privileges (`id`, `role_id`, `privilege_id`) VALUES (605, 3, 213);
INSERT INTO shop_rbac_roles_privileges (`id`, `role_id`, `privilege_id`) VALUES (606, 3, 214);
INSERT INTO shop_rbac_roles_privileges (`id`, `role_id`, `privilege_id`) VALUES (607, 3, 215);
INSERT INTO shop_rbac_roles_privileges (`id`, `role_id`, `privilege_id`) VALUES (608, 3, 216);
INSERT INTO shop_rbac_roles_privileges (`id`, `role_id`, `privilege_id`) VALUES (609, 3, 217);
INSERT INTO shop_rbac_roles_privileges (`id`, `role_id`, `privilege_id`) VALUES (610, 3, 218);
INSERT INTO shop_rbac_roles_privileges (`id`, `role_id`, `privilege_id`) VALUES (611, 3, 219);


#
# TABLE STRUCTURE FOR: shop_settings
#

DROP TABLE IF EXISTS shop_settings;

CREATE TABLE `shop_settings` (
  `name` varchar(255) NOT NULL,
  `value` text,
  `locale` varchar(5) NOT NULL,
  PRIMARY KEY (`name`,`locale`)
) ENGINE=MyISAM DEFAULT CHARSET=utf8;

INSERT INTO shop_settings (`name`, `value`, `locale`) VALUES ('mainImageWidth', '320', '');
INSERT INTO shop_settings (`name`, `value`, `locale`) VALUES ('mainImageHeight', '320', '');
INSERT INTO shop_settings (`name`, `value`, `locale`) VALUES ('smallImageWidth', '140', '');
INSERT INTO shop_settings (`name`, `value`, `locale`) VALUES ('smallImageHeight', '140', '');
INSERT INTO shop_settings (`name`, `value`, `locale`) VALUES ('addImageWidth', '800', '');
INSERT INTO shop_settings (`name`, `value`, `locale`) VALUES ('addImageHeight', '600', '');
INSERT INTO shop_settings (`name`, `value`, `locale`) VALUES ('imagesQuality', '99', '');
INSERT INTO shop_settings (`name`, `value`, `locale`) VALUES ('systemTemplatePath', './templates/newLevel/shop/', '');
INSERT INTO shop_settings (`name`, `value`, `locale`) VALUES ('frontProductsPerPage', '12', '');
INSERT INTO shop_settings (`name`, `value`, `locale`) VALUES ('adminProductsPerPage', '24', '');
INSERT INTO shop_settings (`name`, `value`, `locale`) VALUES ('ordersMessageFormat', NULL, '');
INSERT INTO shop_settings (`name`, `value`, `locale`) VALUES ('ordersMessageText', 'Здравствуйте, %userName%.  \n\nМы благодарны Вам за то, что совершили заказ в нашем магазине \"ImageCMS Shop\" \nВы указали следующие контактные данные: \n\nEmail адрес: %userEmail% \nНомер телефона: %userPhone% \nАдрес доставки: %userDeliver%  \n\nМенеджеры нашего магазина вскоре свяжутся с Вами и помогут с оформлением и оплатой товара.  \n\nТакже, Вы можете всегда посмотреть за статусом Вашего заказа, перейдя по ссылке:  %orderLink%.  \n\nСпасибо за ваш заказ, искренне Ваши, сотрудники ImageCMS Shop.  \n\nПри возникновении любых вопросов, обращайтесь за телефонами:  \n+7 (095) 222-33-22 +38 (098) 222-33-22', '');
INSERT INTO shop_settings (`name`, `value`, `locale`) VALUES ('ordersSendMessage', NULL, '');
INSERT INTO shop_settings (`name`, `value`, `locale`) VALUES ('ordersSenderEmail', NULL, '');
INSERT INTO shop_settings (`name`, `value`, `locale`) VALUES ('ordersSenderName', 'DemoShop ImageCms.net', '');
INSERT INTO shop_settings (`name`, `value`, `locale`) VALUES ('ordersMessageTheme', 'Данные для просмотра совершенной покупки', '');
INSERT INTO shop_settings (`name`, `value`, `locale`) VALUES ('2_LMI_SECRET_KEY', 'bank', '');
INSERT INTO shop_settings (`name`, `value`, `locale`) VALUES ('2_LMI_PAYEE_PURSE', 'bank', '');
INSERT INTO shop_settings (`name`, `value`, `locale`) VALUES ('1_LMI_SECRET_KEY', 'cur', '');
INSERT INTO shop_settings (`name`, `value`, `locale`) VALUES ('1_LMI_PAYEE_PURSE', 'cur', '');
INSERT INTO shop_settings (`name`, `value`, `locale`) VALUES ('2_OschadBankData', 'a:5:{s:8:\"receiver\";s:41:\"ТЗОВ \"Екзампл Магазин\" \";s:4:\"code\";s:9:\"123456789\";s:7:\"account\";s:12:\"123456789123\";s:3:\"mfo\";s:6:\"123456\";s:8:\"banknote\";s:7:\"грн.\";}', '');
INSERT INTO shop_settings (`name`, `value`, `locale`) VALUES ('3_SberBankData', 'a:8:{s:12:\"receiverName\";s:45:\"Наименование получателя\";s:8:\"bankName\";s:29:\"Банк получателя\";s:11:\"receiverInn\";s:10:\"1231231231\";s:7:\"account\";s:20:\"15412398123312341237\";s:3:\"BIK\";s:9:\"123123123\";s:11:\"cor_account\";s:20:\"12312312334012340123\";s:8:\"bankNote\";s:7:\"руб.\";s:9:\"bankNote2\";s:7:\"коп.\";}', '');
INSERT INTO shop_settings (`name`, `value`, `locale`) VALUES ('4_RobokassaData', 'a:3:{s:5:\"login\";s:5:\"login\";s:9:\"password1\";s:9:\"password1\";s:9:\"password2\";s:9:\"password2\";}', '');
INSERT INTO shop_settings (`name`, `value`, `locale`) VALUES ('notifyOrderStatusMessageFormat', NULL, '');
INSERT INTO shop_settings (`name`, `value`, `locale`) VALUES ('notifyOrderStatusMessageText', '', '');
INSERT INTO shop_settings (`name`, `value`, `locale`) VALUES ('notifyOrderStatusSenderEmail', NULL, '');
INSERT INTO shop_settings (`name`, `value`, `locale`) VALUES ('notifyOrderStatusSenderName', '', '');
INSERT INTO shop_settings (`name`, `value`, `locale`) VALUES ('notifyOrderStatusMessageTheme', '', '');
INSERT INTO shop_settings (`name`, `value`, `locale`) VALUES ('wishListsMessageFormat', 'text', '');
INSERT INTO shop_settings (`name`, `value`, `locale`) VALUES ('wishListsMessageText', '', '');
INSERT INTO shop_settings (`name`, `value`, `locale`) VALUES ('wishListsSenderEmail', 'noreply@example.com', '');
INSERT INTO shop_settings (`name`, `value`, `locale`) VALUES ('wishListsSenderName', '', '');
INSERT INTO shop_settings (`name`, `value`, `locale`) VALUES ('wishListsMessageTheme', '', '');
INSERT INTO shop_settings (`name`, `value`, `locale`) VALUES ('notificationsMessageFormat', 'text', '');
INSERT INTO shop_settings (`name`, `value`, `locale`) VALUES ('notificationsMessageText', '', '');
INSERT INTO shop_settings (`name`, `value`, `locale`) VALUES ('notificationsSenderEmail', 'noreply@example.com', '');
INSERT INTO shop_settings (`name`, `value`, `locale`) VALUES ('notificationsSenderName', '', '');
INSERT INTO shop_settings (`name`, `value`, `locale`) VALUES ('notificationsMessageTheme', '', '');
INSERT INTO shop_settings (`name`, `value`, `locale`) VALUES ('callbacksSendNotification', '0', '');
INSERT INTO shop_settings (`name`, `value`, `locale`) VALUES ('callbacksMessageFormat', 'text', '');
INSERT INTO shop_settings (`name`, `value`, `locale`) VALUES ('callbacksMessageText', '', '');
INSERT INTO shop_settings (`name`, `value`, `locale`) VALUES ('callbacksSendEmailTo', 'manager@example.com', '');
INSERT INTO shop_settings (`name`, `value`, `locale`) VALUES ('callbacksSenderEmail', 'noreply@example.com', '');
INSERT INTO shop_settings (`name`, `value`, `locale`) VALUES ('callbacksSenderName', '', '');
INSERT INTO shop_settings (`name`, `value`, `locale`) VALUES ('callbacksMessageTheme', '', '');
INSERT INTO shop_settings (`name`, `value`, `locale`) VALUES ('userInfoRegister', '1', '');
INSERT INTO shop_settings (`name`, `value`, `locale`) VALUES ('userInfoMessageFormat', 'text', '');
INSERT INTO shop_settings (`name`, `value`, `locale`) VALUES ('userInfoMessageText', '', '');
INSERT INTO shop_settings (`name`, `value`, `locale`) VALUES ('userInfoSenderEmail', 'noreply@example.com', '');
INSERT INTO shop_settings (`name`, `value`, `locale`) VALUES ('userInfoSenderName', '', '');
INSERT INTO shop_settings (`name`, `value`, `locale`) VALUES ('userInfoMessageTheme', '', '');
INSERT INTO shop_settings (`name`, `value`, `locale`) VALUES ('topSalesBlockFormulaCoef', '1', '');
INSERT INTO shop_settings (`name`, `value`, `locale`) VALUES ('pricePrecision', '0', '');
INSERT INTO shop_settings (`name`, `value`, `locale`) VALUES ('smallAddImageWidth', '90', '');
INSERT INTO shop_settings (`name`, `value`, `locale`) VALUES ('smallAddImageHeight', '90', '');
INSERT INTO shop_settings (`name`, `value`, `locale`) VALUES ('forgotPasswordMessageText', 'Здравствуйте!\n\nНа сайте %webSiteName% создан запрос на восстановление пароля для Вашего аккаунта.\n\nДля завершения процедуры восстановления пароля перейдите по ссылке %resetPasswordUri% \n\nВаш новый пароль для входа: %password%\n\nЕсли это письмо попало к Вам по ошибке просто проигнорируйте его.\n\n\nПри возникновении любых вопросов, обращайтесь по телефонам:  \n(012)  345-67-89 , (012)  345-67-89 \n---\n\nС уважением, \nсотрудники службы продаж %webSiteName%', '');
INSERT INTO shop_settings (`name`, `value`, `locale`) VALUES ('watermark_wm_hor_alignment', 'left', '');
INSERT INTO shop_settings (`name`, `value`, `locale`) VALUES ('watermark_wm_vrt_alignment', 'bottom', '');
INSERT INTO shop_settings (`name`, `value`, `locale`) VALUES ('watermark_watermark_type', 'text', '');
INSERT INTO shop_settings (`name`, `value`, `locale`) VALUES ('watermark_watermark_image', '', '');
INSERT INTO shop_settings (`name`, `value`, `locale`) VALUES ('watermark_watermark_image_opacity', '50', '');
INSERT INTO shop_settings (`name`, `value`, `locale`) VALUES ('watermark_watermark_padding', '', '');
INSERT INTO shop_settings (`name`, `value`, `locale`) VALUES ('watermark_watermark_text', 'demoshop.imagecms.net', '');
INSERT INTO shop_settings (`name`, `value`, `locale`) VALUES ('watermark_watermark_font_size', '', '');
INSERT INTO shop_settings (`name`, `value`, `locale`) VALUES ('watermark_watermark_color', '', '');
INSERT INTO shop_settings (`name`, `value`, `locale`) VALUES ('watermark_watermark_font_path', '', '');
INSERT INTO shop_settings (`name`, `value`, `locale`) VALUES ('watermark_active', '', '');
INSERT INTO shop_settings (`name`, `value`, `locale`) VALUES ('forgotPasswordMessageText', NULL, 'ru');
INSERT INTO shop_settings (`name`, `value`, `locale`) VALUES ('ordersMessageText', NULL, 'ru');
INSERT INTO shop_settings (`name`, `value`, `locale`) VALUES ('ordersSenderName', NULL, 'ru');
INSERT INTO shop_settings (`name`, `value`, `locale`) VALUES ('ordersMessageTheme', NULL, 'ru');
INSERT INTO shop_settings (`name`, `value`, `locale`) VALUES ('notifyOrderStatusMessageText', NULL, 'ru');
INSERT INTO shop_settings (`name`, `value`, `locale`) VALUES ('notifyOrderStatusSenderName', NULL, 'ru');
INSERT INTO shop_settings (`name`, `value`, `locale`) VALUES ('notifyOrderStatusMessageTheme', NULL, 'ru');
INSERT INTO shop_settings (`name`, `value`, `locale`) VALUES ('wishListsMessageText', '', 'ru');
INSERT INTO shop_settings (`name`, `value`, `locale`) VALUES ('wishListsSenderName', 'admin', 'ru');
INSERT INTO shop_settings (`name`, `value`, `locale`) VALUES ('wishListsMessageTheme', '', 'ru');
INSERT INTO shop_settings (`name`, `value`, `locale`) VALUES ('notificationsMessageText', '', 'ru');
INSERT INTO shop_settings (`name`, `value`, `locale`) VALUES ('notificationsSenderName', '', 'ru');
INSERT INTO shop_settings (`name`, `value`, `locale`) VALUES ('notificationsMessageTheme', '', 'ru');
INSERT INTO shop_settings (`name`, `value`, `locale`) VALUES ('callbacksMessageText', '', 'ru');
INSERT INTO shop_settings (`name`, `value`, `locale`) VALUES ('callbacksSenderName', '', 'ru');
INSERT INTO shop_settings (`name`, `value`, `locale`) VALUES ('callbacksMessageTheme', '', 'ru');
INSERT INTO shop_settings (`name`, `value`, `locale`) VALUES ('userInfoMessageText', '', 'ru');
INSERT INTO shop_settings (`name`, `value`, `locale`) VALUES ('userInfoSenderName', '', 'ru');
INSERT INTO shop_settings (`name`, `value`, `locale`) VALUES ('userInfoMessageTheme', '', 'ru');
INSERT INTO shop_settings (`name`, `value`, `locale`) VALUES ('adminMessageCallback', '<h1>Спасибо за заказ звонка</h1>\n<div>В ближайшее время наши менеджеры свяжутся с Вами</div>  ', '');
INSERT INTO shop_settings (`name`, `value`, `locale`) VALUES ('adminMessages', 'a:3:{s:8:\"incoming\";s:0:\"\";s:8:\"callback\";s:27:\"вфы вфыв фыв фы\";s:5:\"order\";s:0:\"\";}', 'ru');
INSERT INTO shop_settings (`name`, `value`, `locale`) VALUES ('selectedProductCats', 'a:1:{i:0;s:2:\"41\";}', '');
INSERT INTO shop_settings (`name`, `value`, `locale`) VALUES ('adminMessageIncoming', '<h1>Спасибо</h1>\n<div>В ближайшее время наши менеджеры свяжутся с Вами</div>  ', '');
INSERT INTO shop_settings (`name`, `value`, `locale`) VALUES ('adminMessageOrderPage', '<h1>Спасибо</h1>\n<div>В ближайшее время наши менеджеры свяжутся с Вами</div>  ', '');
INSERT INTO shop_settings (`name`, `value`, `locale`) VALUES ('mainModImageWidth', '640', '');
INSERT INTO shop_settings (`name`, `value`, `locale`) VALUES ('mainModImageHeight', '480', '');
INSERT INTO shop_settings (`name`, `value`, `locale`) VALUES ('smallModImageWidth', '90', '');
INSERT INTO shop_settings (`name`, `value`, `locale`) VALUES ('smallModImageHeight', '90', '');
INSERT INTO shop_settings (`name`, `value`, `locale`) VALUES ('order_method', NULL, '');
INSERT INTO shop_settings (`name`, `value`, `locale`) VALUES ('forgotPasswordMessageText', 'Здравствуйте!\n\nНа сайте %webSiteName% создан запрос на восстановление пароля для Вашего аккаунта.\n\nДля завершения процедуры восстановления пароля перейдите по ссылке %resetPasswordUri% \n\nВаш новый пароль для входа: %password%\n\nЕсли это письмо попало к Вам по ошибке просто проигнорируйте его.\n\n\nПри возникновении любых вопросов, обращайтесь по телефонам:  \n(012)  345-67-89 , (012)  345-67-89 \n---\n\nС уважением, \nсотрудники службы продаж %webSiteName%', 'en');
INSERT INTO shop_settings (`name`, `value`, `locale`) VALUES ('ordersMessageText', 'Здравствуйте, %userName%.  \n\nМы благодарны Вам за то, что совершили заказ в нашем магазине \"ImageCMS Shop\" \nВы указали следующие контактные данные: \n\nEmail адрес: %userEmail% \nНомер телефона: %userPhone% \nАдрес доставки: %userDeliver%  \n\nМенеджеры нашего магазина вскоре свяжутся с Вами и помогут с оформлением и оплатой товара.  \n\nТакже, Вы можете всегда посмотреть за статусом Вашего заказа, перейдя по ссылке:  %orderLink%.  \n\nСпасибо за ваш заказ, искренне Ваши, сотрудники ImageCMS Shop.  \n\nПри возникновении любых вопросов, обращайтесь за телефонами:  \n+7 (095) 222-33-22 +38 (098) 222-33-22', 'en');
INSERT INTO shop_settings (`name`, `value`, `locale`) VALUES ('ordersSenderName', 'DemoShop ImageCms.net', 'en');
INSERT INTO shop_settings (`name`, `value`, `locale`) VALUES ('ordersMessageTheme', 'Данные для просмотра совершенной покупки', 'en');
INSERT INTO shop_settings (`name`, `value`, `locale`) VALUES ('ordersManagerEmail', NULL, '');
INSERT INTO shop_settings (`name`, `value`, `locale`) VALUES ('ordersSendManagerMessage', NULL, '');
INSERT INTO shop_settings (`name`, `value`, `locale`) VALUES ('notifyOrderStatusMessageText', '', 'en');
INSERT INTO shop_settings (`name`, `value`, `locale`) VALUES ('notifyOrderStatusSenderName', '', 'en');
INSERT INTO shop_settings (`name`, `value`, `locale`) VALUES ('notifyOrderStatusMessageTheme', '', 'en');
INSERT INTO shop_settings (`name`, `value`, `locale`) VALUES ('wishListsMessageText', '', 'en');
INSERT INTO shop_settings (`name`, `value`, `locale`) VALUES ('wishListsSenderName', '', 'en');
INSERT INTO shop_settings (`name`, `value`, `locale`) VALUES ('wishListsMessageTheme', '', 'en');
INSERT INTO shop_settings (`name`, `value`, `locale`) VALUES ('notificationsMessageText', '', 'en');
INSERT INTO shop_settings (`name`, `value`, `locale`) VALUES ('notificationsSenderName', '', 'en');
INSERT INTO shop_settings (`name`, `value`, `locale`) VALUES ('notificationsMessageTheme', '', 'en');
INSERT INTO shop_settings (`name`, `value`, `locale`) VALUES ('callbacksMessageText', '', 'en');
INSERT INTO shop_settings (`name`, `value`, `locale`) VALUES ('callbacksSenderName', '', 'en');
INSERT INTO shop_settings (`name`, `value`, `locale`) VALUES ('callbacksMessageTheme', '', 'en');
INSERT INTO shop_settings (`name`, `value`, `locale`) VALUES ('userInfoMessageText', '', 'en');
INSERT INTO shop_settings (`name`, `value`, `locale`) VALUES ('userInfoSenderName', '', 'en');
INSERT INTO shop_settings (`name`, `value`, `locale`) VALUES ('userInfoMessageTheme', '', 'en');
INSERT INTO shop_settings (`name`, `value`, `locale`) VALUES ('MemcachedSettings', 'a:1:{s:11:\"MEMCACHE_ON\";b:0;}', '');
INSERT INTO shop_settings (`name`, `value`, `locale`) VALUES ('adminMessageMonkey', '', '');
INSERT INTO shop_settings (`name`, `value`, `locale`) VALUES ('adminMessageMonkeylist', '', '');
INSERT INTO shop_settings (`name`, `value`, `locale`) VALUES ('MobileVersionSettings', 'a:1:{s:15:\"MobileVersionON\";b:0;}', '');
INSERT INTO shop_settings (`name`, `value`, `locale`) VALUES ('4_LiqPayData', 'a:2:{s:11:\"merchant_id\";s:0:\"\";s:12:\"merchant_sig\";s:0:\"\";}', '');
INSERT INTO shop_settings (`name`, `value`, `locale`) VALUES ('facebook_int', 'a:3:{s:9:\"secretkey\";s:0:\"\";s:9:\"appnumber\";s:0:\"\";s:8:\"template\";s:8:\"newLevel\";}', '');
INSERT INTO shop_settings (`name`, `value`, `locale`) VALUES ('vk_int', 'a:3:{s:7:\"protkey\";s:0:\"\";s:9:\"appnumber\";s:0:\"\";s:8:\"template\";s:8:\"newLevel\";}', '');
INSERT INTO shop_settings (`name`, `value`, `locale`) VALUES ('xmlSiteMap', 'a:6:{s:18:\"main_page_priority\";b:0;s:13:\"cats_priority\";b:0;s:14:\"pages_priority\";b:0;s:20:\"main_page_changefreq\";b:0;s:21:\"categories_changefreq\";b:0;s:16:\"pages_changefreq\";b:0;}', '');
INSERT INTO shop_settings (`name`, `value`, `locale`) VALUES ('mobileTemplatePath', './templates/commerce_mobiles/shop/PIE', '');
INSERT INTO shop_settings (`name`, `value`, `locale`) VALUES ('ordersRecountGoods', '', '');
INSERT INTO shop_settings (`name`, `value`, `locale`) VALUES ('ordersuserInfoRegister', NULL, '');
INSERT INTO shop_settings (`name`, `value`, `locale`) VALUES ('notifyOrderStatusStatusEmail', NULL, '');
INSERT INTO shop_settings (`name`, `value`, `locale`) VALUES ('8_LMI_PAYEE_PURSE', '6456456456464', '');
INSERT INTO shop_settings (`name`, `value`, `locale`) VALUES ('8_LMI_SECRET_KEY', '456', '');
INSERT INTO shop_settings (`name`, `value`, `locale`) VALUES ('watermark_watermark_interest', '25', '');
INSERT INTO shop_settings (`name`, `value`, `locale`) VALUES ('9_OschadBankData', 'a:5:{s:8:\"receiver\";s:0:\"\";s:4:\"code\";s:10:\"1234567890\";s:7:\"account\";s:0:\"\";s:3:\"mfo\";s:0:\"\";s:8:\"banknote\";s:0:\"\";}', '');
INSERT INTO shop_settings (`name`, `value`, `locale`) VALUES ('ss', 'a:9:{s:4:\"yaru\";s:1:\"1\";s:5:\"vkcom\";s:1:\"1\";s:8:\"facebook\";s:1:\"1\";s:7:\"twitter\";s:1:\"1\";s:9:\"odnoclass\";s:1:\"1\";s:7:\"myworld\";s:1:\"1\";s:2:\"lj\";s:1:\"1\";s:4:\"type\";s:6:\"button\";s:8:\"vk_apiid\";s:0:\"\";}', '');
INSERT INTO shop_settings (`name`, `value`, `locale`) VALUES ('1CCatSettings', 'a:1:{s:8:\"filesize\";s:11:\"file_limit=\";}', '');
INSERT INTO shop_settings (`name`, `value`, `locale`) VALUES ('1CSettingsOS', 'N;', '');
INSERT INTO shop_settings (`name`, `value`, `locale`) VALUES ('usegifts', '0;', 'ru');
INSERT INTO shop_settings (`name`, `value`, `locale`) VALUES ('ordersCheckStocks', '', '');
INSERT INTO shop_settings (`name`, `value`, `locale`) VALUES ('imageSizesBlock', 'a:4:{s:5:\"small\";a:3:{s:4:\"name\";s:5:\"small\";s:6:\"height\";s:2:\"65\";s:5:\"width\";s:2:\"63\";}s:6:\"medium\";a:3:{s:4:\"name\";s:6:\"medium\";s:6:\"height\";s:3:\"260\";s:5:\"width\";s:3:\"149\";}s:4:\"main\";a:3:{s:4:\"name\";s:4:\"main\";s:6:\"height\";s:3:\"452\";s:5:\"width\";s:3:\"288\";}s:5:\"large\";a:3:{s:4:\"name\";s:5:\"large\";s:6:\"height\";s:3:\"600\";s:5:\"width\";s:3:\"384\";}}', '');
INSERT INTO shop_settings (`name`, `value`, `locale`) VALUES ('imagesMainSize', 'auto', '');
INSERT INTO shop_settings (`name`, `value`, `locale`) VALUES ('additionalImageWidth', '600', '');
INSERT INTO shop_settings (`name`, `value`, `locale`) VALUES ('additionalImageHeight', '384', '');
INSERT INTO shop_settings (`name`, `value`, `locale`) VALUES ('arrayFrontProductsPerPage', 'a:3:{i:0;s:2:\"12\";i:1;s:2:\"24\";i:2;s:2:\"48\";}', '');
INSERT INTO shop_settings (`name`, `value`, `locale`) VALUES ('thumbImageWidth', '62', '');
INSERT INTO shop_settings (`name`, `value`, `locale`) VALUES ('thumbImageHeight', '62', '');


#
# TABLE STRUCTURE FOR: shop_sorting
#

DROP TABLE IF EXISTS shop_sorting;

CREATE TABLE `shop_sorting` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `pos` int(11) DEFAULT NULL,
  `get` varchar(25) NOT NULL,
  `active` tinyint(1) DEFAULT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB AUTO_INCREMENT=11 DEFAULT CHARSET=utf8;

INSERT INTO shop_sorting (`id`, `pos`, `get`, `active`) VALUES (1, 4, 'rating', 1);
INSERT INTO shop_sorting (`id`, `pos`, `get`, `active`) VALUES (2, 1, 'price', 1);
INSERT INTO shop_sorting (`id`, `pos`, `get`, `active`) VALUES (3, 2, 'price_desc', 1);
INSERT INTO shop_sorting (`id`, `pos`, `get`, `active`) VALUES (4, 3, 'hit', 1);
INSERT INTO shop_sorting (`id`, `pos`, `get`, `active`) VALUES (5, 5, 'hot', 1);
INSERT INTO shop_sorting (`id`, `pos`, `get`, `active`) VALUES (6, 0, 'action', 1);
INSERT INTO shop_sorting (`id`, `pos`, `get`, `active`) VALUES (7, 8, 'name', 0);
INSERT INTO shop_sorting (`id`, `pos`, `get`, `active`) VALUES (8, 9, 'name_desc', 0);
INSERT INTO shop_sorting (`id`, `pos`, `get`, `active`) VALUES (9, 6, 'views', 0);
INSERT INTO shop_sorting (`id`, `pos`, `get`, `active`) VALUES (10, 7, 'topsales', 0);


#
# TABLE STRUCTURE FOR: shop_sorting_i18n
#

DROP TABLE IF EXISTS shop_sorting_i18n;

CREATE TABLE `shop_sorting_i18n` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `locale` varchar(11) NOT NULL DEFAULT 'ru',
  `name` varchar(50) NOT NULL,
  `name_front` varchar(50) DEFAULT NULL,
  `tooltip` varchar(256) NOT NULL,
  PRIMARY KEY (`id`,`locale`)
) ENGINE=InnoDB AUTO_INCREMENT=11 DEFAULT CHARSET=utf8;

INSERT INTO shop_sorting_i18n (`id`, `locale`, `name`, `name_front`, `tooltip`) VALUES (1, 'ru', 'По рейтингу', 'Рейтинг', '');
INSERT INTO shop_sorting_i18n (`id`, `locale`, `name`, `name_front`, `tooltip`) VALUES (2, 'ru', 'От дешевых к дорогим', 'От дешевых к дорогим', '');
INSERT INTO shop_sorting_i18n (`id`, `locale`, `name`, `name_front`, `tooltip`) VALUES (3, 'ru', 'От дорогих к дешевым', 'От дорогих к дешевым', '');
INSERT INTO shop_sorting_i18n (`id`, `locale`, `name`, `name_front`, `tooltip`) VALUES (4, 'ru', 'Популярные', 'Популярные', '');
INSERT INTO shop_sorting_i18n (`id`, `locale`, `name`, `name_front`, `tooltip`) VALUES (5, 'ru', 'Новинки', 'Новинки', '');
INSERT INTO shop_sorting_i18n (`id`, `locale`, `name`, `name_front`, `tooltip`) VALUES (6, 'ru', 'Акции', 'Акции', '');
INSERT INTO shop_sorting_i18n (`id`, `locale`, `name`, `name_front`, `tooltip`) VALUES (6, 'ua', '', '', '');
INSERT INTO shop_sorting_i18n (`id`, `locale`, `name`, `name_front`, `tooltip`) VALUES (7, 'ru', 'А-Я', 'Имени', '');
INSERT INTO shop_sorting_i18n (`id`, `locale`, `name`, `name_front`, `tooltip`) VALUES (8, 'ru', 'Я-А', 'Имени(Я-А)', '');
INSERT INTO shop_sorting_i18n (`id`, `locale`, `name`, `name_front`, `tooltip`) VALUES (9, 'ru', 'Просмотров', 'Количеству просмотров', '');
INSERT INTO shop_sorting_i18n (`id`, `locale`, `name`, `name_front`, `tooltip`) VALUES (10, 'ru', 'Топ продаж', 'Топ продаж', '');


#
# TABLE STRUCTURE FOR: shop_spy
#

DROP TABLE IF EXISTS shop_spy;

CREATE TABLE `shop_spy` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `user_id` int(11) DEFAULT NULL,
  `product_id` int(11) DEFAULT NULL,
  `price` int(11) DEFAULT NULL,
  `variant_id` int(11) DEFAULT NULL,
  `key` varchar(500) DEFAULT NULL,
  `email` varchar(50) DEFAULT NULL,
  `old_price` int(11) DEFAULT NULL,
  PRIMARY KEY (`id`)
) ENGINE=MyISAM AUTO_INCREMENT=5 DEFAULT CHARSET=utf8;

INSERT INTO shop_spy (`id`, `user_id`, `product_id`, `price`, `variant_id`, `key`, `email`, `old_price`) VALUES (3, 69, 102, 550, 113, 'IPrMlWydoeP9Cmex30upNOUsdTa4bIrg', NULL, 549);


#
# TABLE STRUCTURE FOR: shop_warehouse
#

DROP TABLE IF EXISTS shop_warehouse;

CREATE TABLE `shop_warehouse` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `name` varchar(255) NOT NULL,
  `address` varchar(255) DEFAULT NULL,
  `phone` varchar(255) DEFAULT NULL,
  `description` text,
  PRIMARY KEY (`id`),
  KEY `shop_warehouse_I_1` (`name`)
) ENGINE=MyISAM AUTO_INCREMENT=3 DEFAULT CHARSET=utf8;

INSERT INTO shop_warehouse (`id`, `name`, `address`, `phone`, `description`) VALUES (1, 'warehouse 1', 'address', 'phone', '');
INSERT INTO shop_warehouse (`id`, `name`, `address`, `phone`, `description`) VALUES (2, 'warehouse 2', 'address 2', '', '');


#
# TABLE STRUCTURE FOR: shop_warehouse_data
#

DROP TABLE IF EXISTS shop_warehouse_data;

CREATE TABLE `shop_warehouse_data` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `product_id` int(11) NOT NULL,
  `warehouse_id` int(11) NOT NULL,
  `count` int(11) DEFAULT NULL,
  PRIMARY KEY (`id`),
  KEY `shop_warehouse_data_FI_1` (`product_id`),
  KEY `shop_warehouse_data_FI_2` (`warehouse_id`)
) ENGINE=MyISAM AUTO_INCREMENT=38 DEFAULT CHARSET=utf8;

INSERT INTO shop_warehouse_data (`id`, `product_id`, `warehouse_id`, `count`) VALUES (37, 132, 2, 3);
INSERT INTO shop_warehouse_data (`id`, `product_id`, `warehouse_id`, `count`) VALUES (36, 132, 1, 2);
INSERT INTO shop_warehouse_data (`id`, `product_id`, `warehouse_id`, `count`) VALUES (35, 132, 1, 1);


#
# TABLE STRUCTURE FOR: support_comments
#

DROP TABLE IF EXISTS support_comments;

CREATE TABLE `support_comments` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `ticket_id` int(11) NOT NULL,
  `user_id` int(11) NOT NULL,
  `user_status` int(11) NOT NULL,
  `user_name` varchar(100) NOT NULL,
  `text` varchar(500) NOT NULL,
  `date` int(11) NOT NULL,
  UNIQUE KEY `id` (`id`)
) ENGINE=MyISAM AUTO_INCREMENT=2 DEFAULT CHARSET=utf8;

INSERT INTO support_comments (`id`, `ticket_id`, `user_id`, `user_status`, `user_name`, `text`, `date`) VALUES (1, 3, 1, 1, 'admin', 'Вы можете оплатить услуги безналичным переводом и наличными.', 1353064129);


#
# TABLE STRUCTURE FOR: support_departments
#

DROP TABLE IF EXISTS support_departments;

CREATE TABLE `support_departments` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `name` varchar(45) DEFAULT NULL,
  PRIMARY KEY (`id`)
) ENGINE=MyISAM AUTO_INCREMENT=4 DEFAULT CHARSET=utf8;

INSERT INTO support_departments (`id`, `name`) VALUES (1, 'Техническая поддержка');
INSERT INTO support_departments (`id`, `name`) VALUES (2, 'Финансовый отдел');
INSERT INTO support_departments (`id`, `name`) VALUES (3, 'Отдел консультаций');


#
# TABLE STRUCTURE FOR: support_tickets
#

DROP TABLE IF EXISTS support_tickets;

CREATE TABLE `support_tickets` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `user_id` int(11) DEFAULT NULL,
  `last_comment_author` varchar(50) NOT NULL,
  `text` text,
  `theme` varchar(100) NOT NULL,
  `department` int(11) NOT NULL,
  `status` smallint(1) DEFAULT NULL,
  `priority` varchar(15) DEFAULT NULL,
  `date` int(11) DEFAULT NULL,
  `updated` int(11) NOT NULL,
  PRIMARY KEY (`id`)
) ENGINE=MyISAM AUTO_INCREMENT=4 DEFAULT CHARSET=utf8;

INSERT INTO support_tickets (`id`, `user_id`, `last_comment_author`, `text`, `theme`, `department`, `status`, `priority`, `date`, `updated`) VALUES (1, 1, '', 'Не могу настроить на сайте переадресации. На локалке все работает. Помогите пожалуйста.', 'htaccess', 1, 0, '2', 1353061322, 1353061322);
INSERT INTO support_tickets (`id`, `user_id`, `last_comment_author`, `text`, `theme`, `department`, `status`, `priority`, `date`, `updated`) VALUES (2, 1, '', 'Какой тарифный план лучше подходит для моего сайта?', 'хостинг', 3, 0, '1', 1353061376, 1353061376);
INSERT INTO support_tickets (`id`, `user_id`, `last_comment_author`, `text`, `theme`, `department`, `status`, `priority`, `date`, `updated`) VALUES (3, 1, 'admin', 'Как я могу полатить хостинг?', 'Оплата услуг', 2, 0, '0', 1353061402, 1353064130);


#
# TABLE STRUCTURE FOR: tags
#

DROP TABLE IF EXISTS tags;

CREATE TABLE `tags` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `value` varchar(255) NOT NULL,
  PRIMARY KEY (`id`),
  KEY `value` (`value`)
) ENGINE=MyISAM DEFAULT CHARSET=utf8;

#
# TABLE STRUCTURE FOR: trash
#

DROP TABLE IF EXISTS trash;

CREATE TABLE `trash` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `trash_id` varchar(255) DEFAULT NULL,
  `trash_url` varchar(255) DEFAULT NULL,
  `trash_redirect_type` varchar(20) DEFAULT NULL,
  `trash_redirect` varchar(255) DEFAULT NULL,
  `trash_type` varchar(3) DEFAULT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8;

#
# TABLE STRUCTURE FOR: user_autologin
#

DROP TABLE IF EXISTS user_autologin;

CREATE TABLE `user_autologin` (
  `key_id` char(32) CHARACTER SET utf8 COLLATE utf8_bin NOT NULL,
  `user_id` mediumint(8) NOT NULL DEFAULT '0',
  `user_agent` varchar(150) CHARACTER SET utf8 COLLATE utf8_bin NOT NULL,
  `last_ip` varchar(40) CHARACTER SET utf8 COLLATE utf8_bin NOT NULL,
  `last_login` timestamp NOT NULL DEFAULT CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP,
  PRIMARY KEY (`key_id`,`user_id`),
  KEY `last_ip` (`last_ip`)
) ENGINE=MyISAM DEFAULT CHARSET=utf8;

#
# TABLE STRUCTURE FOR: user_temp
#

DROP TABLE IF EXISTS user_temp;

CREATE TABLE `user_temp` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `username` varchar(255) NOT NULL,
  `password` varchar(34) NOT NULL,
  `email` varchar(100) NOT NULL,
  `activation_key` varchar(50) NOT NULL,
  `last_ip` varchar(40) NOT NULL,
  `created` timestamp NOT NULL DEFAULT CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP,
  PRIMARY KEY (`id`)
) ENGINE=MyISAM DEFAULT CHARSET=utf8;

#
# TABLE STRUCTURE FOR: users
#

DROP TABLE IF EXISTS users;

CREATE TABLE `users` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `role_id` int(11) DEFAULT NULL,
  `username` varchar(50) DEFAULT NULL,
  `password` varchar(255) DEFAULT NULL,
  `email` varchar(100) DEFAULT NULL,
  `banned` tinyint(1) DEFAULT NULL,
  `ban_reason` varchar(255) DEFAULT NULL,
  `newpass` varchar(255) DEFAULT NULL,
  `newpass_key` varchar(255) DEFAULT NULL,
  `newpass_time` int(11) DEFAULT NULL,
  `last_ip` varchar(40) DEFAULT NULL,
  `last_login` int(11) DEFAULT NULL,
  `created` int(11) DEFAULT NULL,
  `modified` datetime DEFAULT NULL,
  `address` varchar(255) DEFAULT NULL,
  `cart_data` text,
  `wish_list_data` text,
  `key` varchar(255) NOT NULL,
  `amout` float(10,2) NOT NULL,
  `discount` varchar(255) DEFAULT NULL,
  `phone` varchar(32) DEFAULT NULL,
  PRIMARY KEY (`id`),
  KEY `users_I_1` (`key`)
) ENGINE=MyISAM AUTO_INCREMENT=49 DEFAULT CHARSET=utf8;

INSERT INTO users (`id`, `role_id`, `username`, `password`, `email`, `banned`, `ban_reason`, `newpass`, `newpass_key`, `newpass_time`, `last_ip`, `last_login`, `created`, `modified`, `address`, `cart_data`, `wish_list_data`, `key`, `amout`, `discount`, `phone`) VALUES (48, 1, 'admin', '$1$D9..QF5.$WvhO1OqX6pi6n54aa6jVL.', 'ad@min.com', NULL, NULL, NULL, NULL, NULL, '194.44.251.143', 2013, 1384939504, NULL, '', 'a:3:{s:17:\"SProducts_103_114\";a:6:{s:8:\"instance\";s:9:\"SProducts\";s:9:\"productId\";i:103;s:9:\"variantId\";i:114;s:8:\"quantity\";i:1;s:5:\"price\";d:34;s:11:\"variantName\";s:0:\"\";}s:17:\"SProducts_189_217\";a:6:{s:8:\"instance\";s:9:\"SProducts\";s:9:\"productId\";i:189;s:9:\"variantId\";i:217;s:8:\"quantity\";i:1;s:5:\"price\";d:12250;s:11:\"variantName\";s:0:\"\";}s:17:\"SProducts_191_219\";a:6:{s:8:\"instance\";s:9:\"SProducts\";s:9:\"productId\";i:191;s:9:\"variantId\";i:219;s:8:\"quantity\";i:1;s:5:\"price\";d:809;s:11:\"variantName\";s:0:\"\";}}', NULL, 'uqZ2v', '1025.00', NULL, '');


#
# TABLE STRUCTURE FOR: widget_i18n
#

DROP TABLE IF EXISTS widget_i18n;

CREATE TABLE `widget_i18n` (
  `id` int(11) NOT NULL,
  `locale` varchar(11) NOT NULL,
  `data` text NOT NULL,
  PRIMARY KEY (`id`,`locale`),
  KEY `locale` (`locale`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8;

INSERT INTO widget_i18n (`id`, `locale`, `data`) VALUES (16, 'ru', '<div class=\"container\">\n<ul class=\"items items-benefits\">\n<li>\n<div class=\"frame-icon-benefit\"><span class=\"helper\">&nbsp;</span> <span class=\"icon-benefits_1\">&nbsp;</span></div>\n<div class=\"frame-description-benefit f-s_0\"><span class=\"helper\">&nbsp;</span>\n<div>\n<div class=\"title\">Бесплатная</div>\n<p>доставка</p>\n</div>\n</div>\n</li>\n<li>\n<div class=\"frame-icon-benefit\"><span class=\"helper\">&nbsp;</span> <span class=\"icon-benefits_2\">&nbsp;</span></div>\n<div class=\"frame-description-benefit f-s_0\"><span class=\"helper\">&nbsp;</span>\n<div>\n<div class=\"title\">Гибкая система</div>\n<p>скидок</p>\n</div>\n</div>\n</li>\n<li>\n<div class=\"frame-icon-benefit\"><span class=\"helper\">&nbsp;</span> <span class=\"icon-benefits_3\">&nbsp;</span></div>\n<div class=\"frame-description-benefit f-s_0\"><span class=\"helper\">&nbsp;</span>\n<div>\n<div class=\"title\">Индивидуальный</div>\n<p>подход</p>\n</div>\n</div>\n</li>\n<li>\n<div class=\"frame-icon-benefit\"><span class=\"helper\">&nbsp;</span> <span class=\"icon-benefits_4\">&nbsp;</span></div>\n<div class=\"frame-description-benefit f-s_0\"><span class=\"helper\">&nbsp;</span>\n<div>\n<div class=\"title\">высокий уровень</div>\n<p>сервиса</p>\n</div>\n</div>\n</li>\n</ul>\n</div>');
INSERT INTO widget_i18n (`id`, `locale`, `data`) VALUES (17, 'ru', '<div class=\"wrap-frame-delivery-payment\">\n<div class=\"frame-delivery-payment\"><dl><dt class=\"title f-s_0\"><span class=\"icon_delivery\">&nbsp;</span><span class=\"text-el\">Доставка:</span></dt><dd class=\"frame-list-delivery\">\n<ul class=\"list-style-1\">\n<li><strong>Новая Почта:</strong> доставка бесплатно</li>\n<li><strong>Ин-Тайм:</strong> стоимость по тарифам перевозчика</li>\n</ul>\n</dd><dt class=\"title f-s_0\"><span class=\"icon_payment\">&nbsp;</span><span class=\"text-el\">Оплата:</span></dt><dd class=\"frame-list-payment\">\n<ul class=\"list-style-1\">\n<li><strong>Наличными:</strong> оплата при получении товара</li>\n<li><strong>На карточку:</strong> №885018658945</li>\n</ul>\n</dd></dl></div>\n</div>');
INSERT INTO widget_i18n (`id`, `locale`, `data`) VALUES (20, 'ru', '<div class=\"title-h1\">Интернет-магазин автошин &laquo;Beautiful cars&raquo;</div>\n<div class=\"title-h2\">Что предлагает наш магазин и почему выгодно купить шины именно здесь?</div>\n<p>Купить шины в Украине, а особенно в Киеве, не составляет большой проблемы. Множество магазинов предлагают купить резину на авто от уже зарекомендовавших себя и менее известных производителей. Цены, как и уровень качества продукции, разные. Сейчас &laquo;обуть&raquo; своего железного коня можно за любые деньги. Что же покупают чаще? Анализ продаж за несколько последних лет свидетельствует о том, что большинство водителей, которые ездят на новых автомобилях, предпочитают купить шины по более высокой цене. Много автомобилистов в Украине покупают автошины по одному принципу: мы не такие богатые, чтобы покупать дешевые вещи.</p>\n<p>Во-первых, покупка фирменных шин &mdash; это не затраты, а разумные вложения, которые со временем обязательно окупятся. Качественные автошины обеспечивают лучшее сцепление с дорогой и сокращают тормозной путь. Выигранных несколько сантиметров на трассе значат очень много, и речь идет не только о стоимости поврежденного бампера дорогого автомобиля, но и о бесценной человеческой жизни.</p>');


#
# TABLE STRUCTURE FOR: widgets
#

DROP TABLE IF EXISTS widgets;

CREATE TABLE `widgets` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `name` varchar(50) NOT NULL,
  `type` varchar(15) NOT NULL,
  `data` text NOT NULL,
  `method` varchar(50) NOT NULL,
  `settings` text NOT NULL,
  `description` varchar(300) NOT NULL,
  `roles` text NOT NULL,
  `created` int(11) NOT NULL,
  PRIMARY KEY (`id`),
  KEY `name` (`name`)
) ENGINE=MyISAM AUTO_INCREMENT=29 DEFAULT CHARSET=utf8;

INSERT INTO widgets (`id`, `name`, `type`, `data`, `method`, `settings`, `description`, `roles`, `created`) VALUES (3, 'latest_news', 'module', 'core', 'recent_news', 'a:4:{s:10:\"news_count\";s:1:\"3\";s:11:\"max_symdols\";s:3:\"150\";s:10:\"categories\";a:1:{i:0;s:2:\"69\";}s:7:\"display\";s:6:\"recent\";}', 'Последние новости', '', 1291632457);
INSERT INTO widgets (`id`, `name`, `type`, `data`, `method`, `settings`, `description`, `roles`, `created`) VALUES (4, 'recent_product_comments', 'module', 'comments', 'recent_product_comments', 'a:2:{s:14:\"comments_count\";s:1:\"5\";s:13:\"symbols_count\";s:1:\"0\";}', 'Последние комментарии продукта', '', 1308300371);
INSERT INTO widgets (`id`, `name`, `type`, `data`, `method`, `settings`, `description`, `roles`, `created`) VALUES (5, 'tags', 'module', 'tags', 'tags_cloud', '', 'Теги', '', 1312362714);
INSERT INTO widgets (`id`, `name`, `type`, `data`, `method`, `settings`, `description`, `roles`, `created`) VALUES (6, 'path', 'module', 'navigation', 'widget_navigation', '', 'Виджет навигации', '', 1328631622);
INSERT INTO widgets (`id`, `name`, `type`, `data`, `method`, `settings`, `description`, `roles`, `created`) VALUES (10, 'popular_products', 'module', 'shop', 'products', 'a:4:{s:12:\"productsType\";s:11:\"popular,hit\";s:5:\"title\";s:21:\"хиты продаж\";s:13:\"productsCount\";s:2:\"10\";s:7:\"subpath\";s:7:\"widgets\";}', 'Популярные товары', '', 1363606273);
INSERT INTO widgets (`id`, `name`, `type`, `data`, `method`, `settings`, `description`, `roles`, `created`) VALUES (11, 'new_products', 'module', 'shop', 'products', 'a:4:{s:12:\"productsType\";s:11:\"popular,hot\";s:5:\"title\";s:33:\"Новые поступления\";s:13:\"productsCount\";s:2:\"10\";s:7:\"subpath\";s:7:\"widgets\";}', 'Новые товары', '', 1363606324);
INSERT INTO widgets (`id`, `name`, `type`, `data`, `method`, `settings`, `description`, `roles`, `created`) VALUES (12, 'action_products', 'module', 'shop', 'products', 'a:4:{s:12:\"productsType\";s:14:\"popular,action\";s:5:\"title\";s:41:\"Акционные предложения\";s:13:\"productsCount\";s:2:\"10\";s:7:\"subpath\";s:7:\"widgets\";}', 'Акционные товары', '', 1363606361);
INSERT INTO widgets (`id`, `name`, `type`, `data`, `method`, `settings`, `description`, `roles`, `created`) VALUES (13, 'brands', 'module', 'shop', 'brands', 'a:4:{s:10:\"withImages\";b:1;s:11:\"brandsCount\";s:2:\"10\";s:7:\"subpath\";s:7:\"widgets\";s:5:\"title\";s:27:\"Торговые марки\";}', 'Бренды', '', 1363606422);
INSERT INTO widgets (`id`, `name`, `type`, `data`, `method`, `settings`, `description`, `roles`, `created`) VALUES (14, 'view_product', 'module', 'shop', 'view_product', 'a:4:{s:12:\"productsType\";b:0;s:5:\"title\";s:54:\"Недавно просмотренные товары\";s:13:\"productsCount\";s:2:\"10\";s:7:\"subpath\";s:7:\"widgets\";}', 'Недавно просмотренные товары', '', 1363606497);
INSERT INTO widgets (`id`, `name`, `type`, `data`, `method`, `settings`, `description`, `roles`, `created`) VALUES (15, 'similar', 'module', 'shop', 'similar_products', 'a:3:{s:5:\"title\";s:27:\"Похожие товары\";s:13:\"productsCount\";s:1:\"5\";s:7:\"subpath\";s:7:\"widgets\";}', 'Похожие товары', '', 1363606582);
INSERT INTO widgets (`id`, `name`, `type`, `data`, `method`, `settings`, `description`, `roles`, `created`) VALUES (28, 'popular_products_category', 'module', 'shop', 'products', 'a:4:{s:12:\"productsType\";s:17:\"date,hit,category\";s:5:\"title\";s:16:\"Popular products\";s:13:\"productsCount\";s:2:\"10\";s:7:\"subpath\";s:7:\"widgets\";}', 'Популярная категория товара', '', 1374575193);
INSERT INTO widgets (`id`, `name`, `type`, `data`, `method`, `settings`, `description`, `roles`, `created`) VALUES (27, 'ViewedProducts', 'module', 'shop', 'view_product', 'a:4:{s:12:\"productsType\";b:0;s:5:\"title\";s:14:\"ViewedProducts\";s:13:\"productsCount\";s:2:\"10\";s:7:\"subpath\";s:7:\"widgets\";}', 'Просмотренные товары', '', 1374575092);
INSERT INTO widgets (`id`, `name`, `type`, `data`, `method`, `settings`, `description`, `roles`, `created`) VALUES (16, 'benefits', 'html', '<div class=\"container\">\n<ul class=\"items items-benefits\">\n<li>\n<div class=\"frame-icon-benefit\"><span class=\"helper\">&nbsp;</span> <span class=\"icon-benefits_1\">&nbsp;</span></div>\n<div class=\"frame-description-benefit f-s_0\"><span class=\"helper\">&nbsp;</span>\n<div>\n<div class=\"title\">Бесплатная</div>\n<p>доставка</p>\n</div>\n</div>\n</li>\n<li>\n<div class=\"frame-icon-benefit\"><span class=\"helper\">&nbsp;</span> <span class=\"icon-benefits_2\">&nbsp;</span></div>\n<div class=\"frame-description-benefit f-s_0\"><span class=\"helper\">&nbsp;</span>\n<div>\n<div class=\"title\">Гибкая система</div>\n<p>скидок</p>\n</div>\n</div>\n</li>\n<li>\n<div class=\"frame-icon-benefit\"><span class=\"helper\">&nbsp;</span> <span class=\"icon-benefits_3\">&nbsp;</span></div>\n<div class=\"frame-description-benefit f-s_0\"><span class=\"helper\">&nbsp;</span>\n<div>\n<div class=\"title\">Индивидуальный</div>\n<p>подход</p>\n</div>\n</div>\n</li>\n<li>\n<div class=\"frame-icon-benefit\"><span class=\"helper\">&nbsp;</span> <span class=\"icon-benefits_4\">&nbsp;</span></div>\n<div class=\"frame-description-benefit f-s_0\"><span class=\"helper\">&nbsp;</span>\n<div>\n<div class=\"title\">высокий уровень</div>\n<p>сервиса</p>\n</div>\n</div>\n</li>\n</ul>\n</div>', '', '', 'Преимущества', '', 1371214822);
INSERT INTO widgets (`id`, `name`, `type`, `data`, `method`, `settings`, `description`, `roles`, `created`) VALUES (17, 'payments_delivery_methods_info', 'html', '<div class=\"frame-delivery-payment\"><dl><dt class=\"title f-s_0\"><span class=\"icon_delivery\">&nbsp;</span><span class=\"text-el\">Доставка</span></dt><dd class=\"frame-list-delivery\">\n<ul class=\"list-style-1\">\n<li>Новая Почта</li>\n<li>Другие транспортные службы</li>\n<li>Курьером по Киеву</li>\n<li>Самовывоз</li>\n</ul>\n</dd><dt class=\"title f-s_0\"><span class=\"icon_payment\">&nbsp;</span><span class=\"text-el\">Оплата</span></dt><dd class=\"frame-list-payment\">\n<ul class=\"list-style-1\">\n<li>Наличными при получении</li>\n<li>Безналичный перевод</li>\n<li>Приват 24</li>\n<li>WebMoney</li>\n</ul>\n</dd></dl></div>\n<div class=\"frame-phone-product\">\n<div class=\"title f-s_0\"><span class=\"icon_phone_product\">&nbsp;</span><span class=\"text-el\">Заказы по телефонах</span></div>\n<ul class=\"list-style-1\">\n<li>(097) <span class=\"d_n\">&minus;</span>567-43-21</li>\n<li>(097) <span class=\"d_n\">&minus;</span>567-43-22</li>\n</ul>\n</div>', '', '', 'Информация о способах доставки', '', 1371821417);
INSERT INTO widgets (`id`, `name`, `type`, `data`, `method`, `settings`, `description`, `roles`, `created`) VALUES (20, 'start_page_seo_text', 'html', '', '', '', '', '', 1378821714);


